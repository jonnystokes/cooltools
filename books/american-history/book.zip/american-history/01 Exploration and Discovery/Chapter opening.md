**Part 1: The Land and Its First Peoples**

# Chapter 1: Exploration and Discovery

**Chapter 1 of 37 · Exploration and Discovery · 10 eras · about 110 minutes**

**Almost every place in this chapter was already somebody's home when the explorers arrived, and the people who lived there often showed them the way.**

In the South Dakota Cultural Heritage Center there is a lead plate six inches by eight. One side has Latin words stamped into it that name King Louis XV of France. On the other side somebody scratched a date, March 30, 1743, and the names of four Frenchmen. Two of them were brothers, the sons of a fur trader, and they had just crossed the northern Great Plains with two Mandan guides. They buried the plate beside the Missouri River. It stayed in the ground for 170 years, until 1913.

This chapter describes the explorers in order, from the footprints at White Sands to the four astronauts who flew around the Moon in April 2026. For the first eight eras, watch for two things. Watch who shows the way: Hopi guides to the Grand Canyon, a Crow map to South Pass, an Ojibwe guide to the source of the Mississippi, four Inuit men at the North Pole. And watch what the explorers do to the people they meet. Some traded with them and were fed by them. Others took captives, burned towns and killed. After 1950 the only places left were the deepest ocean and space, where nobody had ever lived.

**Three questions this chapter answers**

- How do we know people were living here at least 21,000 years ago?
- What did the explorers do to the people whose land they crossed?
- Which famous "firsts" are still in doubt?

**Five minutes?** Read "Four captains along the coast, 1497 to 1542" in The 1500s.

**Can skip:** "The first recorded climb of Pikes Peak, 1820", "Alaska, 1867 to 1885", "1898: islands in two oceans", "Mapping the sea floor". The chapter still makes sense without them.

## Before 1500

**Era 1 of 10 · Before 1500 · about 4 minutes**

The first people to explore this land came from Asia during the last ice age. At that time a strip of dry land joined Siberia to Alaska. Human footprints at White Sands, in New Mexico, show that people were here at least 21,000 years ago, and probably about 23,000 years ago. Over thousands of years their descendants spread across the whole continent, into its deserts, mountains, forests, coasts and plains.

Hundreds of Native nations lived here by 1500, speaking many different languages. Nobody knows how many people lived north of Mexico at that time. Estimates run from about 1 million to about 18 million.

### How old are the footprints at White Sands?

The footprints at White Sands National Park, in New Mexico, are at least 21,000 years old and probably about 23,000. Scientists dated seeds of a water plant found in the layers just above and just below the prints. Tests on the seeds gave ages of about 21,000 and about 23,000 years.

For a long time scientists had thought people first arrived only about 13,500 to 16,000 years ago. When the seed dates came out in 2021, some scientists questioned them. A water plant can take in old carbon from the rock around it, and that can make its seeds test older than they are.

**The second test.** In 2023 a team led by Jeff Pigati, a scientist who studies rocks and the earth at the US Geological Survey, tested two other things from the same layers. They dated pollen from pine trees and other trees that grow cones. They also measured how long grains of quartz sand had been buried out of the sunlight.

Tests on the pollen gave about 21,000 to 23,000 years, and tests on the quartz gave at least 21,500 years. Every method put the footprints at about 21,000 to 23,000 years old. The park's own web page on the footprints states that people have lived in North America "for at least 23,000 years."

### Trade routes and Pacific voyaging

Native people knew routes across the continent long before any European arrived. Traders carried copper from Lake Superior, shells from the Gulf of Mexico, turquoise from the Southwest and obsidian, a natural glass formed by volcanoes, from the West. Archaeologists, the scientists who dig up and study the things people left behind, have found each of these goods hundreds of miles from where it came from.

The people of Cahokia, a city on the Mississippi River near present-day St. Louis, controlled a hard stone called Mill Creek chert, which could be shaped into tools. Hoe blades made of it turn up more than 400 miles away.

Polynesian sailors, the people of the many islands of the central and southern Pacific, crossed thousands of miles of open ocean to reach the Hawaiian Islands. The archaeologist Patrick Kirch reviewed 150 years of study and put their first arrival and settlement between about the years 1000 and 1200. Older studies had put it between about the years 300 and 750. Scientists still argue about the exact century.

### Leif Erikson

> **Who:** A Norse sailor from Greenland, son of Erik the Red, who led one of the first European voyages to North America.
>
> **When and where:** About the year 1000, and a Norse camp dated to 1021. L'Anse aux Meadows, Newfoundland, Canada.

**A storm on the sun in the year 993 dates the Norse camp.**

Norse sailors from Greenland, the people often called Vikings, reached North America about 500 years before Columbus. Two sagas, old stories written down in Iceland, tell what happened: the *Saga of the Greenlanders* and the *Saga of Erik the Red*. They say that Leif Erikson, son of Erik the Red, reached a land he called Vinland.

The sagas also describe the people the Norse met there, whom the Norse called Skraelings. According to the sagas, the two groups traded and also fought, and the fights led the Norse to leave. The sagas give the people no other name, and no record shows which Native nation they belonged to.

**Finding the camp.** A local man, George Decker, led the Norwegian explorer Helge Ingstad to some old mounds near the village of L'Anse aux Meadows in 1960. People there called the place the "old Indian camp." Helge Ingstad and the archaeologist Anne Stine Ingstad dug there for seven seasons, from 1961 to 1968. They found a Norse camp.

**Dating it.** A storm on the sun in the year 993 left a mark in the rings of trees growing on Earth. In 2021 scientists found that mark in pieces of wood at the camp that had been cut with metal blades, and they counted the rings out to the bark. The Norse cut those trees down in 1021. That is 471 years before Columbus reached the Bahamas.

Estimates of how long the Norse stayed run from a few years to about twenty. Another account says the camp was only a place to repair boats. Native people had lived on the same spot long before the Norse came. Five earlier groups had lived there, the oldest about 6,000 years ago. A Native people that archaeologists call the Dorset lived there about 300 years before the Norse.

**Known:** Norse people cut trees at L'Anse aux Meadows in 1021.

**Not known:** which place in the sagas the camp was. One answer is Leif's own camp, and another is a second place the sagas call Hop. Nothing dug up at the site has settled it.

## The 1500s

**Era 2 of 10 · The 1500s · about 14 minutes**

This era starts a few years early, in 1492, with Christopher Columbus's first voyage across the Atlantic. In the century after it, European sailors mapped the Atlantic and Gulf coasts, and Spanish armies marched far inland. Every place they reached was already the home of a Native nation. Native guides showed several of them the way, including the way to the Grand Canyon. The explorers also took people captive, seized stored food and attacked towns whose people refused to let them in.

Spanish colonists built St. Augustine, in Florida, inside a Timucua town in 1565.

### Christopher Columbus

> **Who:** A sea captain from Genoa, in Italy, who sailed west for Spain looking for a sea route to Asia.
>
> **When and where:** Four voyages from 1492 to 1504, to the Bahamas, the Caribbean islands and the coasts of Central and South America.

**A lookout on the *Pinta* saw land at about 2 in the morning.**

Christopher Columbus crossed the Atlantic four times, and he never set foot in what is now the United States. He sailed for the king and queen of Spain, and he believed that by sailing west he could reach Asia.

The lookout was Rodrigo de Triana, and the date was October 12, 1492. The land he saw was an island in the Bahamas. Its people, the Lucayan Taino, called it Guanahani. Columbus named it San Salvador. On that first voyage he took Taino people captive and carried them to Spain to show the king and queen.

**The tribute.** Columbus's soldiers made war on the Taino of Hispaniola, an island in the Caribbean, in 1494 and 1495. They fought until the Taino surrendered and agreed to pay a tribute, a payment that a conquered people are forced to hand over. Columbus set the rule.

In the Cibao, the part of the island with the gold mines, every Taino aged 14 or older had to bring in a hawk's bell, a small round bell, full of gold dust every six months. A priest named Bartolomé de las Casas wrote that the Spaniards cut off the hands of people who failed to pay. How often Spaniards did this is still argued over.

**Sold as slaves.** Columbus's men rounded up about 1,500 Taino in February 1495. They shipped about 500 of the strongest to Spain to be sold as slaves, and about 200 of them died on the voyage. Some accounts give 1,600 and 550. Within a few decades most of the Taino on Hispaniola were dead. Spanish soldiers made war on them, Spanish colonists forced them to work, and many died of disease. Counts of how many Taino lived there when Columbus arrived do not agree.

**Arrested.** The Spanish rulers sent an investigator, Francisco de Bobadilla, to Hispaniola in 1500. Bobadilla arrested Columbus and sent him back to Spain in chains. Bobadilla took statements from 23 witnesses and wrote them into a report. It records that Columbus punished a man who stole corn by having his ears and nose cut off. Then Columbus sold the man as a slave. The report was found again in 2005 in an archive, a building that stores old papers, in the Spanish city of Valladolid.

Columbus died in Valladolid on May 20, 1506. He never said in public that he had reached a new continent. What he believed in private is not settled. The name "America" came from another Italian sailor, Amerigo Vespucci. Vespucci wrote in 1503 that the lands across the Atlantic were a new continent. In 1507 a German mapmaker, Martin Waldseemuller, printed a world map that named the new land America.

### Four captains along the coast, 1497 to 1542

**Cabot, 1497.** John Cabot was an Italian, born Giovanni Caboto, who sailed for King Henry VII of England. His small ship, the *Matthew*, reached the coast of North America on June 24, 1497, with a crew of 18 to 20 men. Where he landed is disputed. Some accounts say Newfoundland and others say Cape Breton Island. Cabot went ashore only once, and he went no farther inland than a crossbow could shoot. King Henry gave him 10 pounds in English money, which was about two years' pay for a laborer.

**Ponce de León, 1513.** Juan Ponce de León sailed from Puerto Rico in March 1513 with three ships and 65 people. Among them were two free Africans, one of them a man named Juan Garrido, and two enslaved Native people. Ponce de León named the land La Florida. His was the first European expedition to Florida that anyone wrote down. A map made in 1502, called the Cantino map, already shows a shape like Florida, so Spanish slave raiders may have reached it first without leaving a record.

On the Gulf coast the Calusa people of southwest Florida refused to trade. Calusa warriors in canoes drove his ships away. In the fights that followed, his men captured eight Calusa, four men and four women.

Ponce de León came back in 1521 to build a colony on Calusa land. Calusa warriors fought the newcomers, and they wounded him. He died of the wound in Cuba that July. A popular story says that he was searching for a Fountain of Youth. No writing from his own time supports that story, and his contract with the Spanish king says nothing about a fountain.

**Verrazzano, 1524.** Giovanni da Verrazzano, an Italian sailing for the king of France, followed the Atlantic coast from Florida to what is now New Brunswick, in Canada, in 1524. In New York Bay he met about 30 canoes of Lenape people. In Narragansett Bay, Wampanoag and Narragansett people visited him. Verrazzano wrote to the French king about the voyage himself.

In his letter he described what about twenty of his men did on the peninsula now called Delmarva, south of New York Bay. They found an old woman, a young woman and some children hiding in the grass. He wrote: "We took the boy from the old woman to carry back to France." His men wanted to take the young woman too, he wrote, "but it was impossible to take her to the sea because of the loud cries she uttered."

So his men kidnapped the boy, and they left the young woman behind only because she screamed. The boy was about eight years old. The letter does not give his name or his people, and no known record tells what happened to him in France.

**Cartier, 1534.** The Frenchman Jacques Cartier explored the St. Lawrence River, in present-day Canada, from 1534 to 1542. In the winter of 1535 to 1536, Native people at the town of Stadacona gave his men a medicine made from evergreen trees, which saved them from scurvy. These people are now called the St. Lawrence Iroquoians. Scurvy is a disease caused by a severe lack of vitamin C, which comes from fresh food. It makes people weak, damages their gums and makes them bleed under the skin.

Cartier kidnapped Donnacona, an Iroquoian chief, in 1536, along with Donnacona's two sons and seven other people. The French never brought any of them home.

### Cabeza de Vaca and Estevanico

> **Who:** Two of the four survivors of a Spanish expedition who crossed the Southwest on foot. Álvar Núñez Cabeza de Vaca was a Spanish member of the expedition. Estevanico was an enslaved African man.
>
> **When and where:** 1528 to 1539. Florida, Texas, the Southwest and northern Mexico.

**Four men out of an army of 600 walked from Texas to Mexico City.**

Two of the four were Álvar Núñez Cabeza de Vaca and a man the Spanish called Estevanico, or Esteban. The four walked from the coast of Texas to Mexico City between 1534 and 1536.

The army belonged to Pánfilo de Narváez. It left Spain in June 1527 with about 600 men. In April 1528 Narváez landed near Tampa Bay, in Florida, with 300 men. They took over a town of the Apalachee people. Apalachee warriors attacked them there, at first 200 at once, shooting burning arrows into the houses the Spaniards had taken.

Many of the men also fell sick, and many were starving. By September only 242 of them were still alive. By then the survivors had built rafts to try to reach Mexico by sea. In November 1528 a storm washed about 80 of them onto Galveston Island, off the coast of Texas.

Estevanico was born about the year 1500 in Azemmour, in Morocco, in North Africa. Cabeza de Vaca described him as a Black man who spoke Arabic. In 1522 a Spanish nobleman, Andrés Dorantes, bought him as a slave. Dorantes and Estevanico were both on the Narváez expedition, and both lived through it.

On the Texas coast, Native people held the survivors as slaves for years. These people are now called Coahuiltecan. In 1534 the last four escaped: Cabeza de Vaca, Dorantes, Alonso del Castillo Maldonado and Estevanico. They walked west. Along the way they worked as healers among the nations they met. In July 1536 they reached Mexico City. Cabeza de Vaca published an account of the journey in 1542.

After the journey the Spanish viceroy in Mexico, Antonio de Mendoza, bought Estevanico from Dorantes or received him as a gift. A viceroy is the king's governor of a colony. Some evidence suggests that Mendoza freed him.

**The last journey.** Mendoza sent a friar named Marcos de Niza north in 1539 to look for seven rich cities that people called Cibola, with Estevanico as his guide. A friar is a member of a Catholic religious order. They left Culiacán, in northern Mexico, on March 7, 1539. Estevanico went ahead of the friar with Native guides from Sonora, in northern Mexico.

People of Hawikuh, a Zuni town, killed him when he got there. One Spanish account says he was "shot through with arrows." The Spanish accounts disagree about why. Francisco Vázquez de Coronado, who led a Spanish army to Hawikuh the next year, wrote in 1540 that the people of the town killed Estevanico because he had "killed and assaulted their women." Pedro de Castañeda, who marched with Coronado and wrote an account of the march in the 1560s, wrote that they killed him because he demanded turquoise and women.

Estevanico was not the first African to explore North America. Juan Garrido, a free African who sailed with Ponce de León to Florida in 1513, came before him.

### Armies inland: de Soto and Coronado, 1539 to 1542

Two Spanish armies marched deep into the continent between 1539 and 1542.

Hernando de Soto landed in Florida in May 1539 with 620 men and 220 horses. For three years he marched through the Southeast, and his soldiers took the stored food of the towns they passed through. From October 1539 to March 1540 his army lived in Anhaica, the capital of the Apalachee people, where Tallahassee stands today. There his men ate the Apalachee's stored food.

**Hostages.** De Soto seized dozens of men, women and children to carry his army's supplies. To get his army through, he took local leaders hostage, holding them prisoner so that their people would let the army pass safely. One was the leader of the Coosa people, whom de Soto held until the army had passed the Coosa towns. At a town called Hymahi, de Soto's men took all the food. A National Park Service history states that de Soto burned at least one person from the town to death. He did it while questioning people about a town farther on, called Cofitachequi.

**Mabila.** De Soto's army reached Mabila on October 18, 1540. The town was most likely in the southern part of present-day Alabama, and it was surrounded by a palisade, a wall of tall upright logs. Its leader was a man the Spanish called Tascalusa. A Spanish officer, Baltasar de Gallegos, decided that a leading man of Mabila had not shown him respect. Rodrigo Ranjel, de Soto's secretary, wrote that Gallegos cut off the man's arm "with a slash."

Then a battle began. De Soto's men fought for about nine hours and set the town on fire with people still inside. One of the expedition's own record keepers wrote: "We killed them all either with fire or the sword." The counts of the dead do not agree. A National Park Service history gives about 2,000 people of Mabila killed and over 200 Spanish. Reports from the University of Alabama give thousands of people of Mabila killed, and about 20 Spanish killed and 250 wounded. The site of Mabila has never been found.

De Soto died of fever beside the Mississippi River on May 21, 1542. His men sank his body in the river. They did not want the nations they had fought to learn that he could die. The survivors reached Mexico in September 1543.

**Coronado.** Francisco Vázquez de Coronado left Compostela, in Mexico, in February 1540. He led about 400 European soldiers, 1,300 to 2,000 Native allies from Mexico and four friars. They were looking for cities of gold.

Close to starving, they reached the Zuni town of Hawikuh in July 1540 and demanded to be let in. The Zuni had drawn lines of sacred cornmeal on the ground and warned the Spaniards not to cross them. When the Spaniards crossed, the Zuni shot arrows. Coronado's men attacked the town, and the Zuni left it after a short fight.

Coronado sent out scouting parties from there. Pedro de Tovar's men forced their way into a Hopi town whose people had refused to let them in. Hopi guides then led García López de Cárdenas and his men to the South Rim of the Grand Canyon. They were the first Europeans to see it.

**The Tiguex war.** The army camped along the Rio Grande among the Tiguex pueblos in the winter of 1540 to 1541. A pueblo is a town of connected houses built of stone or dried mud. Coronado's men took over the pueblo of Coofor, near present-day Bernalillo, New Mexico, and forced its people out.

A National Park Service history states that the fighting began after "a Spanish soldier assaulted a Pueblo woman, wife to a Tiguex man." Pedro de Castañeda, who was on the march, wrote down what happened about twenty years later. A Spaniard told the woman's husband to hold his horse, went up into the house, and raped her or tried to rape her. Rape means forcing a person to have sex.

Castañeda would not name the man. A later witness, Juan de Contreras, named him in testimony as Juan de Villegas, a soldier on horseback. The husband and the town's leaders came to complain and pointed out the horse. The soldier denied it, and nobody punished him.

In the war that followed, Coronado's soldiers killed hundreds of Tiguex people and burned their villages. At a pueblo called Arenal, the defenders made the sign of peace. Two Spaniards, Pablo de Melgosa and Diego López, answered with the same sign. The defenders put down their weapons, and the Spaniards promised not to punish them.

**Arenal.** Spanish soldiers then took the captives to Cárdenas's tent. Coronado had ordered Cárdenas not to take any of them alive. Cárdenas had 200 stakes set up to burn the captives alive.

When the soldiers began tying them to the stakes and burning them, about a hundred men in the tent fought back. Spanish soldiers on foot attacked the tent, and horsemen chased down the men who ran. Castañeda wrote that not one of them was left alive, except a few who hid. Those few spread the news that the Spaniards did not keep their promises of peace. Coronado's men also made Tiguex women and children slaves.

**Quivira.** A Native guide the Spanish called "the Turk," probably a Wichita or Pawnee man, led the army out onto the Great Plains in the spring of 1541. He told them of a rich land called Quivira. At Quivira, in present-day central Kansas, Coronado found the grass houses of Wichita towns and no gold. Before he left, Coronado ordered the Turk garroted. That means he was strangled to death with a cord or an iron collar that was tightened around his neck. The army went back to Mexico in 1542.

Spanish officials later charged Coronado and Cárdenas with crimes against Native people on the march. Coronado's friends sat on the court in Mexico that heard his case, and they cleared him. Members of the Council of the Indies, the king's council in Spain for the American colonies, found Cárdenas guilty.

### St. Augustine, 1565

Pedro Menéndez de Avilés and about 800 colonists landed on the coast of Florida in September 1565. The colonists included 26 women and an unknown number of enslaved Africans. They settled at the town of a Timucua chief named Seloy. They used Seloy's council house, the building where the town's leaders met, as their first fort. That same month Menéndez's men destroyed Fort Caroline, a French settlement nearby in Timucua country. At Matanzas Inlet they killed more than a hundred Frenchmen who had surrendered.

The Timucua soon wanted the Spaniards gone from their town. Timucua warriors shot flaming arrows at the fort in 1566. Nine months after they arrived, the Spaniards moved their settlement across the bay to Anastasia Island.

**If you remember one thing:** Sailors mapped the coasts, and the two Spanish armies that marched inland took the stored food of the towns they passed and killed people who fought back and people who had surrendered.

- 1492: Columbus reaches the Bahamas. He never sees the mainland of what is now the United States.
- 1540: Hopi guides lead Cárdenas's men to the Grand Canyon. That winter Coronado's soldiers burn the Tiguex captives at Arenal.
- 1565: Spanish colonists build St. Augustine inside the Timucua town of Seloy.

**Next:** In 1609 a Frenchman, Samuel de Champlain, went to war beside his Wendat, Algonquin and Montagnais allies.

## The 1600s

**Era 3 of 10 · The 1600s · about 7 minutes**

European colonists built small settlements far apart from each other in the 1600s. The Spanish had held St. Augustine, in Florida, since 1565. English colonists built James Fort, at Jamestown in Virginia, in 1607, and the Spanish governor Pedro de Peralta founded Santa Fe, in New Mexico, in about 1610. French colonists settled on the St. Lawrence River, in present-day Canada. On Manhattan Island, the homeland of the Lenape people, Dutch colonists built New Amsterdam. The land between these settlements was the home of Native nations.

The explorers of this century traveled by water, in ships and in canoes. Native guides and hosts told several of them where the rivers went.

### Champlain and the lake, 1609

Samuel de Champlain, a Frenchman, explored the coast of New England as far south as Cape Cod in 1605 and 1606. In 1608 he founded Quebec, on the St. Lawrence River in present-day Canada. That first winter, 16 of his 25 men died of scurvy.

Champlain went south in June 1609 with two other Frenchmen and a party of Wendat, Algonquin and Montagnais warriors. The Wendat are also called the Huron. They took him to the lake now named for him, between present-day New York and Vermont. In late July, at Ticonderoga, they met a party of Haudenosaunee men. The Haudenosaunee are also called the Iroquois. In the fight that followed, according to the historian Marcel Trudel, Champlain killed two of the Haudenosaunee men.

### Henry Hudson

> **Who:** An English sea captain hired by the Dutch East India Company to look for a sea route to Asia.
>
> **When and where:** 1609 to 1611. The Hudson River in New York, then Hudson Bay in Canada.

**The ship's mate wrote down every killing on the river.**

Henry Hudson sailed the Dutch ship *Half Moon* up a river in what is now New York in September 1609. The Lenape called it Muhheakantuck, and the Mohicans called it Mahicannittuk. Today it is called the Hudson River. Hudson was not the first European in its harbor. Verrazzano had been there in 1524. The Lenape and Munsee people lived along the lower river, and the Mohicans lived along the upper river.

Hudson's mate, the officer just below the captain, was Robert Juet, and he kept a journal of the voyage. It records what happened on the river. Two canoes carrying 26 men attacked the ship's small boat on September 6. An arrow hit a sailor named John Colman in the throat and killed him. Two other sailors were hurt.

Three days later the crew seized two Native men who had come aboard. They dressed them in red coats to keep them on the ship. On the morning of September 15 the two men climbed out through a port, a small opening in the ship's side, and swam away. Once the ship was under sail, Juet wrote, "they called to us in scorn."

**The way back.** On the way back down the river, Hudson's crew killed about 10 to 12 Native men. Juet's journal records each of these killings, on October 1 and 2.

A man in a canoe climbed in through the cabin window on October 1. He took a pillow, two shirts and two belts for carrying bullets. The ship's mate shot him in the chest and killed him. Another man swam up and grabbed the side of the ship's small boat. The ship's cook cut off one of the man's hands with a sword, and the man drowned.

The next day, men in two canoes shot arrows at the ship. The crew fired their guns and killed two or three of them. About a hundred men on a point of land shot at the ship too. Juet fired a small cannon at them and killed two. He fired again at a canoe with nine or ten men in it and killed one, and the crew shot three or four more.

Then the ship anchored off the shore that Juet called "Manna-hata." Juet did not write down which nation the dead men belonged to.

**The mutiny.** Hudson sailed for England on his next voyage, in a ship called the *Discovery*. He searched for a northern sea passage in the great bay in Canada now named for him. The crew spent the winter in James Bay. In June 1611 most of the crew mutinied, which means they rose up against their captain. They put Hudson, his teenage son John and seven sick or loyal men into a small open boat and sailed away. No European saw any of them again.

A survivor, Abacuk Pricket, named Henry Greene and Robert Juet as the leaders. The men Pricket blamed were already dead and could not answer him, so his story cannot be checked. Only eight of the thirteen mutineers lived to reach England. English courts put some of them on trial, and none was punished.

### Marquette and Jolliet

> **Who:** Jacques Marquette, a French Jesuit priest, and Louis Jolliet, a fur trader born near Quebec. The Jesuits are a group of priests within the Catholic Church.
>
> **When and where:** May to August 1673. From St. Ignace, Michigan, down the Mississippi River to the mouth of the Arkansas River.

**They turned back 435 miles short of the Gulf.**

Jacques Marquette and Louis Jolliet paddled down the Mississippi River in 1673 far enough to learn that it flows to the Gulf of Mexico and not to the Pacific Ocean. Native people had told them about the river first. Illinois people had described it to Marquette and invited him to visit.

The two men left St. Ignace, in present-day Michigan, on May 17, 1673. They had two canoes and five paddlers of French and Native ancestry. On the river, Michigamea warriors almost attacked them. The town's elders stopped the attack and fed the travelers. Farther south the Quapaw people hosted them for two nights near the mouth of the Arkansas River.

They turned back on July 17, about 435 miles from the Gulf. They feared the Spanish. They had also been told that the nations farther south were well armed and would attack anyone who got in the way of their trade.

On the way home they took a shorter route up the Illinois River, which their Native hosts told them about. In August they reached the mission of St. Francis Xavier, a church post where priests worked to turn Native people to the Catholic faith, at Green Bay in present-day Wisconsin.

Near Montreal, Jolliet's canoe tipped over in the Lachine Rapids, and his notes were lost. Marquette's account became the main record of the journey. Marquette died of dysentery on May 18, 1675, in present-day Michigan. Dysentery is an infection of the gut that causes severe, bloody diarrhea.

### Robert de La Salle

> **Who:** A French fur trader and explorer who claimed the whole Mississippi River valley for the king of France.
>
> **When and where:** 1682 to 1687. The lower Mississippi River and the coast of Texas.

**One of his own men shot him from an ambush in Texas.**

Robert de La Salle was the first European known to follow the Mississippi River all the way down to the sea. In February 1682 his party came down the Illinois River to the Mississippi, built canoes there, and paddled down to the Gulf of Mexico. On the way, his men built a small fort near present-day Memphis, Tennessee.

**The claim.** At the mouth of the river, on April 9, 1682, La Salle claimed the whole Mississippi River basin for France. A river basin is all the land whose rain drains into one river. He named it Louisiana, after King Louis XIV. Many Native nations lived in that basin. La Salle left every one of them out of his claim. In 1803 French officials sold the claim that began that day to the United States.

**The lost colony.** La Salle sailed from France in July 1684 with four ships and 300 colonists to build a colony at the river's mouth. The ships sailed past the river's mouth and landed at Matagorda Bay, in Texas, on the land of the Karankawa people. Before they got there, Spanish sea raiders in the Caribbean had seized one ship with its load of supplies and tools.

In Matagorda Bay a second ship ran onto a sandbar and stuck there. The commander of the third, the escort ship, sailed it back to France. That left only *La Belle*, and it later ran aground in the bay. The colonists built their settlement on Garcitas Creek, near present-day Victoria, Texas.

One of La Salle's own men, Pierre Duhaut, killed him from an ambush on March 19, 1687, near present-day Navasota, Texas. Jean L'Archeveque had drawn La Salle into talking with him so that Duhaut could strike. Later a third member of the party shot Duhaut. In 1688 Karankawa-speaking people killed the 20 adults still at the colony and took five children captive. The wreck of *La Belle* was found in Matagorda Bay in 1995.

## 1700 to 1750

**Era 4 of 10 · 1700 to 1750 · about 4 minutes**

Men of the Russian navy reached the coast of Alaska in 1741, and four Frenchmen, two of them sons of a fur trader, crossed the northern Great Plains in 1742 and 1743 with Mandan guides. They may have been the first Europeans to do so. English colonists did little exploring beyond the Appalachian Mountains between 1700 and 1750. The journeys into country that no European had mapped came from outside the English colonies.

### Vitus Bering

> **Who:** A Danish-born officer in the Russian navy who led the Russian voyage that reached Alaska in 1741.
>
> **When and where:** 1728 and 1741. The Bering Strait and the coast of Alaska.

**In 1991 scientists dug up Bering's bones to learn how he died.**

Vitus Bering led the Russian voyage that reached Alaska in 1741. On his first voyage, in August 1728, he sailed north through the narrow strip of sea between Asia and North America. It is now called the Bering Strait.

Before the second voyage, Native people in Kamchatka, in eastern Siberia, killed several Russians under Bering's command. Bering sent a group of armed men north to find the killers, with orders not to use force if they could avoid it. The armed men killed several Koryak people in the settlement of Utkolotsk and made the rest slaves.

The Russians tortured Koryak people, hurting them on purpose to make them give up the killers. The naturalist on the voyage, Georg Steller, was horrified to see it. A naturalist is a scientist who studies plants and animals. The report of what Steller saw does not say how the Russians tortured them.

**Alaska.** Bering commanded the ship *St. Peter* in 1741. On July 16 his crew sighted Mount Saint Elias on the Alaska coast, and they landed briefly at or near Kayak Island. That coast was Native land. Steller described animals that European scientists had not recorded before, among them a bird now called Steller's jay and a sea animal now called Steller's sea cow.

Bering's second ship, the *St. Paul*, was under the command of Aleksei Chirikov. On July 15, 1741, Chirikov's crew sighted land in southeast Alaska, the homeland of the Tlingit people. Two days later he sent an officer, Abram Dementiev, and 10 armed men ashore in a boat to look for a safe place to anchor. After a week they had not come back. Chirikov sent another officer, Saveliev, and a few men in his second, smaller boat. They did not come back either.

**Fifteen men lost.** With no boats left, Chirikov could not search for them or land, and on July 27 he sailed west without them.

**Not known:** what happened to the 15 men. People living on that shore may have killed them, they may have drowned in the strong tides along that coast, or, as one study argues, they went to live among the Tlingit.

**Bering's death.** On the way home, scurvy spread through the crew of the *St. Peter*. The ship was wrecked on an island near Kamchatka, now called Bering Island. Bering died there on December 19, 1741. About 28 of his men also died. At the time, people blamed scurvy for all of these deaths. A team of Russian and Danish scientists dug up Bering's remains in 1991 and studied his teeth and bones. They concluded that his own death was more likely caused by heart failure.

### The lead plate: the La Verendrye brothers on the northern Plains, 1742 to 1743

Two French brothers and two companions buried a lead plate beside the Missouri River on March 30, 1743, at the fort of a nation the French called the Little Cherry People. The plate is six by eight inches. One side has words in Latin stamped into it that name King Louis XV, the brothers' father and the year 1741. On the other side someone scratched the date and the names of the men who placed it. The plate was found at Pierre, South Dakota, in 1913. It is kept in the South Dakota Cultural Heritage Center.

Their father, Pierre La Verendrye, was a French fur trader in what is now Canada. Two of his sons and two other Frenchmen left Fort La Reine, at present-day Portage la Prairie, Manitoba, on April 29, 1742. The son who kept the journal was known by the French title the Chevalier, which means knight. He was most likely Louis-Joseph La Verendrye. They reached the Mandan towns on the upper Missouri River on May 19 and waited there two months. On July 23 they set out west with two Mandan guides.

For months they traveled with Plains nations that the French called the Horse People, the Bow People and the Little Cherry People. Which modern nations these were is not agreed. The Bow People may have been Pawnee, and the Little Cherry People were probably Arikara.

Some of the nations they met were at war. The Horse People told the brothers that two years before, a nation the French called the Snake People had destroyed seventeen of the Horse People's villages. The Snake People had killed the men and the old women and taken the young women to sell. Which nation the Snake People were is not certain.

The brothers may have been the first Europeans to see the Rocky Mountains, probably in what is now Wyoming. Their journal is hard to follow, so nobody knows their route for certain. It lay in French archives until it was found in 1851.

## 1750 to 1800

**Era 5 of 10 · 1750 to 1800 · about 8 minutes**

American and British diplomats signed a peace treaty in Paris on September 3, 1783. Diplomats are officials who speak for their countries, and a treaty is a written agreement between them. In the treaty the diplomats agreed that the western border of the new United States would be the Mississippi River. Native nations lived on the land between the Appalachian Mountains and that river. The diplomats did not invite them to the talks.

Before and after that treaty, colonists from Virginia and North Carolina pushed through the Appalachians into Kentucky, which the Shawnee used as a hunting ground. In the Pacific, three voyages reached places no European was known to have reached before. Spanish scouts saw San Francisco Bay in 1769. The British navy captain James Cook reached the Hawaiian Islands in 1778. In 1792 an American fur trader, Robert Gray, sailed into the mouth of the Columbia River.

### Daniel Boone

> **Who:** A hunter who marked Boone's Trace, later called the Wilderness Road, through the Cumberland Gap into Kentucky.
>
> **When and where:** 1767 to 1778. The Appalachian Mountains and Kentucky.

**The Shawnee took his skins and told him never to come back.**

Daniel Boone marked the road that colonists used to cross the Appalachian Mountains into Kentucky. He and his brother Squire first crossed into Kentucky in 1767. In May 1769 Boone set out with five other men on a hunting and trapping trip that lasted two years. One of them, John Findley, had told him about the Cumberland Gap, a low pass through the Appalachians. Native nations had used the gap long before any colonist, and in 1750 a Virginia doctor named Thomas Walker had told colonists about it.

Kentucky was the hunting ground of the Shawnee. The Cherokee and the Haudenosaunee also claimed it. In a treaty signed at Fort Stanwix in 1768, Haudenosaunee leaders gave up their claim to Kentucky to the British. The Shawnee did not sign that treaty. In 1769 Native men chased away Joseph Martin and the men at the fort he had built near the gap for people who claimed land there.

A Shawnee party caught Boone and his brother-in-law, John Stewart, on December 22, 1769. The Shawnee took all their skins and told them to leave and never come back.

**The attack of 1773.** Boone led his family and about 50 other people toward Kentucky in 1773 to settle there. On October 9 a small group left the main party to get supplies. It included Boone's oldest son, James, several white men and two enslaved Black men named Charles and Adam. A band of Delaware, Shawnee and Cherokee men attacked them. The historian John Mack Faragher writes that the band had decided "to send a message of their opposition to settlement."

The attackers shot James Boone, who was 16 or 17, and Henry Russell through the hips so they could not run. The historians Michael Lofaro and Nancy O'Malley describe what the attackers did next. They tortured the two young men, slashing them with knives and tearing out their fingernails and toenails. Then they killed them. They captured Charles. Adam hid in a pile of driftwood and saw what happened. The families turned back.

Virginians fought the Shawnee in 1774 in a war called Dunmore's War. After the Virginians won a battle at Point Pleasant, Shawnee leaders gave up their claims to Kentucky. Then Richard Henderson, a judge from North Carolina, hired Boone to help start a colony in Kentucky, which Henderson called Transylvania.

**The sale.** Boone invited leaders of Cherokee towns to a meeting at Sycamore Shoals in March 1775, where Henderson bought the Cherokee claim to Kentucky. Three Cherokee leaders, Attakullakulla, Oconostota and Sewanooko, signed the deed, the paper that handed over the land. It is dated March 17. It covered about 20 million acres. Henderson paid in trade goods, which one estimate values at about 10,000 British pounds.

The sale broke the law. A British royal order of 1763 and the laws of Virginia and North Carolina all forbade private buyers to buy Native land. A Cherokee leader named Dragging Canoe refused to agree to the sale. He warned that Kentucky "is bloody ground, and will be dark and difficult to settle."

**The road.** Boone then led a work party that cut a trail through the Cumberland Gap into central Kentucky. It was later called the Wilderness Road. The work party included Sam, an enslaved Black man, and other enslaved workers. Near present-day Richmond, Kentucky, Native men attacked the camp and killed Sam and his owner. Boone built a settlement called Boonesborough on the Kentucky River.

**The girls in the canoe.** Three teenage girls were floating in a canoe on the Kentucky River outside Boonesborough on July 14, 1776. Two Cherokee and three Shawnee warriors, led by the Cherokee Hanging Maw, captured them. The girls were Boone's daughter Jemima and Elizabeth and Frances Callaway. Boone's men caught up two days later, as the warriors were building a fire for breakfast, and freed the girls. In 1778 Shawnee warriors captured Boone himself. He lived among the Shawnee for months before he escaped.

### Who saw San Francisco Bay first? The Pacific, 1769 to 1792

**California, 1769.** Scouts under a Spanish sergeant, José Francisco Ortega, were the first Europeans known to see San Francisco Bay. A Spanish official, José de Gálvez, had sent an expedition north from San Diego in 1769 to survey California and to claim it for Spain. Native nations already lived there. The commander was Gaspar de Portolá. His party of 74 men included soldiers, an engineer, two friars and Christian Native men from Baja California. They walked past Monterey Bay without recognizing it.

In early November 1769 Ortega led a group of scouts over Montara Mountain, south of present-day San Francisco. A huge bay blocked their way north. Portolá, their commander, was not with the scouting party.

Portolá and his officers agreed to turn back on November 11. Members of the expedition reported that most of their meetings with Native people along the way were peaceful, and that people gave the Spaniards directions and food. On November 30 about a dozen Rumsen people brought the starving soldiers pinole, which is flour made from ground seeds.

**Hawaii, 1778.** The British navy captain James Cook reached the Hawaiian Islands on January 18, 1778. He and his crews were the first Europeans known to see them. They landed at Waimea, on the island of Kauai, and on Niihau. While Cook's men were ashore collecting supplies, one of them, John Williamson, shot and killed a Hawaiian man. Cook's crews were also the first Europeans to bring some diseases to the islands.

Cook came back in late November 1778. At Kealakekua Bay, on the island of Hawaii, about 10,000 people and 1,000 canoes met the ships, and the high chief Kalaniopuu welcomed him.

**Cook's death.** Hawaiians took one of the ships' boats on February 13, 1779. The next day Cook went ashore to kidnap Kalaniopuu and hold him until the boat was returned. Crowds gathered. Cook fired a warning shot, then shot one Hawaiian man dead. In the fight that followed, Hawaiians killed Cook and four marines, the soldiers who served on his ships. Cook's men killed seventeen Hawaiians. The accounts of Cook's last moments contradict each other.

**The Columbia, 1792.** Robert Gray was a sea captain from Rhode Island. In 1787 a group of Boston merchants sent him and another captain, John Kendrick, to the Pacific Northwest. The two were to buy sea otter furs and sell them in China. In 1790 Gray finished the first voyage by an American ship around the world.

On his first trip, in August 1788, his men fought the Tillamook people at Tillamook Bay, in Oregon. On August 16 Marcus Lopez, Gray's Black cabin boy and cook from the Cape Verde Islands, saw that a Tillamook man had taken his cutlass, a short curved sword. Lopez chased the man. Armed Tillamook men surrounded Lopez and killed him. Gray named the bay Murderer's Harbor.

Gray attacked Native villages along the coast in 1792, both before and after he found the Columbia. In April 1792 he ordered his men to destroy Opitsaht, a Nuu-chah-nulth village of about 200 houses on Vancouver Island, in present-day Canada. The village was empty at the time. One of his officers, John Boit, called it "a fine village, the Work of Ages," and wrote that Gray "had let his passions go too far."

In May he ordered an attack on another Nuu-chah-nulth village, and his men killed seven people and took their sea otter furs.

**The river.** Gray's crew found a safe channel over the sandbars at the mouth of a large river, where Chinook and Clatsop people lived. It was the evening of May 11, 1792. His ship, the *Columbia Rediviva*, sailed in. Gray named the river the Columbia, after his ship. He was the first navigator known to enter it who was not Native.

Gray fired on a group of Chinook people at Grays Harbor, in present-day Washington State, later in 1792, and killed 20. Back in Clayoquot Sound, near Opitsaht, a war canoe came toward his ship at night, and Gray killed or wounded at least 25 of the men in it. In 2005 Gray's descendants formally apologized for the destruction of Opitsaht.

## 1800 to 1850

**Era 6 of 10 · 1800 to 1850 · about 27 minutes**

**The deal.** American diplomats in Paris, the officials who spoke for their country, agreed to pay France $15 million for the right to take Louisiana from the Native nations who lived on most of it. The date was April 30, 1803. American officials could now take that land by a treaty, a written agreement between nations, or by war, and no European government could claim it ahead of them.

Louisiana covered about 828,000 square miles, most of the Mississippi's river basin west of the river. French officials controlled only a small part of it. Americans call the deal the Louisiana Purchase, and with it the land the United States claimed nearly doubled.

Over the next fifty years Army officers, fur trappers and a Navy squadron, a group of warships, crossed and mapped lands where Native nations already lived. Native guides showed several of them the way.

Crow people drew a map that showed trappers the way over South Pass. Two men who had run away from Spanish missions, church settlements run by Catholic priests, led a party across the Mojave Desert. An Ojibwe guide led an American to the source of the Mississippi. Some of these explorers killed the people whose land they crossed.

### Meriwether Lewis and William Clark

> **Who:** Two Army officers sent by President Thomas Jefferson to cross the Louisiana Purchase to the Pacific Ocean.
>
> **When and where:** May 1804 to September 1806. From near St. Louis up the Missouri River, over the Rocky Mountains and down the Columbia River to the Pacific coast of Oregon.
>
> **Movie:** *The Far Horizons* (1955). It invents a romance between Sacagawea and Clark, and a rivalry between the captains.

**Every man but York came home to double pay and 320 acres.**

Meriwether Lewis and William Clark led an Army expedition from near St. Louis, through the new Louisiana Purchase and beyond it, to the Pacific Ocean and back. President Thomas Jefferson gave them written orders. They were to find "the most direct & practicable water communication across this continent for the purpose of commerce." Jefferson wanted a river route that traders could use to cross the continent. Members of Congress voted $2,324 for supplies.

Jefferson also ordered them to tell the Native nations they met that their land now belonged to the United States. They were to say that the president in Washington, whom they called "their great father," now ruled over them. Lewis and Clark carried silver peace medals with Jefferson's face on them. They carried an air rifle to show off American weapons.

**The doctrine of discovery.** American officials used the expedition's maps, medals and flags as legal steps to claim each nation's land. They relied on a rule in American law called the doctrine of discovery. Under it, a land that no European had known before belonged to the European government whose explorers found it first, and no other European government could claim it. No one asked the Native nations who already lived there. La Salle had made the same kind of claim for France in 1682. When American diplomats bought Louisiana, they bought France's claim.

**The journey.** Clark and about 30 men left Camp Dubois, in Illinois, near St. Louis, on May 14, 1804. Lewis joined them at St. Charles, Missouri. In all the party had as many as 45 members, among them York, a man Clark held as a slave. Sergeant Charles Floyd died on August 20, 1804, probably of appendicitis, an infection of a small part of the gut. He was the only member of the party to die on the journey.

Near present-day Fort Pierre, South Dakota, Lakota chiefs, among them Black Buffalo, stopped the boats on September 25, 1804, and demanded gifts before they would let them pass. Lakota warriors took hold of a boat and an oar. Lewis ordered his men to show their guns, and Clark drew his sword. Black Buffalo ordered his warriors back, and nobody was killed. In his journal Clark called the Lakota the "vilest miscreants," meaning the worst villains, and in the same line he used an insulting word for Native people.

The party spent the winter of 1804 to 1805 at Fort Mandan, beside the Mandan and Hidatsa towns in present-day North Dakota. There Lewis and Clark, the expedition's two captains, hired a French-Canadian trader, Toussaint Charbonneau. They also met Sacagawea, a young Shoshone woman he held as his wife.

In the spring they went on up the Missouri to the streams where it begins. They crossed the Continental Divide at Lemhi Pass. The Continental Divide is the line of high ground that separates rivers flowing east from rivers flowing west. They crossed the Bitterroot Mountains at Lolo Pass and then went down the Clearwater, Snake and Columbia rivers by canoe. They found no water route across the continent. What they found instead was a trail that Native people used.

They first saw the Pacific on November 7, 1805. On November 24 Clark wrote down every member's choice for a place to spend the winter, including the choices of York and of Sacagawea. Accounts differ about whether this counts as a vote. The party built Fort Clatsop near present-day Astoria, Oregon. Food ran short that winter, and they had too little money to buy enough food from the Native nations nearby.

On the way home the party split up. Lewis took three men: George Drouillard and the brothers Joseph and Reubin Field. On the night of July 26, 1806, the four camped with some Blackfeet men on the Two Medicine River in present-day Montana.

**The only killings.** At dawn the Blackfeet men took the Americans' guns and tried to drive off their horses. Reubin Field stabbed one of the Blackfeet men to death. Lewis shot another man in the belly. The National Park Service says two or three Blackfeet were killed. Lewis wrote down no names for them. He left a peace medal around the neck of a dead man "that they might be informed who we were." It was the only fight on the expedition in which anyone was killed.

The expedition reached St. Louis on September 23, 1806. The captains had met more than 70 Native nations and drawn about 140 maps. Every man in the party except York received double pay and 320 acres of land.

### Sacagawea

> **Who:** A Lemhi Shoshone woman who interpreted for Lewis and Clark while carrying her baby son.
>
> **When and where:** 1805 to 1806. From Fort Mandan in North Dakota to the Pacific and back.

**Her brother turned out to be the Shoshone leader with the horses.**

Sacagawea spoke for the expedition with her own Shoshone people. She was its interpreter, the person who put one language into another. She was born about 1788 near present-day Salmon, Idaho, among the Lemhi Shoshone. Most accounts say she was Shoshone. A Hidatsa account written in 2021, *Our Story of Eagle Woman*, states that she was Hidatsa by birth.

Hidatsa raiders captured her and several other children in 1800, when she was about 12. The raiders killed four Shoshone men, four women and several boys. She was held at a Hidatsa village in present-day North Dakota. When she was about 13, Toussaint Charbonneau, a French-Canadian trader, took her as his wife. She did not agree to it. Accounts say he either bought her and another Shoshone girl, Otter Woman, from the Hidatsa, or won Sacagawea gambling. Records of the expedition describe Charbonneau as her husband and her owner.

Her son, Jean Baptiste, was born at Fort Mandan on February 11, 1805. Lewis gave her crushed rattlesnake rattle to speed the birth. She carried her son on the whole journey.

The party met a band of Shoshone in August 1805. Its leader, Cameahwait, turned out to be her brother. Sacagawea interpreted, and the Shoshone traded horses to the party for the crossing of the mountains. She also met a woman who had been taken prisoner at the same time as she was.

She was mainly the expedition's interpreter, not its guide. On the way home she did show the way in country she knew. On July 13, 1806, she told Clark to cross into the valley of the Yellowstone River through the pass now called Bozeman Pass, in Montana. Clark wrote that she "has been of great service to me as a pilot through this Country."

In the journals the men called her "the wife of our interpreter" and "the Snake woman." Snake was their name for the Shoshone. They also called her by an insulting word for a Native woman.

**Her death.** A clerk at a fur post on the Missouri River, John Luttig, wrote that "the wife of Charbonneau" died of a fever on December 20, 1812, at about age 25. The post was in present-day South Dakota. The next year William Clark became the legal guardian of her son and her daughter, Lizette, which meant the law made him responsible for the children. That is the strongest record, and most accounts accept it.

**Known:** a clerk wrote down her death in December 1812, and Clark took legal charge of her children in 1813.

**Disputed:** Shoshone tradition holds that she lived until 1884 and died on the Wind River Reservation in Wyoming, land the US government had set aside for the Shoshone. The Hidatsa account also disputes the 1812 record.

### York

> **Who:** A Black man held as a slave by William Clark, who took him on the Lewis and Clark expedition.
>
> **When and where:** 1804 to about 1815. The journey to the Pacific, then Kentucky.

**He asked Clark for his freedom, and Clark had him whipped.**

York crossed the continent with Lewis and Clark as a slave, and he came home still a slave. He was born into slavery in Caroline County, Virginia. His parents, Old York and Rose, were enslaved by John Clark III. In 1799 William Clark inherited York under his father's will. Before the expedition York married a woman who was enslaved by a different owner, near Louisville, Kentucky.

On the journey York hunted with a gun. Enslaved men were usually not allowed to carry one. On November 24, 1805, Clark wrote down York's choice for the winter camp alongside everyone else's.

After the expedition every other man received double pay and 320 acres of land. York received nothing. He asked Clark for his freedom because of his services on the journey. He also asked to be hired out near his wife in Louisville, or to be sold to someone there. Clark refused, and he wanted York hired out to "a Severe Master."

In 1808 Clark wrote that York had "Such a notion about freedom and his emence Services." He meant that York believed his great services on the journey had earned him his freedom. Clark did not agree. In July 1809 Clark whipped York, giving him what Clark called "a Severe trouncing," and had him put in jail.

Clark rented York out to work for other people as a wagon driver in Louisville. The last record of him in that work is from 1815. In 1811 his wife's owner planned to move to Natchez, Mississippi, far to the south, and York probably never saw her again. The National Park Service states that York was freed sometime after 1815. No paper freeing him has been found. Nobody knows for certain when or how he died.

President Bill Clinton made York an honorary sergeant in the US Army in 2001.

### Zebulon Pike

> **Who:** A US Army lieutenant sent to explore the northern and southern edges of the Louisiana Purchase.
>
> **When and where:** 1805 to 1807. Minnesota, then Colorado, New Mexico and northern Mexico.

**Spanish soldiers arrested him and took his papers.**

Zebulon Pike led two Army expeditions to the edges of the Louisiana Purchase. His commander, General James Wilkinson, sent him out. Pike left St. Louis on August 9, 1805, to find where the Mississippi River begins. On September 21, 1805, at the mouth of the Minnesota River, he bought land from the Dakota people for a future Army fort. He named Cass Lake, in present-day Minnesota, as the river's source, but the true source is a lake farther up. An Ojibwe guide showed it to an American in 1832.

Wilkinson sent him west in 1806 to find where the Arkansas and Red rivers begin, near the Spanish lands of New Mexico and Texas. In November 1806 Pike's men tried to climb the tall peak in present-day Colorado that later took his name. They turned back in snow up to their waists. They had gone almost two days without food.

Pike's party crossed into Spanish land. No one knows whether he got lost or went there on purpose. On February 26, 1807, Spanish soldiers arrested Pike and some of his men. The soldiers took them to Santa Fe and then to Chihuahua, in Mexico. There the Spanish commander, Nemesio Salcedo, questioned Pike and took his papers. Spanish officials released Pike at the Louisiana border on July 1, 1807. Accounts still differ about whether Pike was an explorer or a spy for Wilkinson.

Pike was killed on April 27, 1813, in the War of 1812, during an American attack on the town of York, now Toronto, in Canada. By then he was a general. As British soldiers pulled back, they blew up their store of gunpowder, and the blast killed Pike and 37 other American soldiers.

### John Colter

> **Who:** A soldier of the Lewis and Clark expedition who stayed in the mountains to trap.
>
> **When and where:** 1806 to 1809. Montana and Wyoming.

**He ran five miles naked with the Blackfeet behind him.**

John Colter walked alone through the country that is now Yellowstone National Park in the winter of 1807 to 1808. He was the first person of European descent known to see it. He had been a member of the Lewis and Clark expedition. On August 13, 1806, at the Mandan towns, the captains let him leave early to guide two trappers back up the Missouri River.

Colter joined a fur party led by the trader Manuel Lisa in 1807. In October 1807 Lisa sent him out alone to find the Crow people and ask them to trade. That winter Colter walked more than 500 miles through the country that is now Yellowstone and Grand Teton national parks. He came back in March or April 1808. Few people believed his reports of hot springs, and they called the place "Colter's Hell."

Colter fought beside Flathead and Crow men against the Blackfeet in 1808, and he was wounded in the leg. Many retellings blame Lewis's fight of 1806 for the Blackfeet's anger at Americans, and that link is disputed.

**The run.** He and another trapper, John Potts, were paddling a canoe on the Jefferson River, in present-day Montana, in 1808 or 1809. Several hundred Blackfeet men ordered them ashore. Colter came ashore, and the Blackfeet took his weapons and stripped him naked. Potts refused to come ashore. Blackfeet men shot and wounded him. He shot one of them, and then they killed him with arrows.

The Blackfeet told Colter to run, and they chased him. He ran about five miles to the Madison River. He killed the one man who caught up with him, using the man's own spear. Then he hid in a beaver lodge and walked for eleven days to a trading fort. All of this comes from Colter's own telling, as other people retold it later.

Colter died of jaundice, an illness that turns the skin and eyes yellow. One record gives the date as May 7, 1812, and another gives November 22, 1813.

**By 1810:** Lewis and Clark were home with about 140 maps, Pike was back from Mexico, and few people believed Colter's reports of hot springs in the Yellowstone country.

### The first recorded climb of Pikes Peak, 1820

Three men from an Army expedition led by Major Stephen Long reached the top of the mountain now called Pikes Peak on July 14, 1820. One of them was Edwin James, a 22-year-old naturalist, a scientist who studies plants and animals. It is the first recorded climb to the top. The Ute people call the mountain Tava-kaavi. Their tradition says that Ute ancestors were the first to climb it. Long called the high plains a "Great American Desert."

### Trappers and the fur trade, 1822 to 1840

Two fur traders, William Ashley and Andrew Henry, put an advertisement in a St. Louis newspaper in 1822. They wanted one hundred "enterprising young men," meaning bold young men ready for hard work, to go up the Missouri River to its source and work there for one, two or three years. They paid $200 a year. The men who answered became known as Ashley's Hundred. Jedediah Smith, Jim Bridger and Hugh Glass were among the men who joined Ashley's company.

**The Arikara fight.** Ashley's boats reached the towns of the Arikara people on the Missouri River, in present-day South Dakota, in late May 1823, to buy horses. The Arikara were angry after a fight with men of another fur company, and they wanted a trading post of their own. On June 2, 1823, Arikara men attacked Ashley's party. Records give two counts of Ashley's men killed, 12 and 13.

In August an Army officer, Henry Leavenworth, led about 230 soldiers against the Arikara towns. About 750 Lakota and Yankton warriors and about 50 trappers went with him. His men fired cannon at the towns. Leavenworth and the Arikara then agreed to a peace, and the Arikara left their towns at night. Men of the Missouri Fur Company then burned one of the towns. No reliable count of the Arikara killed has survived.

**The rendezvous.** The trappers met every summer from 1825 to 1840 at a gathering they called the rendezvous, in the mountains of present-day Wyoming, Utah or Idaho. The word is French for a meeting. There the trappers sold their furs and bought supplies for the next year. Native people came too, and so did the Native wives and children of many trappers.

### Hugh Glass

> **Who:** A fur trapper who crawled and walked about 200 miles to safety after a grizzly bear attack.
>
> **When and where:** 1823. Northwestern South Dakota.
>
> **Movie:** *The Revenant* (2015), a film based on his story. An earlier film, *Man in the Wilderness* (1971), is based on it too.

**He let maggots eat the dead flesh in his wounds.**

Hugh Glass crawled and walked about 200 miles to safety after a grizzly bear tore the flesh from his body. The two men left to care for him had taken his gun and gone. In 1823 he joined Ashley's fur company, and he was shot in the leg in the Arikara attack of June 2. A letter he wrote to the parents of John Gardner, a trapper killed that day, still survives.

Late that summer, near the forks of the Grand River in present-day South Dakota, Glass surprised a mother grizzly with two cubs. The bear bit him and slashed him with her claws. Another trapper later said she had "torn the flesh from the lower part of the body, and from the lower limbs," and torn his neck badly. His leg was broken. The cuts on his back were so deep that his ribs showed through.

Andrew Henry, the leader of the party, asked for two men to stay with Glass until he died and then bury him. John Fitzgerald and a man written down as "Bridges" stayed. They dug a grave. Then they left, taking Glass's rifle and knife, and told the others he was dead. Whether "Bridges" was Jim Bridger is still argued. Bridger later denied it.

Glass set his own broken leg and wrapped himself in the bear's hide. He crawled and walked about 200 miles to Fort Kiowa on the Missouri River, and part of the way he floated on a raft down the Cheyenne River. The journey took six weeks.

He left the maggots in his wounds so that they would eat the dead flesh and keep the wounds from turning to gangrene. Gangrene is the rotting of dead flesh in a living body. Glass later found "Bridges" and forgave him. Fitzgerald had joined the Army, and Glass got his rifle back.

The story was first printed in 1825, in a Philadelphia magazine called *The Port Folio*. A writer named James Hall wrote it, and other accounts dispute parts of it. No diary by Glass tells the story. It comes from other people's later retellings. In early 1833 Arikara warriors killed Glass and two other trappers, Edward Rose and Hilain Menard, on the Yellowstone River.

### Jedediah Smith

> **Who:** A fur trapper from New York who led the first party of US citizens known to reach California over land.
>
> **When and where:** 1823 to 1831. The Rocky Mountains, California and Oregon.

**A grizzly tore off his scalp and one ear.**

Jedediah Smith led the first party of US citizens known to reach California over land. He answered Ashley's advertisement in 1822. In the autumn of 1823, in the Black Hills region, a grizzly bear broke his ribs and took his head in its mouth. Smith told another trapper, Jim Clyman, how to sew his scalp and ear back on, and Clyman did. Afterward Smith wore his hair long to hide the scar.

**The map.** Crow people drew a map in sand and on a buffalo hide in 1824, in the Wind River valley of present-day Wyoming, to show Smith's men the way west. With the map, Smith's men crossed South Pass, a crossing of the Rocky Mountains in present-day Wyoming. The Crow already used the pass. A trader named Robert Stuart had crossed it in 1812, but few Americans learned of his crossing. Smith's party made the pass known to Americans.

**California.** Smith led 15 men southwest toward California in August 1826. Mojave people near present-day Needles, California, sheltered them. Two men who had run away from the Spanish missions guided them west across the Mojave Desert. On November 27, 1826, they reached Mission San Gabriel. California then belonged to Mexico.

The Mexican governor, José María Echeandía, arrested Smith as a suspected spy and held him for about two weeks. In 1827 Smith's party became the first US citizens known to cross the Sierra Nevada mountains going east, and then the Great Basin, a huge dry region between the Sierra Nevada and the Rocky Mountains.

Smith came back in August 1827 with 18 men and two French-Canadian women. As they crossed the Colorado River, Mojave men attacked them. Trappers from Taos, in New Mexico, had fought the Mojave, and the Mojave were set on revenge. They killed ten of Smith's men, among them Silas Gobel, and took the two women captive. Smith's men shot and killed two Mojave men.

**The Umpqua.** In 1828 Smith led his men north from California along the Pacific coast, looking for the Columbia River and a way back to the Rocky Mountains. On July 11 an Umpqua man took an axe from their camp on the Umpqua River, in present-day Oregon. Smith and another man tied a cord around the Umpqua man's neck while the rest of the party held their guns ready.

Umpqua men attacked the camp on July 14, while Smith and two others were away. They killed 15 of Smith's men. One man, Arthur Black, escaped.

In 1831 Smith and his partners set out from St. Louis with a wagon train to trade in Santa Fe. On May 27 Smith left the wagon train on the Santa Fe Trail to look for water near the Cimarron River, in present-day Kansas. He did not come back. Weeks later his partners learned that Comanche men had killed him. His body was never found.

### Jim Bridger

> **Who:** A trapper and guide from Virginia who never learned to read or write.
>
> **When and where:** 1823 to 1881. Wyoming, Utah and Montana.

**He reached the Great Salt Lake in a buffalo-hide boat.**

Jim Bridger was one of the first two men who were not Native known to reach the Great Salt Lake. He was born in Richmond, Virginia, in 1804. His parents died when he was 13, and he never learned to read or write. In 1823, at 19, he joined Ashley's trappers.

His boat was a bull boat, a boat made of buffalo hide, and he floated it down the Bear River to the lake in the fall of 1824. A French-Canadian trader, Etienne Provost, reached the lake at about the same time. In October 1824 Shoshone men attacked Provost's party at the Jordan River and killed eight of his men. The Shoshone, the Ute and other nations already lived around the lake.

Bridger and his partner Louis Vasquez built Fort Bridger in 1843, a trading post on the Oregon Trail in present-day Wyoming. In 1850 Bridger found a crossing of the mountains now called Bridger Pass. He later worked as a scout for the Army. By 1875 he was blind, and he died on July 17, 1881. Whether he was the "Bridges" who left Hugh Glass in 1823 is still argued. Bridger denied it.

### The source of the Mississippi, 1832

An Ojibwe guide named Ozaawindib led Henry Rowe Schoolcraft to the true source of the Mississippi River in 1832. Schoolcraft was an Indian agent, a US official who dealt with Native nations, at Sault Ste. Marie, in Michigan. The source was a lake that the Ojibwe called Elk Lake. Schoolcraft renamed it Lake Itasca. He made up the name from pieces of the Latin words for "truth" and "head."

**By 1840:** The trappers had held their last rendezvous. Charles Wilkes's Navy crews had sailed in 1838 and were exploring the Pacific and the coast of Antarctica.

### Charles Wilkes

> **Who:** A US Navy lieutenant who led a large exploring voyage of six ships paid for by the US government.
>
> **When and where:** August 1838 to June 1842. The Pacific islands, Antarctica and the Pacific Northwest.

**His men burned villages in Fiji and brought home 60,000 specimens.**

Charles Wilkes commanded the United States Exploring Expedition, a Navy exploring voyage paid for by the US government. W. John Kress, a plant scientist at the Smithsonian Institution, calls it the first American exploring expedition to other parts of the world. Members of Congress approved it in May 1836. Wilkes was only a lieutenant, and he got the command in April 1838 after more senior officers turned it down.

He left Virginia on August 18, 1838, with six ships and nearly 350 men. They included naturalists, a mineralogist, who studies rocks, and a scholar of languages. One ship, the *Sea Gull*, went missing off South America in 1839.

**Antarctica.** Two officers on the ship *Peacock* sighted mountain peaks in the far south on January 16, 1840. The ships followed the coast. In February Wilkes wrote that they had "discovered the Antarctic Continent." His crews charted about 1,500 miles of that coast, which is now called Wilkes Land. French and British ships were exploring the same waters that year.

**Fiji.** Wilkes's men burned villages and killed Fijians in the Fiji Islands in 1840. On July 12 Wilkes had his men burn the villages of Solevu and Tye after people from Solevu took one of his boats. An officer, William Hudson, took a Fijian chief named Vendovi prisoner by first taking his brothers prisoner. Americans blamed Vendovi for killing American sailors in 1834.

Vendovi died in the Navy hospital in New York soon after the ships came home in June 1842. The expedition's surgeons cut off his head, and his skull became part of the first collections of the Smithsonian Institution. In December 2025 his remains were returned to his home district of Rewa, in Fiji, and buried in the chiefs' burial ground at Lomanikoro.

Off Malolo Island, later in July 1840, Lieutenant Joseph Underwood held the son of a village chief hostage while he bargained for food. The young man jumped from the boat, and the Americans fired over his head. Fighting began. Fijians killed Underwood and Wilkes's nephew, Midshipman Wilkes Henry. The Americans killed about ten Fijians that day. Accounts disagree over whether the escape or the shot started the fight.

The next day Wilkes landed about 70 men on Malolo. He ordered them to kill the men, to burn the villages and to "spare only the women and the children." His men burned the villages of Sualib and Arro and killed between 74 and 104 Fijians. In 1841 men from the *Peacock* fought about 700 islanders on Drummond's Island, in the Gilbert Islands, killed twelve and burned two villages.

**Home.** Wilkes's ships mapped Puget Sound, in present-day Washington State, in 1841, and his men mapped more than 800 miles of Oregon. The *Peacock* was wrecked on the sandbar at the mouth of the Columbia. The expedition came home to New York on June 10, 1842. It had sailed about 87,000 miles and lost two ships and 28 men.

It brought back more than 60,000 plant and bird specimens, which helped start the collections of the Smithsonian Institution in Washington. It also brought 254 live plants, which started what became the US Botanic Garden.

Back home, Navy officers tried Wilkes in a court-martial, a trial held by the military. They cleared him of losing the *Peacock* and of mistreating his officers. They found him guilty of illegally punishing sailors in his squadron.

His punishments had included flogging, which means beating a man's bare back with a whip. Navies of that time used a whip of nine knotted cords, called a cat-o'-nine-tails, which was made to tear the skin and cause great pain. One charge named flogging round the fleet, a sentence under which a sailor was whipped aboard each ship of the squadron in turn.

### John C. Frémont

> **Who:** An Army mapmaker, later known as "the Pathfinder," whose reports and maps guided thousands of travelers west.
>
> **When and where:** 1842 to 1849. The Oregon Trail, the Great Basin, the Sierra Nevada, California and Oregon.

**Kit Carson called what they did on the Sacramento River "a perfect butchery."**

John C. Frémont led four expeditions to map the West, and on the third one his men killed at least 120 Wintu people in California. In 1841 he married Jessie Benton, the daughter of Senator Thomas Hart Benton of Missouri. Benton got the government to pay for Frémont's expeditions. A mountain man, a trapper who lived in the western mountains, named Kit Carson guided him. Frémont and Jessie wrote the report of the first expedition together.

**The maps.** Frémont led 25 men up the Platte River to South Pass in 1842. In 1843 and 1844 he went on to the Columbia River with almost 40 men and a cannon. Then he turned south and, in winter, crossed the Sierra Nevada into California. He was one of the first Americans to see Lake Tahoe. He showed that no river drains the Great Basin to the sea.

Members of the Senate and of the House each ordered 10,000 copies of his report on this trip. In 1846 members of the Senate had seven maps from his work printed. Thousands of American travelers heading west used them as a guide.

**The Sacramento River, 1846.** Frémont set out again in 1845 with an armed party of about 60 men. Officials of the War Department secretly told him to act as a soldier if war with Mexico began.

Some settlers claimed on April 5, 1846, that Native people were about to attack them. Frémont's party attacked a camp of Wintu people on the Sacramento River, near present-day Redding, California. Most of the people in the camp were women and children, and they were trapped against the river. One of Frémont's men, Thomas Breckenridge, wrote that "the order was given to ask no quarter and to give none." That meant no one would be spared, even people who tried to surrender.

Frémont's men fired their rifles in volleys, then charged with swords and pistols. Men on horseback chased and killed people who ran. Riflemen shot people who were swimming in the river. The men who were there gave counts of the dead from 120 to 800 or more. Breckenridge counted 120 to 150, and Thomas Martin, another of Frémont's men, counted over 175. An eyewitness, William Isaac Tustin, said at least 600 to 700 were killed on land and 200 or more in the water.

Kit Carson, who took part, later called it "a perfect butchery." None of Frémont's men was killed or wounded. Nobody was ever charged.

After that, Frémont's men shot Native people on sight. Breckenridge said the men "had orders while in camp or on the move to shoot Indians on sight." On the night of May 9, 1846, Klamath men attacked Frémont's camp and killed two or three of his party.

Three days later Kit Carson led an attack on Dokdokwas, a Klamath village at the mouth of the Williamson River, in present-day Oregon, and killed at least 14 people. The people of Dokdokwas may have had nothing to do with the first attack. Nobody was charged for these killings either. In June 1846 Frémont joined a revolt by American settlers against Mexican rule in California, the start of his part in the war with Mexico.

**The San Juans.** Frémont tried to find a route for a railroad through the San Juan Mountains of Colorado in the winter of 1848 to 1849. By December 12, 1848, the party needed ninety minutes to move 300 yards, and the mules had begun to die. In the end ten of the men died. Some of the starving survivors partly ate at least one of the bodies. Ute warriors later killed two of the men, Benjamin Kern and "Old Bill" Williams, when they went back for the party's gear.

Members of the new Republican Party made Frémont their first candidate for president in 1856. He died in 1890.

**If you remember one thing:** The Army officers and trappers of these fifty years crossed and mapped the West with Native guides, and some of them killed the people whose land they crossed.

In 1803: American diplomats had just bought France's claim to Louisiana, and Lewis and Clark had not yet left St. Louis.

In 1850: South Pass, the Great Salt Lake, the source of the Mississippi, the Yellowstone country and the Great Basin were known to Americans, and thousands of travelers were heading west with Frémont's maps.

**Next:** Jim Beckwourth, a Black trapper born into slavery, lived for years with the Crow before he found his pass through the Sierra Nevada in 1850.

## 1850 to 1900

**Era 7 of 10 · 1850 to 1900 · about 13 minutes**

After the Civil War members of Congress paid for four survey teams, groups sent to measure and map the western lands in detail, and other Americans pushed into Alaska and the Arctic. Native nations lived on the land the surveyors mapped. One survey leader, an Army officer, had written orders to count them and to choose places for Army forts.

Secretary of State William Seward agreed in 1867 to buy Alaska from Russia, and in 1885 an Army officer crossed part of its interior.

The official in charge of the census, the government's count of everyone in the country, wrote in 1890 that there could "hardly be said to be a frontier line" left between settled and unsettled land. American explorers had already turned toward the North Pole. Two of their voyages ended with most of the men dead.

### Jim Beckwourth

> **Who:** A Black fur trapper, born into slavery, who lived with the Crow and found a low pass through the Sierra Nevada.
>
> **When and where:** 1824 to 1866. The Rocky Mountains, California and Colorado.

**Marysville owed him for the trail and never paid.**

Jim Beckwourth found the lowest pass through the Sierra Nevada mountains in California, and it is now named for him.

He was born into slavery in Frederick County, Virginia, in 1798 or 1800. His father, Jennings Beckwith, was a white planter who held Beckwourth's mother, a Black woman, as a slave. By law he owned her, and she could not refuse him. His father freed him in papers filed in court in 1824, 1825 and 1826.

Beckwourth joined Ashley's fur company in 1824. For eight or nine years he lived with a band of Crow people, who named him "Bull's Robe." He married the daughter of a chief and rose from warrior to chief. His own book says he became the Crow's highest war chief. Other accounts suggest his fur company planned his stay so that it could win the Crow people's trade.

Beckwourth found the pass in 1850. At 5,221 feet above sea level, it is the lowest crossing of the Sierra Nevada in California. In 1851 he improved an old Native path over it into a trail that ran down to the town of Marysville. It saved gold seekers and settlers about 150 miles and kept them off steep passes such as Donner Pass.

By Beckwourth's own account, the merchants of Marysville had promised to pay him for the trail. When he came to collect in 1851, two large fires had burned the town, and its leaders were unable to pay him. In 1996 Marysville named its largest park Beckwourth Riverfront Park, to recognize the debt the town still owed him.

Beckwourth told the story of his life to a writer, Thomas Bonner, in the winter of 1854 to 1855. The book came out in 1856. Bonner never paid Beckwourth his half of the money. How much of the book is true is disputed.

**Sand Creek.** Colonel John Chivington hired Beckwourth as a scout in 1864. Beckwourth and about a dozen other scouts guided Chivington's soldiers to a camp of Cheyenne and Arapaho people at Sand Creek, in Colorado. The commander of a nearby Army fort had told the Cheyenne they would be safe there, and the camp was flying an American flag.

The soldiers attacked the camp on November 29, 1864. Counts of the dead run from about 70 to about 230. National Park Service counts give about 230 killed, most of them women, children and old people, and another estimate gives 70 to 163 Cheyenne. Soldiers cut scalps and other parts from the bodies of the dead.

Beckwourth spoke out in anger against the attack, and he later testified about it. Because he had guided the soldiers there, the Cheyenne refused to trade with him.

He died in a Crow village in Montana in 1866. Jim Bridger and a newspaper editor, William Byers, said the Crow poisoned him. Modern accounts name severe high blood pressure as the more likely cause.

### The Great Surveys of the West, 1867 to 1879

**King.** Clarence King, a geologist, a scientist who studies rocks and the earth, began a survey in 1867 along the 40th parallel, from eastern California to Wyoming. A parallel is an east-west line on a map. In 1872 King's team found a field in Colorado where diamonds had supposedly been found, and showed that the diamond field was a fake.

**Hayden and Yellowstone.** Members of Congress gave Ferdinand Hayden $40,000 in 1871 to survey the Yellowstone country. His party of 32 included the photographer William Henry Jackson and the painter Thomas Moran. The railroad banker Jay Cooke arranged for Moran to go. Cooke wanted to make Yellowstone known to help the Northern Pacific Railroad.

Jackson took the first known photographs of Yellowstone's waterfalls. Jackson's photographs, Moran's paintings and the survey's work helped persuade members of Congress to make Yellowstone a public park. President Ulysses S. Grant signed the law on March 1, 1872.

A band of Mountain Shoshone called the Tukudika had lived in the Yellowstone country for thousands of years. In the fall of 1879 the park's superintendent, Philetus Norris, found a camp the Tukudika had recently left.

He asked the US Indian agent at Fort Washakie for help. The agent sent a party of Shoshone men, who moved the Tukudika out of their homeland to the Wind River Reservation, in Wyoming. A National Park Service history states that the Tukudika "were forcibly removed to reservations," which means they were made to go whether they wanted to or not.

**Wheeler.** Army Lieutenant George Wheeler mapped the land west of the 100th meridian from 1872 to 1879. A meridian is a north-south line on a map, and the 100th meridian runs through the Great Plains. Under his orders, each inch of his maps was to stand for eight miles of land.

He was also to "discover the numbers, habits, and disposition of Indians in the section" and to "select sites for future military installations." That meant counting the Native people, learning how they lived and whether they were friendly, and picking places for Army forts.

Members of Congress ended the Wheeler, King and Powell surveys in 1879 and moved their work into a new agency, the US Geological Survey. Clarence King was its first director.

### Alaska, 1867 to 1885

**Two cents an acre.** Secretary of State William Seward and a Russian diplomat, Eduard de Stoeckl, signed a treaty at 4 in the morning on March 30, 1867. Under it, Seward agreed to pay $7.2 million for Alaska, about 2 cents an acre, for 586,412 square miles, and de Stoeckl agreed for Russia to sell it. Most reactions in the United States were positive. Some opponents called it "Seward's Folly" or "Seward's Icebox."

Seward's own figures counted about 8,000 Native people under Russian rule and about 50,000 more living beyond it. Neither Seward nor the Russian officials asked any of them.

**Across Alaska on foot.** Army Lieutenant Henry Allen set out in the spring of 1885 to cross Alaska with two soldiers, Sergeant Cady Robertson and Private Fred Fickett, and $2,000. They went up the Copper River. At the Native village of Taral a prospector, John Bremner, joined them. A prospector is a person who searches for gold or other minerals. Local Native people showed them how to build and use boats made of animal skins. The men ate rotten meat full of worms.

They crossed the Alaska Range by a pass that Allen named Miles Pass and went down the Tanana River and up the Koyukuk, about 1,500 miles in all. Two of the men got scurvy, a disease caused by a severe lack of vitamin C, which comes from fresh food.

### John Wesley Powell

> **Who:** A Civil War officer who had lost an arm and who led the first recorded boat journey by white men through the whole Grand Canyon.
>
> **When and where:** May to August 1869. The Green and Colorado rivers in Wyoming, Utah and Arizona.
>
> **Movie:** *Ten Who Dared* (1960), a Disney film about the expedition.

**He ran the Grand Canyon with one arm and four wooden boats.**

John Wesley Powell led the first recorded boat trip by white men through the whole Grand Canyon, in 1869. At the Battle of Shiloh, in April 1862, he was giving the order to fire when a rifle bullet hit his right arm. He lost the arm below the elbow. The raw nerve endings hurt him for the rest of his life. He went back to the Army and fought at Vicksburg.

Powell and nine other men set out from Green River, in Wyoming Territory, on May 24, 1869, in four wooden boats. At a rapid they named Disaster Falls they wrecked and lost one boat, the *No Name*. They named other places along the way, among them Flaming Gorge and Glen Canyon. One man, Frank Goodman, left the trip in July.

**The three who left.** Three men, Oramel Howland, his brother Seneca Howland and William Dunn, left the river on August 28. They were afraid of the rapids ahead, and they climbed out of the canyon. They were never seen again.

Shivwits Paiute men later told Powell's interpreter that they had killed the three by mistake. The Shivwits said they had taken them for prospectors who had raped and killed a Shivwits woman. Rape means forcing a person to have sex. Other accounts say Mormon settlers from Toquerville, Utah, killed them instead. Mormons are members of the Church of Jesus Christ of Latter-day Saints.

**Not known:** which account is true.

Powell and five men reached the Mormon settlement of St. Thomas, Nevada, on August 30, 1869. They had traveled almost 930 miles in 98 days. They were the first white men recorded passing through the whole canyon. Paiute people and other Native nations had lived along it long before them.

Powell went down the river a second time in 1871 and 1872. From 1881 to 1894 he led the US Geological Survey.

### Toward the North Pole, 1879 to 1898

**The Jeannette.** Twenty of the 33 men on the *Jeannette* died on the voyage, among them its captain, Navy Lieutenant George De Long. In 1879 De Long sailed the ship north through the Bering Strait. James Gordon Bennett Jr., the owner of the *New York Herald* newspaper, paid for the voyage. De Long hoped to find an open sea around the North Pole.

Ice trapped the ship for nearly two years and crushed it on June 13, 1881. The men dragged their boats across the ice and then sailed for the Lena River in Siberia. One boat, under Lieutenant Charles Chipp, was lost with all eight men in it.

De Long and the men in his boat landed in the river's delta, the low, wet land where a river splits into many channels near the sea. They starved there. His last journal entry, on October 30, 1881, lists the dead and ends "Mr Collins dying." Thirteen men came home. The voyage proved that there is no open sea at the pole.

**Greely.** Only six of the 25 men Army Lieutenant Adolphus Greely took to the far north came home, and Greely ordered one of the others shot. In 1881 Greely took his men to Ellesmere Island, in Canada's far north. They were to record the weather as part of the First International Polar Year, when scientists from several countries studied the far north and far south at the same time.

Two of his men, Lieutenant James Lockwood and Sergeant David Brainard, set a new record for the farthest north anyone had reached. Two dog drivers from Greenland, Jens Edward and Thorlip Frederik Christiansen, went with them. Both were Inuit, the Native people of the far north.

Supply ships failed to reach the party in 1882 and again in 1883. The men spent their last winter at Cape Sabine with about 40 days of food. Private Charles B. Henry stole food again and again.

Greely wrote an order on June 6, 1884: "Private Henry will be shot to-day." The order warned that Henry was stronger than any two of the other men. Three men, David Brainard, Francis Long and Julius Fredericks, shot him at 2 in the afternoon. On Greely's order, two of their guns held bullets and one held a blank, a cartridge with no bullet in it.

When rescue ships arrived on June 22, 1884, seven men were still alive. One died soon after, so six of the 25 lived to go home. Apart from Henry, the dead died of hunger, cold and drowning. In August 1884 doctors examined the body of one dead officer, Lieutenant Frederick Kislingbury, and found flesh cut from the bones. The survivors said they knew nothing about anyone eating the dead.

**The six Inuit.** Robert Peary was a Navy officer who later led expeditions toward the pole. In 1894 he reached the Cape York meteorite in northern Greenland. A meteorite is a rock that falls to Earth from space. Inuit people had relied on it to make tools. Peary took it.

In 1896 Franz Boas, a scientist at the American Museum of Natural History in New York, asked Peary to bring an Inuk, one of the Inuit, to the museum. The next year Peary deceived six Inuit into sailing with him to New York. He promised they could go home within a year with tools, weapons and gifts, and he did not keep that promise. The six arrived in September 1897. Staff at the museum kept them in its basement, and 20,000 people paid to look at them.

All six had tuberculosis, a lung disease that spreads through the air, by November 1. Four died in a New York hospital in 1898: Qisuk on February 17, Atangana and Nuktaq that spring, and a girl, Aviaq, on May 24. Qisuk's son, Minik, born about 1890, survived.

**The fake burial.** The museum's scientific staff wanted to keep Qisuk's body for study. Boas had the staff hold a fake burial. They filled a coffin with stones, laid a stuffed shape covered with a cloth on top, and buried it so that Minik would believe his father had been buried. Boas later said the ceremony was meant to comfort the boy.

Museum staff sent Qisuk's body to the estate of the museum's building manager, William Wallace, where Wallace had a workshop for cleaning skeletons. There the flesh was stripped from Qisuk's bones. The records do not name who did that work. Museum staff later put the skeleton on display in the museum. Wallace adopted Minik.

Of the two who lived, a young man named Uisaakassak demanded to go home to Greenland. He sailed home on the ship *Windward* in July 1898. Minik stayed in the United States. About 1906 New York newspapers reported that his father's skeleton was on display, and Minik learned it from his classmates. He died in the flu epidemic of 1918. In 1993 a Canadian writer, Kenn Harper, got the remains of Qisuk and the three others returned to Greenland, where they were buried at Qaanaaq.

### 1898: islands in two oceans

Eight years after the census official wrote that the frontier line was gone, President William McKinley, members of Congress and American diplomats took control of islands in the Pacific Ocean and the Caribbean Sea. Among them were the Hawaiian Islands, which James Cook had reached in 1778. Members of Congress voted to annex the Republic of Hawaii, which means to take it over as part of the United States. McKinley signed their resolution on July 7, 1898. Hawaii's former ruler, Queen Liliʻuokalani, protested to Congress.

After a war between Spain and the United States, diplomats from the two countries signed a treaty in Paris on December 10, 1898. Under the treaty, Spanish officials gave up Cuba and handed Puerto Rico, Guam and the Philippines to the United States. American officials agreed to pay Spain $20 million for the Philippines.

**If you remember one thing:** Survey teams mapped the West on land where Native nations lived. In the Arctic most of the men on two American voyages died, mainly of hunger and cold, and four of the Inuit whom Peary brought to New York died there.

**One number:** six. Of the 25 men Greely took to Ellesmere Island in 1881, six came home. The *Jeannette* did a little better, 13 men out of 33.

**Next:** Matthew Henson, a Black sailor from Maryland, worked beside Robert Peary for more than twenty years and made seven Arctic voyages with him.

## 1900 to 1950

**Era 8 of 10 · 1900 to 1950 · about 10 minutes**

Many American explorers of the years 1900 to 1950 worked far from home. Some traveled by dog sled toward the North Pole. Pilots flew toward both poles and across the Atlantic Ocean. Teams from Yale University and from a New York museum dug in the mountains of Peru and the Gobi Desert of Mongolia.

Two of the explorers' claims are still argued over. One is whether Robert Peary's party reached the North Pole in 1909, and the other is whether Richard Byrd flew over it in 1926.

In some of the places these explorers went, local people led the way. Inuit men, women and children joined Peary's last expedition to the North Pole. The Inuit are the Native people of the far north, from Alaska to Greenland. Four Inuit men were in the small party that Peary said reached the pole, and a local man led Hiram Bingham up to Machu Picchu.

### Matthew Henson (with Robert Peary)

> **Who:** A Black sailor and explorer from Maryland who was Robert Peary's navigator and dog-sled driver on seven Arctic voyages.
>
> **When and where:** 1887 to 1909. Northern Greenland and the Arctic Ocean.

**Henson said he reached the spot before Peary did.**

Matthew Henson went with Robert Peary on the 1909 journey that Peary claimed reached the North Pole. Members of Congress thanked Peary in 1911. Most of Henson's honors came after 1937, more than 25 years after the journey.

Henson was born in Charles County, Maryland, in 1866. His parents were sharecroppers, farmers who worked someone else's land for a share of the crop. They had been free before the Civil War. In 1867 the family left southern Maryland to escape attacks by the Ku Klux Klan, a group of white men who used violence to terrorize Black people.

At 12 Henson went to sea as a cabin boy. The ship's captain, a man named Childs, taught him to read and write. In November 1887 Henson was working in a clothing store in Washington, D.C., when he met Robert Peary, a Navy officer. Peary hired him as his helper on a trip to measure and map land in Nicaragua, where people were planning a canal. Their first Arctic trip together was in 1891 and 1892, and by 1909 they had made seven Arctic voyages.

Henson traded with the Inuit and learned their language. They called him Mahri-Pahluk. He is remembered as the only member of the expedition who was not Inuit and became skilled at driving and training dog teams the Inuit way. He was also Peary's navigator, the person who worked out where they were and which way to go.

**The last expedition.** Peary's ship, the *Roosevelt*, left New York in July 1908. Inuit men, women and children from Cape York, in Greenland, joined the expedition. In February 1909 the sled parties set out across the frozen Arctic Ocean. There were 7 expedition members, 19 Inuit, 140 dogs and 28 sleds.

They carried supplies forward in relays. One party hauled loads part of the way and left them, and the next party carried them on. By the end Peary could no longer walk, and he rode on a sled. He sent Henson ahead as a scout.

Peary said that his party had reached the North Pole on April 6, 1909. The last group was six men: Peary, Henson and four Inuit men named Ootah, Egingwah, Seegloo and Ooqueah. Henson later said that he was the first of the party to reach the spot they believed was the pole.

**The claim.** The claim is disputed. Frederick Cook, who had been the doctor on Peary's trip of 1891 to 1892, said he had reached the pole in 1908, a year before Peary. Members of a National Geographic Society committee backed Peary. In 1989 the British explorer Wally Herbert studied Peary's records for the National Geographic Society. He concluded that the records were unreliable. They showed the party moving faster than seemed possible. Herbert found that the party may have stopped 30 to 60 miles short of the pole.

**Honors, late.** Members of Congress voted Peary their formal thanks in 1911, and he was promoted to rear admiral, one of the highest ranks in the Navy.

Henson published a book in 1912 called *A Negro Explorer at the North Pole*. "Negro" was the common word for a Black person at that time. He became the first African American life member of the Explorers Club, a society of explorers, in 1937, and he received a medal for the Peary expedition in 1944. Presidents Harry Truman and Dwight Eisenhower welcomed him to the White House.

He died on March 9, 1955. In 1988 he and his wife were buried again at Arlington National Cemetery. The National Geographic Society gave him its Hubbard Medal in 2000. In 2021 the International Astronomical Union, the scientists' group that names places in space, named a crater on the Moon after him.

### Hiram Bingham

> **Who:** A Yale history teacher, not a trained archaeologist, who made the Inca site of Machu Picchu famous.
>
> **When and where:** 1911 to 1915. The Andes Mountains of Peru.

**Somebody had already written "A. Lizarraga 1902" on a wall.**

Hiram Bingham reached Machu Picchu in 1911 and later made it famous around the world, though people had known the place long before he arrived. He taught South American history at Yale University. He was not trained as an archaeologist, a scientist who studies the past by digging up what people left behind. In 1911 he led an expedition from Yale to Peru to look for the last capital of the Inca. The Inca ruled an empire in the Andes Mountains before the Spanish arrived.

A local man named Melchor Arteaga led Bingham up to Machu Picchu on July 24, 1911. The people living in the valley next to it already knew the ruins. Explorers from the Peruvian city of Cusco are said to have reached it in 1901. One of them, Agustin Lizarraga, wrote "A. Lizarraga 1902" in charcoal on a wall there, and Bingham found the writing. A map from 1874 already shows the site. Bingham later wrote about the ruins as if he had found them himself.

Bingham guessed that Machu Picchu was the Incas' last capital, and he called it the "Lost City." The last capital was really Vilcabamba, which Bingham also visited without recognizing it.

Bingham's team dug up about 40,000 objects at Machu Picchu, among them mummies, bones and pottery. They shipped them to Yale under an order from Peru's government. Peruvian officials said the objects had only been lent. Yale and Peruvian officials agreed in 2007 on what to do with them, and Yale officials began sending the objects back in 2012.

### Roy Chapman Andrews

> **Who:** A naturalist from Wisconsin who started as a janitor at the American Museum of Natural History and later ran it.
>
> **When and where:** 1922 to 1928. The Gobi Desert of Mongolia.

**His team found nests full of dinosaur eggs on July 13, 1923.**

From 1922 to 1928 Roy Chapman Andrews led the American Museum of Natural History's expeditions into the Gobi Desert of Mongolia. His teams went by car from Peking, in China, the city now called Beijing. He was looking for the remains of the earliest humans. His teams found none.

They found other fossils instead. Fossils are the remains of living things from long ago, turned to stone or pressed into rock. In 1922 they found the bones of a giant relative of the rhinoceros that had no horn. In 1923 they found the first nests of dinosaur eggs known to science. Scientists first thought the eggs came from a dinosaur called *Protoceratops*. In 1995 scientists showed that they belonged to a meat-eating dinosaur called *Oviraptor*.

Chinese officials seized what the expedition had found in 1928. They later gave the finds back. In 1934 Andrews became director of the museum.

### Richard Byrd

> **Who:** A US Navy pilot who led flights and expeditions to both poles.
>
> **When and where:** 1926 to 1935. The Arctic and Antarctica.
>
> **Movie:** *With Byrd at the South Pole* (1930), a documentary film of the trip.

**His diary holds navigation readings that somebody erased.**

Richard Byrd led the first flight to the South Pole, in 1929. His claim to have flown over the North Pole three years earlier is disputed. Byrd became a Navy pilot in 1918.

**The North Pole claim.** Byrd and the pilot Floyd Bennett flew a three-engine plane, the *Josephine Ford*, toward the North Pole on May 9, 1926. Members of Congress voted both men the Medal of Honor for the flight. Most researchers who have studied the flight believe the plane could not carry enough fuel to fly as far as Byrd said. In 1958 another pilot, Bernt Balchen, said that Bennett had told him they never reached the pole.

Byrd's diary was made public in 1996. Its erased navigation readings differ from his official report, and the records do not say who erased them. The historian Dennis Rawlins concluded that Byrd flew about 80 percent of the way and turned back because of an oil leak. Other researchers defend Byrd's claim.

**The South Pole.** In Antarctica, Byrd built a base camp called Little America on the Ross Ice Shelf, a huge sheet of ice floating on the sea. On November 28, 1929, Byrd, the pilot Bernt Balchen, the radio operator Harold June and the photographer Ashley McKinley took off for the South Pole. They flew there and back in 18 hours and 41 minutes. To make the plane light enough to climb onto the high ice of the Antarctic Plateau, they threw supplies out.

**Alone.** Byrd spent five months alone in a weather hut called Advance Base on his second expedition, in 1934. Fumes from a badly vented stove, one that did not let its smoke out properly, gave him carbon monoxide poisoning. Carbon monoxide is a gas with no smell that stops the blood from carrying oxygen. He nearly died. Men from the base camp reached him on their third try. Byrd died in 1957.

### Charles Lindbergh

> **Who:** An airmail pilot who made the first solo nonstop flight across the Atlantic Ocean.
>
> **When and where:** May 20 to 21, 1927. From Garden City, New York, to Paris, France.

**He flew alone for 33 hours and 30 minutes.**

Charles Lindbergh, an airmail pilot, became the first person to fly alone and without stopping across the Atlantic Ocean in May 1927. Workers at Ryan Airlines, a company in San Diego, built his single-engine plane, the *Spirit of St. Louis*.

Lindbergh took off from Roosevelt Field, in Garden City, New York, on May 20, 1927. He landed at Le Bourget airfield outside Paris the next day, after about 3,600 miles. He won the $25,000 Orteig Prize, which had been offered for the first nonstop flight between New York and Paris.

Two British fliers, John Alcock and Arthur Brown, had made the first nonstop flight across the Atlantic eight years earlier. They flew from St. John's, Newfoundland, to Clifden, Ireland, on June 14 and 15, 1919, in under sixteen hours. Lindbergh was the first to make the crossing alone.

### Amelia Earhart

> **Who:** The first woman to fly alone and nonstop across the Atlantic Ocean.
>
> **When and where:** 1932, Newfoundland to Northern Ireland, and 1937, the central Pacific Ocean.

**The *Itasca* heard her clearly, and she could not hear the ship.**

Five years after Lindbergh, Amelia Earhart made the same kind of crossing, alone and without stopping, the first woman to do it. In 1928 she had crossed the Atlantic by air as a passenger, the first woman to do so.

She took off alone from Harbour Grace, in Newfoundland, on May 20, 1932, when she was 34. She flew through strong winds and ice, and her engine had problems. After 14 hours and 56 minutes she landed in a pasture near the city of Derry, in Northern Ireland. Members of Congress voted her the Distinguished Flying Cross, a medal for bravery or great skill in flying.

**Around the world.** Earhart set out in 1937 to be the first woman to fly around the world. Her route ran about 29,000 miles, near the equator. The navigator Fred Noonan flew with her. On June 29 they reached Lae, in New Guinea, with about 7,000 miles to go.

They took off for Howland Island, a tiny island in the Pacific, on July 2, 1937. A Coast Guard ship, the *Itasca*, waited there to guide them in by radio. The crew of the *Itasca* heard her clearly, but she could not hear the ship. The ship's radio direction finder could not lock onto her signal to show which way it came from.

At 7:58 in the morning she radioed that she could not hear the *Itasca*. Earhart and Noonan were never found. She was declared legally dead on January 5, 1939.

## 1950 to 2000

**Era 9 of 10 · 1950 to 2000 · about 13 minutes**

After 1950 the places no person had ever seen were the deepest parts of the ocean and space beyond the Earth. The Soviet Union, a large country ruled from Moscow, was the main rival of the United States in those years. On October 4, 1957, Soviet engineers launched Sputnik, the first satellite to circle the Earth. A satellite is an object that travels in a path around a planet.

The next year members of Congress passed a law that set up NASA, the US space agency. Soviet and American crews then flew into space, one flight after another. Between 1969 and 1972 twelve American astronauts walked on the Moon.

Three American astronauts died in a fire on the launch pad in 1967. Seven died when the space shuttle *Challenger* broke apart in 1986. A space shuttle was a spacecraft that rode rockets up into space and landed on a runway when it came back. In the ocean, two men reached the deepest point on Earth in 1960, and scientists found living things around hot springs on the sea floor in 1977.

### Don Walsh

> **Who:** A US Navy lieutenant who, with the Swiss scientist Jacques Piccard, made the first dive to the deepest point in the ocean.
>
> **When and where:** January 23, 1960. The Challenger Deep in the Mariana Trench, near Guam in the Pacific Ocean.

**Below 30,000 feet a window pane cracked and the craft shook.**

Navy Lieutenant Don Walsh and the Swiss ocean scientist Jacques Piccard reached the bottom of the deepest known place in the ocean on January 23, 1960. It is called the Challenger Deep, and it lies in the Mariana Trench, near the island of Guam in the Pacific. No craft of any kind, with people or without, had been there before.

They went down in the *Trieste*, a deep-diving craft called a bathyscaphe. Piccard's father, Auguste Piccard, had designed it, and it was built in Italy in 1953. The US Navy bought it. The trip down took 4 hours and 47 minutes. The pane that cracked was one of the outer window panes, and the two men went on to the bottom.

At the time they measured the depth as 37,799 feet. The figure was later corrected to 35,814 feet, which is almost seven miles. Newer measurements give between 35,797 and 36,070 feet. The two men stayed on the bottom for twenty minutes, in a cabin that was 45 degrees Fahrenheit.

Walsh and Piccard reported seeing flatfish on the bottom. Scientists now doubt it, because fish are not known to live deeper than about 26,000 to 28,000 feet. Walsh later said they could have been mistaken.

### Into space, 1957 to 1972

**NASA.** NASA was set up on July 29, 1958, under a law called the National Aeronautics and Space Act. NASA's staff began work on October 1, 1958. Its full name is the National Aeronautics and Space Administration.

**The first people in space.** A Soviet cosmonaut, Yuri Gagarin, circled the Earth once on April 12, 1961, the first person to travel into space. Cosmonaut is the Russian word for an astronaut. Three weeks later, on May 5, 1961, Alan Shepard became the first American in space. His flight lasted 15 minutes. It went up into space and came straight back down without circling the Earth.

President John F. Kennedy asked Congress on May 25, 1961, to set the goal, "before this decade is out, of landing a man on the Moon and returning him safely to the Earth." The Moon program was called Apollo. At its peak 400,000 people worked on it, and it cost $25.4 billion.

John Glenn circled the Earth three times on February 20, 1962, in 4 hours and 55 minutes, in a capsule called *Friendship 7*. He was the first American to orbit the Earth, which means to travel all the way around it. Two Soviet cosmonauts had orbited before him.

**Apollo 1.** Three astronauts died in a fire during a practice countdown on the launch pad in Florida on January 27, 1967. They were Gus Grissom, Ed White and Roger Chaffee, the crew of Apollo 1. An electric spark set nylon material on fire inside a cabin filled with pure oxygen. The hatch opened inward, and the pressure inside the cabin held it shut. It took workers on the launch pad five minutes to open all three layers of the hatch.

The fire melted the men's suits and air hoses. Doctors who examined their bodies found that the main cause of death was carbon monoxide gas from the fire, which had stopped their hearts. All three also had third-degree burns, burns that destroy the skin all the way through. Most of the burns happened after the men had died.

**The Moon.** The crew of Apollo 8 became the first people to orbit the Moon in December 1968. Between December 1968 and December 1972, 24 astronauts flew around the Moon. Six Apollo crews landed on it, and twelve men walked on it. The last landing was Apollo 17, in December 1972. No one has walked on the Moon since.

### Katherine Johnson

> **Who:** A Black mathematician from West Virginia who calculated the flight paths of the first American spaceflights.
>
> **When and where:** From 1953. The Langley laboratory in Hampton, Virginia.
>
> **Movie:** *Hidden Figures* (2016). The actor Taraji P. Henson plays Johnson.

**Glenn refused to fly until she had checked the machines' numbers.**

Katherine Johnson worked out the flight path of the first American spaceflight, in 1961, and checked the numbers for the first American flight around the Earth, in 1962. She was born in White Sulphur Springs, West Virginia, in 1918. Her county had no public high school for Black students.

Her family sent her to one on the campus of West Virginia State College, and she started there at the age of ten. Later she was one of three Black students chosen to be the first to attend the graduate school of West Virginia University.

**"Colored Computers."** The Langley laboratory, in Hampton, Virginia, hired her in June 1953. The laboratory belonged to NACA, the government agency that came before NASA. Her job title was "computer." At that time a computer was a person who did long calculations by hand.

Segregation means keeping people apart by race. Virginia's lawmakers had passed segregation laws, and federal workplaces had segregation rules of their own. Under them, Johnson and the other Black women computers had to work, eat and use restrooms apart from white workers. The sign on their office read "Colored Computers." "Colored" was a word for Black people used at that time.

Johnson calculated the path and the launch time for Alan Shepard's flight in 1961. For John Glenn's flight in 1962, NASA officials used electronic computers for the first time to plan the orbit. Glenn asked for Johnson by name to check the machines' numbers. He refused to fly until she had checked them. She later worked on the paths that let Apollo spacecraft meet each other in space.

President Barack Obama gave her the Presidential Medal of Freedom in 2015. Members of Congress awarded her the Congressional Gold Medal in 2019. She died on February 24, 2020, at the age of 101.

### Apollo 11 crew

> **Who:** Neil Armstrong, Buzz Aldrin and Michael Collins, the crew of the first spacecraft to land people on the Moon.
>
> **When and where:** July 16 to 24, 1969. From Florida to the Moon's Sea of Tranquility and back to the Pacific Ocean.

**About one in five people on Earth watched the first step live.**

Neil Armstrong and Buzz Aldrin became the first people to land on the Moon on July 20, 1969. A Saturn V rocket had launched them and Michael Collins from Kennedy Space Center, in Florida, on July 16.

Armstrong and Aldrin flew the lunar module, a small landing craft named *Eagle*, down to a flat plain called the Sea of Tranquility. Collins stayed in orbit around the Moon in the command module, *Columbia*, the part of the spacecraft that would carry all three men home. About six hours after landing, Armstrong stepped out onto the Moon. Aldrin followed him 19 minutes later. An estimated 600 million people watched Armstrong's first steps live on television, and another count gives 650 million.

The two men collected 47.5 pounds of rock and soil and spent more than 21 hours on the Moon's surface. The three astronauts splashed down safely in the Pacific Ocean on July 24, 1969.

### Apollo 13 crew

> **Who:** Jim Lovell, Jack Swigert and Fred Haise, a Moon-landing crew whose spacecraft was badly damaged by an explosion.
>
> **When and where:** April 11 to 17, 1970. Between the Earth and the Moon.
>
> **Movie:** *Apollo 13* (1995), based on Lovell's book about the flight, *Lost Moon*.

**An oxygen tank exploded two days out, and they came home anyway.**

The crew of Apollo 13 survived an explosion on the way to the Moon by living in their small landing craft. They were Jim Lovell, the commander, Jack Swigert and Fred Haise. Swigert had taken the place of Ken Mattingly, who had been exposed to German measles, an illness that spreads from person to person.

The spacecraft launched on April 11, 1970. Two days later the crew stirred one of the oxygen tanks, a routine job. Damaged insulation on the wires inside the tank caught fire, and the tank exploded. The oxygen in both of the main spacecraft's tanks escaped into space.

After the explosion, mission controllers cancelled the Moon landing and worked to bring the crew home alive. The three men shut down the main spacecraft to save it for the trip back down through the atmosphere, the layer of air around the Earth.

They moved into the small lunar module, *Aquarius*, and lived in it on the way home. It was cold and wet inside, and they ran short of drinking water. The air had to be cleared of carbon dioxide, the gas people breathe out. The crew and the engineers on the ground worked out a way to make the main spacecraft's carbon dioxide filters fit the lunar module.

The crew swung around the Moon and headed home. They splashed down safely in the South Pacific on April 17, 1970. Members of the review board later blamed the way the tank had been tested before the flight, and the Teflon plastic inside it.

### Sylvia Earle

> **Who:** A marine biologist from New Jersey who set a deep-diving record and led the first all-woman team to live underwater.
>
> **When and where:** 1970 to 1992. The Virgin Islands and the waters off Hawaii.

**She walked the sea floor 1,250 feet down, with no line up.**

Sylvia Earle holds the women's record for the deepest dive to the sea floor. She became a marine biologist, a scientist who studies life in the sea. In 1969 she asked to join the Tektite project, which let scientists live in a laboratory under the sea. She had already spent more than 1,000 hours underwater doing research. The government officials running the project turned her down, because they did not want men and women living together in the laboratory.

So in 1970 Earle led the first all-woman team of aquanauts, people who live and work underwater. They lived in a laboratory 50 feet below the surface off the Virgin Islands.

She put on a hard diving suit in 1979 that kept the water pressure away from her body. With no line connecting her to the surface, she dived to the sea floor off Oahu, Hawaii, 1,250 feet down. That women's depth record still stands. From 1990 to 1992 she was the first woman to be chief scientist of NOAA, the US government's ocean and weather agency.

### Robert Ballard

> **Who:** A Navy oceanographer and sea-floor geologist from Kansas.
>
> **When and where:** 1977 to 1989. The Pacific floor near the Galápagos Islands and the North Atlantic.

**First he had to look at two sunken Navy submarines in secret.**

Robert Ballard helped find living things where scientists had expected none, and later he found the wreck of the *Titanic*. He became an oceanographer, a scientist who studies the ocean, and he worked at the Woods Hole Oceanographic Institution.

Ballard was a diver in 1977 on an expedition that used the submarine *Alvin* on the sea floor near the Galápagos Islands, in the Pacific. Its members found hot springs on the sea floor. Groups of living things surrounded them. They got their energy from chemicals in the water from the springs, not from sunlight. All the scientists on board were geologists, scientists who study rocks and the Earth, because they had been certain there would be no life to study.

**The Titanic.** Ballard asked the Navy in 1982 to pay for a search for the *Titanic*. He planned to use a new camera robot called *Argo*, which a ship could tow along the sea floor. The Navy's leaders agreed, on one condition. First he had to use *Argo* to look in secret at the wrecks of two Navy nuclear submarines, the *Thresher* and the *Scorpion*. Both had sunk in the 1960s.

After that work, in 1985, Ballard and a French team found the wreck of the *Titanic*. In June 1989 he found the wreck of the *Bismarck*, a battleship of Nazi Germany that sank in the North Atlantic in May 1941.

### Sally Ride and Mae Jemison

> **Who:** The first American woman in space and the first African American woman in space.
>
> **When and where:** 1983 and 1992, aboard the space shuttles *Challenger* and *Endeavour*.

**Reporters sent more than 500 requests to interview Ride.**

Sally Ride became the first American woman in space in 1983, and Mae Jemison became the first African American woman in space in 1992. Ride was a physicist from California, a scientist who studies matter and energy. She joined NASA in 1978. On June 18, 1983, she flew on the space shuttle *Challenger*. She was the third woman in space. The first had been Valentina Tereshkova of the Soviet Union, in 1963. At 32 Ride was the youngest American astronaut to fly.

On the flight Ride worked the shuttle's robot arm. Two months later, on August 30, 1983, Guion Bluford became the first African American in space.

Ride later served on the Rogers Commission, which investigated the *Challenger* explosion in 1986, and on the Columbia Accident Investigation Board, which investigated the loss of the shuttle *Columbia* in 2003. She was the only person to serve on both. She died in 2012. Her obituary, the published notice of her death, named Tam O'Shaughnessy as her partner of 27 years. Ride had kept the relationship private while she was alive. She is the first astronaut known to have been LGBTQ, which stands for lesbian, gay, bisexual, transgender or queer.

**Jemison.** Mae Jemison was born in Decatur, Alabama, in 1956 and grew up in Chicago. She studied chemical engineering at Stanford University and then became a doctor. From 1983 to 1985 she worked as a doctor in Liberia and Sierra Leone, in West Africa. She went there with the Peace Corps, a US government program that sends volunteers to work in other countries. She joined NASA in 1987. From September 12 to 20, 1992, she flew aboard the space shuttle *Endeavour*.

### The Challenger explosion, 1986

The space shuttle *Challenger* broke apart 73 seconds after it lifted off on January 28, 1986. All seven people on board died. They were the commander, Dick Scobee, the pilot, Michael Smith, and Ellison Onizuka, Judith Resnik, Ronald McNair, Gregory Jarvis and Christa McAuliffe, a schoolteacher. Many schools watched the launch live because a teacher was on board.

The shuttle broke apart because rubber rings, called O-rings, failed in a joint of one of its booster rockets. The rings sealed the joint so that hot gas could not escape. The record cold that morning had made them stiff. Test results going back to 1977 had shown that these seals were flawed. Two engineers at the Morton Thiokol company, Allan McDonald and Roger Boisjoly, had warned against launching in the cold. NASA managers ignored their warnings.

Several of the crew are thought to have survived the breakup itself. Someone switched on the emergency air supply of the pilot, Michael Smith. The crew cabin then fell and struck the ocean.

**If you remember one thing:** Between 1950 and 2000 people reached the bottom of the ocean and walked on the Moon, and ten American astronauts died on the launch pad or on the way up.

**One question this era leaves open:** whether people would ever go back to the Moon. Nobody has walked on it since Apollo 17 came home in December 1972. The next era states the answer.

**Next:** A second space shuttle, *Columbia*, was lost in 2003, seventeen years after *Challenger*.

## 2000 to Today

**Era 10 of 10 · 2000 to Today · about 6 minutes**

Since 2000, robot spacecraft steered from Earth have explored Mars and the outer solar system. Rovers, robot vehicles, drive across Mars, and probes, robot spacecraft sent to study faraway places, have flown past Pluto and out beyond the planets. People have lived on the International Space Station, a laboratory that circles the Earth, without a break since November 2, 2000.

On Earth, most of the ocean floor has still not been mapped. In April 2026 an international mapping project reported that 28.7 percent had been mapped. That same month four astronauts flew around the Moon, the first people to travel there since 1972.

### The loss of Columbia, 2003

The space shuttle *Columbia* broke apart over Texas and Louisiana on February 1, 2003, as it was coming back down through the atmosphere. All seven astronauts on board died. They were the commander, Rick Husband, the pilot, William McCool, and Michael Anderson, Kalpana Chawla, David Brown, Laurel Clark and Ilan Ramon, the first astronaut from Israel.

During the launch, a piece of foam from the shuttle's big fuel tank had broken off and hit the left wing. It damaged the panels that protected the wing from the heat of coming back through the atmosphere. Foam had struck shuttles before, on 65 of the 79 earlier launches that had been photographed.

While *Columbia* was in orbit, a team of engineers asked several times for pictures of the wing, taken by military satellites or telescopes. The mission's management team said it had no need for the pictures, and Linda Ham, the mission manager, cancelled the request.

### Robots to Mars and beyond

NASA's rover *Curiosity* landed in Gale crater on Mars in August 2012. In March 2013 NASA scientists reported what a rock it drilled showed: water had once filled that place, at the end of a river or in a lake, and tiny living things could have lived in it. Nothing in the rock showed that any did. *Curiosity* was still working in September 2026.

The rover *Perseverance* landed in Jezero Crater in February 2021. The mission's planners chose the crater because an ancient river once flowed into it and left a delta, a fan of mud and sand. *Perseverance* drills rock samples and stores them so that a later mission could bring them to Earth. In July 2024 it found a rock that shows a possible chemical sign of ancient life.

*Perseverance* carried a helicopter named *Ingenuity*, the first aircraft to fly on another planet. It was built for five flights and made 72 over nearly three years, until its rotor blades broke in January 2024.

The probe *New Horizons* left Earth in January 2006. On July 14, 2015, it became the first spacecraft to visit Pluto, passing 7,800 miles above it. In 2019 it flew past an object called Arrokoth, about 4 billion miles from the Sun.

Two older probes, *Voyager 1* and *Voyager 2*, were launched in 1977. In 2012 *Voyager 1* became the first spacecraft to reach interstellar space, the space between the stars, which begins beyond the stream of particles that blows out from the Sun. *Voyager 2* followed in 2018. *Voyager 1* is the most distant object people have ever made.

Both Voyagers get their power from plutonium, a radioactive metal that gives off heat, and their power drops a little every year. In April 2026 NASA engineers switched off one of *Voyager 1*'s instruments to save power. Two of its science instruments still work.

The James Webb Space Telescope was launched on December 25, 2021, from French Guiana, in South America. It cost just under $10 billion. It was built to see light that left the first galaxies, about 180 million years after the universe began. A galaxy is a huge group of billions of stars.

### James Cameron

> **Who:** A Canadian film director who dove alone to the deepest point in the ocean.
>
> **When and where:** March 26, 2012. The Challenger Deep in the Mariana Trench, in the western Pacific Ocean.

**He spent about three hours alone at the bottom of the ocean.**

James Cameron, a film director from Canada, became the first person to dive alone to the Challenger Deep, the deepest point in the ocean, on March 26, 2012. He piloted a small deep-diving craft, the *Deepsea Challenger*, to the bottom alone. The craft was built in Sydney, Australia, with the National Geographic Society.

The trip down took 2 hours and 37 minutes, about twice as fast as the *Trieste* in 1960. The deepest reading on the dive was 35,787 feet. No one before him had stayed on the bottom so long. A problem with the craft's hydraulic system made it hard to use the equipment for collecting samples. The hydraulic system used fluid under pressure to move the equipment.

Cameron's was the second dive with people on board to reach the Challenger Deep, 52 years after Don Walsh and Jacques Piccard. He was the third person to go there, after Walsh and Piccard. The *Deepsea Challenger* was later given to the Woods Hole Oceanographic Institution, where Robert Ballard had worked.

### Mapping the sea floor

In an international project called Seabed 2030, people from many countries are working to map the whole floor of the ocean. On April 28, 2026, staff of the International Hydrographic Organization, a group of countries that work together on sea charts, published the project's latest total. The project's leaders reported that 28.7 percent of the ocean floor had been mapped. Almost five million square kilometers, about 1.9 million square miles, had been added in the year before. In June 2025 the project had reported 27.3 percent.

### Artemis II crew

> **Who:** Reid Wiseman, Victor Glover and Christina Koch of NASA and Jeremy Hansen of Canada, the first people to travel to the Moon since 1972.
>
> **When and where:** April 1 to 10, 2026. From Florida around the Moon and back to the Pacific Ocean off San Diego.

**They flew 252,756 miles from Earth, farther than any people before them.**

Four astronauts flew around the Moon in April 2026, the first people to go there in more than 50 years. They were the commander, Reid Wiseman, the pilot, Victor Glover, and Christina Koch of NASA, and Jeremy Hansen of the Canadian Space Agency. They launched on April 1, 2026. It was the first flight with a crew for NASA's Orion spacecraft and its SLS rocket. SLS stands for Space Launch System. The crew circled around the Moon but did not land.

According to NASA's announcement of April 10, 2026, their farthest point broke the record of 248,655 miles set by the crew of Apollo 13 in 1970. A web page of the Smithsonian's National Air and Space Museum states that Koch became the first woman to travel that far from Earth. Glover became the first Black man and Hansen the first Canadian to do so.

Koch had already spent 328 days in orbit on the International Space Station, ending in February 2020. It was the longest single spaceflight by a woman up to that time.

Some experts outside NASA objected to flying this mission without a redesigned heat shield. After Orion's test flight without a crew in November 2022, NASA engineers found that its heat shield had worn away in ways they had not expected. The heat shield protects the spacecraft from the heat of coming back through the atmosphere. NASA's leaders kept the same shield for Artemis II and changed the path the spacecraft would take on the way down.

The crew splashed down safely in the Pacific Ocean off San Diego at 5:07 p.m. Pacific time on April 10, 2026, after a trip of nearly ten days.

**The three questions, answered**

- How do we know people were living here at least 21,000 years ago? Human footprints at White Sands, in New Mexico, lie between layers of seeds, pollen and quartz sand, and three different tests date those layers to about 21,000 to 23,000 years ago.
- What did the explorers do to the people whose land they crossed? Some traded with them and were fed by them. Others took captives, from the 500 Taino Columbus's men shipped to Spain to the six Inuit Peary brought to New York, and some killed: de Soto's men at Mabila, Coronado's at Arenal, Frémont's on the Sacramento River.
- Which famous "firsts" are still in doubt? Peary's North Pole in 1909 and Byrd's flight over it in 1926. Wally Herbert found Peary's records unreliable, and most researchers think Byrd's plane could not carry enough fuel. Older firsts are in doubt too: Spanish slave raiders may have reached Florida before Ponce de León, Ute tradition says Ute ancestors climbed Pikes Peak before Long's men, and nobody knows whether the Norse camp in Newfoundland was Leif's own.

**What changed:** For thousands of years almost every place an explorer reached was already somebody's home, and after 1950 the only places left were the deep ocean and space, where nobody had ever lived.

**Five dates to keep**

- 1021: Norse sailors cut trees at L'Anse aux Meadows, in Newfoundland.
- 1540: Hopi guides lead Spanish soldiers to the rim of the Grand Canyon.
- 1806: Lewis and Clark reach St. Louis with about 140 maps.
- 1909: Peary says his party has reached the North Pole.
- 1969: Armstrong and Aldrin walk on the Moon.

**Not known:** Nobody knows how many people lived north of Mexico in 1500, and the estimates run from about 1 million to about 18 million.

**Where to go:** The La Verendrye lead plate from 1743 is kept in the South Dakota Cultural Heritage Center.

**Next:** Chapter 2, Native Nations, which describes what happened to the nations whose land the explorers in this chapter crossed, from the nations' side.
