# Chapter 3: Land and Environment

**Chapter 3 of 37 · Land and Environment · 10 eras · about 95 minutes**

**Americans cleared this land, used it up and then saved pieces of it, and at almost every step the people who lost most had the least say: first Native nations, later poor and Black neighborhoods.**

Miantonomi, a leader of the Narragansett nation, told the Montaukett people on Long Island in 1642 what the English were doing to the land. The plains had once been full of game, he said, but the English were cutting down the grass and the trees. Their cows and horses ate the grass, their hogs spoiled the clam banks, and he warned that his listeners would all starve. An English soldier wrote his words down. The next year, English officials sentenced Miantonomi to death.

This chapter follows the land itself through ten eras, from Native nations burning forests on purpose to government fire crews learning that same kind of burning from Yurok people today. Keep an eye on two things. The first is the numbers. Beavers, salmon, forests, 30 million bison and billions of passenger pigeons fall era by era. Some, like the eastern forests and the bison, later climb back, and the passenger pigeon never does. The second is who had to move. The families driven out of the first national parks were Native. The neighborhoods beside the waste dumps of the 1900s were far more likely than others to be Black or poor.

**Three questions this chapter answers**

- How did Native nations shape the land before Europeans came?
- What happened to the 30 million bison and the billions of passenger pigeons?
- Who was pushed out when parks were made, and who lived next to the waste?

**Five minutes?** Read "Yosemite and the Ahwahneechee" in 1850 to 1900.

**Can skip:** "Whaling from Nantucket", "The forest reserves", "Plastic in the rain". The chapter still makes sense without them.

## Before 1500

**Era 1 of 10 · Before 1500 · about 2 minutes**

Native nations shaped the land of North America for thousands of years before any European arrived. In the eastern forests, people set fires on purpose to keep the woods open and to grow food for the animals they hunted. Farmers planted three crops together in a way that kept the soil good. In southwest Florida, the Calusa built pens in the water to hold live fish.

Animals shaped the land too. Beavers dammed streams across the continent, and bison grazed the Plains. Nobody knows how many bison lived there before 1500. The figure usually given, about 30 million, is for the early 1800s, before hunters killed off the herds.

### Why Native people burned the woods

For thousands of years, Native people in what is now the eastern United States burned their forests on purpose to keep them open. They set low fires in the understory, the layer of brush and small plants under the tall trees. They burned the same ground again and again. The fires helped oaks and other trees that can live through fire. Food plants grew back after each burn, and so did food for game, the wild animals people hunted.

**What the trees show.** Researchers at Penn State, a university in Pennsylvania, published a study in the journal *Annals of Forest Science* in 2019. They found that which trees grew in the eastern forests depended more on Native burning than on the climate. Even small groups of people burned large areas, over and over. European colonists treated this burning as unimportant.

### Three crops in one field

Native farmers grew corn, beans and squash together in the same field, three crops known as the Three Sisters. The beans put nitrogen, a natural substance that plants need to grow, into the soil. The wide squash leaves shaded the ground and held the soil in place. The tall corn stalks gave the bean vines something to climb.

Growing the three crops together kept the soil good for years. A field planted with only one crop, year after year, wears out.

### Beavers, bison and fish pens

Beavers changed whole watersheds, all the land that drains into one stream or river. Their dams held back water in ponds. The ponds slowed floods, and the wet ground around them became meadows. Nobody counted the beavers, so the numbers are estimates. They run from 60 million to 400 million beavers in North America before the fur trade, the buying and selling of animal skins between European traders and Native trappers.

Bison lived on the Plains, the wide grasslands in the middle of the continent. About 30 million lived there in the early 1800s. Estimates for the years before Europeans came are less certain.

In what is now southwest Florida, the Calusa people built watercourts between 1300 and 1400. These were pens in the water that held live fish until people needed them for food.

## The 1500s

**Era 2 of 10 · The 1500s · about 3 minutes**

Two things changed the land of the Americas in the 1500s: new animals arrived from Europe, and most of the Native people who had farmed the land died. Ships brought pigs, horses, cattle and earthworms. Pigs that escaped from the Spanish explorer Hernando de Soto and his men went wild in the Southeast, and European earthworms moved into northern forests that had never had worms.

Most of the Native people died of diseases that came across the ocean with Europeans: with European settlers, and with the Africans whom Europeans had enslaved and carried over. European soldiers and settlers killed others in wars to take Native lands, and many starved. Forest grew back over the farmland of the people who died.

### Pigs, horses and cattle

Pigs that escaped from Hernando de Soto's herd became the ancestors of the feral hogs of the Southeast, pigs from farm stock that live in the wild.

**Thirteen pigs.** De Soto landed near Tampa Bay, in what is now Florida, in May 1539, with about 600 men and a herd of pigs. The written histories of his expedition list the first herd as 13 pigs. By the time de Soto died in 1542, the herd had grown to about 700. That count leaves out the pigs the men ate or gave away and the pigs that escaped.

Horses and cattle came with the Spanish. Columbus brought horses on his second voyage, in 1493, and Spanish colonists brought horses and cattle to their colony in New Mexico in 1598.

### Earthworms

Before Europeans came, the forests of northern North America had no earthworms. Glaciers, thick sheets of ice that once covered the north, had scraped the ground bare of them. For roughly the last 12,000 years, the forests that grew back after the ice stood on a thick, soft layer of fallen leaves called duff. Native wildflowers and young trees grew in it.

European earthworms crossed the ocean hidden in ballast soil, heavy dirt carried low in a ship to keep it steady. Worms also came in the soil around the roots of plants brought from Europe. Later they spread west with wagons, horses and farms. Where European worms move into a northern forest, they eat the duff that the wildflowers and young trees need.

### Forest over lost farms

Most of the Native people of the Americas died after 1492. Epidemics, diseases that spread quickly to many people, killed most of them. European settlers brought the diseases, and so did enslaved Africans whom Europeans had carried across the ocean. The diseases included smallpox, measles and influenza, and Native people had never been exposed to any of them before.

European soldiers and settlers made war on Native nations to take their land, and they enslaved Native people. Famine, a lack of food so great that people starve, followed when too few people were well enough to farm.

**What the deaths did to the land.** A team of researchers at University College London, in England, published an estimate in 2019. They estimated that the Native population of the Americas fell from about 60 million to about 6 million within roughly a hundred years. Other estimates of the starting number differ. For North America north of Mexico alone, they run from 1 million to 18 million.

The team estimated that about 55.8 million hectares of farmland grew back into forest after its farmers died. A hectare is a square 100 meters on each side, so that is an area bigger than California.

The new trees took carbon dioxide, a gas that traps heat, out of the air. By the team's estimate, the regrowth lowered the carbon dioxide in the air by 7 to 10 parts in every million. It cooled the whole planet by about 0.15 degrees Celsius, about a quarter of a degree Fahrenheit. All of these figures are this one team's estimates.

## The 1600s

**Era 3 of 10 · The 1600s · about 4 minutes**

English colonists and the Native nations of New England had different ideas in the 1600s about what land was for. The colonists treated land as property that one owner held forever, marked off with fences and recorded in deeds, the papers that say who owns a piece of land. The Native nations used their land by season, with planting grounds, fishing places and hunting grounds, and no one person owned it forever.

The historian William Cronon describes these two ways of using land in his 1983 book *Changes in the Land*. The colonists let their cattle and hogs roam free. The animals got into Native planting fields, and colonists and Native people quarreled over it again and again, as the Narragansett leader Miantonomi told his listeners in 1642.

Trappers changed the land too. They caught so many beavers for the fur trade in these years that the beaver's numbers began a long fall.

### The beaver trade

Hat makers in Europe wanted beaver fur to make felt, a thick cloth made by pressing fur together. Native trappers caught the beavers, and European traders paid for the furs with goods made in Europe. The number of beavers in the Northeast began to fall in the 1600s.

The fall went on until about 1900, when about 100,000 beavers were left in North America, most of them in Canada. Today there are roughly 15 million, against the 60 million to 400 million of the years before the fur trade. All of these numbers are estimates.

### The first limits on cutting trees

A Plymouth Colony rule of 1626 forbade anyone to cut timber, wood for building, on the colony's land, or to sell it, without official permission. It was among the earliest conservation rules in the colonies, rules for protecting land, water, plants and animals so that people do not use them up.

William Penn wrote rules for settlers in Pennsylvania in 1681. For every five acres a settler cleared of trees, Penn's rules required the settler to leave one acre, a piece of land a little smaller than a football field, still covered in trees. The rules named oaks and mulberry trees, which were useful for ships and for silk. Settlers widely ignored this rule.

### Miantonomi

> **Who:** A sachem, or leader, of the Narragansett nation, who said out loud in 1642 what English settlers were doing to Native land.
>
> **When and where:** A speech to the Montaukett people on Long Island in 1642, written down by the English soldier Lion Gardener. He was killed near present-day Norwich, Connecticut, in 1643.

**English officials sentenced him to death and handed him to his enemy.**

Miantonomi spoke to the Montaukett people on Long Island in 1642. English settlement in New England was then about one generation old, and he told them what the English were doing to the land.

Lion Gardener, an English soldier, wrote the speech down in his *Relation*, an account he set down in 1660, years later. By Gardener's record, Miantonomi said that "our fathers had plenty of deer and skins and our plains were full of game and turkeys."

Then he said that the English "with scythes cut down the grass, and with axes fell the trees" (a scythe is a long curved blade for cutting grass, and to fell a tree is to cut it down). He went on: "their cows and horses eat the grass, and their hogs spoil our clam banks, and we shall all be starved."

**Known:** The complaints match what colonists were doing at the time, cutting the forests and letting their cattle and hogs roam into Native fields.

**Not known:** Nobody can check Miantonomi's exact words, because an Englishman wrote them down years after the speech.

**The sentence.** Uncas, the sachem of the Mohegan nation, captured Miantonomi in 1643 and took him to Hartford. That September the commissioners of the United Colonies of New England met in Boston. They were English officials from the Massachusetts Bay, Plymouth, Connecticut and New Haven colonies. They passed the case to a group of ministers, or church leaders. Then the commissioners sentenced Miantonomi to death and handed him back to Uncas to carry out the sentence.

Governor John Winthrop of Massachusetts Bay wrote in his journal that "they all agreed that he ought to be put to death." He gave their reason, spelling the name a different way: "Uncas could not be safe while Miantonomo lived."

Mohegan men took Miantonomi back to the place near present-day Norwich, Connecticut, where he had been captured. There one of Uncas's men, walking behind him, killed him with a hatchet blow to the head. Mohegan tradition and later histories name that man as Wawequa, the brother of Uncas. By the historian Neal Salisbury's account, several Englishmen went along to make sure the killing was carried out.

## 1700 to 1750

**Era 4 of 10 · 1700 to 1750 · about 3 minutes**

Colonists of the early 1700s used land and sea as if there would always be more. Tobacco planters in Virginia, the owners of large farms called plantations, wore out the soil of a field in three or four years. Then they cleared new ground farther up the rivers and moved on.

In New England the king's officials saved one thing, the largest white pines, for the masts of the Royal Navy, Britain's navy. Whalers from the island of Nantucket were sailing far out into the ocean to hunt sperm whales by the middle of the century.

### The king's pines

The king's officials kept the largest white pines in New England for the masts of the Royal Navy's ships, the tall poles that hold up the sails. The rule appeared in the Massachusetts Bay charter of 1691, the written grant from the king that set up the colony's government. It covered every white pine 24 inches across or more.

Under the White Pine Act of 1722, cutting any white pine more than 12 inches across without a license, or written permission, was against the law in New Hampshire and nearby colonies. The king's trees carried a mark called the Broad Arrow, three slashes cut with a hatchet. Royal officials enforced these laws loosely until the 1760s.

### Worn-out tobacco fields

A tobacco field in colonial Virginia gave good crops for only three or four years. After that, planters cleared new ground and let the old field grow over with scrub, brush and small trees. The land around Jamestown wore out early. Planters moved up the rivers and reached the Rappahannock and the Potomac by about 1650, and they kept moving up the rivers all through the 1700s. Because new land was cheap, they kept wearing out one field after another.

**Whose land it was.** The new land along the Rappahannock River was the homeland of the Rappahannock Tribe. The tribe's own history states that English settlement there began illegally in the 1640s. By that history, Rappahannock leaders sold their first land to the English in 1651. They spent more than ten years in county courts trying to get paid for that sale and others, and they never received full payment.

The tribe's history goes on to say that by the late 1660s, settlers and bands of settlers who acted as their own law had forced the Rappahannock to move. The tribe moved first inland on the north side of the river, and later to its old hunting grounds on the south side. In 1683, the history states, officials of the Virginia colony forced the tribe out of their homes and moved them to a place called Portobago Indian Town.

**Who did the work.** Indentured servants and enslaved Africans worked the tobacco fields. An indentured servant worked for a master for a set number of years, often four to seven, to pay for the trip to America. Planters held enslaved Africans as property and forced them to work without pay for life. Under a Virginia law of 1662, a child born to an enslaved mother was enslaved for life too. Growing tobacco took a great deal of hand work, and planters wanted more and more workers to do it.

### Whaling from Nantucket

Whalers from Nantucket, an island off Massachusetts, were hunting sperm whales far out in the ocean by the middle of the 1700s. Before that, New Englanders hunted right whales, another kind of whale, from the beaches. On Nantucket, people tell a story that deep-sea whaling began there in 1712, when wind blew Christopher Hussey's boat out to sea and the men aboard killed a sperm whale.

**Known:** Obed Macy first wrote the story down in his history of Nantucket in 1835, more than 120 years later, and historians at the Nantucket Historical Association call 1712 the traditional date.

**Not known:** No record from 1712 shows that Hussey's voyage happened the way the story tells it.

## 1750 to 1800

**Era 5 of 10 · 1750 to 1800 · about 5 minutes**

After independence, American leaders turned the land beyond the mountains into squares that could be sold, and they took it from the nations who lived there with treaties signed under threat and then with armies. In 1785 members of Congress ordered the land north and west of the Ohio River measured into a grid. The Shawnee, the Miami, the Lenape (Delaware) and other nations lived on that land. That January, US officials had claimed most of Ohio in a treaty, a written agreement between nations, signed under threat.

Surveyors measured the land under army guard. US generals led armies against the nations, who had joined together to stop settlement, from 1790 to 1794. After General Anthony Wayne's army defeated them in 1794, leaders of eleven nations signed a treaty in 1795 in which they handed most of Ohio to the United States.

The king's claim to New England's biggest white pines ended with independence. Before that, in 1772, men in Weare, New Hampshire, beat a sheriff who came to arrest a mill owner fined for cutting them. Once the king's claim was gone, settlers crossed the Appalachian Mountains and cleared the forest for farms.

### Ebenezer Mudgett

> **Who:** A sawmill owner in Weare, New Hampshire, fined for cutting the king's white pines, who led the Pine Tree Riot.
>
> **When and where:** South Weare, New Hampshire, April 13 and 14, 1772.

**At dawn, 20 to 30 men with soot-blackened faces beat the sheriff.**

Ebenezer Mudgett owned a sawmill in Weare, New Hampshire. He had been fined for cutting the king's white pines, the trees kept by law for the masts of the Royal Navy.

Sheriff Benjamin Whiting rode into South Weare on April 13, 1772, with a warrant to arrest Mudgett, a paper from a court that allowed the arrest. Mudgett told him he would pay in the morning.

At dawn on April 14, Mudgett came back with 20 to 30 men who had blackened their faces with soot, the black powder that smoke leaves behind. They beat the sheriff and his deputy with rods and drove them out of town. The fight became known as the Pine Tree Riot.

**The trial.** Eight men stood trial in the Superior Court at Amherst, New Hampshire, in September 1772, for rioting and for beating Whiting. They pleaded guilty. The four judges fined each man only 20 shillings, in British coins, and made them pay the cost of the hearing. After the riot, officials mostly stopped enforcing the law that kept the pines for the navy.

**Known:** Some accounts count the riot as a forerunner, an earlier event of the same kind, of the Boston Tea Party, a protest in December 1773.

**Not known:** No one has proved that the riot led to the Tea Party.

### The grid, 1785

Members of the Confederation Congress, the national government of the United States before the Constitution, passed a law called the Land Ordinance on May 20, 1785. It specified how the public land would be sold. Public land was land that US officials claimed for the nation, and Native nations lived on much of it. Under the ordinance, surveyors had to survey that land, which means measure it and map it, before anyone could buy it.

The surveyors divided the land into townships, squares six miles long on each side. They cut each township into 36 sections. A section was one square mile, which is 640 acres. The sections were numbered, and members of Congress set aside section 16 in every township to support public schools.

After changes to the system in 1796, surveyors carried the grid across the continent to the Pacific Ocean. People in airplanes over the Midwest can still see its checkerboard pattern on the ground.

### Whose land the grid covered

The land north and west of the Ohio River was the home of the Shawnee, Lenape, Wyandot, Miami, Ottawa, Chippewa, Potawatomi and other nations in 1785. As members of Congress saw it, the historian George W. Knepper writes, "Indian claims to that land had to be cleared." Here, cleared means ended, so that no Native nation still had a right to the land.

**The treaty at Fort McIntosh.** US commissioners, officials sent to do a certain job, met leaders of several nations at Fort McIntosh in January 1785, four months before the Land Ordinance passed. In the treaty they made there, the commissioners said that most of the Native people of Ohio had to stay inside a reserve, an area set aside for them, between the Cuyahoga and Maumee rivers. Under the treaty, Knepper writes, most of Ohio would be open for settlement.

The Shawnee refused to obey the treaty. Knepper writes that it was made under threat by minor chiefs who had no right to speak for their people. A year later, US commissioners forced the Shawnee into another treaty, at Fort Finney.

**The first survey.** Surveyors for the national government began measuring this land in eastern Ohio in September 1785, and they stopped after a few miles when they heard of an attack by Native people. They went back to work in 1786 under army guard, and they measured the land for sale while the nations who lived on it still rejected the treaty.

### The war for Ohio and the Treaty of Greenville

Chapter 2 tells this war from the nations' side. The nations of the region had joined in a confederacy, a union of nations, to stop American settlement. Led by Little Turtle of the Miami and others, its warriors beat American armies in 1790 and 1791, and General Anthony Wayne's army defeated the confederacy at Fallen Timbers in 1794. Here is what the war meant for the land.

**The land the nations lost.** A year after Fallen Timbers, on August 3, 1795, leaders of eleven northwestern nations signed the Treaty of Greenville. In it they handed nearly 17 million acres to the United States, an area a little bigger than West Virginia. Under the treaty, the nations kept only the northwest quarter of Ohio and the lands beyond it, behind a boundary called the Greenville Treaty Line.

### Clearing after independence

After independence, the British king no longer had any right to the white pines in the United States. Settlers crossed the Appalachian Mountains, some of them into the Northwest Territory, the US name for the land north and west of the Ohio River, and cut down the forest to make farms.

## 1800 to 1850

**Era 6 of 10 · 1800 to 1850 · about 4 minutes**

New Englanders put their rivers to work and cut down most of their forests in the first half of the 1800s, and a few Americans began to write about saving wild places. Mill dams across the rivers stopped the salmon from swimming upstream to lay their eggs. By 1850 farmers had cleared most of New England's forest, partly to feed a boom in sheep.

The painter George Catlin wrote in 1832 about keeping a huge park for the bison and the Plains nations, which he called "a nation's park." He meant a park that would hold both the bison and the Native nations who lived there. In these same years John James Audubon painted the birds of North America, and Henry David Thoreau lived for two years in a cabin he built at Walden Pond, in Massachusetts.

### Dams stop the fish

Atlantic salmon live in the ocean but swim up rivers to spawn, or lay their eggs. A dam across a river blocks them on the way. The first dam across the Connecticut River went up at Turners Falls, Massachusetts, in 1798, and it cut the salmon off from the water where they spawned. By the War of 1812, no salmon came into the Connecticut River at all.

**The Great Stone Dam.** Workers for the Essex Company, a company formed to use the river's water to power mills, built the Great Stone Dam across the Merrimack River at Lawrence, Massachusetts. They finished it in 1848. It stood 30 miles from the sea, and salmon could not get past it. By 1865 the salmon runs, the yearly trips of fish up a river, were gone from the rivers of southern New England. The runs of shad, another fish, collapsed as well.

The writers of an 1857 report in New Hampshire named three causes: the dams, fishing with no limits, and mill machinery that killed young fish.

### The bare East

New Englanders had cut down most of their forest by 1850. Estimates of how much was cleared run from about 60 percent to 80 percent of the land, and some places were cleared even more. One estimate puts the forest left in 1850 as low as a quarter of New England.

A boom in Merino sheep, a kind of sheep raised for its wool, was one cause of the clearing. By 1840 New England farmers kept about 4 million sheep, more sheep than there were people, and they cleared still more forest to feed them.

Across the eastern United States, the forest reached its smallest size around 1872, roughly half the land it had covered in 1620. After that, many eastern farmers left their farms and moved west, and trees grew back on the fields they left behind.

### A park for people and bison

The painter George Catlin traveled far up the Missouri River, into the West, in 1832. He feared that the bison and the Plains nations would be destroyed together. He wrote of "a magnificent park," which he called "a nation's park, containing man and beast, in all the wild and freshness of their nature's beauty." In Catlin's plan, the people who lived on the land would stay on it with the animals.

Forty years later, in 1872, Yellowstone became the first national park. By 1879 its superintendent, the official in charge, had the Tukudika people who lived there forced out and taken to a reservation, land set aside for a Native nation to live on. The next era tells how.

### John James Audubon

> **Who:** A painter and naturalist, a person who studies animals and plants in the wild. He painted *The Birds of America*, 435 life-size pictures of birds.
>
> **When and where:** He lived from 1785 to 1851. His book came out from 1827 to 1838. In 1813, on the way to Louisville, Kentucky, he saw a flock of passenger pigeons that he figured at more than 1 billion birds.
>
> **Movie:** *John James Audubon: Drawn from Nature* (PBS American Masters, 2007)

**One flock of passenger pigeons darkened the sky for three days.**

John James Audubon painted the birds of North America at their real size. His book *The Birds of America* contains 435 of these paintings. It came out from 1827 to 1838, and Audubon worked on it for about 18 years.

Audubon was riding to Louisville, Kentucky, in 1813 when a flock of passenger pigeons, wild pigeons that flew in huge flocks, passed over him. In his own account, that one flock darkened the sky for three days. He did the arithmetic himself and put it at more than 1 billion birds.

**Why this story is here:** About a hundred years after Audubon's count, the passenger pigeon was gone.

### Henry David Thoreau

> **Who:** A writer who also worked as a land surveyor, measuring woodlots for a living.
>
> **When and where:** He lived from 1817 to 1862. He lived in a cabin at Walden Pond, near Concord, Massachusetts, from July 4, 1845, to September 6, 1847.

**He lived at Walden Pond for two years, two months and two days.**

Henry David Thoreau wrote about wild nature, and he earned his money measuring land. He worked as a land surveyor, measuring and mapping woodlots, pieces of land kept for growing trees.

Thoreau moved into a cabin he had built himself at Walden Pond, near Concord, Massachusetts, on July 4, 1845. He lived there until September 6, 1847. His book about those years, *Walden*, came out in 1854.

Thoreau gave a talk called "Walking" in Concord on April 23, 1851. It came out as an essay in June 1862, just after he died. In it he wrote that "in Wildness is the preservation of the world," using preservation to mean keeping something safe.

## 1850 to 1900

**Era 7 of 10 · 1850 to 1900 · about 21 minutes**

US officials gave away the land they had taken from Native nations in these fifty years, and hunters killed nearly all the bison, the animals the Plains nations lived on. Members of Congress passed laws in 1862 for giving the land to railroad companies, to settlers called homesteaders and to the states for colleges. By one historian's count, US officials took more than 1.5 billion acres from the nations between 1776 and 1887.

On the Plains, hide hunters killed the bison for their skins, which are called hides. About 30 million bison lived there in the early 1800s, and fewer than 1,000 were left by 1900. Army generals wrote in favor of the killing, to take away the nations' food and force them onto reservations. Professional hunters killed passenger pigeons at their nesting grounds, a reported 50,000 birds a day for months at one Michigan nesting in 1878.

The first parks were made on Native land, and soldiers and officials forced out the people who lived there. Volunteer soldiers drove the Ahwahneechee people out of Yosemite Valley in 1851, and President Abraham Lincoln signed the Yosemite Grant in 1864. Yellowstone became the first national park in 1872, and its superintendent had the Tukudika people forced out in 1879. John Muir helped found the Sierra Club in 1892, in part to protect the forests and mountains of California's Sierra Nevada.

### Land taken from Native nations, in acres

US officials took more than 1.5 billion acres from Native nations from 1776 to 1887, more than half the area of the United States today. They took it by treaty and by executive order, a command from the president. Historian Claudio Saunt, of the University of Georgia, made this count from maps that Charles C. Royce published in 1899, which show every piece of land US officials took from the nations by treaty or order.

Once officials had taken the land, it counted as public land, land that US officials claimed for the nation. Members of Congress then passed it on to railroads, settlers and colleges.

**Railroads.** President Abraham Lincoln signed the Pacific Railway Act on July 1, 1862. Under it, railroad companies received "every alternate section of public land, designated by odd numbers," meaning every other square mile. For each mile of track, a company got five of these sections on each side of the line.

The act also states: "The United States shall extinguish as rapidly as may be the Indian titles to all lands falling under the operation of this act." With those words, which use extinguish to mean end, the lawmakers told officials to end the nations' legal ownership of the land along the railroads as fast as they could. From 1850 to 1871, members of Congress granted railroad companies about 130 million acres, an area bigger than California.

**Homesteads.** Lincoln signed the Homestead Act on May 20, 1862. Under it, a person could claim up to 160 acres of public land and keep it after living on it or farming it for five years. Over the life of the law, US officials handed 270 million acres to private owners this way, 10 percent of the area of the United States. A National Park Service page states that much of this land "was seized from the Native Americans who previously inhabited it." Seized means taken by force.

**Colleges.** Lincoln signed the Morrill Act on July 2, 1862. Under it, each state received 30,000 acres of public land for each of its senators and representatives in Congress. State officials sold the land to pay for colleges of "agriculture and the mechanic arts," which means farming and the use of machines.

A page about the act from the National Archives, the office that keeps the government's records, states that the act "resulted in the expropriation," or taking away, "of over 10 million acres from Native American tribal lands."

The reporters Robert Lee and Tristan Ahtone traced that land for the magazine *High Country News* in 2020. US officials got it through takings that the reporters call "violence-backed," meaning that violence or the threat of it forced the nations to give the land up. Officials paid the nations less than $400,000 in all. By the early 1900s, sales of the land had raised $17.7 million for 52 universities, more than 40 times what the nations were paid. In 2020 the universities still held more than 500,000 acres of it.

One example comes from Minnesota. Four bands of Dakota people signed treaties at Mendota and Traverse des Sioux in the summer of 1851. The reporters describe the conditions as "withholding of rations," or food supplies, "the threat of violence, enforced starvation." The Dakota received "less than 2.4¢ per acre."

**Allotment.** Chapter 2 tells how federal officials used the Dawes Act of 1887 against the nations. Here is what became of the land. Under the act, federal officials cut reservations into plots, 160 acres for the head of a family and less for others, and opened the land left over, which they called "surplus," to white settlers.

By the National Park Service's count, reservation land fell from 138 million acres in 1887 to 48 million acres in 1934. About 90 million acres, 65 percent of what the nations held, passed out of their hands.

### Fire made a crime, 1850

California's state lawmakers passed a law called the *Act for the Government and Protection of Indians* on April 22, 1850. Under Section 10 of the law, it was a crime to set the prairie on fire, or to refuse to help put out a prairie fire. Section 10 states that such people "shall be subject to fine or punishment, as a Court may adjudge proper." That means a judge would choose the punishment.

Section 10 speaks of "any person or persons." The whole law was about Native people, though, and burning the land on purpose was a Native practice. Reporters at the news outlet ICT write that under California law, cultural fire, burning done by Native people to care for the land, was "explicitly banned" for more than 150 years.

**The rest of the law.** Under other sections of the same law, white people could take custody of Native children, meaning control over the children and where they lived, until the children were grown. Officials could also arrest Native people they called "vagrants," meaning people with no home or work. Within 24 hours, officials could hire those people out "to the best bidder" for up to four months. This was forced labor: the arrested person had to work for whoever won the bidding.

### Yosemite and the Ahwahneechee

The Ahwahneechee people lived in Yosemite Valley, in California's Sierra Nevada mountains, and their headman, or leader, was Tenaya. In 1851 volunteer soldiers burned their villages and their food and drove them out of the valley.

**How it started.** James D. Savage was a trader who had moved onto Ahwahneechee land to mine gold and to trade. Ahwahneechee fighters attacked his trading post on the Fresno River in December 1850, took his supplies and killed two of his men. One account says Chowchilla fighters joined them.

California's governor, John McDougal, called for volunteers early in 1851 after attacks on miners and traders. About 200 men on horseback formed the Mariposa Battalion, a unit of soldiers, on January 24, 1851. Their commander was Major James D. Savage. State officials supplied their camp gear and supplies. Federal money paid for the battalion, through federal officials called US Indian commissioners.

**What the battalion did.** The battalion's men first entered Yosemite Valley on March 27, 1851, by the Park Service's date. A National Park Service page states that they "systematically burned villages and food supplies and forced men, women, and children away from their homes."

Lafayette H. Bunnell rode with the battalion and wrote an account of it in 1880. He writes that in Captain John Boling's company, men on foot had orders "to burn any caches they might find," the hidden stores of food. Acorns were the people's main food for the winter.

On the upper San Joaquin River, next to Yosemite, Bunnell says the huts and "adjacent supplies of acorns, were at once given to the flames." He estimated the acorns burned there at 800 to 1,000 bushels, and pine nuts too. A bushel fills a large basket, so that was 800 to 1,000 large baskets of winter food.

In Yosemite Valley, Bunnell found that "nearly all the acorns had been burnt." The battalion's men marched Tenaya and his people to a reservation on the Fresno River.

**Tenaya's son.** Battalion men held Tenaya's youngest son and another young man as hostages, prisoners held to force others to do something, tied to a tree. Bunnell writes that the guards let the two untie themselves "in order to fire upon them, expecting to kill them both." One guard shot Tenaya's son in the back and killed him. The other young man escaped.

Bunnell describes the shooter only as "a young man" urged on by "an old Texan," and he names neither of them. Captain Boling told the guards "that they had committed murder." Bunnell writes that "no punishment was ever inflicted upon the perpetrators," meaning the men who did it. Tenaya was killed in 1853 in a fight with Mono Lake Paiutes. Accounts of why the fight happened differ.

**The park.** President Lincoln signed the Yosemite Grant on June 30, 1864. With it, US lawmakers set aside Yosemite, the first land the nation's lawmakers set aside to protect and to keep for public use. California's state officials took charge of it under the grant. Yosemite became a national park on October 1, 1890.

The National Parks Conservation Association, a group that campaigns for the parks, states in an article that the 1890 park came "with authorization," or official permission, "to remove anyone making homes without permission." Ahwahneechee families came back and lived in the valley anyway, and they worked for the hotels and the park.

**The count of the dead.** A Park Service page states that by 1910, more than 90 percent of the Ahwahneechee who had lived in the valley were dead or missing. The page does not say how each of them died or went missing.

To Tu Ya, also called Maria Lebrado Ydrte, saw the 1851 raid as a child. She was Tenaya's granddaughter. She saw the battalion's men destroy her home in Yosemite Valley, and during the raid she saw her uncle murdered.

Because she was Tenaya's granddaughter, Tenaya's sons were her uncles, so the son the guard shot was one of them. The Park Service page does not say whether he was the uncle she saw killed, and it does not name who killed that uncle. The page describes To Tu Ya as the last survivor of the raid. She came back to Yosemite in the late 1920s and told her story.

**By 1887:** Railroads, homesteaders and colleges held hundreds of millions of acres that had belonged to Native nations, and US officials had begun cutting up the reservations that were left.

### Hide hunters and the railroads

Hide hunters, who sold the skins for money, killed most of the Plains bison. About 30 million bison lived on the Plains in the early 1800s. By 1900 fewer than 1,000 were left, about one for every 30,000, and one count in 1884 found only 325. The hunters called themselves "buffalo runners," because bison are also called buffalo.

**The railroads.** The first railroad across the country, finished in 1869, carried hunters out to the herds. Leather makers at a tannery in Pennsylvania, a place where animal skins are made into leather, found a way in 1871 to turn bison hides into leather for harnesses and machine belts. Each hide sold for $1 to $3. The Kansas Pacific and the Atchison, Topeka and Santa Fe railroads carried the hides east.

Lieutenant Colonel Richard Irving Dodge, an army officer, estimated that three railroads carried about 1.4 million hides from the southern Plains in 1872, 1873 and 1874. He had a count from one line, the Santa Fe, and guessed that the other two lines carried as many.

Dodge also figured that hunters wasted so many hides before 1874 that about three bison were killed for every hide shipped. By his estimate, that adds up to more than 3 million bison killed by white hunters in those three years, and about 1.2 million more killed by Native hunters, about 4.4 million in all. William T. Hornaday of the Smithsonian Institution reported these totals in 1889. They are Dodge's estimates, not counts.

Dodge described Kansas in the fall of 1873: "Where there were myriads of buffalo the year before, there were now myriads of carcasses. The air was foul with a sickening stench." (Myriads means huge numbers, and carcasses are the dead bodies of animals.)

### Officers who wanted the bison gone

Army officers encouraged the hide hunters. Several officers also wrote that killing the bison would force the Plains nations onto reservations.

**Known:** No one has found a written order to kill off the bison.

**Disputed:** Historians disagree about whether the army had a plan anyway. Robert Utley writes that the army had no official policy, but that officials cheered the killing because it would force the nations onto reservations. David Smits argues that the army followed a plan that was mostly never written down. William Dobak doubts that the army caused much of the killing at all.

**What the officers wrote.** General William T. Sherman wrote to General Philip H. Sheridan in May 1868 that the nations would go wherever the bison were. He suggested inviting hunters from England and America to a great buffalo hunt to "make one grand sweep of them all." In 1869 Sherman became the commanding general of the whole army.

Sheridan answered in a letter of October 15, 1868, that the best way was "to now make them poor by the destruction of their stock, and then settle them on the lands allotted to them." By "stock," Sheridan meant the nations' bison and horses. A month earlier, another officer had written in his journal that his orders were to kill all the buffalo his men found.

Not every officer agreed. Colonel William B. Hazen wrote in 1872 that killing the buffalo to take away the nations' food was a false idea, and he called the killing a waste.

**Help from the forts.** Officers at army posts, among them Forts Griffin, Dodge, Concho and Richardson, gave the hunters protection and supplies and helped them ship hides. In 1873 hide hunters asked Dodge, then in command at Fort Dodge, what he would do if they hunted south into Texas, on hunting grounds reserved for the Kiowa, Comanche, Southern Cheyenne and Arapaho under the 1867 Medicine Lodge Treaty. One of the hunters later recalled that Dodge told them to hunt buffalo where the buffalo were.

Colonel Nelson A. Miles wrote out his plan in December 1874, during the Red River War of 1874 and 1875: "I would leave as few Indians or Buffalo behind, and as little for them to subsist on as possible." (To subsist is to stay alive.) In a book about his own life, published in 1896, he wrote that the buffalo and the Indian had both stood in the way of what he called civilization.

### Officials in Washington

Leaders of the Plains nations asked officials to stop the hunters, and the officials did not stop them. A Sioux delegation, a group sent to speak for its people, asked Columbus Delano in 1871 to keep white hunters out of Sioux country. Delano was the Secretary of the Interior, one of the president's top officials. He refused.

Colonel Edward Wynkoop had been the Cheyenne's Indian agent, the US official in charge of their reservation. In 1872 he reported words that Little Robe, a Cheyenne chief, had said to him: "What do you think my people ought to do when they see their cattle, the buffaloes, killed by your race when they are not hungry?" Only Wynkoop's report records these words.

Delano's yearly report for 1873 records that he "would not seriously regret the total disappearance of the buffalo from our western prairies, in its effect on the Indians." He saw the loss of the bison as "a means of hastening their sense of dependence upon the products of the soil and their own labors." He meant that without the bison, Native people would have to live by farming.

**A law that never was.** Members of both houses of Congress passed a bill to protect the bison in 1874. Under it, no one but a Native person could kill a female bison, or more males than needed for food, and the fine would be $100 for each animal. President Grant did not sign the bill. Members of Congress ended their meeting before he signed it, so the bill never became law. This is called a pocket veto.

Grant had promised a Southern Cheyenne and Arapaho delegation that hunters would be kept out of their country. Their agent, John D. Miles, wrote on September 30, 1874, that "they looked in vain." They watched for the hunters to be kept out, and the hunters kept coming.

Texas lawmakers brought in their own bill to protect the bison in 1875. The *Handbook of Texas*, published by the Texas State Historical Association, states that Sheridan protested it, "contending that peace with the Indians could be maintained only if their food supply was eliminated." The lawmakers did not pass the bill.

**The speech in Texas.** A speech that Sheridan is said to have given against the bill comes from one source only. The former hide hunter John R. Cook wrote about it in 1907, about 32 years later. In Cook's account, Sheridan told the lawmakers to give each hunter "a medal of bronze, with a dead buffalo on one side and a discouraged Indian on the other." Cook also has him say: "let them kill, skin, and sell until the buffaloes are exterminated," or killed off completely.

**Disputed:** No official record of Sheridan speaking to the lawmakers has turned up. Smits reports that, but he judges Cook believable. Writing in *Harper's* magazine in 2008, Christopher Ketcham called the speech "believed to be apocryphal," which means probably made up.

**By 1890:** One count in 1884 had found only 325 bison left on the Plains, and no federal law protected the ones that remained.

### Frank Mayer

> **Who:** A buffalo runner, one of the hunters who killed bison for their hides, from 1872 to 1878, who later said the army helped the runners.
>
> **When and where:** The Plains in the 1870s. He died in Fairplay, Colorado, in February 1954, at a reported age of 104.

**He said the army gave hunters "free ammunition, all you could use."**

Frank H. Mayer killed bison for their hides from 1872 to 1878. At about age 100 he told his story to a writer, Charles B. Roth. It came out in 1958 as a book, *The Buffalo Harvest*, four years after Mayer died.

The book describes the business: the rifle, the wagons, the skinners who cut the hides off the dead animals, and hides that sold for a dollar or two each.

Mayer said that "army officers in charge of plains operations encouraged the slaughter of buffalo in every possible way." They gave hunters free ammunition. "All you had to do to get it was apply at any frontier army post," he said. "I received thousands of rounds in this way." Mayer also quoted an officer he did not name: "if we kill the buffalo we conquer the Indian."

The last part of the book records Mayer's regret for what the runners did.

**Not known:** Mayer told the story when he was very old, the numbers in it are his own, and some people have questioned even his age.

### The pigeon nestings

Professional hunters killed passenger pigeons where the birds gathered to nest, and by the mid-1890s the wild flocks were almost gone. At their peak, an estimated 3 to 5 billion passenger pigeons lived in North America. By one estimate they made up four of every ten birds on the continent.

About 136 million pigeons nested across some 850 square miles of Wisconsin in 1871, by one estimate. Professional netters, who caught the birds in nets, and shooters worked one of the last great nesting grounds, near Petoskey, Michigan, in 1878. They killed a reported 50,000 birds a day for months. Railroads carried the dead birds to city markets. Hunters learned where each big nesting was from telegraph messages, which were sent over wires.

### Yellowstone and the Tukudika

President Grant signed a law on March 1, 1872, and under it Yellowstone became the first national park. In the law, members of Congress set the park apart "for the benefit and enjoyment of the people." The Tukudika, a band of Mountain Shoshone also called the Sheep Eaters, already lived there. A Park Service page states that they had lived in that area "for thousands of years." The Shoshone, Bannock, Crow, Blackfeet and other nations also have ties to the park's land.

Chapter 1 tells this removal briefly, and here is how it happened. Philetus W. Norris, Yellowstone's superintendent from 1877 to 1882, found a Tukudika camp near Bunsen Peak in the fall of 1879 and asked the Indian agent at Fort Washakie for help. The agent, whom the writer John Clayton names as James Patten, sent a party of Shoshone, who brought the Tukudika to the Wind River Reservation. In the words of a Park Service page, the Tukudika "were forcibly removed to reservations."

**Not known:** The records do not say how many Tukudika were taken or what force the Shoshone party used, and the letters between Norris and Patten have not survived.

**Keeping people out.** Norris met in Washington with a Crow delegation in the spring of 1880, while officials were asking the Crow to give up 1.6 million acres. That spring Norris also got a "solemn promise" from people at the Lemhi agency, the office of another Indian agent, and at the Wind River Reservation to stay out of the park.

A Park Service page states that early superintendents "actively discouraged tribes from visiting the newly established park to hunt or collect resources." In his reports, Norris called the Tukudika "feeble," or weak, "and harmless." He wrote that Native people stayed away from the geysers out of "superstitious awe," meaning fear that came from beliefs about spirits. Clayton reports that historians and Shoshone scholars treat that claim as false. With it, Norris helped support a false story that no one had lived on the park's land.

**The court case.** Justices of the US Supreme Court ruled on Native hunting in and around the park in 1896. Wyoming officials had arrested a Bannock man named Race Horse for hunting elk in Wyoming. He hunted under the 1868 Fort Bridger Treaty, in which US officials promised a right to hunt on "unoccupied lands."

Justice Edward Douglass White wrote the Court's decision, in *Ward v. Race Horse*. He called the treaty right "temporary and precarious," which means easily lost, and he ruled that the right had ended when Wyoming became a state. After the ruling, hunting under the treaty in and around Yellowstone was a crime under Wyoming law.

More than 120 years later, on May 20, 2019, the justices threw out the 1896 decision in a different case, *Herrera v. Wyoming*, about the Crow people's own treaty. They ruled that the Crow treaty right to hunt had not ended when Wyoming became a state.

### The forest reserves

George Perkins Marsh, a scholar from Vermont who also represented the United States in other countries, published a book called *Man and Nature* in 1864. In it, Marsh argued that whole societies collapse when their people destroy the forests and wear out the soil. Writers at the Forest History Society and the National Park Service link his book to the Forest Reserve Act of 1891. Under that law, a president could set aside public forest land. Those forest reserves were the start of the national forests.

### John Muir

> **Who:** A writer born in Scotland whose magazine articles made Yosemite known across the country, and who helped found the Sierra Club.
>
> **When and where:** He lived from 1838 to 1914. He came to California in 1868 and was president of the Sierra Club from 1892 to 1914.
>
> **Movie:** *John Muir in the New World* (PBS American Masters, 2011)

**The Sierra Club started with 182 members in San Francisco.**

John Muir was born in Scotland in 1838 and came to California in 1868. He wrote magazine articles about Yosemite. Readers across the country learned about Yosemite from them, and protecting it became a national cause.

Muir and others founded the Sierra Club in San Francisco on May 28, 1892. The founders wrote down the club's aims. One was "to explore, enjoy, and render accessible the mountain regions of the Pacific Coast," which means to make them easy for people to reach. Another was to win the help of "the people and government in preserving the forests and other natural features of the Sierra Nevada."

Muir was the club's first president, and he led it until he died in 1914. In May 1903 he took President Theodore Roosevelt camping in Yosemite.

**If you remember one thing:** US officials gave away the land they had taken from Native nations, hunters killed nearly all the bison the Plains nations lived on, and soldiers and officials forced Native people out of the first parks.

- 1851: Volunteer soldiers drive the Ahwahneechee out of Yosemite Valley.
- 1862: Lincoln signs the Pacific Railway Act, the Homestead Act and the Morrill Act, the laws under which officials give away public land.
- 1872: Yellowstone becomes the first national park. In 1879 its superintendent has the Tukudika forced out.
- 1872 to 1874: Three railroads carry about 1.4 million bison hides east.

**Next:** After 1900, presidents put hundreds of millions of acres under federal protection, and some of that land had belonged to Native nations.

## 1900 to 1950

**Era 8 of 10 · 1900 to 1950 · about 16 minutes**

President Theodore Roosevelt and the federal officials after him took charge of hundreds of millions of acres in the first half of the 1900s, and some of that land had belonged to Native nations. Roosevelt alone put about 230 million acres under federal protection from 1901 to 1909, in national forests, parks, bird refuges (land where wild birds are kept safe) and monuments.

Glacier National Park, created in 1910, lies mostly on land that federal officials count as sold by the Blackfeet in 1895. Before the sale, about 600 Blackfeet had starved to death in one winter. Many Blackfeet say they only rented the land out.

The last passenger pigeon died in the Cincinnati Zoo in 1914. In Yellowstone, park managers poisoned wolves until they killed the park's last pack in 1926.

On the southern Plains, farmers had plowed up the grass that held the soil, and in the 1930s that soil blew away. Forest Service leaders ordered crews in 1935 to bring every wildfire under control by 10 the next morning. Young men in the Civilian Conservation Corps planted billions of trees.

### Roosevelt's acres

The 230 million acres Roosevelt protected, an area bigger than Texas, included 150 national forests, 5 national parks, the first 18 national monuments, 51 federal bird reservations and 4 national game preserves. Some counts combine the bird reservations and game preserves into one figure of 55.

A national forest is public land where federal foresters, people trained to study and manage forests, look after the trees. The U.S. Forest Service began in 1905, with Gifford Pinchot as its first chief, and its foresters ran the national forests.

**The first refuge.** Roosevelt named Pelican Island, in Florida, the first federal bird reservation on March 14, 1903. It became the first piece of what is now the National Wildlife Refuge System.

Roosevelt signed the Antiquities Act on June 8, 1906. Under it, a president could protect land by proclamation, an official announcement, and land protected this way is called a national monument. Devils Tower became the first one that September 24.

**Whose land.** Many national forests were made from the ancestral lands of Native nations, the lands their ancestors lived on. Arthur Blazer, the president of the Mescalero Apache Tribe, told a Senate committee in 2018 that the US Department of Agriculture, which runs the Forest Service, "has acknowledged that the vast majority of federal forest lands are carved out of the ancestral homelands of Indian tribes."

Forest Service staff say the same of the national forests in North Carolina, and the staff of Olympic National Forest say it of all the land in present-day Washington. A Park Service web page states that Devils Tower is sacred to dozens of Native nations, including the Arapaho, Cheyenne, Crow, Kiowa, Lakota and Shoshone. The Lakota name for it is Mato Tipila, which means Bear Lodge.

### Theodore Roosevelt

> **Who:** The president from 1901 to 1909. In those years he put about 230 million acres of land under federal protection.
>
> **When and where:** The White House, 1901 to 1909. Yosemite, California, in May 1903.
>
> **Movie:** *The Roosevelts: An Intimate History* (PBS, Ken Burns, 2014), a documentary about the whole Roosevelt family

**Roosevelt slept under a pile of about 40 wool blankets.**

President Theodore Roosevelt went camping in Yosemite with John Muir, the first president of the Sierra Club, in May 1903. Muir wanted the best of the wild land left wild. The two men spent three nights sleeping in the open.

They camped first under the Grizzly Giant, a giant sequoia tree, on May 15, and that was the night of the blankets. The next night, near Sentinel Dome, a snowstorm dropped five inches of new snow on top of about five feet of old snow. They spent the last night in a meadow near Bridalveil Fall.

### Glacier and the Blackfeet

Most of Glacier National Park lies on land that federal officials say the Blackfeet sold to the United States in 1895. The deal came after a winter in which about 600 Blackfeet starved to death. Many Blackfeet say the tribe only rented the land out and never sold it.

**Before the sale.** US Army troops attacked Heavy Runner's camp of Piikani people, one of the Blackfeet peoples, on the Marias River in 1870, as Chapter 2 tells. By the best estimate they killed about 177 men, women and children. The army's own count was 173, and the National Parks Conservation Association's figure is more than 200.

By 1880 hide hunters had killed nearly all the bison. Members of Congress then cut the money for annuities, the food and goods that US officials had promised a tribe every year in a treaty as payment for land.

**The Starvation Winter.** Early storms held up supplies in the winter of 1883 and 1884. In December a wagonload of bacon reached the Blackfeet agency near Browning, the office of the US official who ran the reservation. The Montana Historical Society's textbook describes the bacon as "so old it was contaminated with maggots," the young of flies, which feed on rotting meat.

The textbook states that 600 Blackfeet died of starvation, about one in four of the tribe. Other accounts give counts from 500 to 800. The Assiniboine, another nation, lost about 300 people. That winter is known as the Starvation Winter.

No record names the person who sent the spoiled bacon. John Young had been the Blackfeet's Indian agent, the US official in charge of their reservation, since December 1876. He went to Washington in 1881 and got $15,000 put back into the reservation's budget. He protested against shrinking supplies and more cuts to the agency's budget.

No one acted on his protests, and in September 1883 he resigned. The records do not name the officials who ignored him. The new agent, R. A. Allen, did not arrive until the middle of March 1884.

**The sale.** The same textbook states: "After Starvation Winter, the tribes sold the only resource they had left: land." The Blackfeet sold a strip of about 800,000 acres in 1895 for $1.5 million. Prospectors, people who search for gold and other metals, hoped the strip held gold.

Many Blackfeet say the tribe offered the land as a 99-year lease, which is a rental, and never sold it. They also say that because of a surveying mistake, US officials took another 45,000 acres. Under the agreement, the Blackfeet kept the right to hunt, fish, cut wood and gather plants on the land.

Little Dog told the US commissioners, the officials sent to buy the land, that the Blackfeet "did not ask the government to come and buy their land." White Calf, a Piikani chief, said of Chief Mountain: "Chief Mountain is my head. Now my head is cut off."

**The park.** Prospectors found no gold. The strip became a forest reserve in 1897, under the 1891 law that let a president set aside public forest land. Members of Congress made most of the strip Glacier National Park on May 11, 1910. After that, an article by the National Parks Conservation Association states, the Blackfeet's rights on the land "essentially vanished."

After the park was created, judges ruled that the Blackfeet's right to go into the mountains in the park no longer counted. A 2019 *High Country News* report states that hunting and fishing rights ended in 1910 and that only the right to gather plants remained. By 1912 a park ranger had arrested a Blackfeet tribal member for hunting in the park. The accounts of that arrest name neither the ranger nor the hunter.

A judge of a US District Court ruled in 1932 that the Blackfeet had no right to hunt in the park. In 1973 a judge ruled that Blackfeet people could enter the park without paying the entrance fee.

### Hetch Hetchy

People who wanted to protect land split into two sides over Hetch Hetchy Valley. Gifford Pinchot's side said conservation meant using the land carefully, forever. The side of John Muir, the first president of the Sierra Club, said the best of it should be left wild.

Hetch Hetchy Valley lies inside Yosemite National Park. After the earthquake and fire of 1906, San Francisco's city leaders wanted the valley for a reservoir, a lake made by a dam to store water. Pinchot backed the city. Muir and the Sierra Club fought the dam for years.

Members of Congress sided with the city and passed the Raker Act, which allowed the city to dam the valley. President Wilson signed it on December 19, 1913. Muir died a year later, on December 24, 1914. The O'Shaughnessy Dam was finished in 1923, and the valley is under water today.

Members of Congress passed the National Park Service Organic Act on August 25, 1916, partly in reaction to the Hetch Hetchy fight. With it they created a new federal office, the National Park Service, whose officials took charge of protecting the parks.

### Gifford Pinchot

> **Who:** The first American trained as a professional forester, and the first chief of the U.S. Forest Service, until President Taft fired him. Later he was twice governor of Pennsylvania.
>
> **When and where:** He lived from 1865 to 1946. He ran the Forest Service from 1905 to 1910.
>
> **Movie:** *Seeking the Greatest Good* (WVIA and PBS, 2013)

**President Taft fired him on January 7, 1910.**

Gifford Pinchot was the first American trained as a professional forester. He defined conservation as "the greatest good to the greatest number for the longest time." To Pinchot, that meant using the public lands carefully and keeping them useful forever.

Pinchot became the first chief of the Forest Service in 1905. In 1909 and 1910 he fought in public with the Secretary of the Interior over claims to federal coal lands in Alaska, and President Taft fired him for refusing to obey his bosses.

Pinchot and John Muir had been friends until they took opposite sides over Hetch Hetchy. Pinchot later served two terms as governor of Pennsylvania.

### The last passenger pigeons

In about a century, the passenger pigeon went from an estimated 3 to 5 billion birds to none. After the last confirmed wild bird was shot, a few people reported seeing wild passenger pigeons until about 1902, and no one confirmed those sightings.

### Press Clay Southworth

> **Who:** A 14-year-old boy who shot the last confirmed wild passenger pigeon.
>
> **When and where:** Pike County, Ohio, on March 24, 1900.

**His family stuffed the bird and gave it buttons for eyes.**

Press Clay Southworth, age 14, shot a passenger pigeon in Pike County, Ohio, on March 24, 1900. He asked his mother first, then used his family's 12-gauge shotgun. His bird is the last wild passenger pigeon that anyone has confirmed. Southworth told the story himself decades later.

His family had the bird mounted, which means stuffed and set up for display. It got buttons for eyes, so people called it "Buttons." The Ohio History Connection, in Columbus, keeps it today.

**Martha.** The last passenger pigeon of all was a bird named Martha. She died at the Cincinnati Zoo on September 1, 1914, at about 29 years old. Her body was frozen in a 300-pound block of ice and shipped to the Smithsonian Institution, which still has it. Sol Stephan, the zoo's general manager, had cared for Martha, and he saved her feathers in a cigar box.

**Not known:** Nobody can say for sure where Martha came from, because Stephan's accounts changed over the years and the zoo's own records do not agree with each other.

### Yellowstone's wolves

Park managers in Yellowstone killed at least 136 wolves between 1914 and 1926, and in 1926 they killed the park's last wolf pack. The National Park Service gives these numbers. The *Idaho Capital Sun* and other later accounts report that park rangers shot the last two wolf pups near Soda Butte that year.

The managers used poison, especially one called strychnine, which they put inside the bodies of dead animals for wolves to eat. Dan Stahler, a biologist, told *Smithsonian* magazine in 2026: "We're talking crates and crates of this poisoning." In 1915 the park's superintendent called wolves "a decided menace," or danger, to the animals they hunted.

The killing in Yellowstone was part of a program to wipe out predators, animals that hunt other animals for food, on public lands across the whole country. The program's targets were wolves, bears, cougars and coyotes. Rewards for dead wolves went back almost 300 years. The first recorded wolf bounty in the colonies, a reward paid for each dead animal, dates from Massachusetts in 1630.

### Why did the Plains soil blow away?

Wind carried away the soil of the southern Plains in the 1930s, because farmers had plowed up the grass that held it. Wheat sold at high prices during World War I. Farmers with tractors plowed up tens of millions of acres of shortgrass, the short native grass of the southern Plains. Its roots formed sod, a thick mat of roots and earth that held the soil in place.

A drought, a long time with too little rain, began in 1931. With the sod gone, the dry soil blew away.

**What blew away.** By the count of the US Department of Agriculture, about 35 million acres of farmland, an area about the size of Iowa, had been ruined for growing crops by December 1934. The same count listed 100 million acres that had lost all or most of their topsoil, the top layer of soil where crops grow. Another 125 million acres were losing it fast. In 1935 alone, an estimated 850 million tons of topsoil blew off the southern Plains.

The worst single dust storm struck on April 14, 1935, a day called Black Sunday. It crossed the Plains as a black wall of dust moving at 60 miles an hour.

That spring, a soil scientist named Hugh Hammond Bennett was testifying, or giving evidence, at a hearing in Washington while dust from the Plains darkened the sky outside. Bennett said: "This, gentlemen, is what I've been talking about." Accounts of the hearing differ about the day. Some put it in late March 1935, and others in early April.

Members of Congress declared soil erosion, the wearing away of soil by wind or water, "a national menace." The Soil Conservation Service began on April 27, 1935, with Bennett as its director. The methods that followed included contour plowing, which means plowing along the curves of a slope instead of up and down it. They also included shelterbelts, rows of trees planted to slow the wind, and planting grass on the land again.

### Caroline Henderson

> **Who:** A farmer and writer who homesteaded in the Oklahoma Panhandle and stayed on her land through the dust years.
>
> **When and where:** Near Eva, Oklahoma, from 1907. She lived from 1877 to 1966.

**When the dust came, she kept farming and did not leave.**

Caroline Henderson graduated from Mount Holyoke College. In 1907 she began homesteading near Eva, in the Oklahoma Panhandle, claiming public land and farming it for years in order to own it. When the dust storms came in the 1930s, she stayed on her land.

Henderson wrote letters about the dust years. In one, dated June 30, 1935, she described trying to rescue her home from wind-blown dust "which penetrates wherever air can go." Soon everything was covered again, she wrote, with dust that ran "from a film to actual ripples on the kitchen floor." She swept her floors with sawdust that had oil mixed in.

The *Atlantic Monthly* magazine printed her letters as "Letters from the Dust Bowl." One appeared in May 1936. That same month, Henry A. Wallace, the Secretary of Agriculture, wrote to praise her.

Across her whole life, her letters run from 1908 to 1966. The University of Oklahoma Press later collected them in a book, *Letters from the Dust Bowl*.

### Every fire put out

Forest Service rules from 1935 to 1978 required crews to control every wildfire by the morning after someone spotted it. A fire called the Big Burn covered 3 million acres of the Northern Rockies in 1910 and killed at least 78 people. After it, Forest Service leaders tried to put out every fire. In 1935 they made the "10 a.m. policy," under which crews had to bring each fire under control by 10 o'clock the morning after it was spotted.

**What the stopping did.** For thousands of years Native people had burned the eastern forests on purpose. Researchers at Penn State call the total stopping of fires after about 1940 "an ecologically transformative event in all forests." They mean it changed how the plants and animals of every forest lived together.

**The men who made it work.** About 3 million young men worked in the Civilian Conservation Corps, a federal work program, from 1933 to 1942. Because the corps had so many men, Forest Service leaders could carry out the 10 a.m. policy. Estimates of the trees the corps members planted run from more than 2 billion to 3.5 billion, and the figure most often given is about 3 billion. The corps members also fought fires, worked to stop erosion and did building work in more than 800 parks.

Forest Service officials worked with the Ad Council, an advertising group, to start the Smokey Bear campaign in 1944. Its slogan, "Only YOU can prevent forest fires," dates from 1947. In 1950 a bear cub was rescued from the Capitan Gap fire in New Mexico, and the cub became the living Smokey Bear.

### Aldo Leopold

> **Who:** A forester for the U.S. Forest Service who got the first wilderness area set aside, and later wrote *A Sand County Almanac*.
>
> **When and where:** He lived from 1887 to 1948. He worked in New Mexico in the 1920s and later in Wisconsin.
>
> **Movie:** *Green Fire: Aldo Leopold and a Land Ethic for Our Time* (2011)

**In 1924 he got the world's first official wilderness area set aside.**

Aldo Leopold began as a forester for the U.S. Forest Service. In 1924 he got the Gila Wilderness, in New Mexico, set aside. It was the first area in the world officially named a wilderness area, which is land kept free of roads and buildings. Frank C. W. Pooler, the Forest Service official in charge of the region, approved Leopold's plan on June 3, 1924.

The Gila Wilderness covered about 755,000 acres. Under the plan the area had no roads, cabins or other buildings. People could still hunt and fish there, and ranchers could let their animals feed on its grass.

**Whose homeland it was.** The Gila had been a homeland of the Chiricahua and Warm Springs Apache, and Mogollon and Mimbres people had also lived in the region. Before Leopold came to New Mexico, US Army soldiers, federal officials and white settlers had forced many Apache people onto reservations. Army soldiers imprisoned Chiricahua and Warm Springs Apache people for defending their land.

Of the thousands of Chiricahua and Warm Springs Apache who had lived in the Gila, only a few hundred were still alive after the Army imprisoned them. US officials later sent the survivors to Fort Sill, Oklahoma, more than 500 miles away.

**Later years.** Leopold taught at the University of Wisconsin. He bought a worn-out farm in Wisconsin and rebuilt its soil and its woods. On April 21, 1948, he had a heart attack and died while helping to fight a grass fire on a neighbor's land.

His book *A Sand County Almanac* came out in 1949, the year after he died. In it he called for a "land ethic," an ethic being a set of ideas about right and wrong. In Leopold's land ethic, people count themselves as members of the land community and stop acting as its conquerors. The book includes his "green fire" essay, about watching a wolf die after it was shot.

**If you remember one thing:** Federal officials took charge of protecting hundreds of millions of acres, much of it Native land, while the passenger pigeon, Yellowstone's wolves and the soil of the southern Plains were lost.

In 1900: The Forest Service, the National Park Service and the first national monument did not exist yet, and a boy in Ohio shot the last confirmed wild passenger pigeon.

In 1950: Crews had orders to put out every wildfire by 10 the next morning, and a bear cub rescued from a fire in New Mexico had become the living Smokey Bear.

**Next:** After 1950 a chemical called DDT thinned the eggshells of bald eagles, a river in Cleveland caught fire, and families found buried chemicals seeping into their basements.

## 1950 to 2000

**Era 9 of 10 · 1950 to 2000 · about 16 minutes**

Pollution that people could see pushed members of Congress to pass the big laws that protect the land, air and water, and then people began to count who lived next to the waste. DDT, a chemical for killing insects, left bald eagles with eggs so thin they broke. In 1969 an oil well blew out off Santa Barbara, California, and oil and trash on the Cuyahoga River in Cleveland caught fire.

Between 1970 and 1973, members of Congress passed the Clean Air Act, the Clean Water Act and the Endangered Species Act, and the Environmental Protection Agency opened.

Park Service officials forced the last Native families in Yosemite Valley out of their homes in 1969. Later in the 1970s, families at Love Canal, in Niagara Falls, New York, found chemicals seeping into their basements. They lived on and beside more than 20,000 tons of buried chemical waste.

Residents of Warren County, North Carolina, lay in the road in 1982 in front of trucks carrying poisoned soil to a landfill, a place where trash and waste are buried, in a mostly Black community. In a 1983 federal study, investigators looked at four landfills for dangerous waste in eight southeastern states. All four were in areas where Black residents were 38 to 90 percent of the people.

In a 1987 national study, Charles Lee found that race was the strongest clue to where such waste sites stood. That year Rev. Benjamin F. Chavis Jr. named the pattern "environmental racism."

### DDT and the eagles

DDT is a pesticide, a chemical made to kill insects, and it was in wide use from the mid-1940s. DDT thinned the eggshells of raptors, birds that hunt other animals, until the eggs broke in the nest. By 1963 only 417 nesting pairs of bald eagles were left in the lower 48 states, meaning every state except Alaska and Hawaii.

### Rachel Carson

> **Who:** A marine biologist, a scientist who studies life in the sea, and a writer. She had worked as a writer and editor for the U.S. Fish and Wildlife Service. She wrote *Silent Spring*.
>
> **When and where:** She lived from 1907 to 1964. *Silent Spring* came out in September 1962. She died in Silver Spring, Maryland.
>
> **Movie:** *Rachel Carson* (PBS American Experience, 2017)

**She went on television to defend her book while sick with cancer.**

Rachel Carson first became famous for a book called *The Sea Around Us*. In September 1962 she published *Silent Spring*. In it she laid out what persistent pesticides, the kind that stay in soil, water and living things for a long time, were doing to birds, soil, water and people.

People in the chemical industry attacked her, and Carson answered them with evidence. She spoke on the television program *CBS Reports* on April 3, 1963. By then she was already sick with breast cancer, and she died of it on April 14, 1964. Officials of the Environmental Protection Agency banned DDT in 1972, eight years later.

### Yosemite's last village

Park Service officials evicted, or forced out of their homes, the last Native families who lived in Yosemite Valley in 1969. Then they destroyed their cabins.

**How the village began.** Ahwahneechee and Paiute families lived in a village in the valley in the 1920s and worked in the park. The Ahwahneechee are also called the Southern Sierra Miwok. Native workers helped build the Ahwahnee Hotel, which was finished in 1927. Park Service workers built cabins at a new site, called Wahhoga, in 1933, for families that park officials had moved out of the old village.

Charles Goff Thomson was Yosemite's superintendent from 1929 to 1937. A history published by Brigham Young University states that Thomson wanted to use the new village to control the Native people in the park. The families paid rent, and they paid for their power and water.

Park Service officials made a housing rule in 1953 under which only permanent government workers could live in the village. As each home fell empty, the officials destroyed it. In 1969 they evicted the families who were still there.

**How it ended.** Deborah Tucker's parents lived in the village. She told the National Parks Conservation Association: "The Park Service came and burned the cabins out." Some later magazine accounts say the empty cabins were burned in a firefighting training exercise. A Park Service web page states that a Native home near Camp 4 "was razed," or torn down completely, "in the 1960s when the last Indian village was removed from Yosemite Valley."

Jay Johnson, the last Native park worker who lived in the valley, retired and left in 1996.

**Not known:** No record names the official who ordered the village torn down in 1969. Erin Davenport, a Yosemite park historian, told the National Parks Conservation Association that park historians have found no record of why it was done either.

### The river that burned and the Santa Barbara oil spill

Oil and trash floating on the Cuyahoga River in Cleveland, Ohio, caught fire on June 22, 1969. The fire burned for about 20 to 30 minutes before it was brought under control. The river had burned at least 13 times since 1868. The 1912 fire killed five men, and the 1952 fire did $1.3 million in damage.

**Whose waste it was.** The river ran past steel mills and other factories. A 2019 *Smithsonian* magazine article names American Ship Building, the Sherwin-Williams Paint Company, Republic Steel and Standard Oil as Cleveland companies whose success left the river full of poisonous waste. A Cleveland State University history states that the river was "polluted from decades of industrial waste."

The 1969 fire started in oil and trash caught under two railroad bridges near the Republic Steel mill. A flare thrown from a passing train most likely lit it. Investigators from Cleveland's Bureau of Industrial Wastes looked into the fire. No record names the company whose oil burned.

Editors at *Time* magazine published a story on the burning river on August 1, 1969, and readers across the country saw it. Carl Stokes was Cleveland's mayor and the first Black mayor of a major US city. The day after the fire, he held a news conference at the river and called on the state and federal governments to act.

**Santa Barbara.** Earlier the same year, oil had spilled on the coast of California. Five months before the Cuyahoga fire, on January 28, 1969, an oil well blew out under Platform A. It was a Union Oil Company drilling platform about 5.5 miles southeast of Santa Barbara, California. A blowout is an uncontrolled burst of oil and gas up a well. Officials of the U.S. Geological Survey, the federal agency that approved offshore drilling, had excused Union Oil from federal safety rules when they approved its drilling permit.

Federal and state investigators found that extra steel pipe lining the well would have prevented the blowout. About 100,000 barrels of oil, more than 4 million gallons, leaked out by December 1969, and the oil blackened the beaches at Santa Barbara. By one estimate, about 9,000 birds died.

### Earth Day and the new laws

An estimated 20 million Americans took part in Earth Day events on April 22, 1970, a day set aside for events about protecting the land, air and water. The 1970 census, the national government's count of everyone in the country, counted 203,392,031 people in the United States, so about one in ten Americans took part. Senator Gaylord Nelson organized Earth Day with Denis Hayes.

**The new laws.** The National Environmental Policy Act became law on January 1, 1970. Under it, federal officials had to study how a big federal project would affect the land, air and water before they went ahead. The Environmental Protection Agency, called the EPA, opened on December 2, 1970. Its officials enforce the federal laws against pollution.

Members of Congress passed the Clean Air Act in 1970. In 1972 EPA officials banned DDT, and members of Congress passed the Clean Water Act. The Endangered Species Act, for kinds of plants and animals in danger of dying out, became law on December 28, 1973.

After the DDT ban, bald eagles came back. They grew from 417 nesting pairs in 1963 to about 10,000 pairs by 2007. That year, federal officials took the bald eagle off the endangered list.

### Love Canal

Workers for Hooker Chemical buried more than 20,000 tons of chemical waste in an old canal in Niagara Falls, New York, from the 1940s into the 1950s. Families later lived on and beside it, and the chemicals seeped into their homes.

**What was buried.** The canal, called Love Canal, covered 15 acres. Hooker Chemical and Plastics Corporation began using it in 1942. The sources put the waste at about 21,000 tons, and they differ slightly on the exact amount and on whether the dumping ended in 1952 or 1953. In a 1981 report, officials of New York State's health department wrote that Hooker "admits" burying 21,800 tons.

Investigators later found more than 200 chemical compounds there. The timeline lists 200 tons of dioxin, a group of chemicals that cause cancer and harm babies before they are born.

**Who knew.** A federal judge wrote in a 1994 decision that Hiram Young, Hooker's works manager, was responsible for the company's waste disposal. The court record does not say who first decided to use the canal as a dump.

Hooker's lawyer visited the dump in 1946 and saw children with swimsuits. He warned the company's president that Hooker was "running a real hazard," and he suggested guards or a fence. Hooker's executives talked about his ideas, but they never built the fence. City officials of Niagara Falls also used the canal as a dump for the city's own waste until 1953.

**The sale for $1.** Hooker sold the covered canal to the Niagara Falls Board of Education for $1 in 1953. Hooker's officials wrote into the deed "a disclaimer of responsibility for future damages due to the presence of buried chemicals," a statement that refused blame for any harm the chemicals did later. That same year, Hooker officials told Board members "that homes could not be built at the Canal site."

**The school.** The members of the Board of Education had a public elementary school, the 99th Street School, built on the middle third of the canal in 1954. That January their architect wrote that the builders had dug into two pits of chemical waste, some of it in 55-gallon drums. He wrote that it was "poor policy to attempt to build over this soil."

Building of homes on 97th and 99th Streets, beside the canal, began in 1954. The Board of Education later sold part of the canal land to others. Board members talked in 1957 about a plan to sell a piece of it to developers for building homes. A Hooker lawyer told the Board on November 7, 1957, that the land was "unsuitable," or not fit, "for construction" where "basements, water lines, sewers and such underground facilities would be necessary."

Ninety-nine homes had backyards that touched the canal by the spring of 1978. No record names the companies that built the homes.

**The chemicals come up.** By the 1970s, chemicals were coming up into yards and basements. On October 3, 1976, chemicals from the buried waste were reported "seeping into basements of homes." In November 1976, testers found 15 chemicals, including three toxic chlorinated hydrocarbons, a kind of chemical that contains chlorine.

Families in the neighborhood counted miscarriages, the deaths of unborn babies before they can live outside the mother's body. They also counted birth defects, problems in a baby's body that are there when the baby is born, and illness. Dr. Beverly Paigen, a scientist, found a "high rate of birth defects and miscarriages among Love Canal families."

**The emergency.** Dr. Robert Whalen, New York State's health commissioner, the state's top health official, declared a state of emergency on August 2, 1978. That is an official order saying that people are in danger and need help fast. He closed the 99th Street School and ordered pregnant women and children under 2 moved out.

President Jimmy Carter approved emergency federal money on August 7 so that state officials could buy homes. State officials moved the first 236 families out, at a cost of $10 million. Other counts say 239 families.

**The lawsuit.** New York State's lawyers sued Occidental Petroleum, which owned Hooker by then, and two Hooker companies for $635 million in April 1980.

Scientists in a study paid for by the EPA reported on May 17, 1980, that they had found chromosome damage in 11 of the 36 residents tested. Chromosomes are the strands in each cell that carry a person's genes. Damage to them can raise the risk of cancer, and of birth defects in the person's children.

**The second emergency.** That month, residents held two EPA officials for about six hours to demand that the rest of the families be moved. Carter then declared a second emergency, which opened the way to move 710 more families. In all, about 950 families left.

Members of Congress passed a law called Superfund in December 1980. Under it, federal officials could make companies that polluted a site pay for cleaning it up. Occidental agreed in 1994 and 1995 to pay New York State and the federal government more than $225 million for the cleanup and the moves.

### Lois Gibbs

> **Who:** A 27-year-old housewife at Love Canal whose son went to the 99th Street School. She started the Love Canal Homeowners Association.
>
> **When and where:** Love Canal, in Niagara Falls, New York, from 1978 to 1980.
>
> **Movie:** *Lois Gibbs and the Love Canal* (CBS television movie, 1982), with Marsha Mason playing Gibbs

**She was 27, and her son's school stood on buried chemicals.**

Lois Gibbs was a housewife when she learned about the buried chemicals at Love Canal. Her son went to the 99th Street School, which stood on and beside the old canal. Officials brushed off her worries. In August 1978 she organized her neighbors into the Love Canal Homeowners Association.

Gibbs later founded the Center for Health, Environment & Justice. Through it, she has helped other neighborhoods fight the pollution near their homes. In 1990 she won the Goldman Environmental Prize, an award given to people who protect the environment. A CBS television movie about her aired on February 17, 1982.

### Warren County

Residents of Warren County, North Carolina, lay down in the road in front of trucks in September 1982. The trucks carried soil poisoned with PCBs to a new landfill near Afton, a mostly Black community. An exhibit by the University of North Carolina Library and other histories describe the protest as the start of the environmental justice movement. People in that movement fight a pattern in which companies and government officials put polluting sites next to poor, Black, brown and Native communities.

PCBs are a group of chemicals made by people. They were used in electrical, heating and hydraulic equipment, machines worked by liquid under pressure. An EPA web page states that PCBs cause "a variety of adverse health effects," or harmful effects, "in animal and humans."

**Where the soil came from.** The poisoned soil came from roadsides. Robert Ward, of the Ward Transformer Company of Raleigh, hired Robert Burns and his sons to get rid of oil that contained PCBs. The Burns family ran a business called Transformer Sales, in Allegany, New York. In the summer of 1978, the Burns men sprayed about 31,000 gallons of the oil from their trucks at night, on the shoulders, or edges, of about 240 miles of roads in 14 North Carolina counties.

**The site.** Governor James B. Hunt Jr. announced a plan in December 1978 to bury about 60,000 tons of the soil scraped from those roadsides. He chose a landfill at Afton, in Warren County. State officials bought farmland there from a farmer who was in money trouble. Warren County had the highest share of African American residents in North Carolina, and it was one of the poorest counties in the state. The Afton community was 84 percent African American.

Most people near Afton drank water from wells. The water table there, the level underground where the soil is full of water, was only about 5 to 10 feet down. The U.S. Commission on Civil Rights later wrote that the site "was not scientifically the most suitable site, because the water table was a mere 5-10 feet below the surface."

**The protest.** Residents formed a group called Warren County Citizens Concerned About PCBs and sued. They lost in 1982. The trucks began to deliver the soil that September, and protesters lay in the road. Officers arrested about 500 people, and one later count says more than 500.

State officials went ahead and built the landfill. Governor Hunt promised that the soil would be cleaned of poison once a way to do it existed. The cleanup was finished by 2003 and cost $17.1 million.

### Counting who lives near the waste

The authors of two studies in the 1980s counted who lived near hazardous waste sites, the places that hold waste that can harm people's health. Both found the answer tied to race.

**The 1983 study.** Members of Congress asked the US General Accounting Office, a federal office that investigates for Congress, to study landfills for hazardous waste in eight southeastern states. Its report came out on June 1, 1983.

The report lists four landfills in those states that took other people's waste for pay. One was the Warren County landfill. The others were in Sumter County, Alabama, Chester County, South Carolina, and Sumter County, South Carolina. All four were in areas where Black residents made up 38 to 90 percent of the population.

**The 1987 study.** The Commission for Racial Justice of the United Church of Christ published a national study in 1987, *Toxic Wastes and Race in the United States*. Charles Lee wrote it. He found that race was "the most potent variable in predicting where these facilities were located," more powerful than household income or the value of homes. The race of the people nearby predicted where a waste site stood better than how much money they had.

When the report came out, the commission's leader, Rev. Benjamin F. Chavis Jr., called the pattern "environmental racism." He meant "intentionally selecting communities of color for wastes disposal sites and polluting industrial facilities." Communities of color are places where most people are not white. The authors of a follow-up study in 1994 found that people of color were "47 percent more likely to live near a hazardous waste facility than white Americans."

President Bill Clinton signed Executive Order 12898 on February 11, 1994. In it he directed the officials of federal agencies to find and deal with pollution that fell hardest on communities of color and poor communities. A 2007 report by the United Church of Christ states that the EPA "has failed to implement" the order, meaning its officials had not carried it out.

### Wolves back in Yellowstone

Gray wolves brought from Canada were released in Yellowstone National Park starting in January 1995, and by the end of 1996, 31 wolves had been moved there. Park managers had killed the park's last wolf pack in 1926. For most of the 1900s, elk had eaten the park's willows and other woody plants so heavily that the plants could not grow tall. After the wolves came back, the willows began to grow.

**Known:** Park Service scientists wrote in 2019 that most studies agree on that growth.

**Disputed:** Scientists still debate how much of that growth the wolves caused, by hunting the elk and changing where the elk fed.

**If you remember one thing:** Members of Congress passed the big federal laws against pollution in the 1970s, and then residents and researchers showed that waste sites stood far more often beside Black and poor neighborhoods.

**One number:** In 1963 there were 417 nesting pairs of bald eagles in the lower 48 states. By 2007, after the DDT ban, there were about 10,000, roughly 24 times as many.

**Next:** After 2000 came the warmest year ever measured, fires that burned millions of acres, and a fight in Louisiana over a chemical plant beside a school.

## 2000 to Today

**Era 10 of 10 · 2000 to Today · about 15 minutes**

The land grew hotter and drier after 2000, and fires grew bigger. The year 2024 was the warmest ever measured, both for the whole world and for the lower 48 states. Heat and drought dried forests that had filled up with fuel during about a century of stopping fires.

Fires burned about 4.2 million acres of California in 2020. Lake Mead and Lake Powell, two reservoirs on the Colorado River, fell to record lows in 2021 and 2022. Fire managers now set fires on purpose again, and Yurok people teach cultural fire to government fire crews.

Fights over pollution and protected land went on. Shell's managers agreed in 2002 to pay to move the families of Old Diamond, a Louisiana neighborhood beside a Shell chemical plant. Federal lawyers sued the owner of a plant near an elementary school in LaPlace in 2023, and they dropped the suit in 2025.

President Donald Trump cut Bears Ears National Monument, in Utah, by about 91 percent on July 13, 2026. As of September 26, 2026, the land he removed was open to mining claims, and lawsuits against the cut were waiting in federal court.

Some animals came back. Bald eagles grew from 417 nesting pairs in 1963 to about 71,400 in the 2020s, by the newest count. The bison, fewer than 1,000 in 1900, now number more than 400,000, most of them in herds raised for sale. Wolves, wiped out of Yellowstone by 1926, numbered 2,797 in seven western states at the end of 2022.

### The warmest year

Scientists at NOAA, the federal agency that tracks weather and climate, reported in January 2025 that 2024 was the warmest year on record for the planet. The world averaged 1.29 degrees Celsius, about 2.3 degrees Fahrenheit, above the average for the 20th century, the years 1901 to 2000. Scientists at NASA and other groups agreed. The lower 48 states averaged 55.5 degrees Fahrenheit in 2024, which was 3.5 degrees above their 20th-century average. Seventeen states set records.

### Why are the fires bigger?

After about a century of stopping fires, the woods held heavy loads of fuel, the dead wood and brush that burns. Heat and drought dried that fuel out.

**The Camp Fire.** The Camp Fire of November 8, 2018, killed 85 people in California and destroyed nearly all of the town of Paradise. About 19,000 buildings burned. Those figures are the ones given by the encyclopedia *Britannica* and by a timeline from the National Institute of Standards and Technology, a federal science agency. It was the deadliest wildfire in the United States in a century.

**The 2020 fires.** Fires burned about 4.2 million to 4.3 million acres of California in 2020, an area bigger than Connecticut and about 4 percent of the state. By the count of CAL FIRE, California's fire agency, that was the most in modern records. One fire, called the August Complex, passed 1 million acres. It became known as the first "gigafire" in the state's modern history, meaning a fire that burned more than a million acres.

Fire managers at government agencies now set fires on purpose to burn off fuel. These planned fires are called prescribed burns, and prescribed burning is official policy again.

### Margo Robbins

> **Who:** A member of the Yurok Tribe who helped found the Cultural Fire Management Council, to bring traditional burning back to Yurok land.
>
> **When and where:** The Klamath River country of northern California. The first community burn was in 2012, and the council formed in 2013.

**She wanted straight hazel shoots to weave baskets for her grandchildren.**

Margo Robbins, a member of the Yurok Tribe, wanted hazel for weaving baskets. When hazel is burned, it sends up new shoots that grow straight, and weavers need straight shoots. Her first goal was to weave baskets to carry her grandchildren.

Robbins and others held their first community burn on Yurok land along the Klamath River in 2012. In 2013 they formed the Cultural Fire Management Council. Cultural fire, burning done by Native people to care for the land, was the practice California's lawmakers had made a crime in 1850, in the same law that let officials hire out Native adults to the highest bidder.

After the council's burns, deer came back to the burned ground at Weitchpec. Council members now run training exchanges, called TREX, that teach cultural burning to fire crews.

### The shrinking river

The Southwest had its driest 22 years in at least 1,200 years from 2000 to 2021. Scientists from UCLA and Columbia University found this by studying tree rings, which show how much a tree grew each year. They published their study in the journal *Nature Climate Change* in February 2022. They found that about 42 percent of how bad the drought was came from climate change caused by people.

About 40 million people depend on the Colorado River for water, and so does much of the country's winter vegetable crop. Lake Mead and Lake Powell, two reservoirs on the river, fell to record lows in 2021 and 2022. By the middle of 2022, Lake Mead was about a quarter full.

**The cut.** Officials of Arizona, California and Nevada agreed in May 2023 to cut their use of the river by at least 3 million acre-feet through the end of 2026. News reports gave that figure from the federal Bureau of Reclamation. An acre-foot is enough water to cover one acre of land one foot deep. The cut is about a tenth of the water those three states are allowed to take, and federal officials agreed to pay the states for the water they gave up.

### Cancer Alley

The stretch of Louisiana between Baton Rouge and New Orleans holds a long line of chemical plants. A 2007 report by the United Church of Christ describes this strip as "so-called 'cancer alley,' the chemical manufacturing corridor between Baton Rouge and New Orleans," a corridor being a long, narrow strip of land. The towns of Norco and LaPlace are both in it.

The same report records who lived near commercial hazardous waste sites across the country in 2000, using census figures. In neighborhoods with such sites, 56 percent of the people were people of color, against 30 percent elsewhere. The poverty rate was 18 percent near the sites and 12 percent elsewhere. Forty of the 44 states with such sites showed the same gap.

### Margie Richard

> **Who:** A schoolteacher from the Old Diamond neighborhood of Norco, Louisiana, who led her neighbors' campaign to make Shell pay to move them away from its plant.
>
> **When and where:** Norco, Louisiana. The campaign ended in 2002. She won the Goldman Environmental Prize in April 2004.

**Her family's home stood 25 feet from a Shell plant's fence.**

Four generations of Margie Richard's family lived in the Old Diamond neighborhood of Norco, Louisiana. Their home stood 25 feet from the fence of a Shell Chemical plant. Shell had bought land in Diamond and built the plant there in the early 1950s. The neighborhood sat between the chemical plant and a Shell refinery, a plant that turns crude oil into fuels.

Residents of Old Diamond kept a record of the cancers and birth defects among their neighbors.

**The fires.** Gas leaked from a Shell pipeline in 1973, and a spark from a lawnmower set it on fire. The fire burned Leroy Jones, age 16, to death while he was cutting grass. It also burned to death Helen Washington, who was resting on her porch. An explosion at the Shell refinery in 1988 killed seven workers and damaged homes in Diamond.

In a 2004 interview with *Grist* magazine, Richard remembered: "The elder people were always coughing ... black soot falling on the grass, on our houses." She also said: "My sister died at a very early age from a rare bacterial disease."

**The campaign.** Richard led the neighborhood's campaign for about 13 years. Residents tested their own air with buckets built to catch air samples. They took their case to Shell's shareholder meetings, where the company's owners gather, and to Shell in the Netherlands.

Shell's managers agreed in 2002 to pay to move every Old Diamond family that wanted to leave. They also agreed to cut the plant's emissions, the pollution it sends into the air, by 30 percent, and to put $5 million into a community fund. Shell paid at least $80,000 for each house and $50,000 for each trailer, about $30 million in all.

Richard became the first African American to win the Goldman Environmental Prize, in April 2004.

### The plant by the school

Federal lawyers sued the owner of a plant in LaPlace, Louisiana, in 2023, and they dropped the suit in 2025. The plant released a chemical likely to cause cancer into the air near an elementary school.

The plant is in St. John the Baptist Parish (a parish in Louisiana is like a county in other states). The company DuPont built the plant to make neoprene, a kind of man-made rubber. The Japanese company Denka bought it about 2015, according to AP news reporting in 2025. To make neoprene, the plant used a chemical called chloroprene, and it released chloroprene into the air.

EPA scientists found in 2010 that chloroprene is "likely to be carcinogenic to humans," meaning likely to cause cancer. They also found that children breathing it build up a lifetime risk of cancer faster than adults do.

**The school.** More than 300 children went to the 5th Ward Elementary School in 2023, about 450 feet from the plant, or about a football field and a half.

The EPA's recommended long-term level for chloroprene is 0.2 micrograms in each cubic meter of air, a microgram being one millionth of a gram. In their 2023 lawsuit, federal lawyers reported the averages at the five air monitors closest to the plant. The lowest was "more than four times" the recommended level, and the highest was "more than 14 times" that level.

AP reporters wrote in March 2025 that the community around the plant is about 59 percent Black. They also reported that the plant's air pollution posed the highest cancer risk from any single source to a mostly Black population in the country.

**The lawsuit.** Lawyers for the US Justice Department, acting for the EPA under President Biden, sued Denka under the Clean Air Act on February 28, 2023. They asked the court to force deep cuts in the plant's chloroprene pollution. A trial was set for April 2025.

Under President Trump, Justice Department lawyers dropped the suit on March 7, 2025. Their press release stated that dropping it carried out the president's order called "Ending Radical and Wasteful Government DEI Programs and Preferencing." DEI stands for diversity, equity and inclusion.

Denka's managers announced on May 13, 2025, that the LaPlace plant would not start making chloroprene again "for an indefinite period," meaning with no end date. They named losses of more than $100 million, rising costs, falling production and problems keeping enough staff. Articles in trade magazines also listed the pollution rules as a reason. The plant was not making chloroprene as of May 2025.

### Plastic in the rain

More than 1,000 tons of tiny plastic pieces fall each year on protected land in the western United States. Janice Brahney, a scientist at Utah State University, and her team found this in a study published in the journal *Science* on June 12, 2020. The pieces are called microplastic, bits of plastic too small to see easily, and they fall with rain and with dust. The team sampled 11 parks and other protected areas.

Each year's total is about as much plastic as more than 120 million plastic bottles. Most of the pieces were tiny fibers from clothing.

### Comebacks

People nearly wiped out the bald eagles and the bison, and wiped out the wolves of Yellowstone and of public lands across the country. All three live in far larger numbers now. Hide hunters killed the bison, park managers and others poisoned and shot the wolves, and DDT that people sprayed thinned the eagles' eggshells.

**Eagles.** The U.S. Fish and Wildlife Service counted about 71,400 nesting pairs of bald eagles in the 2020s, against 417 in 1963. The figure of about 10,000 pairs for 2007 and the figure for the 2020s come from different counts. For the newer one, the service's crews surveyed nests from the air in 2018 and 2019, used bird watchers' reports for places they could not fly over, and built a computer model to estimate the total. The service's officials said the eagles had kept increasing fast since their survey of 2009.

**Bison.** About 30 million bison lived on the Plains in the early 1800s, and fewer than 1,000 were left by 1900. A count in 2008 found about 20,500 Plains bison in 61 herds kept for conservation. It also found about 400,000 bison in commercial herds, which are raised for sale. A U.S. Fish and Wildlife Service web page now lists about 420,000 bison in commercial herds.

**Wolves.** State wildlife officials estimated 2,797 wolves in seven western states at the end of 2022. Park Service biologists counted 108 wolves in nine packs in Yellowstone National Park at the end of 2024. At the end of 2025, the park's lead wolf biologist, Dan Stahler, gave a count of 84 wolves in eight packs. People are still fighting in court over whether wolves should stay on the endangered list.

### Land given back

Chapter 2 tells how members of Congress gave the National Bison Range, a bison refuge on the Flathead Reservation in Montana, back to the Confederated Salish and Kootenai Tribes in 2020.

**How the tribes lost it.** President Theodore Roosevelt signed a law on May 23, 1908, under which federal officials could spend money to buy land on the reservation for a bison range. The tribes objected strongly. Federal officials took the land anyway and paid about $1.56 an acre.

The Fifth Amendment to the Constitution requires fair payment when the government takes private property for public use. Judges of the U.S. Court of Claims, a federal court that heard claims for money against the national government, ruled in 1971 that the price had been below the land's fair value. That made the taking a break of the Fifth Amendment. The judges awarded the tribes about $231,548.

**Wahhoga.** Park Service officials in Yosemite agreed in 2018 to share the care of Wahhoga, the site of the valley's last Native village, for 30 years. They share it with the American Indian Council of Mariposa County. A roundhouse, a round building for gatherings, was finished there in the winter of 2025.

### Bears Ears

Three presidents have created, cut, restored and cut again Bears Ears National Monument in Utah since 2016. As of September 26, 2026, most of the land was out of the monument and open to mining claims, and no court had ruled on the latest cut.

**Created and cut.** President Obama created the monument on December 28, 2016, with 1.35 million acres. Five tribes had proposed it: the Hopi Tribe, the Navajo Nation, the Ute Mountain Ute Tribe, the Ute Indian Tribe and the Pueblo of Zuni.

President Donald Trump cut it by about 85 percent in December 2017, to about 201,876 acres. President Biden restored it on October 8, 2021. In June 2022, the five tribes signed an agreement with the Bureau of Land Management and the Forest Service to manage the monument together.

**The 2026 cut.** Trump signed a proclamation on July 13, 2026, that cut Bears Ears to 121,096 acres, a cut of about 91 percent. Reporters for the *Moab Sun News* published these figures on July 18, 2026. About 1.24 million acres left the monument. What is left is two pieces, Shash Jáa, about 106,816 acres, and Indian Creek, about 14,279 acres.

The proclamation lists minerals in the removed land: silver, copper, uranium, vanadium and zinc. The same day, Trump cut Grand Staircase-Escalante National Monument from about 1.87 million acres to about 181,500 acres.

**The tribes' commission.** In the July proclamation, Trump also ended the Bears Ears Commission. Elected representatives of the five tribes sat on it, and they had managed the monument with federal officials under the 2022 agreement. Reporters for the *Moab Sun News* wrote that a committee that only gives advice took its place, with tribes holding 5 of about 15 seats.

The tribes say Interior Department officials promised in writing in June 2025 to ask the commission's views before any change to the boundaries, and that no one asked it before July 13. Their statement said: "Our Tribes were not informed of or asked about this decision, and that's unacceptable."

**The mining claims.** Under the proclamation, the removed land opened on September 11, 2026, to new mining claims, mineral leasing, grazing and timber cutting. A mining claim is a legal claim to the right to mine minerals on public land, and mineral leasing means renting out the right to take minerals from the ground.

By noon on September 11, 16 claims had been recorded in San Juan County. By September 23 staff of a conservation group had counted 23 claims in the land taken out of Bears Ears, 20 of them filed by one mining company.

**In court.** On September 2, 2026, three sets of groups that had sued over Trump's 2017 cut went back to the federal court in Washington and asked it to hear the new cut as well. They argue that the Antiquities Act of 1906 lets a president create a monument and does not let a president undo one. Utah's members of Congress called the cuts "a return to an appropriate application of the Antiquities Act."

The tribes' own 2017 case, *Hopi Tribe v. Trump*, is still pending, which means undecided, in the same court. As of September 26, 2026, no court had ruled on the 2026 cuts, and no judge had ordered them stopped.

**If you remember one thing:** After 2000 the land grew hotter and drier and the fires grew bigger, bald eagles, bison and wolves came back by the thousands, and the fights went on over chemical plants beside Black neighborhoods and over Native land such as Bears Ears.

**Still open:** No court has yet decided whether a president can undo a national monument another president made. The tribes' 2017 case and the suits filed in September 2026 were still waiting in federal court on September 26, 2026.

**The three questions, answered**

- How did Native nations shape the land before Europeans came? They burned the eastern forests on purpose, again and again, to keep them open and grow food for game, and they planted corn, beans and squash together to keep the soil good.
- What happened to the 30 million bison and the billions of passenger pigeons? Hide hunters, carried by the railroads and helped by army officers who wanted the Plains nations' food gone, left fewer than 1,000 bison by 1900. Netters and shooters killed the pigeons at their nestings, and the last one died in a zoo in 1914.
- Who was pushed out when parks were made, and who lived next to the waste? Native people were pushed out: the Ahwahneechee in Yosemite, the Tukudika in Yellowstone, the Blackfeet at Glacier. Studies from 1983 on found waste sites far more often beside Black and poor neighborhoods.

**What changed:** Americans cleared, sold and wore out the land that Native nations had kept with fire, then began to protect parts of it by law, and fire crews now learn the old burning from the Yurok.

**Five dates to keep**

- 1642: Miantonomi describes what English settlers are doing to the land.
- May 20, 1785: Members of Congress pass the Land Ordinance, the start of the grid.
- March 1, 1872: Yellowstone becomes the first national park.
- September 1, 1914: Martha, the last passenger pigeon, dies.
- April 22, 1970: About 20 million Americans take part in Earth Day.

**Not known:** Nobody counted the bison on the Plains before 1500, and the usual figure of about 30 million comes from the early 1800s.

**Where to go:** Devils Tower National Monument, the first national monument, which the Lakota call Mato Tipila, or Bear Lodge.

**Next:** Chapter 4, Immigration to America. It asks why people left home to come here, and whom Americans tried to keep out.
