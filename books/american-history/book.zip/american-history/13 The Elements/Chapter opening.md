# Chapter 13: The Elements

**Chapter 13 of 37 · The Elements · 10 eras · about 85 minutes**

**From the first ironworks to the uranium mines, the people whose land held the metal often lost that land. Many of the people who dug and handled it paid with their freedom or their health.**

A lump of pure copper that weighs 3,708 pounds has been at the Smithsonian, in Washington, since 1860. It once lay in the Ontonagon River country near Lake Superior. The Ojibwe had known it for a long time, held it sacred and made offerings at it. In 1843 a Detroit merchant hauled it away, and a federal agent made him hand it over to the government. The Keweenaw Bay Indian Community asked for it back in 1991, and Smithsonian officials refused in 2000.

This chapter follows the elements people here dug up, shaped, named and made, from copper hammered 9,500 years ago to the hunt for element 120. The gold, copper and uranium in this chapter lay under Cherokee, Ojibwe, Sioux and Navajo land, so watch what happened to the people who lived there. Watch, too, who did the work with the metal: Scottish prisoners, enslaved ironworkers, hatters, dial painters, men making a lead additive for gasoline, and uranium miners. Nobody in the United States discovered a new element until 1940. Between 1940 and 1974, teams in American labs made or found at least twelve.

**Three questions this chapter answers**

- Who lost their land when Americans found gold and copper on it?
- What did the people in charge say about the radium, lead and uranium that poisoned workers?
- When did someone in the United States first discover a new element?

**Five minutes?** Read "Lead in gasoline and paint" in 1900 to 1950.

**Can skip:** "Meanwhile in Europe", "Lead at Galena", "Elements at home". The chapter still makes sense without them.

## Before 1500

**Era 1 of 10 · Before 1500 · about 4 minutes**

Native miners near Lake Superior were digging and shaping copper at least 9,500 years ago. A 2021 study places them among the world's first coppersmiths, people who make things out of copper. All the land that later became the United States was Native land before 1500. No miner or metalworker from these thousands of years is known by name.

Copper is one of the chemical elements. Everything is made of atoms, tiny pieces far too small to see, and an element is a substance made of only one kind of atom. Copper, iron, gold and silver are all elements.

**Numbers and rows.** Each element has a number. It counts the protons, tiny particles in the center of each atom, so copper is element 29 because every copper atom has 29 protons. Chemists arrange the elements in order of their numbers in a chart called the periodic table.

The numbers rise from left to right along each row, and the elements in each column often act alike. The seventh row ends with element 118. Heavier elements, such as element 120, which scientists are trying to make, would go in an eighth row.

Nobody anywhere on Earth knew what an element was before 1500. People here mined copper, gathered salt and colored earth, and chose hard stone for tools. In some regions they also worked iron that had fallen from space. They turned these materials into tools, beads, ornaments and paint.

### Copper from Lake Superior

In the Lake Superior country, in what are now Michigan, Wisconsin and Minnesota, veins of pure copper metal, called native copper, run through the rock. Native miners dug it out and hammered it into spear points, knives, fishhooks and ornaments. They also made awls, thin pointed tools for punching holes.

**How old the work is.** David Pompeani, a scientist who studies rocks and the Earth, led a team that dated the copper work. They used 53 radiocarbon dates, ages measured from things that were once alive, such as wood or bone. The team published its results in 2021 in *Radiocarbon*, a magazine for scientists' studies. The copper work began at least 9,500 years ago, about 3,500 years earlier than scientists had thought. It was busiest between about 7,000 and 5,000 years ago.

The oldest known copper work in the Middle East is a pendant, an ornament that hangs from a cord, about 8,700 years old. So the Lake Superior work is as old as the earliest copper work known in the Middle East, or older. Writers at the journal *Science* reported the study under the headline "Ancient Native Americans were among the world's first coppersmiths."

Traders carried Lake Superior copper hundreds of miles along Native trade routes. Along the same routes they carried shells, blue-green turquoise stone, and obsidian, a natural glass that forms from volcanic lava.

### Iron from space

The only iron metal people here could work before 1500 came from meteorites, pieces of rock or metal from space that have fallen to Earth. Nobody here yet got iron out of rock by smelting, which means heating rock until the metal inside it melts out.

**The beads from Havana.** Archaeologists, the scientists who dig up and study what people left behind long ago, found 22 iron beads in 1945 in burial mounds near Havana, Illinois. Native people of the Hopewell way of life, which lasted in the eastern woodlands from about 2,000 to 1,600 years ago, had built the mounds over the graves of their dead. They made the beads about 2,000 years ago.

Timothy McCoy of the Smithsonian and four other scientists studied the beads and published their findings in 2017. The iron came from the Anoka meteorite, an iron meteorite from Minnesota. So people had carried or traded the metal several hundred miles before anyone made it into beads. The beadmakers shaped the iron by hammering it, the same way people worked copper.

### Gold, silver, ochre, salt and stone

In some regions, metalworkers made ornaments of gold and silver. People also gathered salt and traded it, and they made tools of flint and chert, two hard stones.

**A compound.** Red and yellow ochre, a colored earth, went into paint. Ochre gets its color from iron oxide, a compound. A compound is two or more elements joined together, and iron oxide is iron joined with oxygen.

## The 1500s

**Era 2 of 10 · The 1500s · about 1 minute**

Spanish explorers crossed the Southeast and the Southwest in the 1500s on long journeys called expeditions, looking for gold and silver. They found no cities of gold in the lands that later became the United States. The land was still Native land from coast to coast, and people here worked the same copper, gold and meteorite iron as before. The Spaniards brought some metal of their own into their few outposts, the small forts and settlements they built.

### Spanish gold hunters, 1539 to 1543

Hernando de Soto led a Spanish expedition across the Southeast from 1539 to 1543. Francisco Vázquez de Coronado led another across the Southwest from 1540 to 1542. Both men were following stories of cities full of gold, and neither found one. In the same century Spaniards did find large amounts of silver, but in Mexico and South America, not in the future United States.

**No science of elements yet.** Nobody here or anywhere else had a science of elements. In Europe, the modern idea of an element had not been written down. People there who studied what things are made of still worked by alchemy, the older practice that came before chemistry. Alchemists tried to turn ordinary metals, such as lead, into gold by heating them and trying to make them purer. They kept most of their methods secret.

## The 1600s

**Era 3 of 10 · The 1600s · about 5 minutes**

The first ironworks English colonists built here stood on the land of the Powhatan, a union of Native towns in eastern Virginia, and Powhatan fighters destroyed it in 1622. At the second, at Saugus in Massachusetts, workers melted iron out of ore, rock that contains metal, from 1647 until about 1670. The company's men forced Scottish prisoners of war to work there. People in Europe, Asia and Africa had been smelting iron for thousands of years already.

### Falling Creek, 1619 to 1622

English colonists began building an ironworks on Falling Creek, near present-day Richmond, in 1619. They built it for the Virginia Company, the English company that King James I had allowed to start a colony in Virginia in 1606. By March 1622 the furnace was ready to make iron, or close to it.

Opechancanough was the head chief of the Powhatan. The English colony stood on Powhatan land, and English colonists had been moving farther up the James River and settling more of it. From 1618, Virginia Company officials gave land to new colonists, who planted it in tobacco. By 1620 colonists were taking the land they wanted from the Powhatan without asking or paying, according to the historian Betty Wood.

Company officials, George Thorpe most of all, also pressed the Powhatan to send their children to live among the English. The English wanted to school the children and make them Christian. Opechancanough planned attacks on many parts of the colony to drive the English out for good.

**The attack.** Powhatan fighters destroyed the ironworks at Falling Creek on March 22, 1622, and killed 27 people there. The colonists never managed to rebuild the works.

### Hammersmith at Saugus

Richard Leader began building an ironworks on the Saugus River near Boston in 1646. He worked for the Company of Undertakers of the Iron Works in New England, and in the 1600s an undertaker meant a person who took on a business project. People called the works Hammersmith. Its furnace was running by the next year.

**From ore to iron.** Hammersmith was the first ironworks in North America where every stage of the work happened on one site. The ore was bog iron, which workers collected from swamps and ponds. A blast furnace, a tall furnace with air blown into its fire, got hot enough to melt the iron out of the ore. The iron that came out of it was called pig iron.

At the forge, a workshop where workers heat iron and hammer it, they turned pig iron into wrought iron, a tougher iron that bends instead of breaking. In the rolling and slitting mill, rollers pressed the iron flat and blades cut it into strips. The strips were the raw material for nails, tools and horseshoes. Seven waterwheels powered the machines.

The works ran until about 1668 to 1670. The site is now Saugus Iron Works National Historic Site. Chapter 8 tells more about both ironworks and the people who built and ran them.

### Scottish prisoners at Saugus

Scottish prisoners of war did forced labor at Saugus. English soldiers under Oliver Cromwell took these Scottish soldiers prisoner at the Battle of Dunbar in 1650 and the Battle of Worcester in 1651. About 400 prisoners from the two battles reached New England in all, according to the National Park Service. The prisoners had no choice about going or about the work.

**The march to Durham.** Cromwell's soldiers won the Battle of Dunbar in September 1650. They marched about 3,900 of the fittest prisoners south to the English city of Durham. Their English captors gave them no food and no shelter on the march, and killed some of them for refusing to keep walking. At Durham the English locked the prisoners in the city's cathedral, a large church that was not in use at the time.

A group of English leaders called the Council of State decided to send most of the prisoners to the colonies. In November 1650 they ordered 150 of the Dunbar prisoners handed over to agents of John Becx and Joshua Foote, two of the main investors in the Company of Undertakers. The prisoners sailed from England on a ship called the *Unity* and reached Boston in December 1650. The records do not show how many died on the voyage.

The men running the company sent 36 of these prisoners to work at Saugus, according to the historian Marsha Hamilton. They put others to work at a company warehouse in Boston and sold the rest to farmers, merchants and other mills.

**Bound to work.** The company's men forced many of the Scots to work five to seven years at Saugus under indentures, written agreements that bound a person to work for a master for a set number of years. These men had no say in theirs. They had to work to pay back the cost of their voyage, food, shelter, care and clothing. National Park Service staff give the term at Saugus as seven years.

Most of the Scots at Saugus cut wood, worked as colliers, the men who made charcoal, or did heavy work that needed no special skill. Other prisoners did hard and dangerous forced labor elsewhere in Massachusetts and in New Hampshire and Maine, for the farmers, merchants and mill owners who bought them.

### Meanwhile in Europe

Chemists in Europe, people who study what substances are made of and how they change, began to separate their work from alchemy in the 1600s. Robert Boyle's book *The Sceptical Chymist* ("chymist" is an old spelling of chemist), published in 1661, is one sign of that split. Every element discovered in this century was found in Europe. Phosphorus, for one, was found in the city of Hamburg in 1669.

## 1700 to 1750

**Era 4 of 10 · 1700 to 1750 · about 3 minutes**

At many of the iron furnaces colonists built between 1700 and 1750, the owners forced enslaved people to do much of the work. Colonists had built ironworks in New England, Pennsylvania, Maryland, Virginia and New Jersey. By about 1750 they were shipping raw iron, iron not yet made into finished goods, from their own furnaces to Britain. Nobody discovered an element anywhere in the Americas in these years, and element science still happened only in Europe.

### Enslaved and indentured ironworkers

British investors set up the Principio Company in Maryland in 1719. Its furnace began with workers who were mostly indentured servants from Britain. By the middle of the 1700s, more of the workers there were enslaved African Americans, many of them in skilled jobs.

The owners fed their enslaved and indentured workers mostly corn and salt pork. Some of these workers tried to escape. Historians at the University of Maryland and the Maryland Historical Trust, who surveyed the state's old industries, wrote that escape attempts were "not uncommon."

**The Baltimore Iron Works.** Five rich Maryland planters, owners of large farms called plantations, founded the Baltimore Iron Works in 1731. They were Dr. Charles Carroll, his cousins Charles and Daniel Carroll, Daniel Dulany and Benjamin Tasker. The partners put up money and supplied enslaved people, whom they held as property and forced to work without pay. The works opened with 89 workers, and 42 of them were enslaved, according to the staff of the Mount Clare Museum House in Baltimore.

Workers hauled cartloads of charcoal, oyster shells and iron ore to the top of the furnace in 12-hour shifts. The furnace ran day and night, six or seven days a week. Many of the workers were enslaved people. Others were convicts, people found guilty of crimes in Britain and shipped across the ocean as punishment. The owners did not give the workers enough food, according to the museum. Some enslaved and convict workers ran away, and others worked slowly or carelessly on purpose.

### The Iron Act of 1750

Members of Parliament, Great Britain's lawmakers, passed the Iron Act in 1750. They wrote it to keep colonists making pig iron and bar iron, iron hammered into bars, and sending it to Britain. The act also stated that colonists could not build new mills to make finished ironware, iron goods ready for use. The members of Parliament wanted that business kept in Britain.

Colonists ignored the ban. After 1750 they built more than sixty new ironworks, about twenty of them in Pennsylvania. By the American Revolution, colonists made more iron than people in England and Wales did. By a common ranking, the colonies were third in the world for iron.

**At home.** Colonists used other elements every day. Lead went into gunshot and into pewter, a gray metal made mostly of tin and used for plates, bowls, mugs and spoons. Kettles and buttons were made of copper or of brass, a metal made partly of copper. Silver and gold arrived in the colonies as Spanish coins.

## 1750 to 1800

**Era 5 of 10 · 1750 to 1800 · about 5 minutes**

Chemists in Europe turned chemistry into a modern science in the second half of the 1700s. Among them were Carl Wilhelm Scheele in Sweden and Antoine Lavoisier in France, who worked out what an element is and found new ones. Nobody in the United States discovered an element in these years. Americans put elements into their coins and dug ores out of the ground.

Joseph Priestley, one of those chemists, collected oxygen in England in 1774 and moved to Pennsylvania twenty years later. Meanwhile owners of iron furnaces in Maryland held hundreds of Black people in slavery. And in North Carolina in 1799, a 12-year-old boy found a gold nugget in a creek on his father's farm.

### Three elements in the new coins

Lawmakers in Congress passed the Coinage Act, and it became law on April 2, 1792. Under it, government officials set up the United States Mint, where workers make the country's coins. The act also stated that the coins would be made of three elements: gold for coins called eagles, silver for dollars and smaller coins, and copper for cents.

### Enslaved ironworkers in Maryland

After the Revolution, Maryland officials took a one-fifth share of the Baltimore Iron Works from Daniel Dulany, who had sided with Britain in the war as a Loyalist. They offered the share for sale in 1785 in an advertisement in the *Maryland Gazette*, a newspaper. The advertisement listed more than 200 enslaved Black people at the works, according to the Mount Clare Museum House. Their owners made them work without pay.

**Catoctin Furnace.** Four brothers, Thomas, James, Baker and Roger Johnson, built Catoctin Furnace in Maryland, and it was making iron by 1776. Thomas Johnson later became the first governor of the state of Maryland. In 1803 Baker Johnson became the only owner.

One Johnson owner by himself enslaved more than 80 people at the furnace, according to the Catoctin Furnace Historical Society, which names him only as "Johnson." The society names some of the enslaved men, among them Collier Sam, Waggoner's Henry and Harvey. A collier made charcoal, and a waggoner drove wagons.

Counting all the years the furnace ran on enslaved labor, at least 271 enslaved people and an unknown number of free African Americans worked at Catoctin, according to a 2023 study in the journal *Science*. They mined ore, made charcoal, worked the forge, filled the furnace, drove wagons and cut wood. Others worked in the owners' houses and fields. The furnace had a cemetery for its African American workers, with burials from 1774. Between about 1825 and 1850, the owners switched to paid workers, most of them white.

**The cemetery.** The same study traced the DNA, the material in the body's cells that parents pass down to their children, of 27 people buried in the Catoctin cemetery. Scientists from Harvard Medical School, the Smithsonian and the company 23andMe planned and led the work, and they published it on August 4, 2023. They linked the 27 people to nearly 42,000 living relatives.

### Joseph Priestley

> **Who:** The English chemist credited with discovering oxygen, who spent his last ten years as an immigrant in Pennsylvania.
>
> **When and where:** Isolated oxygen on August 1, 1774, in England. Moved to America in 1794. Lived in Northumberland, Pennsylvania, until his death on February 6, 1804.

**Priestley pointed sunlight through a lens and caught a new gas.**

He did it in England on August 1, 1774. With a burning lens, a glass lens that bends sunlight to one hot point, he heated mercuric oxide, a compound of the element mercury and oxygen. He isolated a gas from it, which means he collected the gas apart from everything else. The gas was later named oxygen.

Carl Wilhelm Scheele, in Sweden, had found the same gas earlier but published his work later. The French chemist Antoine Lavoisier gave oxygen its name. Priestley had already invented carbonated water, water with bubbles of gas in it, in Leeds in 1767. In 1770 he gave rubber its English name, because he found it was good for rubbing out pencil marks.

**A mob, then Pennsylvania.** Priestley was also a minister, a leader of a church, and he preached outside the official Church of England. Many people in Birmingham, England, turned against him for his views on religion, and in 1791 a mob there burned his home and his laboratory. In 1794 he left England for Pennsylvania and settled in Northumberland, where his house was finished in 1798.

There he built what was then the best chemistry laboratory in the United States and identified the gas carbon monoxide. He turned down a job as a professor at the University of Pennsylvania. Priestley died in Northumberland in 1804. American chemists met at his house in 1874, one hundred years after he isolated oxygen, and that meeting was a step toward the founding of the American Chemical Society in 1876. The house is now a National Historic Landmark.

### Conrad Reed

> **Who:** A 12-year-old farm boy who found the first gold in the United States that an expert confirmed was real.
>
> **When and where:** 1799, Little Meadow Creek, Cabarrus County, North Carolina.

**The Reeds used a 17-pound gold nugget to hold a door open.**

Conrad Reed pulled a heavy yellow rock out of Little Meadow Creek in 1799. The creek ran through the farm of his father, John Reed, in Cabarrus County, North Carolina. The rock was a gold nugget, a lump of metal found in the ground, and it weighed 17 pounds.

Nobody in the family knew the rock was gold. They used it as a doorstop for about three years. In 1802 a jeweler identified it as gold and bought it from John Reed for $3.50, about a week's wages. It was worth about $3,600 at the time.

Conrad's find was the first gold found in the United States that an expert checked and showed was real. After it, people in North Carolina began the first gold mining in the United States.

## 1800 to 1850

**Era 6 of 10 · 1800 to 1850 · about 5 minutes**

Thousands of miners rushed onto Native land to dig gold in Georgia from 1829 and copper in Michigan from 1843. The Georgia gold lay under Cherokee land, and the Michigan copper lay under Ojibwe land. Georgia lawmakers gave the Cherokee gold country away by lottery, a drawing of names by chance. In 1842 a United States official signed a treaty, a written agreement between nations, under which Ojibwe bands, groups within the Ojibwe nation, gave up the copper country.

Nobody in the United States discovered a new element in these years. In Europe, chemists such as Humphry Davy and Jöns Jacob Berzelius found one element after another.

### Gold on Cherokee land

North Carolina came first. After Conrad Reed's find in 1799, more people dug for gold on the Reed farm and along the creeks near it, and that mining grew from 1803. Miners in North Carolina dug more gold than miners in any other state until the California gold rush of 1849.

The first printed report of gold in Georgia appeared in the *Georgia Journal*, a newspaper, on August 1, 1829. The gold was in the Cherokee Nation, the homeland of the Cherokee people. By the spring of 1830, about 4,000 miners had crowded onto Cherokee land to dig. The gold town of Dahlonega takes its name from the Cherokee word for "golden."

**The Gold Lottery.** Members of the Georgia General Assembly, the state's lawmakers, passed a law on December 24, 1831. Under it they divided "the original Cherokee Indian territory" into lots and gave it away by lottery. In the Gold Lottery, winners received lots of 40 acres in the gold country for a fee of $10 a lot. The drawings ran from October 22, 1832, to May 1, 1833.

The Cherokee who lived on the land could not enter, because the lawmakers barred anyone who lived in the Cherokee territory. The lots went to white Georgians. Men who were United States citizens, widows and the families of orphans could enter if they had lived in Georgia for three years and had not mined gold in the Cherokee territory since June 1, 1830.

**Forced out.** President Martin Van Buren sent General Winfield Scott in 1838 to force the remaining Cherokee off their land and west of the Mississippi River. Scott commanded about 7,000 soldiers and members of state militias, part-time armies run by the states. His troops forced the Cherokee into stockades, pens fenced with tall wooden posts.

A missionary wrote in June 1838 that the Cherokee "have been dragged from their houses." In Georgia, he wrote, "multitudes were allowed no time to take any thing with them except the clothes they had on."

Scott's soldiers forced more than 16,000 Cherokee to leave for the west in 1838 and 1839, on the journey called the Trail of Tears. Over 4,000 died of cold, hunger and disease along the way, by the usual count. Russell Thornton, a scientist who studies the size of populations, puts the Cherokee losses at about 8,000 or more. Chapter 2, Native Nations, tells the Trail of Tears in full.

### Copper on Ojibwe land

Douglass Houghton was Michigan's state geologist, a scientist the state paid to study its rocks. In 1840 he published a report on the copper of the state's Upper Peninsula. The Keweenaw Peninsula there has veins, long thin bands running through the rock, of pure native copper. Native miners had worked those same veins for thousands of years.

The land belonged to Ojibwe bands. Robert Stuart, an official the United States sent to make an agreement, signed the Treaty of La Pointe with Ojibwe bands on October 4, 1842. Under the treaty, the bands gave up land along the south shore of Lake Superior, including the Keweenaw copper country.

The treaty states that the Ojibwe would receive $12,500 a year in coins and $10,500 a year in goods for 25 years. It also states that $75,000 would go toward debts the Ojibwe owed to traders. The Ojibwe kept the right to hunt on the land "until required to remove by the President of the United States." That meant they could hunt there only until the President ordered them to leave.

The treaty never uses the word copper, but people came to call it the Copper Treaty. The Bad River Band of Ojibwe and the Lac Courte Oreilles Ojibwa College both say that United States officials wanted the copper.

**The copper rush.** United States officials opened an office at Copper Harbor in 1843 to handle land with metal in it. From that year on, thousands of prospectors, people who search the ground for metal, poured into the Upper Peninsula in the nation's first great copper rush. The Keweenaw stayed the country's biggest source of copper into the 1880s.

### The Ontonagon Boulder

Julius Eldred, a merchant from Detroit, made a deal in the summer of 1841 for the sacred Ontonagon Boulder, the 3,708-pound lump of pure copper. He made it with Okandikan, a leader of the Ontonagon band of Ojibwe. Eldred agreed to pay $45 right away and $105 more if he managed to move the boulder. He hauled it away in 1843.

Walter Cunningham was the United States government's agent in charge of the lands with metal in them. Before Eldred could leave Copper Harbor, Cunningham made him hand the boulder over to the government in Washington. Later, members of Congress paid Eldred money to make up for his loss.

The boulder sat in a yard of the War Department, the part of the government that ran the army, until 1860. Then it was moved to the Smithsonian, the national museum in Washington, D.C., and put on display.

The Keweenaw Bay Indian Community, made up of the L'Anse and Ontonagon bands of Lake Superior Ojibwe, formally asked the Smithsonian to return the boulder in 1991. Smithsonian officials refused in 2000. They said the boulder did not fit the meaning of a sacred object under the law on returning Native objects, and it stayed at the Smithsonian.

### Lead at Galena

Miners also dug lead in these years, in Missouri and in the Galena district of Illinois and Wisconsin. The town of Galena, Illinois, is named for galena, a lead ore.

## 1850 to 1900

**Era 7 of 10 · 1850 to 1900 · about 7 minutes**

Mercury from the gold mines got into California's rivers and fish, and mercury in the hat shops of Danbury, Connecticut, poisoned the hatters who breathed it. California's gold miners released about 13 million pounds of it at their mines and into rivers. Miners also took gold from the Black Hills, land that belonged to the Sioux, and in 1877 members of Congress voted to take the hills from them.

Aluminum, rare at the start of these years, was cheap by the end of them. In 1886 Charles Martin Hall, a 22-year-old in Oberlin, Ohio, found a cheap way to make it. By the middle of the 1890s its price had fallen from about $12 a pound to less than $1. Scientists abroad already knew aluminum as an element. What Hall found was a process, a series of steps for making the metal.

### Mercury in the rivers and the hat shops

Mercury is an element, a metal that stays liquid at room temperature, also called quicksilver. Gold miners used it to catch the fine bits of gold in the gravel they dug, and they lost mercury into the rivers.

**How much mercury.** California's gold miners used about 26 million pounds of mercury, and about half of it, some 13 million pounds, escaped into the ground and the rivers. Scientists at the United States Geological Survey, the government office for studying the country's rocks and water, made the count.

Placer miners, who wash gold out of sand and gravel in streams, lost about 10 million pounds of mercury, 80 to 90 percent of it in the Sierra Nevada mountains. Miners at hardrock mines, which are dug into solid rock, lost about 3 million pounds more.

**Still in the fish.** The Geological Survey's scientists list three ways this mercury reaches people: in fish they eat, in mud they handle and in the air they breathe. In the air it is a vapor, a gas rising off a liquid or a solid. The form that builds up most easily in living bodies, fish included, is called methylmercury. It is also the form most poisonous to people.

California officials had warned people about eating fish from about 20 lakes, rivers and other waters by 2005, because of mercury. Fish in the Bear and Yuba river areas carry enough mercury to put people's health at risk, the scientists found. They give no count of people poisoned by the gold miners' mercury.

**The Danbury shakes.** People in Danbury, Connecticut, had made hats since 1780. To make felt, a thick cloth of pressed fur, they soaked fur in a liquid that contained mercury nitrate, a compound of mercury, and the fur matted together into felt. This step was called carroting. As they worked, the hatters breathed in the mercury as vapor and as dust.

Doctors first described the hatters' mercury poisoning in medical writing in 1860, and people called it the Danbury shakes. The poisoned hatters had tremors, shaking they could not stop. Their skin itched, burned or peeled. Some lost their hair and teeth. They sweated, swelled up, felt dizzy and got confused. The mercury slurred their speech and made them stumble, and people mistook the shaking hatters for drunks. In bad cases, hatters had hallucinations: they saw or heard things that were not there.

The members of Connecticut's State Board of Health watched the mercury's effects in Danbury's hat factories in the 1880s and 1890s. They did not act, because the carroting was not harming people outside the factories. The historian Shirley Wajda, who wrote the history of the Danbury shakes for Connecticut Humanities, names no factory owner and gives no count of hatters poisoned before 1900.

### Silver, copper and a table from Russia

Miners found the Comstock Lode, a long, rich band of ore inside the rock, at Virginia City, Nevada, in 1859. It was the richest find of silver ore ever made in North America. Its ore held gold as well as silver, and miners rushed there too.

Dmitri Mendeleev, in Russia, published his periodic table of the elements in 1869: a chart that arranges the elements in order, with elements that act alike grouped together. Mendeleev used his table to predict elements that nobody had found yet. Every element that Americans discovered later went into it.

Americans strung copper wire through their cities in these years for electric lights and the telephone. The copper came from Michigan, and later from Butte, Montana.

### Gold from the Black Hills

The Black Hills, in what is now South Dakota, belonged to the Sioux under the Fort Laramie Treaty of 1868. Lieutenant Colonel George A. Custer led an Army expedition into the hills in 1874, with miners along, and the men confirmed that there was gold. Miners poured in, and in late 1875 President Ulysses S. Grant ordered the Army to stop keeping them out.

Members of Congress then voted to cut off the Sioux's food until they gave up the hills. In 1877 they took the hills by law, though only about one in ten adult Sioux men had signed the paper giving them up. Chapter 12, Landmarks, tells that story in full. It also tells about the money the justices of the Supreme Court awarded the Sioux in 1980, about $106 million, which the Sioux have refused.

### An aluminum tip for the Washington Monument

Chapter 12, Landmarks, tells how workers finished the Washington Monument in 1884. Its tip was a pyramid of aluminum, a metal that was rare then. Aluminum cost about $1 an ounce, the same as silver, though some price records from those years give a little less.

Colonel Thomas Lincoln Casey of the Army Corps of Engineers was the engineer in charge of finishing the monument. He talked over the metal for the tip with William Frishmuth, the owner of a Philadelphia foundry, a factory where workers melt metal and pour it into molds. Frishmuth chose aluminum, and Casey agreed. Aluminum matched the color of the monument's granite and would not stain. It also polished well and could be engraved.

Frishmuth cast a pyramid that weighed 100 ounces, the largest piece of aluminum anyone had yet cast. After some bargaining over his bill, he was paid $225.

Before the tip went up, Frishmuth showed it at the Tiffany's store in New York without permission. The tip sat on the floor, so visitors could step over the top of the Washington Monument. Workers set it in place on December 6, 1884.

### Charles Martin Hall and Julia Brainerd Hall

> **Who:** A 22-year-old Ohio college graduate who invented the cheap way to make aluminum, and his older sister, a chemist whose notes helped win the fight over his patent.
>
> **When and where:** February 23, 1886, in the family woodshed in Oberlin, Ohio.

**Charles Hall made aluminum in a woodshed, with batteries he built himself.**

Hall was 22 and had just finished at Oberlin College. In the family woodshed he melted a substance called cryolite and dissolved aluminum oxide, a compound of aluminum and oxygen, in it. On February 23, 1886, he ran electricity from batteries he had built himself through the melted mix, and beads of aluminum metal came out.

His older sister, Julia Brainerd Hall, had studied chemistry at Oberlin College. She helped with the experiments, watched them and wrote them down. Later Hall had to fight for his patent, the government paper that gave him alone the right to make and sell his invention for a set number of years. Julia's notes helped him win.

In France, Paul Héroult found the same process in the same year, working on his own. Both men were born in 1863, and both died in 1914. The method is called the Hall-Héroult process, and aluminum makers around the world still use it.

**Cheap aluminum.** Aluminum cost about $12 a pound in the early 1880s. In 1888 the investors who backed Hall formed the Pittsburgh Reduction Company to make aluminum his way. After aluminum makers began to use his process, the price fell to about $2 a pound, and by 1893 to about 78 cents. The company's owners renamed it the Aluminum Company of America, or Alcoa, in 1907. Aluminum became cheap enough for kitchen foil and pots and pans.

### Helium, almost found in America

William Hillebrand, a chemist at the United States Geological Survey, got a gas out of uranium ore around 1890. The gas did not join with other substances. Hillebrand recorded it as nitrogen and missed the chance to find helium.

William Ramsay in London followed up on Hillebrand's paper in 1895. He got a gas out of cleveite, a uranium mineral, and examined it with a spectroscope, an instrument that splits light into its colors. He saw a yellow line that belongs to helium. Scientists had seen helium's line in the light of the sun since 1868, but nobody had found helium on Earth before. The credit for finding it on Earth goes to Ramsay.

## 1900 to 1950

**Era 8 of 10 · 1900 to 1950 · about 24 minutes**

Radium, lead, mercury, arsenic and uranium poisoned many of the Americans who worked with them in the first half of the 1900s. Young women who painted watch dials swallowed radium because their supervisors told them to shape their brushes with their lips, and many of them died of radium poisoning. At least 15 workers died of lead poisoning in the 1920s at the plants that made a lead additive for gasoline.

Arsenic from a copper smelter in Montana killed farm animals. From 1941 Navajo and other Native miners dug uranium, and Navajo miners later reported that no one had told them of its dangers.

At the same time, scientists began making new elements, substances of only one kind of atom, with a machine at Berkeley, California. The first, in 1937, was identified in Italy, in material that had come out of that machine. By the end of 1949, teams working in the United States had made or found seven more: astatine, neptunium, plutonium, curium, americium, promethium and berkelium.

### The gas well that put out the fire

Helium is an element, a gas that does not burn. A drilling company struck a roaring gas well on William Greenwell's farm near Dexter, Kansas, in May 1903. The people of Dexter planned a celebration. They pushed a burning bale of hay toward the gas to light a giant flame, and the gas put the fire out. Local people made fun of it as "wind gas."

Erasmus Haworth was a Kansas geologist, a scientist who studies rocks. He carried samples of the gas to the University of Kansas. There the chemists Hamilton P. Cady and David F. McFarland tested it. On December 7, 1905, they showed that the gas was 1.84 percent helium. Scientists had thought helium was rare on Earth, and Cady and McFarland found large amounts of it in the natural gas under the Great Plains.

**Helium for airships.** Airships flew in World War I, and helium became valuable to armies because it does not burn. Members of Congress passed the Helium Act in 1925. Under it, federal workers, people who worked for the national government, began producing helium and storing it underground in the Bush Dome of the Cliffside gas field, near Amarillo, Texas. That store became the Federal Helium Reserve, and for decades it held nearly all of the world's supply of helium.

Under a 1927 law, no one could sell American helium to other countries. For that reason, the German airship *Hindenburg* flew on hydrogen, a gas that burns. On May 6, 1937, the *Hindenburg* caught fire as it came in to land at Lakehurst, New Jersey. Of the 97 people on board, 35 died, and so did a man working on the ground.

After the fire, President Franklin D. Roosevelt considered selling helium to Germany. Then in 1938 Hitler took over Austria and made it part of Germany, and Harold Ickes, the Secretary of the Interior, refused to sell. Ickes headed the federal department in charge of public lands.

### Radium on the watch dials

Marie and Pierre Curie found the element radium in France in 1898. Radium is radioactive: its atoms break apart on their own and give off radiation, energy that shoots out of an atom as it breaks apart. Some radiation travels as tiny, fast particles that can damage the living cells of a body. The kind radium gives off is called alpha radiation.

Workers at American companies mixed radium into paint in the early 1900s so that watch numbers glowed in the dark. Other sellers put radium into tonics, drinks they claimed would make people healthy.

**The companies.** Two doctors, Sabin Albin von Sochocky and George S. Willis, founded the Radium Luminous Materials Corporation in New Jersey in 1914. After World War I the company was reorganized and renamed the U.S. Radium Corporation, with a plant in Orange, New Jersey. At its biggest, the company employed as many as 250 young women, some only 15 years old.

Arthur Roeder, who had been the company's treasurer, in charge of its money, replaced von Sochocky as president in January 1921. Howard Barker was the vice president and chief physicist. In Ottawa, Illinois, the Radium Dial Company ran another dial-painting plant. It belonged to the Standard Chemical Company of Pittsburgh, and Joseph Kelly was its president.

**Known:** More than 3,000 girls and young women painted radium dials across the country in the 1910s and 1920s, by the count of the National Institute of Standards and Technology, a federal science laboratory.

**Not known:** The full count, since Northern Public Radio gives about 4,000 and neither count comes with a list of the painters.

### The Radium Girls

> **Who:** Young women, some of them teenagers, who painted glowing radium numbers on watch and instrument dials and were poisoned by the paint.
>
> **When and where:** The U.S. Radium Corporation in Orange, New Jersey, from 1917, and the Radium Dial Company in Ottawa, Illinois, into the 1930s.

**The method had a name: "lip, dip, paint."**

Young women at the U.S. Radium Corporation plant in Orange, New Jersey, painted watch numbers with radium paint from 1917. To shape each brush to a fine tip, a painter drew it between her lips, then dipped it in the paint and painted: lip, dip, paint. Drawing the brush through the lips was called lip-pointing. Each time a painter lip-pointed, she swallowed a little radium. The women went home glowing, and some people called them ghost girls.

**Who told them to.** Their supervisors told them to lip-point and said the paint was safe. Von Sochocky, one of the company's founders, grew worried about lip-pointing and told the painters to stop, but the supervisors contradicted him, according to Northern Public Radio. Arthur Roeder was the company's president from January 1921, and he still signed papers for the company in 1926. Lip-pointing there went on until after 1926. No surviving record names the New Jersey supervisors.

**What the radium did.** Radium belongs to the same chemical family as calcium, the mineral in bones and teeth. So the painters' bodies took the swallowed radium into their bones and teeth, the way they take in calcium, and there it kept giving off radiation from inside the body. The radiation damaged the bone marrow, the soft center of the bones that makes blood cells, until the marrow stopped making them. Doctors call this aplastic anemia.

The jawbone died and broke down, which doctors call necrosis of the jaw, and some women got bone cancer. A history published by the National Institute of Standards and Technology states that the radiation "had eaten away their bones from the inside out." Some women's spines collapsed, and they had to wear braces. Their jawbones shattered under light pressure. When doctors examined dial painters' bodies after death, they found 99 percent of the radioactivity in the skeleton.

**The first deaths.** Grace Fryer began painting dials at the Orange plant on April 10, 1917, and worked there until 1920. Another painter there, Amelia Maggia, called Mollie, painted dials at the company until she died in 1922. In 1924 a dentist found damage to Grace Fryer's jawbone of a kind he had never seen.

In June 1925 a chemist at the company died of aplastic anemia, and a dial painter died 13 days later. The medical examiner of Essex County, New Jersey, the doctor who looks into sudden and suspicious deaths there, examined the chemist's body. He gave the jaw disease the name "radium jaw."

**The lawsuit.** Grace Fryer and four other dial painters sued the company in May 1927. Their lawyer was Raymond Berry. Mollie Maggia's body was dug up on October 25, 1927. It held 48.4 micrograms of radium, millionths of a gram, which is 500 times the amount later set as the limit for a human body.

Company officials first offered each woman $10,000, with her medical and legal costs taken out of it. The women refused. In June 1928 they accepted $10,000 each, their medical bills and a pension of $600 a year, money paid every year for the rest of their lives. A committee of three doctors had to approve the bills. Some accounts give the amount each woman got as $15,000.

A federal judge arranged the deal on June 4, and the agreement was signed on June 8. The company's officials admitted no blame, and Berry took 10 percent. Von Sochocky, one of the two doctors who founded the company, died of radium poisoning on November 14, 1928. Grace Fryer died in 1933.

**Ottawa, Illinois.** The Radium Dial Company advertised for painters in Ottawa in September 1922. The advertisement named a Miss Murray as the person young women should apply to. Catherine Wolfe, who later married and took the name Donohue, described how Miss Murray taught them to point the brushes between their teeth. Supervisors at Radium Dial told the women the paint was safe, and even healthy, and kept them lip-pointing.

Radium Dial's managers hired doctors to examine the painters from 1925. The doctors told one painter that she was very healthy. Nobody told her that she had tested positive for radiation, her niece said later.

Catherine Wolfe Donohue painted dials there and began to feel sick in 1925. Radium Dial's managers fired her in 1931. In her own words, "my limping was causing much talk." She lost half her body weight, and parts of her jaw fell out.

Joseph Kelly lost his post as Radium Dial's president in 1934. He opened a new dial company, Luminous Processes, a few blocks away and hired many of the same workers. That plant ran until 1976, when officials of the Nuclear Regulatory Commission, a federal agency, found radiation there 1,666 times the allowed level.

**The hearing.** A lawyer took Catherine Donohue's case for no pay, before the Illinois Industrial Commission, a state board that decided claims by workers hurt on the job. At a hearing on February 10, 1938, she brought a box of pieces of bone that she said had come from her jaw. When the judge asked her doctor about her chances of living, she collapsed, and several men carried her from the room. She weighed 71 pounds.

The hearing moved to her home. On April 5, 1938, the hearing officer ruled that her work at Radium Dial had made her sick and awarded her $5,661, which included a pension of $277 a year for life. On July 6 the members of the commission threw out the company's appeal and added $730.

Catherine Donohue died on July 27, 1938, at the age of 35. According to NPR Illinois, she weighed less than 60 pounds. Her lawyer said hers was the eleventh death among women who had done that work at the plant, and Northern Public Radio later counted fifteen Ottawa workers dead of radium. Radium Dial's lawyers appealed all the way to the United States Supreme Court and lost, and the case ended in October 1938. Because Radium Dial had left Illinois, the Ottawa women together collected only $10,000.

### Radium sold as medicine

William J. A. Bailey owned Bailey Radium Laboratories in East Orange, New Jersey. He sold Radithor, which was radium dissolved in water. Bailey had falsely claimed degrees from Harvard and from Vienna, and in 1927 he had pleaded guilty to practicing medicine without the right to do it. His company sold more than 400,000 bottles of Radithor at $1 each.

Eben Byers was a rich Pittsburgh businessman. He hurt his arm in 1927 at a party on a train after the Harvard-Yale football game, and he began drinking Radithor to heal it. He stopped in 1930, when his teeth began falling out. Accounts of how much he drank differ. The Museum of Radiation and Radioactivity at Oak Ridge Associated Universities says he averaged three bottles a day for about two years from December 1927. Other accounts give about 1,400 bottles in all.

The radium destroyed his bones. A government investigator reported that his whole upper jaw except two front teeth, and most of his lower jaw, had been removed. The rest of his bones were slowly breaking down, and holes were forming in his skull.

Byers gave testimony to the Federal Trade Commission, the federal office whose officials act against companies that cheat or mislead buyers. On December 19, 1931, the commission's officials ordered Bailey to stop claiming that Radithor was harmless or that it healed people. Byers died months later, in 1932, at the age of 51.

**By 1938:** Doctors had named radium jaw, a federal judge had arranged the New Jersey painters' settlement, and Illinois officials had ruled that Catherine Donohue's work at Radium Dial made her sick.

### Lead in gasoline and paint

Lead is a soft, heavy metal and an element, and it poisons people who swallow it or breathe it in. Scientists at the National Institute for Occupational Safety and Health (NIOSH), the federal office that studies dangers at work, list what large doses of lead do. Their list includes paralysis (being unable to move part of the body), madness, gout (painful, swollen joints), colic (sharp pains in the belly) and death.

**The additive.** Thomas Midgley Jr., a researcher at General Motors (GM), found that tetraethyl lead, a liquid made of lead joined with other chemicals, stopped engine "knock," a pinging sound in gasoline engines. In August 1924 GM and Standard Oil of New Jersey set up the Ethyl Gasoline Corporation to sell it, and the DuPont company made it.

**The dead.** Workers who made tetraethyl lead died of lead poisoning at three plants. Standard Oil ran one, the Bayway refinery in Elizabeth, New Jersey, a plant that turned oil into gasoline and other products. Seven men died there in October 1924, and 33 went to the hospital, according to Bill Kovarik, who counted the dead in a 2005 article in a journal about workers' health.

Ten more workers died at a DuPont plant in Deepwater, New Jersey, between September 1923 and the fall of 1924. At GM's laboratory in Dayton, Ohio, at least two died, and 40 went to the hospital.

**Known:** At least 15 workers died from making tetraethyl lead in the 1920s, the count NIOSH scientists gave in 2021.

**Disputed:** Kovarik's plant-by-plant numbers add up to at least 19, while other accounts give five dead at Bayway, not seven, and 35 in the hospital.

**How the work poisoned them.** The tanks that held the chemicals were not closed off from the workers, who had to open them between steps, Kovarik writes. Workers squeezed half-melted lead through metal grates with shovels and with their boots.

At Bayway, poisoned men had to be held down and tied into straitjackets, coats that pin a person's arms to the body. Kovarik's account does not say who restrained them. Their bodies were black and blue from muscle spasms they could not stop. They saw things that were not there, such as flying insects, and some could suddenly turn violent or want to kill themselves. Workers called tetraethyl lead "loony gas."

**What the bosses said.** Frank Mann, the Bayway plant supervisor in 1924, said, "These men probably went insane because they worked too hard." A month before the deaths, in September 1924, engineers from DuPont had visited Bayway and called its safety measures "grossly inadequate."

Joseph G. Leslie, a Bayway worker poisoned there, was kept in a mental hospital for 40 years. Only his wife, Gertrude, and later his son knew he was alive, and everyone else believed he had died. Kovarik does not say who sent Leslie to the hospital or who spread the story that he was dead. He names no manager of the Deepwater plant or the Dayton laboratory apart from Midgley and Charles Kettering, who ran GM's research.

Midgley held a press conference on October 30, 1924. He poured tetraethyl lead on his hands and breathed its vapor for about 60 seconds, to show it was safe. A few months earlier, lead had made him seriously ill. At the same event he acknowledged the two deaths in Dayton and said more than 50 workers were "under observation" for lead poisoning.

**The meeting in Washington.** Hugh Cumming, the Surgeon General, ran the Public Health Service, the federal office in charge of the nation's health. On May 20, 1925, he brought more than 100 people from industry and from public health to a meeting in Washington.

Frank Howard of Standard Oil said the industry could not give up "what has come to the industry like a gift from heaven." Yandell Henderson, who studied how the body works at Yale, called tetraethyl lead "one of the most dangerous things in the country today." Alice Hamilton of Harvard told Kettering there were "thousands of things better than lead."

Members of a Surgeon General's committee reported in 1926 that they found "no good grounds" for a ban, and asked for more study. The Ethyl company paid Robert Kehoe of the University of Cincinnati to study lead. Kehoe set out the industry's "safe level" theory, the claim that lead below a certain amount did no harm, and the companies held to that claim for decades.

**Lead paint.** Painters also used paint that contained lead. Between 1925 and 1927, more painters died of lead poisoning than workers in all other jobs combined, NIOSH states.

Delegates of the International Labour Organization, a world body that sets rules for workplaces, met in Geneva in November 1921. They agreed on a treaty to ban lead paint for the insides of buildings. The ban took effect in 1923 in the countries that accepted it. The United States did not belong to the organization until 1934, and it was still outside the ban in 2017.

### Mercury in Danbury's hat shops

Danbury's hatters kept breathing mercury at work after 1900, because they still used it to turn fur into felt. Connecticut lawmakers added mercury poisoning to the state's workmen's compensation law in 1913. Under a law of that kind, employers pay workers who are hurt or made sick by their jobs.

Alice Hamilton of Harvard examined 100 Danbury hatters in 1922 and found 43 with mercury poisoning. Some shook so hard from tremors that they could not feed themselves.

**Who pushed for a fix.** The hatters in the union, a group of workers who join together to bargain with their employers, kept demanding investigations. Grace Mailhouse Burnham, who had set up the Workers' Health Bureau, found a way to make felt without mercury in the Soviet Union. She could not get the hat manufacturers to agree to use it.

Government researchers made a full study only in 1937. They found many hatters poisoned by mercury. They also found that drinking and smoking had not caused the hatters' symptoms, as some manufacturers and insurance companies had claimed in court. The historian Shirley Wajda's account of the Danbury shakes names no factory owner.

**The end of mercury felt.** Officials of the Public Health Service then worked out an agreement with the hatters' unions and the hat manufacturers in the 26 states that made hats. Under it, hat makers stopped using mercury and used hydrogen peroxide in its place.

Connecticut Governor Robert A. Hurley announced his state's ban on December 1, 1941. He said "it was possible to manufacture good fur felt hats without making physical wrecks out of hundreds of workers." Mercury is still in Danbury's soil and in the mud of the Still River.

### Arsenic smoke in Montana

Arsenic is an element and a strong poison. The Anaconda Copper Mining Company started its Washoe smelter, a plant where workers melt ore, rock that holds metal, to get the metal out, at Anaconda, Montana, in 1902. It stood about 25 miles from the copper mines of Butte. When workers melted copper ore there, arsenic went up the smokestack with the smoke, and farmers nearby reported livestock dying in the smelter's first year.

Farmers in the Deer Lodge Valley formed an association in 1904 to sue the company. Fred J. Bliss, whose 320-acre farm lay about five miles from the smelter, filed the case, *Bliss v. Anaconda Copper Mining Co.*, in 1905. In January 1909 a federal judge, William Hunt, agreed that arsenic from the smelter had poisoned livestock and the hay and grass they ate, but he refused to close the smelter.

**The judge's reason.** Closing the smelter, Hunt wrote, would throw thousands of the company's workers out of their jobs and do harm that could never be undone to the cities of Anaconda and Butte. Bliss could ask a court for money for his losses instead. The smelter's superintendent, a Mr. Mathewson, told the court that no known way of catching the arsenic would work at a smelter that size, and in April 1909 Hunt dismissed the case.

**Buying the smoke rights.** The company's officers then bought out many of the farmers. From the rest they bought "smoke easements," legal rights to send the company's smoke over a farm. Staff of the Environmental Protection Agency (EPA), the federal office whose staff work to protect the country's air, water and land, wrote a history of the site. Neither that history nor the 1909 rulings name the officers who chose the buyouts, and neither counts the people harmed by the arsenic.

### Uranium from Navajo land

Uranium is a heavy metal element whose atoms break apart slowly and give off radiation. From 1941, Native American miners, among them Navajo, Pueblo and Hopi people, worked in mines in the Southwest that dug uranium and vanadium, another metal element. The Vanadium Corporation of America began mining uranium in secret on Navajo land in 1943.

Miners working for mining companies dug nearly 30 million tons of uranium ore out of Navajo land from 1944 to 1986, EPA staff report. The companies mined under leases with the Navajo Nation, agreements to use land for a set time in return for payment.

**By 1943:** Hat makers had stopped using mercury, Anaconda's owners had bought the right to send smoke over the farms that were left, and a company was secretly mining uranium on Navajo land.

### A false first, and the machine at Berkeley

While those poisonings went on, physicists, scientists who study matter and energy, were hunting for new elements. Fred Allison, a physicist at Alabama Polytechnic, now Auburn University, announced two new elements in 1931. He called element 85 "alabamine" and element 87 "virginium," and said he had found them with a machine in his lab.

Scientists at other labs tried his method and could not get the same results. They showed that the signals Allison saw came from his equipment, not from any element, and scientists stopped accepting his claims. A Berkeley team made the real element 85 in 1940.

**The machine at Berkeley.** Ernest Lawrence built his first cyclotron, a machine that whirls tiny charged particles in a spiral up to high speed, at Berkeley, California, in 1930 and 1931. When the fast particles hit a target, they can turn atoms of one element into atoms of another. With his machines, Berkeley's Radiation Laboratory became the place most of the new elements made in the United States came from.

### Ernest Lawrence

> **Who:** The physicist who invented the cyclotron, the machine behind most of the elements discovered in the United States.
>
> **When and where:** Berkeley, California, from the 1930s to the 1950s. He won the Nobel Prize in Physics in 1939 and died in 1958.

**Lawrence's first cyclotron was small enough to hold in one hand.**

Lawrence made his first cyclotron out of glass, sealing wax and bronze, and it was small enough to hold in one hand. He and his teams then built larger and larger ones, and the 60-inch cyclotron of 1939 had a magnet that weighed 220 tons. The Radiation Laboratory at Berkeley became an independent laboratory in 1936. Lawrence won the Nobel Prize in Physics, a world prize given each year, in 1939.

His machines made the material for several new elements. His 37-inch cyclotron supplied the metal sheet that held the first element made by people, and teams used his 60-inch cyclotron to make astatine and plutonium in 1940. Lawrence died in 1958. Element 103, lawrencium, carries his name.

### Elements made by people

Mendeleev's periodic table of 1869, the chart of the elements in order, had a gap at element 43, below manganese. Early in 1937, Lawrence mailed a thin sheet of a metal called molybdenum to Emilio Segrè in Palermo, Sicily. The sheet had been part of the 37-inch cyclotron.

**The first element made by people.** Segrè and Carlo Perrier, a scientist who studies minerals, took a few billionths of a gram of element 43 out of the sheet. They named it technetium, from a Greek word meaning "artificial." Technetium was the first element made by people. Italian scientists did the chemistry, and the material came from an American machine.

**The first elements found in America.** Teams in American labs made or found seven new elements in the 1940s. Most of their names came from planets, places and people.

Segrè and two other Berkeley scientists made element 85 in 1940 by striking the element bismuth with alpha particles in the 60-inch cyclotron. It was the element Allison had called "alabamine." In 1947 its makers named it astatine, from a Greek word for "unstable."

Edwin McMillan and a colleague found element 93 the same year, in uranium that had been struck in the cyclotron. It was the first element heavier than uranium. Uranium was named for the planet Uranus, so they named element 93 neptunium, for Neptune, the next planet out.

**Plutonium.** Glenn Seaborg's team made element 94 in the 60-inch cyclotron on December 14, 1940. On the night of February 23 and 24, 1941, they proved by chemistry that it was a new element, in Room 307 of Gilman Hall at Berkeley. The room is now a National Historic Landmark.

They named the element plutonium, for the planet Pluto. Seaborg chose the symbol Pu instead of "Pl" as a joke, because "pee-yoo" is what people say about a bad smell, and the members of the naming committee accepted it. Government officials kept the work secret from the start. During World War II, American scientists used plutonium and uranium to build atomic bombs.

**96 before 95.** Seaborg's team made element 96 in the summer of 1944 and named it curium, for Marie and Pierre Curie. They identified element 95 late that year and named it americium, for the Americas.

An element's number counts the protons in its atoms, not the order in which it was found. These two were so hard to separate from each other that the team nicknamed them "pandemonium" and "delirium," words for wild uproar and madness. Much of this work took place at the Metallurgical Laboratory, a secret wartime lab in Chicago.

**Told on a quiz show.** Seaborg was a guest on a children's radio show called *Quiz Kids* on November 11, 1945. A boy asked him whether any new elements had turned up during the war. Seaborg said yes, elements 95 and 96. He told the boy five days before he planned to announce them to the American Chemical Society, a national group of chemists.

Charles D. Coryell and two other chemists found element 61 in 1945 at Clinton Laboratories in Oak Ridge, Tennessee, now Oak Ridge National Laboratory, in the leftovers of uranium atoms that had been split. Grace Mary Coryell, Charles Coryell's wife, suggested the name promethium, for Prometheus, who stole fire from the gods in Greek stories. The team announced the element in 1947. Promethium is still the only element ever discovered in Tennessee.

Seaborg's team made element 97 at Berkeley in December 1949 by striking americium with alpha particles in the 60-inch cyclotron. They named it berkelium, for Berkeley.

### Emilio Segrè

> **Who:** An Italian physicist who stayed in the United States after Benito Mussolini and his officials barred Jews like him from university jobs in Italy, and who helped find two elements.
>
> **When and where:** Palermo, Sicily, and Berkeley, California, from 1937 into the 1940s. He lived in the United States from 1938 and died in 1989.

**Mussolini's officials took Jews' university jobs while Segrè was visiting Berkeley.**

Emilio Segrè was Jewish, and he was in Berkeley for the summer when he learned the news. Benito Mussolini and his officials in Italy had issued new racial laws against Jews. Under them, Italian officials took university jobs away from Jews. Segrè stayed in the United States and became an American citizen.

He had already helped identify technetium in Palermo. At Berkeley, Segrè helped make astatine in 1940, and with Glenn Seaborg he showed in 1941 that atoms of plutonium-239 could be split.

He won the Nobel Prize in Physics in 1959 for his work on the antiproton, a tiny particle with the opposite electric charge of the proton, a particle in the center of every atom.

### Glenn Seaborg

> **Who:** The chemist whose teams found plutonium and nine more elements, and the first person to see an element named for him while he was alive.
>
> **When and where:** Berkeley, California, and wartime Chicago, from 1940 to 1974. He died in 1999.

**A letter addressed only in element names would reach him, Seaborg joked.**

The address was Seaborgium, Lawrencium, Berkelium, Californium, Americium. That stood for Seaborg, at the Lawrence laboratory, in the city of Berkeley, in California, in America. Element 106 was named seaborgium after him in 1997.

Glenn T. Seaborg led the team that made plutonium in December 1940 and proved it was a new element in February 1941. In all, he helped discover ten elements, numbers 94 through 102 and number 106. One of the ten, nobelium, was later credited to scientists at Dubna in the Soviet Union.

Seaborg shared the 1951 Nobel Prize in Chemistry with Edwin McMillan for their work on the elements heavier than uranium. From 1961 to 1971 he was chairman of the Atomic Energy Commission, the federal agency in charge of atomic energy.

**If you remember one thing:** The elements Americans used poisoned many of the people who handled them, and in 1940 American labs began finding new elements of their own.

- June 8, 1928: The New Jersey dial painters sign their settlement with the U.S. Radium Corporation.
- 1940: Teams at Berkeley make astatine and neptunium, the first elements discovered in the United States, and then plutonium.
- December 1, 1941: Connecticut's governor announces the state's ban on mercury in hat making.

**Next:** After 1950, Berkeley and a lab in the Soviet Union argued over who had made the heaviest elements first, and uranium mining on Navajo land reached its peak.

## 1950 to 2000

**Era 9 of 10 · 1950 to 2000 · about 17 minutes**

Scientists at Berkeley and at Dubna, a lab in the Soviet Union, argued for decades over who had made the newest elements first. Teams at Berkeley and other American labs made or claimed elements 98 through 106 between 1950 and 1974, and Dubna's scientists claimed several of the same ones. In 1992 and 1993 the members of an international panel gave some credit to Berkeley, some to Dubna, and split the rest.

Uranium mining on Navajo land reached its peak in the same years. Miners breathed radioactive gas underground, and most small mines had no fresh air blown in until the 1960s or later. Government researchers and mine owners did not tell the miners the danger, and hundreds of miners died of lung disease and cancer. Other scientists proved that lead was harming children's brains, and between 1971 and 1996 federal officials limited and then banned lead in house paint and in gasoline for cars.

### Elements from Berkeley and from a bomb test

Kenneth Street Jr., Stanley G. Thompson, Albert Ghiorso and Glenn Seaborg made element 98 at Berkeley early in 1950 by striking curium with helium particles. They announced it on March 17, 1950, and named it californium, for the state and its university.

**Two elements from a bomb.** Elements 99 and 100 turned up in the dust of Ivy Mike, the test of a hydrogen bomb, a bomb far more powerful than the first atomic bombs. The test took place at Enewetak Atoll, a ring of small coral islands in the Pacific Ocean, on November 1, 1952. The blast wiped out one of the atoll's islands, Elugelab, turning it to vapor.

Drone planes with no one aboard flew through the mushroom cloud, carrying filter papers to catch the dust. Workers then shipped tons of coral from the blast site to Berkeley. In the dust and coral, Ghiorso and teams from Berkeley, Argonne and Los Alamos found two new elements. In the blast, uranium atoms had soaked up huge numbers of neutrons, tiny particles in the center of an atom.

Government officials classified the discoveries, keeping them secret. The scientists published them on August 1, 1955, with the names einsteinium and fermium. By then both men they honored had died, Enrico Fermi in November 1954 and Einstein in April 1955. Neither man was told that an element would carry his name.

### Seventeen atoms, one at a time

A Berkeley team made element 101 in 1955 from about a billion atoms of einsteinium, all the einsteinium that existed. The team was Ghiorso, Bernard G. Harvey, Gregory R. Choppin, Thompson and Seaborg. They struck the einsteinium with particles, and the new atoms flew off onto a gold foil, a way of catching atoms that Ghiorso had worked out. The team dissolved the foil and rushed it through the chemistry.

They made 17 atoms of element 101 in all. It was the first element identified one atom at a time. In the scientists' own telling, Ghiorso wired the detector to the building's fire alarm, so the bell rang for each new atom. He forgot to disconnect it, and the alarm later emptied the building late at night.

The team named element 101 mendelevium, for Dmitri Mendeleev, the Russian who made the periodic table. That was during the Cold War, the long contest between the United States and the Soviet Union, and Seaborg asked the United States government for approval before he used a Russian's name. A French chemist later told Ghiorso that the name did more for American and Soviet relations than most diplomacy, the work of officials who handle dealings between countries.

### The fight over elements 102 to 106

Berkeley and Dubna each claimed to have made elements 102 through 106 first. Each side gave the elements its own names and argued for them in science journals for decades. In 1992 and 1993 a panel of chemists and physicists called the Transfermium Working Group, named for the elements after fermium, element 100, split the credit between the two labs, and the names were settled in 1997.

**Element 102.** Scientists in three countries worked on element 102. A team in Stockholm, Sweden, claimed it in 1957 and named it nobelium, for Alfred Nobel, then took back its claim. Berkeley scientists claimed the element in 1958, and scientists at Dubna did experiments on it in 1966. The panel's members credited Dubna. The International Union of Pure and Applied Chemistry (IUPAC), the world organization of chemists whose officials approve element names, kept the Swedish name nobelium anyway, because scientists had used it for more than 30 years.

The panel's members split the credit for elements 103, 104 and 105 between Berkeley and Dubna. They credited Berkeley alone with element 106. Element 103 kept the name lawrencium, for Ernest Lawrence.

**Seaborgium.** IUPAC's officials proposed a rule in 1994 against naming elements for living people. Under that rule, they could not have approved the Berkeley name for element 106, seaborgium. In 1997 they set the proposal aside and approved the final names: rutherfordium for element 104, after the scientist Ernest Rutherford, dubnium for element 105, after the town of Dubna, and seaborgium for element 106.

Glenn Seaborg was the first person to see an element named for him while he was alive. He kept a periodic table with seaborgium on it until he died in 1999.

### Albert Ghiorso

> **Who:** The builder of instruments who helped discover more elements than anyone else in history, without ever earning a doctorate.
>
> **When and where:** Berkeley, California, from 1944 to 1974, with work into the 1990s. He died in 2010.

**He helped discover 12 elements and never earned a doctorate.**

Albert Ghiorso helped discover americium through seaborgium, numbers 95 to 106, without a doctorate, the highest university degree. Guinness World Records lists his 12 as the most elements discovered or co-discovered by one person.

Ghiorso built the tools the element hunters needed, among them the detectors. He worked out the method of catching new atoms on a foil, which his team used to find mendelevium in 1955. And he ran the HILAC, a machine at Berkeley that sped up particles to make new elements.

One story his colleagues told about him has him driving fresh, radioactive samples across the lab in a Volkswagen car.

### Darleane Hoffman

> **Who:** A nuclear chemist who proved that plutonium, an element people had made in labs, also occurs in nature.
>
> **When and where:** Los Alamos, New Mexico, from 1953, and Berkeley, California, from 1984. She died in 2025, at the age of 98.

**She found plutonium, an element made in labs, in ancient California rock.**

Darleane C. Hoffman was a nuclear chemist, a chemist who studies atoms that break apart and give off radiation. She began work at Los Alamos in 1953. In 1971 she found traces of plutonium-244 in ancient rock from the Mountain Pass mine in California. Until then plutonium had been known only as an element made in labs, and her find showed that tiny amounts of it also occur naturally on Earth.

Hoffman showed that atoms of fermium-257 could split in two on their own. She was the first woman to lead a science division at Los Alamos. From 1984 she led work at Berkeley on the chemistry of the heaviest elements, studying them one atom at a time.

She won the National Medal of Science in 1997. In 2000 she won the American Chemical Society's Priestley Medal, named for Joseph Priestley, as only the second woman ever to receive it.

### Elements at home

Many home smoke detectors hold a speck of americium-241, about a third of a millionth of a gram. The americium gives off alpha particles inside a small chamber. The particles let a tiny electric current run through the air in the chamber. Smoke that drifts in disturbs the current, and the alarm goes off.

Silicon is an element that was discovered in Sweden in 1824. Computer chips are made of it, and Silicon Valley takes its name from the element in the chips made there.

The federal helium program was $1.4 billion in debt by 1996. That year members of Congress passed the Helium Privatization Act and ordered the Federal Helium Reserve sold.

### Uranium miners on Navajo land

While the element hunters argued over credit, uranium miners on Navajo land were breathing radioactive gas. Their ore went to one buyer. EPA staff state that the Atomic Energy Commission (AEC), the federal agency in charge of atomic energy, was the only buyer until 1966 and kept buying ore until 1970. Doug Brugge and Rob Goble, writing in the *American Journal of Public Health* in 2002, say the government was the only buyer from World War II until 1971.

About 10,000 people worked in uranium mining in all, and about a quarter of them were Navajo. The mining peaked in the middle of the 1950s, with about 750 mines working. The companies named in the records include the Vanadium Corporation of America, Kerr-McGee, the United Nuclear Corporation and Hydro Resources Inc.

**What radon does.** When uranium atoms break apart, they turn into radon, a radioactive gas. Radon atoms then break apart into radioactive specks called radon daughters, and miners breathed them in. Brugge and Goble explain that the daughters stay in the lungs next to delicate cells and hit those cells with strong doses of radiation. The harm named in the records is lung cancer and lung fibrosis, scarring that makes the lungs stiff, so that breathing gets harder.

Navajo miners report that no one told them about the dangers of uranium mining. They say they got no protective equipment and no ventilation, the fans and shafts that blow fresh air into a mine and push radon out. Scientists already knew about the danger from uranium mines in Europe. Brugge and Goble found that few protections were in place for American miners before 1962, and they came slowly after that.

**A warning turned down.** Members of a federal panel, the Advisory Committee on Human Radiation Experiments, traced who made these choices in their 1995 report. In 1948 Merril Eisenbud, a safety expert in the AEC's New York office, urged AEC officials to write safety rules into the agency's contracts to buy ore. Officials of two AEC divisions, Biology and Medicine and Raw Materials, rejected his advice. They said that under the law the AEC had no power over safety in the mines.

**The study that did not warn them.** Public Health Service workers led by Duncan Holaday and Victor Archer followed the miners from 1950 to measure their cancer risk. Accounts give the study group two sizes. Linda M. Richards, writing in 2013 for *Distillations*, the magazine of the Science History Institute, counts 3,415 miners, 779 of them Native American. The 1995 federal committee counted about 4,100. Brugge and Goble found that the researchers did not tell the miners about the risks they were studying.

At first the researchers left the minority miners out of the results, saying they wanted "a homogeneous population," a group of people who are all alike. Duncan Holaday later testified in court that the researchers made a spoken agreement with the mine owners not to tell the miners what they found. They made that deal so the owners would let them into the mines.

Staff of the AEC and of the Public Health Service met on January 25, 1951. The staff at that meeting believed the radon in the mines was at levels that would cause cancer. They agreed that ventilation could lower it, but they called it "unrealistic" to set a limit the mine owners had to meet.

**Hueper's speech.** Wilhelm Hueper, a cancer researcher at the National Cancer Institute, warned about radon. His figures showed lung cancer in 40 to 75 percent of the radioactive ore miners in Europe. In 1952 Shields Warren of the AEC asked the institute's director to stop Hueper from giving those figures in a speech to the Colorado Medical Society. The director ordered Hueper to cut them, and Hueper did not give the speech.

Warren then asked that Hueper be fired. Hueper kept his job, but Victor Archer later said Hueper was forbidden to travel west of the Mississippi River for his research. The 1995 committee report that gives Archer's account does not say who gave that order.

Public Health Service officials urged the mining companies to ventilate. Some large mines got ventilation in the 1950s and 1960s, but most small mines got none until the 1960s or later. Secretary of Labor Willard Wirtz set the first federal radon limit for these mines in 1967. The committee's members found that the mine owners, the state governments and the federal government all had a duty to ventilate the mines after 1951.

**In court.** A federal judge found in 1984, in a case called *Begay v. United States*, that Public Health Service officials, working under the Surgeon General, decided not to warn the miners because they feared many would quit. The judge still ruled that the miners could not sue the United States government. The law that lets people sue the government for harm does not cover choices that officials make as a matter of policy, and the judge found that the choice not to warn the miners was one of those.

In the ruling, the judge wrote that the miners' situation "cries for redress," meaning it called out to be put right, and called it a "tragedy of the nuclear age." Appeals judges upheld the ruling in 1985.

A study from 2000, cited by Brugge and Goble, found 94 deaths from lung cancer among Navajo people from 1969 to 1993, and 63 of them had been uranium miners. Richards reported that by the early 1980s "hundreds of Indian miners had died from lung diseases and cancers."

**Known:** The 1995 federal committee found that 410 of the 4,100 miners in the Public Health Service study had died of lung cancer by 1990, more than five times the 75 deaths expected.

**Not known:** How many Navajo miners died in all, since none of these accounts gives a full count.

**The law of 1990.** Members of Congress passed the Radiation Exposure Compensation Act on October 5, 1990, and President George H. W. Bush signed it on October 15. Under it, a uranium worker made sick by radiation on the job could claim one payment of $100,000, if the worker met the law's rules.

Harris Charley was a Navajo uranium miner. His records show he breathed 1,192 "working level months" of radon, a unit that measures how much radon a miner breathed over time. He died of lung fibrosis in 1986.

His son, Perry H. Charley, became an environmental scientist and worked with Stewart Udall, a former Secretary of the Interior, to investigate the miners' illnesses. In 1996 he helped start the Uranium Education Program at Diné College, which carries the Navajo people's own name for themselves. Navajo organizers, among them Harry Tome, Perry Charley and Phil Harrison, pushed for help for the miners from the 1960s on.

### The spill at Church Rock

An earthen dam owned by the United Nuclear Corporation broke near Church Rock, New Mexico, on July 16, 1979. The dam held waste from the company's uranium mill, a plant that takes uranium out of crushed rock. The waste was tailings, the ground-up rock left behind after the uranium is taken out.

The waste ran at least 80 miles down the Rio Puerco, a river that flows past the homes of about 1,700 Navajo people. Accounts give slightly different amounts. Richards gives 1,000 tons of radioactive tailings and 93 million gallons of acid, radioactive water. New Mexico's Environmental Improvement Division, the state office that checked for pollution, gives 1,100 tons and 94 million gallons.

Measured in curies, a unit of radioactivity, the spill released 46. The accident at the Three Mile Island nuclear power plant, four months earlier, released 13. The U.S. Geological Survey called Church Rock "the largest accidental radioactive release in the United States."

The authors of the Environmental Improvement Division's own report saw it differently. They concluded that the spill's effects "on people and the environment were quite limited." They wrote that the water pumped out of the mines into the Puerco River might be a greater long-term danger.

**What officials did.** Within a few hours, officials of the Environmental Improvement Division began testing the river. They ordered United Nuclear to stop sending waste to the broken pond, and the company stopped milling for about three months. No official declared an emergency or ordered anyone to leave.

New Mexico's governor, Bruce King, turned down the Navajo Nation's request to have the area declared a federal disaster area, according to news accounts. The state's report on the spill names no United Nuclear official as responsible for the dam.

### Lead: the proof and the bans

Thousands of American children went to the hospital each year in the 1960s with lead encephalopathy, swelling and damage of the brain, and about one in four of them died. A 2007 review in the journal *Environmental Health Perspectives* states those numbers.

**Where the lead came from.** Before the 1960s, the poisoned children usually lived in old, poorly kept slum housing, David Rosner and Gerald Markowitz wrote in 2012. The children had swallowed flakes of lead paint and went into convulsions, fits of violent shaking they could not control. Rosner and Markowitz call lead paint in older buildings the major source of lead around children.

Lead harms a child's growing brain. It lowers intelligence and causes trouble with reading, paying attention and behavior, and the 2007 review states that no safe level of lead is known. The review names the main ones to blame: the paint and pigment industry, the oil industry and a few scientists paid by industry.

**The proof.** Clair Patterson, a Caltech scientist who studied the chemistry of rocks and the Earth, measured lead in the air at about 1,000 times its natural level. In a 1965 paper he called the "safe level" idea of Robert Kehoe, the scientist the Ethyl company had paid to study lead, "an ill-defined opinion unsupported by any evidence."

Herbert Needleman, a children's doctor in Pittsburgh, measured the lead in the baby teeth of about 2,500 schoolchildren in the 1970s. Children with more lead in their teeth did worse in school. Scientists paid by the lead industry challenged his work, and later reviews backed his findings, according to Bill Kovarik, who wrote the 2005 article about the tetraethyl lead deaths.

**The bans.** Members of Congress passed the Lead-Based Paint Poisoning Prevention Act in 1971. Under it, homes built or repaired with federal money could have only limited amounts of lead paint, and in 1972 the limit was set at 0.5 percent of the paint. Officials of the U.S. Consumer Product Safety Commission banned lead paint in all homes in 1978, and from then on house paint could hold no more than 0.06 percent lead. Homes built before 1978 are still likely to have some lead paint.

EPA officials began work on a rule to cut the lead in gasoline in 1972 and 1973. Gas stations began selling unleaded gasoline, and car makers built cars for it, in 1975 and 1976. The Clean Air Act's ban on leaded gasoline for cars and trucks took effect on January 1, 1996. On January 29, EPA Administrator Carol M. Browner announced the last step in 25 years of cutting lead out of gasoline. She said the amount of lead in children's blood had fallen 70 percent.

### Poisoned ground put on the cleanup list

EPA officials put both the Anaconda smelter site in Montana and the Church Rock mill on the National Priorities List in 1983. The list includes the country's most dangerous waste sites, chosen for cleanup under the federal Superfund program.

Smelting at Anaconda had stopped in 1980. EPA staff count nearly 100 years of smelting at the whole site, which left arsenic, cadmium, copper, lead and zinc over more than 200 square miles. EPA staff list Atlantic Richfield, the company that bought the smelter in 1977, as responsible for the cleanup.

**If you remember one thing:** Between 1950 and 2000, researchers proved what radon did to uranium miners and what lead did to children, and federal officials banned leaded gasoline and began paying sick uranium workers.

**One number:** 70 percent. That is how far the amount of lead in children's blood had fallen by January 1996, after 25 years of cutting lead out of gasoline, by the count Carol Browner announced.

**Next:** After 2000, Russian and American scientists finished the seventh row of the periodic table together, and lead from old pipes got into the tap water of Flint, Michigan.

## 2000 to Today

**Era 10 of 10 · 2000 to Today · about 11 minutes**

The heaviest elements yet came from Russian and American scientists working together. Joint teams made elements 114 through 118 between 1998 and 2010. The atoms formed at Dubna, in Russia, and scientists from American labs brought detectors and, for element 117, the only target material in the world that would work. In 2015 and 2016 IUPAC's officials recognized the last four elements of the periodic table's seventh row and gave them names.

The poisons of earlier years were still in the ground and the pipes. As of June 2026, EPA staff count 523 abandoned uranium mines on the Navajo Nation. Managers appointed by Michigan's governor switched the water supply of Flint, Michigan, in 2014, and into 2015 the water carried lead from old pipes to the city's people.

### Finishing the seventh row

Scientists at the Joint Institute for Nuclear Research in Dubna, Russia, worked with scientists from Lawrence Livermore National Laboratory in California. For elements 115 and 117, scientists from Oak Ridge National Laboratory and Vanderbilt University joined them. The first atom of element 114 formed at Dubna in December 1998, and element 116 followed in 2000.

IUPAC's officials named element 114 flerovium in May 2012, for Russia's Flerov Laboratory. They named element 116 livermorium, for the Livermore laboratory and the city of Livermore, California.

**The row filled.** IUPAC's officials recognized elements 113, 115, 117 and 118 on December 30, 2015, which filled the seventh row of the periodic table, and they announced the names on November 28, 2016. Scientists at RIKEN, a research institute in Japan, made element 113, the first element discovered in Asia, and it became nihonium. Element 115 was named moscovium, for the region around Moscow, and element 117 tennessine, for Tennessee.

Element 118 became oganesson, for Yuri Oganessian, the Dubna physicist who led the hunt for these heavy elements. It was only the second element named for a living person, after seaborgium. His colleagues asked him to leave the conference call before they voted on the name. IUPAC's officials credited these elements to the joint teams, made up of scientists from several countries who worked together.

### Tennessine and the berkelium target

Joe Hamilton of Vanderbilt University started the partnership on element 117 when he introduced Jim Roberto of Oak Ridge to Yuri Oganessian. To make element 117, the Dubna team needed a target made of berkelium-249, and the only place that could make it was a research reactor at Oak Ridge National Laboratory. The berkelium spent 250 days in the reactor. Oak Ridge chemists then spent 90 days working on it and ended up with 22 milligrams, thousandths of a gram.

**Five trips across the Atlantic.** The berkelium was shipped in June 2009. Russian customs officials, who check what comes into a country at its border, twice rejected the paperwork, so the package crossed the Atlantic Ocean five times. At Dubna, scientists fired a beam of calcium-48 atoms at the target for six months and made six atoms of element 117. The team published the discovery in April 2010.

Tennessee became the second American state named on the periodic table, after California. The atoms of tennessine formed in Russia. Promethium, found at Oak Ridge in 1945, is still the only element discovered in Tennessee.

### Clarice Phelps

> **Who:** A nuclear chemist at Oak Ridge National Laboratory and a U.S. Navy veteran. Her laboratory's staff profile describes her as the first Black woman involved in the discovery of an element.
>
> **When and where:** Oak Ridge National Laboratory, Tennessee, from 2009. Her berkelium work began in 2010, and the laboratory recognized her in 2019.

**She helped purify berkelium for the experiments that confirmed element 117.**

Clarice Phelps served in the U.S. Navy and graduated from Tennessee State University. She joined Oak Ridge National Laboratory in 2009, and her first job there was as a nuclear operations technician.

She worked in the laboratory's Nuclear Security and Isotope Technology Division from 2010. There she was part of a team that helped purify berkelium-249, removing everything else from it. Scientists used that berkelium to confirm the discovery of element 117. The berkelium for the first run at Dubna had shipped in June 2009, before she began this work.

A 2019 news release from Oak Ridge National Laboratory described her as "the first African American woman to be involved with the discovery of an element, tennessine." That first is her laboratory's claim. IUPAC's officials credited Oak Ridge as a laboratory, not its scientists one by one. The same year, she was named to the Periodic Table of Younger Chemists, a project of IUPAC and the International Younger Chemists Network.

### Toward element 120, and the end of federal helium

Scientists in the Heavy Element Group at Berkeley Lab made two atoms of livermorium in a new way in 2024. They fired a beam of titanium-50 at plutonium-244 in the lab's 88-Inch Cyclotron, and Berkeley Lab's news center reported the result on July 23, 2024. The test showed that the method could work for element 120.

Element 120 would start the eighth row of the periodic table, and it would be the heaviest atom ever made. The Berkeley team began runs to make it in 2025, firing titanium-50 at californium-249. As of August 2026, no one had announced a discovery.

**The end of federal helium.** Federal officials sold the Federal Helium System, which included the reserve, the Cliffside gas field and a pipeline 423 miles long, to Messer, a company that sells industrial gases. The sale was completed in June 2024. Messer's accepted bids, opened in January 2024, totaled $423.35 million. Officials of the Bureau of Land Management, a federal agency, stated in 2024 that the sale in the end sent about $460 million to the U.S. Treasury, the government's money office.

Helium is still scarce. Hospitals need it for MRI machines, which take pictures of the inside of the body, and rocket makers and computer chip makers use it too.

### Uranium on Navajo land today

Elsie Mae Begay, a Navajo woman, lived in Monument Valley below the abandoned Skyline uranium mine. Two of her sons who had lived with her died, one of lung cancer and the other of a tumor. Linda Richards, who reported her story in 2013, calls them rare cancers. Richards does not say whether doctors linked the sons' cancers to the mine.

Begay's family hogan, a traditional Navajo house, gave off radiation up to 100 times the acceptable level, the Associated Press reported. When her children were young, they had played in piles of uranium tailings. Richards writes that people testing Navajo homes found dangerous radioactivity where families had built with mine debris or mixed it into concrete floors. EPA officials treated the Begay hogan as nuclear waste, and in 2001 men in radiation suits took it apart and hauled it away.

**The Navajo ban.** Members of the Navajo Nation Council passed the Diné Natural Resources Protection Act in 2005. Under it, uranium mining is banned on Navajo land.

**How many mines.** EPA staff count 523 abandoned uranium mines on the Navajo Nation as of June 2026. They have money to study and clean up 230 of them, fewer than half, and they list 46 as priority mines. Richards, counting abandoned mine sites rather than mines, found at least 1,032 on Navajo land in 2013, and 38 water sources with more radioactive elements than health limits allow.

EPA officials had reached agreements and settlements over the mines worth more than $1.7 billion by June 2026. A settlement is an agreement to pay money to end a legal fight.

About 3,975 uranium workers had applied for payments under the Radiation Exposure Compensation Act by March 2001, according to Brugge and Goble. The law ran out for a time. Members of Congress renewed it as part of the One Big Beautiful Bill Act, which became law on July 4, 2025. According to the Department of Justice in September 2026, workers must file claims by December 31, 2027, and a uranium worker who qualifies receives $100,000, paid once.

### Lead in the water of Flint

Flint, Michigan, is a majority-Black city. Emergency managers switched its water supply in April 2014. Michigan Governor Rick Snyder had appointed them to run the city in place of its elected leaders. Flint had been getting Detroit's water, drawn from Lake Huron, and the new supply came from the Flint River.

**Who made the switch.** Governor Snyder later appointed the Flint Water Advisory Task Force to find out what went wrong. Its 2016 report states that Flint's emergency manager Ed Kurtz approved using the Flint River, and that Darnell Earley, the emergency manager in April 2014, oversaw the switch. A timeline published by the Centers for Disease Control and Prevention (CDC), the federal health agency, states that the river water had no corrosion control, a treatment that keeps water from eating into pipes.

Detroit's water carried a chemical called orthophosphate, which protects pipes from corrosion. The Flint River water had none, and it was high in chloride, a salt. The river water ate into the city's old pipes.

Flint's service lines carry water from the main line under the street into each house. Between 10 and 80 percent of them were made of lead, according to an estimate published in 2016. Lead was in the water for about 18 months, reporters for NPR, a national radio network, said in 2023.

**The children's blood.** Mona Hanna-Attisha, a children's doctor at Hurley Medical Center in Flint, and her colleagues compared blood tests of 1,473 children in Flint with 2,202 outside the city, in a study published in 2016. Among Flint children under 5, the share with high lead in their blood about doubled, from 2.4 percent in 2013 to 4.9 percent in 2015. In the parts of the city with the most lead in the water, it rose from 4.0 to 10.6 percent.

Children absorb 40 to 50 percent of the lead they swallow in water, and adults absorb 3 to 10 percent. Babies who drank formula mixed with tap water were at the highest risk.

**The warnings.** Miguel Del Toral, an EPA expert on lead in water, warned officials of Michigan's Department of Environmental Quality (MDEQ) on February 27, 2015. He wrote that MDEQ's instructions for collecting water samples made the lead readings come out low, and that a federal rule, the Lead and Copper Rule, required Flint to have corrosion control. The same day, Stephen Busch of MDEQ wrote back that Flint had working corrosion control. The task force found that this was wrong.

Del Toral asked another MDEQ official on April 25, 2015, how Flint could meet the rules with no corrosion control. That official traded e-mails about his question with Busch and Mike Prysby of MDEQ. In July 2015 MDEQ's spokesman, Brad Wurfel, wrote that Flint's residents "do not need to worry about lead in the water supply."

Hanna-Attisha and her colleagues at Hurley Medical Center told pregnant women and children to stop drinking the water in September 2015. Flint was connected again to a regional water system in 2015. Snyder asked for federal help on January 14, 2016, President Barack Obama declared a federal emergency in Flint two days later, and EPA officials issued their own emergency order on January 21.

**Legionnaires' disease.** Legionnaires' disease, a lung infection and a kind of pneumonia, is caused by bacteria that grow in poorly treated water. Genesee County, where Flint is, had 90 cases from June 2014 to October 2015. NPR reporters linked the outbreak in 2018 to low chlorine, the chemical that kills germs in drinking water, in Flint's water.

**Known:** State health officials counted 10 dead in one report and 12 in another.

**Disputed:** The official count, because reporters for the PBS program *Frontline* found more deaths from pneumonia that it missed.

**The charges.** None of the officials charged over Flint's water ever went on trial, and no judge sent any of them to jail or prison. Lawyers hired by Michigan's attorney general, the state's top lawyer, charged 15 state and city officials in 2016 and 2017. Seven of them made deals and agreed to help the investigators.

All seven had been charged with at least one felony, one of the most serious kinds of crime. Under the deals, each one accepted a single lesser charge, a misdemeanor, without admitting guilt, and the lawyers dropped the rest. Judges later dismissed all seven cases, so none of them has a criminal record from these charges.

New lawyers took over the cases in 2019. In June they dropped the charges against the other eight, saying the first lawyers had not gone after all the evidence. In January 2021 they brought new charges against nine officials, among them six of those eight and the former governor.

The former governor faced two counts of willful neglect of duty, knowingly failing to do his job. The state's health director and its chief medical executive each faced nine counts of involuntary manslaughter, causing a person's death through carelessness without meaning to kill.

**How the cases ended.** The new lawyers had brought the 2021 charges through a one-judge grand jury, a single judge who decides alone whether to charge someone with a crime. In June 2022 the judges of the Michigan Supreme Court ruled that, under Michigan's laws, such a judge had no power to start a criminal case.

Judges in Genesee County then dismissed all nine cases. The new lawyers declared the cases closed on October 31, 2023. By then the time limit for bringing most of the charges again had run out.

Flint's people sued. U.S. District Judge Judith Levy approved a settlement of $626.25 million on November 10, 2021, for more than 90,000 Flint residents and businesses.

**The three questions, answered**

- Who lost their land when Americans found gold and copper on it? The Cherokee lost theirs after gold turned up in Georgia in 1829, when Georgia lawmakers gave it away by lottery and soldiers forced them west in 1838. The Ojibwe bands of Lake Superior gave up the copper country in the Treaty of La Pointe in 1842, and members of Congress took the Black Hills from the Sioux in 1877, after Custer's men found gold there.
- What did the people in charge say about the radium, lead and uranium that poisoned workers? Supervisors told the dial painters the paint was safe, the Bayway supervisor said his poisoned men had worked too hard, and Thomas Midgley breathed the vapor of tetraethyl lead in front of reporters to show it was safe. Public Health Service researchers agreed with mine owners not to tell the uranium miners what they found.
- When did someone in the United States first discover a new element? In 1940, at Berkeley, California, when teams using Ernest Lawrence's cyclotron made astatine and neptunium, and then plutonium. Every element before that had been found abroad, and Fred Allison's 1931 claims were false.

**What changed:** Nobody anywhere knew what an element was in 1500, and by 2010 scientists from American labs had helped make element 118, the heaviest yet.

**Five dates to keep**

- 1799: Conrad Reed finds a 17-pound gold nugget in North Carolina.
- October 4, 1842: Ojibwe bands give up the Keweenaw copper country in the Treaty of La Pointe.
- June 8, 1928: The New Jersey dial painters sign their settlement with the U.S. Radium Corporation.
- December 14, 1940: Glenn Seaborg's team makes plutonium at Berkeley.
- April 2014: Emergency managers switch Flint's water to the Flint River.

**Not known:** How many Navajo uranium miners died of their work in all, because each count that exists covers only some of them.

**Where to go:** Saugus Iron Works National Historic Site, on the Saugus River near Boston, is the place where Hammersmith's furnace, forge and mill worked from the 1640s until about 1670.

**Next:** Chapter 14, Work and Workers. It asks what the daily job felt like and how working people organized, and Grace Fryer's fight comes back there from the workers' side.
