# Chapter 17: Money

**Chapter 17 of 37 · Money · 10 eras · about 70 minutes**

**Most American money since 1690 has been a written promise to pay, and when the people who made the promise could not keep it, the people holding the money took the loss.**

Soldiers from Massachusetts came home from a failed attack on Quebec in 1690, and the colony's treasury held too few coins to pay them. In December the colony's lawmakers began voting to pay them in paper. Each bill stated that the treasurer would accept it "in all Public payments" and that it could later be traded for coins. No government in Europe or its colonies had printed paper money before. People took the bills and passed them from hand to hand.

This chapter follows money from the shells and copper traded before 1500 to bitcoin. As you read, watch what stood behind a dollar, from Spanish silver to nothing but the law. Watch, too, who took the loss when a promise to pay was broken: whoever held Continental bills in 1781, savers at the banks that failed from 1837 to 1933, and about 31,000 depositors of the Freedman's Bank who never got any money back. In Louisiana in 1837, enslaved people pledged for loans were sold to pay the debts.

**Three questions this chapter answers**

- What has stood behind the dollar, and what stands behind it now?
- Why did people rush to pull their money out of banks, and who lost when a bank failed?
- How did enslavers and bankers use enslaved people to raise money?

**Five minutes?** Read "1930 to 1933: the runs, the holiday and deposit insurance" in 1900 to 1950. The Lydia Lobsiger story follows it.

**Can skip:** "The ATM", "War bonds", "Payday loans". The chapter still makes sense without them.

## Before 1500

**Era 1 of 10 · Before 1500 · about 1 minute**

Wampum, beads made from shell, later passed as money between colonists and Native traders. Before 1500, though, nobody in this land used money of any kind: there were no coins, paper bills, banks or prices. People got what they needed by barter, trading one thing straight for another, and by gifts, and Chapter 16 tells how they carried shells, copper and obsidian, a volcanic glass, hundreds of miles.

### Was wampum money?

Wampum was not money before Europeans came. People used it to keep records, to make agreements between nations, in ceremonies and as gifts.

The white beads came from the shells of whelks, large sea snails. The purple-black beads came from the shells of quahogs, hard-shelled clams of the Atlantic coast. People strung the beads on cords or wove them into belts.

Among the Haudenosaunee, a league of Native nations in what is now New York State, the beads of a belt recorded spoken agreements and histories. People presented the belts at meetings of leaders, called councils, and read them there.

Wampum first passed as money in the 1600s, when colonists and Native traders used it in their dealings with each other.

## The 1500s

**Era 2 of 10 · The 1500s · about 3 minutes**

The American dollar was later based on a Spanish silver coin, and Spanish officials forced Native men to dig the silver for it. The mines lay far to the south, in lands the king of Spain ruled. Workers at Spanish mints, workshops where coins are made, struck the silver into a coin called the piece of eight. Almost none of those coins reached the land that became the United States in the 1500s. This land still had no mint of its own.

### The piece of eight

The piece of eight was a silver coin worth 8 of the Spanish money units called reales. In English it was also called the Spanish dollar. Workers at Spanish mints in the Americas made it from silver dug at Potosí, in what is now Bolivia, and at Zacatecas, in Mexico. Silver was found at Potosí in 1545.

Native men of the Andes, the high mountains of South America, did the digging at Potosí. Francisco de Toledo, the viceroy who governed Peru for the king of Spain, began forcing thousands of them to work in the mines in 1573. They worked in turns, under a system called the mita. Toledo took the name and the idea of turns of work from an older system used by the Inca.

Toledo's rules applied to Native men aged 18 to 50 in the highland provinces between Potosí and Cuzco. Each year about one man in seven from those villages had to go to the mines, more than 11,000 men a year.

The men worked in shifts, one week in the mines and then two weeks of rest. Many brought their families and carried most of their own food. They were paid a little, and most of that pay went to the tax they owed the colonial government. The work was dangerous and unhealthy. By sending the men away from their home villages, Toledo broke up life there too.

Across the Andes, disease killed far more Native people than work in the mines did. No reliable count shows how many of the forced workers died from the work at Potosí.

Traders carried the piece of eight from South America to Europe, and across the Pacific Ocean to Asia. Writers on the history of money, among them Alejandra Irigoin and Bridget Millmore, call it the first money used around the whole world.

Almost none of that silver reached this land. Some did reach St. Augustine, the Spanish military post in Florida that Chapter 16 describes. Pedro Menéndez de Avilés had founded it in September 1565 at Seloy, a Timucua village. Its soldiers were paid from Spanish colonial funds, in the coin of a foreign empire.

Later, Thomas Jefferson and members of Congress based the United States dollar on the piece of eight. Until February 21, 1857, Spanish coins were legal tender in the United States: the law said people had to accept them to pay a debt. The piece of eight was divided into eight parts called bits, so two bits made a quarter of a dollar. Americans still call a quarter "two bits."

## The 1600s

**Era 3 of 10 · The 1600s · about 4 minutes**

English colonists never had enough coins, so they paid each other in goods and then began to make money of their own. Little English coin reached the colonies. Colonists spent what they did get on goods shipped in from overseas, and those coins went back across the ocean. To trade with each other, they paid in tobacco, corn, beaver skins and wampum. Massachusetts leaders opened a mint without England's permission. In 1690 they began printing paper money.

### Money made of goods

Colonists called payment in goods "country pay." Colonial lawmakers set how much each kind of goods was worth when it was used to pay a debt. Money of this kind is called commodity money, because the money is a useful thing in itself.

English money was counted in pence, shillings and pounds. Twelve pence made a shilling, and twenty shillings made a pound.

Virginia lawmakers set a value on tobacco so it could be used as money from the 1620s, and in 1642 they made it legal tender. People in Virginia, Maryland and North Carolina paid with tobacco through much of the colonial period. In the northern colonies, beaver pelts and corn passed as money too.

New England colonists used wampum for small payments, though the nations that made it had not used it as money before colonists came. Members of the Massachusetts General Court, the colony's lawmakers, accepted wampum for small sums from 1637, made it legal tender for small debts in 1650 and canceled that law in 1661.

### The pine-tree shilling, 1652

Members of the Massachusetts General Court voted in 1652 to set up a mint in Boston. They did not ask anyone in England first. By English law, only the king could make coins. In 1652 England had no king.

**Why England had no king.** Supporters of the king had fought a civil war against supporters of Parliament, England's lawmakers. Afterward the judges of a court set up by Parliament found King Charles I guilty of making war on Parliament and on the people of England. Their sentence called him a "traitor" and a "murderer." Fifty-nine of the judges, Oliver Cromwell among them, signed the order for his death. On that order the king was beheaded in London on January 30, 1649.

Workers at the Boston mint struck silver coins worth threepence, sixpence and a shilling. One was the pine-tree shilling, named for the tree stamped on it. They struck pine-tree shillings from about 1667 to 1682, but nearly all of the colony's silver coins carry the date 1652.

**A date as a cover.** Coin experts who write in the magazine CoinWeek and in older books on early American coins explain the 1652 date this way. Charles II became king of England in 1660. A coin dated 1652 could pass as a leftover from the years without a king. A coin with a later date would show that the men of Massachusetts were still making coins without the king's permission.

The mint closed in 1682. In 1684 officials acting for King Charles II canceled the Massachusetts charter, the legal paper that gave the colony the right to exist and stated what it could do. The illegal mint was one of their complaints against the colony.

### John Hull

> **Who:** A Boston silversmith who ran the colony's mint against English law and struck the pine-tree shilling.
>
> **When and where:** Boston, Massachusetts. Mintmaster from 1652 until the mint closed in 1682. Lived 1624 to 1683.

**He kept a share of every batch of coins he struck.**

John Hull ran the Massachusetts mint from 1652 until it closed in 1682, without permission from England. He was a blacksmith's son from Market Harborough, England, and came to Boston with his parents in 1635, when he was 11. He trained as a silversmith, a craftsman who makes things out of silver.

Members of the Massachusetts General Court named him mintmaster, the man in charge of the mint, in 1652, when he was 27. His appointment was dated May 27. Robert Sanderson worked with him as his partner. Under his contract he was paid in coins from every batch, and that pay made him one of the richest men in New England. He later became the colony's treasurer, the official in charge of its money.

A story says Hull gave his daughter Hannah her weight in pine-tree shillings as her dowry, the money or goods a bride's family gives when she marries. The story is a legend. The writer Nathaniel Hawthorne retold it in his book *Grandfather's Chair* and added details of his own.

### The first government paper money, 1690

The soldiers in the chapter's opening were paid in paper bills called bills of credit, and the first ones, voted from December 1690, totaled 40,000 pounds. The soldiers had come home from a failed attack on the French city of Quebec, in Canada, during King William's War. According to accounts from the time, the unpaid troops were close to mutiny, an uprising against their officers.

These bills were the first paper money printed by any government in Europe or the lands Europeans had settled. China had used paper money centuries earlier.

**The paper spreads.** By 1714 Massachusetts lawmakers had put out 240,000 pounds in paper money. By 1718 lawmakers in the other New England colonies were printing their own.

## 1700 to 1750

**Era 4 of 10 · 1700 to 1750 · about 4 minutes**

Lawmakers in colony after colony printed paper money in the early 1700s, until every colony had its own. The bills held their value only where the lawmakers printed limited amounts.

Benjamin Franklin argued for paper money in Pennsylvania and then printed it. In South Carolina, which had no private banks, enslavers borrowed money by pledging land and the people they enslaved. If a loan was not paid back, the lender could take the land or the enslaved people who had been pledged.

### Paper that held its value and paper that lost it

Economists at the Federal Reserve Bank of Cleveland, who study how money and trade work, compared the paper money of the colonies. In Pennsylvania, New York and New Jersey, lawmakers printed limited amounts, and the bills held their value. In New England and the Carolinas, lawmakers printed large amounts. Prices counted in paper money rose there, and each bill was worth less silver than before.

**South Carolina's paper.** Lawmakers there began printing paper money in 1703, when 1.5 South Carolina pounds were worth one English pound. By the late 1720s it took about 7.

In Virginia, people began to pass paper receipts for tobacco as money. Virginia lawmakers set up public warehouses for tobacco, with government inspectors, in the 1720s and 1730s. A planter, a farmer who grew tobacco to sell, brought his tobacco to a warehouse. An inspector checked it, and it stayed in the warehouse. The inspector then wrote a receipt, called a tobacco note, for the inspected tobacco. People passed tobacco notes from hand to hand as money.

### Benjamin Franklin

> **Who:** A Pennsylvania printer who argued for paper money, then printed it with leaf patterns that were almost impossible for counterfeiters, people who make fake money, to copy.
>
> **When and where:** Pennsylvania, from 1729.
>
> **Movie:** *Benjamin Franklin* (2022), a documentary by Ken Burns, shown on PBS. It is about his whole life, not only his work on money.

**He printed the veins of real leaves on paper money.**

Benjamin Franklin printed paper money for three colonies and made it hard to fake. In 1729, when he was 23, he published a pamphlet, a short printed booklet, arguing that Pennsylvania needed more paper money. Its title was *A Modest Enquiry into the Nature and Necessity of a Paper-Currency*, a modest look at what paper money is and why it is needed.

Partly because of the pamphlet, Franklin won the contract to print Pennsylvania's bills in his shop. His firm printed money for Pennsylvania, New Jersey and Delaware.

To stop counterfeiters, Franklin printed the shapes of real leaves on the bills. Every leaf has its own pattern of veins. A counterfeiter could almost never carve that pattern into a printing plate by hand. The method is called nature printing. Franklin almost certainly worked it out from leaf prints he made with his friend Joseph Breintnall. The printing plates were probably cast in metal from plaster molds of real leaves.

Scientists at the University of Notre Dame looked closely at 600 notes printed by Franklin's firm. In their 2023 study they found the leaf prints, tiny shiny flakes of a mineral called mica in the paper, and colored fibers mixed into it. Printers kept putting leaf prints like Franklin's on colonial money into the Revolution.

Colonial bills carried the words "To Counterfeit is Death." Under colonial laws, judges could sentence a counterfeiter to death.

### Loans against land and enslaved people

South Carolina's lawmakers lent some of the colony's paper money out on land. In 1712 they set up a public land bank, through which officials lent paper money to people who pledged their land as security, something a borrower promises to hand over if a loan is not paid back.

People also borrowed from one another through private agreements. One kind was a bond, a written promise to pay back a loan. Another was a mortgage, a loan in which the borrower pledges property as security, so the lender can take that property if the borrower does not pay.

A mortgage could be on land, or on movable property, called chattel. In these loan papers, enslavers and lenders listed enslaved people as chattel. So when an enslaver did not pay, the lender could take the people he had pledged.

Nic Butler of the Charleston County Public Library described in 2024 how these loans worked, including loans from slave brokers, dealers in enslaved people. "A slave owner could mortgage their human chattel to a slave broker to secure credit used to purchase more slaves," he wrote. The enslaver pledged the people he enslaved to get a loan and used the loan to buy more people. Then he paid off the debt with what the people's forced work earned.

Hundreds of colonial land mortgages survive in the Charleston County Register of Deeds, the county office that keeps records of land. Thousands of early chattel mortgages survive in the South Carolina Department of Archives and History.

## 1750 to 1800

**Era 5 of 10 · 1750 to 1800 · about 6 minutes**

Paper money was one of the colonists' quarrels with Britain, and then it was how they paid for the Revolution. Members of the British Parliament banned new paper money as legal tender in New England in 1751 and in all thirteen colonies in 1764. Colonists added the ban to their complaints against Britain. During the war, members of the Continental Congress paid with paper bills that were nearly worthless by 1781.

After the war, Thomas Jefferson, Alexander Hamilton and members of Congress planned a new money system. Members of Congress chose a dollar divided into tenths and hundredths in 1785, set up a national bank in 1791 and created a mint in 1792.

### The Currency Acts

Members of Parliament, Britain's lawmakers, passed the first Currency Act in 1751 because New England's paper money had lost so much of its value. Under the act, Massachusetts Bay, Rhode Island, Connecticut and New Hampshire could no longer print new paper bills as legal tender.

A second Currency Act followed thirteen years later. On April 19, 1764, members of Parliament extended the ban to all thirteen colonies. Colonists were already short of coins. Without new legal-tender paper, they had even less money to pay debts and buy goods. Colonists listed the Currency Acts among their complaints against Britain.

### Not worth a Continental

People working for the British side printed fake Continental bills on purpose, so that the real bills would lose their value faster. Continental bills were the paper money that members of the Continental Congress, the men from the thirteen colonies who led the Revolution, printed from June 1775 to pay for the war. In all, they put out $241,552,780 in Continental bills, and Chapter 16 tells how fast the bills lost their value.

**Made in New York.** Most of the British faking was done in New York City, which the British army held for most of the war. Someone placed an advertisement in the *New York Gazette* of April 14, 1777, asking people going into the other colonies to take fake bills with them.

**The general's letter.** General Henry Clinton, the British commander, wrote about the plan in January 1780. His letter went to Lord George Germain, the official in London in charge of the American colonies. Stuart Hatfield, writing about the British faking in the *Journal of the American Revolution* in 2015, calls that letter the clearest sign that British leaders approved the plan.

People had stopped using the paper by 1781. In North Carolina it took 210 paper dollars to buy what one silver dollar bought.

Continental bills with about $226 million printed on them ended up worthless. Counted in silver, the loss was about $40 million. Whoever was holding the bills as they lost value lost that money, and most of them were ordinary people. The saying "not worth a Continental" comes from these bills, and by the late 1800s people in Britain were using it too.

### Counterfeiting was a hanging crime

Officials in New York hanged Owen Sullivan, whose name was also spelled Syllavan, in 1756 for faking that colony's paper money. Colonial bills were printed with the warning "To Counterfeit is Death," and New York officials carried it out.

Sullivan was born in Ireland in about 1720. As an engraver, he cut designs into metal plates for printing, and as an armorer he had made and repaired weapons for colonial soldiers. He ran gangs of counterfeiters who passed fake colonial bills from New England to New York.

Before that, officials in Rhode Island had punished Sullivan for faking that colony's bills. On October 9, 1752, the *Boston Evening Post* printed a report from Providence, Rhode Island. The report states that he had "lately had both his Ears crop'd, and been branded on both his Cheeks with the Letter C."

Cropping meant cutting off part or all of each ear. Branding meant burning the letter C, for counterfeiter, into the skin of each cheek with a hot iron. The C marked him as a counterfeiter to anyone who saw his face. The report does not name the officials who carried out the punishment.

Sullivan went on counterfeiting. At a session of the Supreme Court for the City and County of New York, he was found guilty of faking and passing New York's bills of credit from 1737. He was hanged on Monday, May 10, 1756. A pamphlet about his life, which says it was "taken from his own mouth," was printed the same year.

### Why a dollar has a hundred cents

A dollar has a hundred cents because the men who planned American money chose to count it by tens. In notes he wrote in 1784, Thomas Jefferson proposed the Spanish dollar as the basic unit, divided into tenths and hundredths. The English system of pounds, shillings and pence did not divide by tens.

Members of Congress voted on July 6, 1785, "that the money unit of the United States of America shall be one dollar." They also voted that the coins should "increase in decimal ratio," counting up by tens. With that vote, the United States became the first nation whose coins were fully based on tens.

Under the Coinage Act of April 2, 1792, members of Congress set up the United States Mint in Philadelphia. The Mint's building was the first building the national government put up under the Constitution. The act defined the dollar as the unit of money. Under it, the decimal system of dollars, dimes, cents and mills became law (a mill is one tenth of a cent).

The act listed coins in three metals: gold coins, including a ten-dollar coin called the eagle, silver coins from the dollar down to the half-dime, and copper coins, the cent and the half-cent.

### Alexander Hamilton

> **Who:** The first Secretary of the Treasury, who planned the national bank and the United States Mint.
>
> **When and where:** Secretary of the Treasury, 1789 to 1795. Lived 1757 to 1804.
>
> **Movie:** *Alexander Hamilton* (2007), a documentary in the PBS series *American Experience*.

**Jefferson and Madison said the Constitution did not allow his bank.**

Alexander Hamilton planned the national bank and the Mint in reports he wrote for Congress. President George Washington chose him on September 11, 1789, to be the first Secretary of the Treasury, the head of the government department in charge of money.

Hamilton sent Congress his *Report on a National Bank* in December 1790. He proposed a bank that would hold the government's money and put out banknotes, paper money printed by a bank, that people could trust.

Lawmakers in Congress then passed a bill to charter the First Bank of the United States, in Philadelphia, for twenty years. Thomas Jefferson and James Madison argued that the Constitution did not allow Congress to create a bank. In the House, Madison asked whether the power to start a bank was "among the powers" listed for Congress in the Constitution.

President Washington asked Hamilton to answer the objections, so that he would have "the arguments for and against the measure." Then Washington signed the bill, on February 25, 1791. Twenty years later, in 1811, a new charter lost by one vote in each house of Congress.

Hamilton had already sent Congress his *Report on the Establishment of a Mint*, in January 1791. In it he defined the dollar in both silver and gold, with 15 ounces of silver worth 1 ounce of gold. Members of Congress built the Coinage Act of 1792 on his plan and set up the Mint under it.

## 1800 to 1850

**Era 6 of 10 · 1800 to 1850 · about 11 minutes**

Americans in these years paid with paper money printed by hundreds of different banks. Some of that paper was lent out against enslaved people, and some against land that had belonged to Native nations.

The country had a national bank twice before 1850, and both banks lost their federal charters, the government papers that allowed them to exist. The First Bank's charter ran out in 1811. President Andrew Jackson vetoed, or refused to sign, a new charter for the Second Bank in 1832, and its federal charter ran out in 1836.

With no national bank and no national paper money from 1836 until 1862, people used gold and silver coins and the notes of state banks. A bank's notes were worth less the farther from that bank a person tried to spend them.

### Banknotes lent against enslaved people

Planters in Louisiana, the enslavers who ran large farms, had set up banks by the 1830s that lent out their own paper money against mortgages on enslaved people. In such a loan the enslaver pledged the people he enslaved, and the bank could take them if he did not pay. The paper notes people carried in their pockets in Louisiana had been lent out against enslaved human beings.

At the Consolidated Association of the Planters of Louisiana, an enslaver pledged "slaves and cultivated land" to the bank in a mortgage. He could then borrow up to half of what the bank's officers judged those people and that land to be worth. He received the loan in the bank's own paper notes.

To raise money to lend, the banks put out bonds. Each bond was a paper promise to repay a loan with interest, an extra payment for the use of the money. Louisiana lawmakers backed $2.5 million of the Consolidated Association's bonds, at 5 percent interest, which meant the state promised to pay the bonds if the bank did not.

Baring Brothers, bankers in London, paid the money up front and sold the bonds to investors in Europe. Chapter 16 lists the other Louisiana banks that raised money this way and the firms that sold their bonds.

A typical bond was for $1,000. Edward E. Baptist wrote in 2010 that this was "roughly the price of a field hand," an enslaved man who worked in the fields. An investor in Europe could own a share of a debt backed by thousands of enslaved people without owning any one person.

**Before the banks.** The merchant Vincent Nolte lent $48,000 to the Louisiana enslaver Alonzo Walsh in 1824. Walsh pledged "from 90 to a 100 head of first rate slaves," using head, the word for counting cattle. The account of the loan gives no names for these people. At New Orleans auction prices they were worth up to $80,000.

**The crash.** Many enslavers had placed several mortgages on the same person. Then cotton prices fell, from 18 cents a pound in 1834 to under 10 cents by late 1836, and by March 1837 ten large New Orleans cotton firms had failed.

When enslavers could not pay, the people they had mortgaged were sold in forced sales to pay their debts. The accounts of the crash do not name who ran each sale. Buyers spent what little cash they had at the first sales, and then the prices of land and of enslaved people fell sharply.

Chapter 16 tells the rest of the crash. It explains why some enslavers kept the people they held, and it gives a 2005 bank report's count of the enslaved people that two Louisiana banks took as security.

### The Bank War

The Bank War was the fight over whether the country should keep a national bank, a bank chartered by the national government to hold the government's money. Members of Congress chartered the Second Bank of the United States in 1816, for twenty years, after the money troubles of the War of 1812. Its main office was in Philadelphia.

Nicholas Biddle became president of the Bank in 1823. Under him the Bank held the government's deposits, the money the government kept in the Bank's care, and moved money across the country. Its officers also collected the notes of state banks and presented them to those banks for payment in gold and silver coins. A state bank had to hold enough coins to pay, so its owners could not print as many notes as they wanted.

Andrew Jackson and his supporters argued that the Bank was a private company with public power, with owners in other countries and no control by voters. They said its officers gave favors to rich people with connections. Biddle and the Bank's defenders argued that with the Bank, the country's money was worth the same everywhere and kept its value. They said that without it, nothing would stop state bankers from printing too much paper.

Henry Clay was running against Jackson for president in 1832. That July, four years before the old charter ran out, Clay led the push for a new one, and members of Congress passed it. Jackson vetoed the charter on July 10, 1832.

**The veto.** In his veto message Jackson called the Bank "unauthorized by the Constitution" and "dangerous to the liberties of the people." He said it weakened the rights of the states. That fall Jackson beat Clay and won a second term.

**The deposits.** Jackson ordered the government's money moved out of the Bank in 1833 and into state banks he chose, which his opponents called "pet banks." Two Treasury secretaries would not move the money, and Jackson replaced them. Roger Taney, the third, moved it. Biddle struck back in 1833 and 1834 by cutting the Bank's lending to force a new charter. Borrowing became hard, and Biddle lost supporters.

Members of the Senate censured Jackson on March 28, 1834, voting to blame him officially for what he had done. The Bank's federal charter ran out in 1836, and the Bank, which went on as a Pennsylvania state bank, failed for good in 1841.

### Andrew Jackson

> **Who:** The president who vetoed the Second Bank's new charter and moved the government's money out of it.
>
> **When and where:** The United States. Veto in 1832, removal of the deposits in 1833.
>
> **Movie:** *Andrew Jackson: Good, Evil and the Presidency* (2007), a two-hour PBS documentary narrated by Martin Sheen. It covers his whole presidency, not only the Bank War.

**He sold 68,000 acres for paper notes that turned out worthless.**

Andrew Jackson distrusted banks and paper money after he lost money on a land deal. In August 1795, at 28, he sold 68,000 acres of land to David Allison. The accounts of the sale do not say where the land lay or which Native nation had lived on it. Jackson was selling for himself, for John Overton and for others.

Allison paid with promissory notes, written promises to pay money later, and Jackson used the notes to buy supplies for a trading post. In 1797 Allison could not pay his debts, and his notes were worth nothing. The people holding the notes came to Jackson for payment instead. It took him about 15 years to pay his way out.

Allison's creditors, the people he owed, had him put in debtors' prison in Philadelphia, a jail for people who could not pay what they owed. He died there on September 28, 1798.

A 2001 article in *American Heritage* magazine describes what Jackson took from all this. By the end, the article states, he had settled ideas about debt, paper money and speculation, which is buying something only to sell it later at a higher price. "He hated them all."

### State banknotes and counterfeit detectors

Each bank that state lawmakers chartered printed its own notes, in its own designs. A note was worth only as much as people trusted the bank that printed it. Far from that bank, people would take its notes only for less than the amount printed on them, and the difference was called a discount.

Store owners checked notes against a printed guide before they took them. The guides were called bank note reporters and counterfeit detectors, and publishers put them out weekly or monthly from about 1826 to 1866. Each issue listed the discount on each bank's notes and described the fake notes going around. Shopkeepers kept them by the cash drawer.

Some banks were called wildcat banks. They were set up under state laws, called free-banking laws, with few rules for opening a bank. The story went that some stood so far out in the woods that only wildcats lived nearby, so nobody could get there to trade the notes for coins.

Economists today, among them Gerald Dwyer and the team of Rolnick and Weber, have found that most free banks were not frauds. The people holding their notes did lose money, but less than the legend says.

### Whose land the Michigan banks lent against

Michigan's wildcat bankers lent money in the late 1830s against land in the southeast of the state, around Ann Arbor. Until 1807 that land belonged to the Potawatomi, Ojibwe, Odawa and Wyandot nations.

In the Treaty of Detroit, a written agreement between nations, leaders of those four nations signed the land over to the United States on November 17, 1807. William Hull, the governor of Michigan Territory, signed for the United States. The land included the place that later became Ann Arbor.

**How much land, for how much.** United States officials paid $57,717.32 for the land, according to a history page of the Ann Arbor District Library, which puts the land's estimated value at $6,400,000. That price was less than 1 dollar for every 100 dollars the land was worth. The library counts the land at about 5.6 million acres, and the treaty page of the Nottawaseppi Huron Band of the Potawatomi counts it at about 8 million.

### Alpheus Felch

> **Who:** A Michigan bank commissioner, later the state's governor and a US senator, who wrote down the frauds he found in 1838.
>
> **When and where:** Michigan, 1838 and 1839. Lived 1804 to 1896.

**Under a top layer of coins, the boxes held nails and glass.**

Alpheus Felch was one of three officials who inspected Michigan's banks in 1838, and he wrote down the frauds he found. A lawyer in Monroe, Michigan, he had been one of four state lawmakers who voted against Michigan's free-banking law.

Michigan lawmakers passed that law on March 15, 1837. Before it, Michigan had 9 banks. Within months there were 18, and then 40. Three bank commissioners were appointed on December 30, 1837, to inspect them, and Felch served as one of them in 1838.

Felch described the inspections in 1880. Some banks kept "grossly insufficient books," records far too poor to show what the bank held. One bank had nothing of value at all. At another, bankers showed the commissioners boxes of coin. Under a top layer of coins, the boxes were filled with nails and glass.

At three banks in a row, the bankers showed the commissioners the same coins as their own. Local accounts say the bankers sent word ahead of the commissioners' route and carried the coins from bank to bank.

The commissioners could close a bank by court order. They could also hand it to a receiver, an official who takes over a failed bank and pays its debts from what is left. After the commissioners' reports, many banks closed and criminal cases followed in the courts.

Michigan lawmakers suspended the free-banking law in 1838. By September 1839 only 9 banks were left. In 1845 the judges of the Michigan Supreme Court ruled that the law broke Michigan's constitution, the state's basic set of laws.

**How much people lost.** People holding the notes of Michigan's failed banks lost an estimated 60 percent of the amount printed on them, according to the Ann Arbor District Library. A note printed for 10 dollars ended up worth about 4.

Economists' estimates of the total lost run from about $350,000, for the "perhaps a dozen" true wildcat banks alone, to about $1 million, for all of Michigan's failed free banks. Some of those economists argue that the judges' 1845 ruling against the law itself made many notes worthless.

### The Panic of 1837: the runs

Chapter 16 describes what the Panic of 1837 did to jobs and food prices. At the banks, it began with a rush for coins.

In a money panic, fear spreads and many people try to get their money out of banks at once. At a single bank, that rush is called a run: people crowd in to trade the bank's notes or their deposits for coins. A bank keeps only part of its money in coin, so it cannot pay everyone at the same time.

The officers of New York City's banks stopped paying out gold and silver for their notes and deposits on May 10, 1837. Bank officers across the country did the same. This was called suspending specie payments, specie meaning coins of gold and silver. People who lined up at the banks got paper promises or nothing.

**Known:** Hundreds of the country's about 850 banks closed in the hard times that lasted to about 1843, about 4 in 10 by the count most often given.

**Not known:** No surviving record counts the depositors who lost their savings.

## 1850 to 1900

**Era 7 of 10 · 1850 to 1900 · about 10 minutes**

Members of Congress gave the country one national paper money during the Civil War. For the rest of the century, Americans argued over what should stand behind it: gold alone, or gold and silver together.

Before the war, more than 10,000 different kinds of banknotes were in use by 1860. Federal officials estimate that from one-third to nearly one-half of that paper money was fake. Members of Congress created the national paper money in 1862 and then taxed state banknotes until bankers stopped printing them.

### Greenbacks

The new national paper money was printed with green ink on the back, so people called the notes greenbacks. Members of Congress passed the Legal Tender Act on February 25, 1862, to help pay for the Civil War. Under the act, they approved $150 million in paper money called United States Notes, and later acts raised the total to $450 million.

**No gold behind them.** Nobody could trade these notes at the Treasury for gold or silver. They were money because members of Congress made them legal tender, which means the law said people had to accept them to pay debts.

Salmon P. Chase, the Treasury Secretary, managed the new paper money. He put his own portrait on the first $1 United States Note, in 1862.

Members of Congress created national banks, which got their charters from the national government, in the National Banking Acts of February 25, 1863, and June 3, 1864. These banks put out national bank notes of one design, backed by government bonds.

**The tax.** In 1865 members of Congress put a tax of 10 percent on state banknotes. Bankers stopped printing their own notes. The state notes still in use fell from $143 million in 1865 to $4 million by 1867. By then, people everywhere in the country used the same national paper money.

**In God We Trust.** The words "In God We Trust" first appeared on American coins in these same years. In November 1861 a Pennsylvania minister, the Reverend M. R. Watkinson, wrote to Chase asking that God be named on the coins. His letter survives in Treasury records. Chase told officials at the United States Mint to prepare a motto.

A two-cent coin was the first United States coin to carry the words IN GOD WE TRUST. Members of Congress approved it in the Coinage Act of April 22, 1864. Chapter 29, Religion, tells how the words became the national motto in 1956.

### Counterfeiters and the Secret Service

Fake bills made up somewhere between a third and a half of the paper money in use in the 1860s, but nobody made a full count at the time. History pages of the US Marshals Service and the Secret Service give about one-third. A 2025 release from the Department of Homeland Security gives nearly one-half.

Treasury officials formed the Secret Service Division on July 5, 1865, as part of the Treasury Department, to catch counterfeiters. Its first chief was William P. Wood, and Treasury Secretary Hugh McCulloch swore him in.

Guarding presidents was not part of the job at first. On September 6, 1901, Leon F. Czolgosz shot President William McKinley at a public event in Buffalo, New York. McKinley died on September 14. Afterward, members of Congress asked the Secret Service to protect presidents. In 1902 its agents took on full-time protection of the president.

### Emanuel Ninger

> **Who:** A sign painter who drew fake money by hand and was caught when his ink ran on a wet bar top.
>
> **When and where:** New Jersey and Manhattan, 1883 to 1896. Lived 1845 to 1924.

**He drew each fake bill by hand, and one took weeks.**

Emanuel Ninger drew fake banknotes by hand for thirteen years, until his ink smudged on a wet bar. He was a sign painter, born in Germany, who lived in New Jersey. He drew United States banknotes, mostly $50 and $100 bills, with a pen, a pencil and a brush made of camel's hair.

To make a bill, Ninger laid a real note against glass and traced over it. He used colored inks for the parts printed in color. One bill took him weeks. From 1883 to 1896 he spent his fakes in Manhattan.

Ninger laid one of his bills on a wet saloon bar on March 28, 1896, and the ink smudged. A man working for the bartender followed him and had him arrested. The tellings of the story differ a little on how the arrest happened, but all of them include the smudged ink on the wet bar.

Ninger pleaded guilty in May 1896, and a judge sentenced him to six years in prison. Newspaper writers and experts at the time marveled that each fake had cost him more work than honest sign painting would have paid.

### The Freedman's Savings Bank, 1865 to 1874

The Freedman's Savings Bank held the savings of people freed from slavery. It failed in 1874, and about 31,000 of its depositors never got any of their money back.

President Abraham Lincoln signed the bank's charter into law on March 3, 1865. The full name was the Freedman's Savings and Trust Company. By 1871 it had about 37 branches in 17 states and Washington, D.C. Most accounts were small, from about $5 to $50. Depositors put money in and took it out over the years, and all their deposits together added up to more than $57 million.

At first the bank could hold only safe government bonds. In 1870 members of Congress changed its charter to let it make loans on land and buildings, and other loans.

**Henry Cooke.** Henry D. Cooke sat on the bank's board and also served his family's banking business. The Office of the Comptroller of the Currency, the government office that oversees national banks, published a history of the bank. It states that Cooke used the Freedman's Bank's money and property "to benefit the latter," meaning his family's business.

**The headquarters.** The bank's headquarters, on Lafayette Square across from the White House, cost more than $200,000 to build and furnish. The Comptroller's history notes that the bank spent that money when it already had problems.

Charles Meigs, an examiner who inspected banks for the Comptroller's office, reported in February 1873 and again in 1874 that the bank was in growing danger of failing. In between, in the Panic of 1873, many of the Freedman's Bank's loans went bad.

Frederick Douglass became the bank's president in March 1874. He put $10,000 of his own money into the bank to restore trust in it. Then he saw that it could not be saved. The bank closed on June 29, 1874.

When the bank closed, it owed about 61,000 depositors nearly $3 million, by the count in the Comptroller's history. Only about half of them ever collected anything.

**Who got paid.** Between 1875 and 1883 the commissioners who closed out the bank's business made five rounds of payments. Depositors who turned in their passbooks, the small books that recorded their savings, got back 62 cents for every dollar they were owed. About 31,000 depositors never turned in their passbooks and got nothing, and the records do not say why.

The bank's signature books and deposit records from 29 branches survive at the National Archives. They list depositors' names, ages, jobs and family members. Black families today use them to trace their history.

### Bank runs of 1873 and 1893

There was no deposit insurance in the 1800s, no promise backed by the government to repay people's savings if their bank failed. Every depositor in a failed bank waited for whatever the receiver, the official who took over the failed bank, could collect from the bank's leftover property.

At least 100 banks failed in the Panic of 1873, in Washington, D.C., Pennsylvania, New York, Virginia, Georgia, Indiana, Illinois and Ohio. On September 20, 1873, the New York Stock Exchange, the market in New York City where people buy and sell shares of companies, closed for ten days. It was the first time it had ever closed.

More than 440 banks suspended in the Panic of 1893, from June to mid-August, by the count of writers for the Federal Reserve's history website. To suspend meant to shut the doors or stop paying out cash, and some of those banks later reopened. Chapter 16 gives the count of banks and businesses that failed.

No surviving record counts how many depositors lost savings in 1873 or 1893, or how much they lost.

### Gold against silver

Americans argued over whether gold alone or gold and silver should stand behind the dollar. Farmers and others who owed money were on one side, and bankers on the other.

With the dollar tied to gold, the supply of money grew slowly. Prices fell through most of the years from 1865 to 1896. A farmer's crop brought fewer dollars each year, but his mortgage payment, the money he owed each year on a loan against his farm, stayed the same.

Supporters of "free silver" wanted the government to coin all the silver brought to it, at 16 ounces of silver to 1 ounce of gold. That would have put more money in use and raised prices, which would have made debts easier to pay. Debtors and many people in the states that mined silver wanted silver. Bankers and bondholders, people who had lent money by buying bonds, wanted gold alone.

Members of Congress dropped the standard silver dollar from the list of coins in the Coinage Act of February 12, 1873. After that, in practice, the dollar was tied to gold alone and not to silver, just as miners in the West were digging more and more silver. People on the silver side called the act "the Crime of '73."

Two later laws required the government to buy some silver. The Bland-Allison Act of 1878 required the Treasury to buy $2 million to $4 million of silver each month and coin it into silver dollars. Lawmakers passed it over President Hayes's veto.

Under the Sherman Silver Purchase Act of 1890, the purchases rose to 4.5 million ounces a month. Treasury officials paid for the silver in notes that could be traded for gold. As holders traded the notes in, the Treasury's gold fell, from $190 million in 1890 to about $100 million in 1893. In 1893, during the panic, members of Congress canceled the Sherman Act because President Cleveland insisted on it.

### William Jennings Bryan

> **Who:** A 36-year-old former congressman from Nebraska who became the Democratic Party's candidate for president with a speech for silver.
>
> **When and where:** The Democratic convention in Chicago, July 9, 1896.

**"You shall not crucify mankind upon a cross of gold."**

William Jennings Bryan became the Democratic Party's candidate for president in 1896 with a speech for silver. On July 9, 1896, at the Democratic convention in Chicago, he gave the last speech in the debate over the party's platform, its list of positions.

He ended the speech with words aimed at the supporters of gold. "You shall not press down upon the brow of labor this crown of thorns," he said. Then he said, "you shall not crucify mankind upon a cross of gold," crucify meaning to put someone to death by nailing them to a cross.

Both pictures come from the Bible's account of the death of Jesus. Bryan was comparing that suffering to the gold standard, a dollar backed by gold alone. Under it prices fell, and farmers and working people found their debts harder to pay each year.

After the speech, the delegates, the party members sent to the convention, chose him as their candidate for president on the fifth round of voting. Republicans wrote support for the gold standard into their platform. Their candidate was William McKinley. Bryan's votes came mostly from the South, the rural Midwest and the Rocky Mountain states. McKinley was strongest in the cities and in the Northeast, the Upper Midwest and the Pacific Coast.

McKinley won the election, with about 51 percent of the votes from the people to Bryan's 47 percent. Gold stayed behind the dollar. Bryan ran against McKinley again in 1900 and lost again.

## 1900 to 1950

**Era 8 of 10 · 1900 to 1950 · about 11 minutes**

The Federal Reserve and deposit insurance, the two protections Americans still have for their savings, both began in these fifty years. Members of Congress and two presidents set them up.

The Federal Reserve, a bank for the nation's banks, came in 1913, six years after the Panic of 1907. Deposit insurance, a government promise to pay savers back if their bank fails, became law in 1933 and began on January 1, 1934, after thousands of banks had failed. Lawmakers meant both to stop bank runs, when many people rush to take their money out of a bank at once.

What stood behind the dollar changed too. In the Gold Standard Act of March 14, 1900, members of Congress made gold the only metal behind the dollar, at $20.67 an ounce. After that, silver was no longer a standard in law. In 1933 President Franklin Roosevelt ordered Americans to turn in their gold coins. From 1934 on, a dollar in an American's hand was paper that could not be traded for gold.

### The Panic of 1907

Depositors rushed to pull their money out of New York's trust companies in October 1907. A trust company was a kind of bank that took people's deposits and managed their money. The country had no central bank, a bank that holds other banks' cash and lends to them in a crisis, so a private banker, J.P. Morgan, organized the rescue.

The trouble began with a failed attempt to corner the stock of United Copper, buying up so much of it that the buyers could set its price. When the attempt failed, the banks of the men behind it were ruined, and depositors grew afraid of other banks linked to those men.

So many depositors demanded their money from the Knickerbocker Trust Company on October 22, 1907, that its officers stopped paying out money. It was one of the largest trust companies in New York. Depositors then ran on the Trust Company of America and others, standing in lines around the block. Some hired people to hold their place in line. Charles T. Barney, the Knickerbocker's former president, shot himself on November 14, 1907.

### J.P. Morgan

> **Who:** A New York banker who ran the rescue in the Panic of 1907 from his own library.
>
> **When and where:** New York City, October and November 1907.

**Locked in his library, the bankers pledged their own $25 million.**

J.P. Morgan was 70 years old when he took charge of stopping the Panic of 1907. He worked from his private library at 36th Street and Madison Avenue in New York City.

Under Morgan's rescue, teams of examiners went through the books of the trust companies and decided which ones were sound enough to save. Officials of the Treasury, the government department in charge of its money, deposited $25 million of the government's money with Morgan's group of banks. Morgan also got the presidents of banks and trust companies to promise money to shared rescue funds.

**The locked room.** Morgan gathered the presidents of the trust companies in his library on the night of November 2 to 3, 1907, and had the doors locked. He kept them in the room until they agreed to put up $25 million of their own, separate from the Treasury's $25 million, to save the weakest trusts. They signed the deal near 5 in the morning.

In the account told by the Morgan Library & Museum and others, Morgan kept the key in his pocket. Memoirs differ on who held the key and on the exact hour, but not on the locked doors. The museum's exhibition on the panic describes the meeting.

People at the time drew a lesson from the panic: the country's money system had depended on one 70-year-old private banker. In the Aldrich-Vreeland Act of 1908, members of Congress created the National Monetary Commission to design a better system.

### Jekyll Island and the Federal Reserve, 1913

The Federal Reserve, the central bank of the United States, began with a secret meeting in November 1910. Six men traveled to the Jekyll Island Club, on an island off Georgia, and to keep the trip secret they traveled as a duck-hunting party. They were Senator Nelson Aldrich, his secretary, a Treasury official and three bankers, among them Paul Warburg. On the island they wrote a plan for a central bank.

The men who were there did not admit to the meeting in public until the 1930s. The Federal Reserve's own published history describes the trip. Members of Congress never passed their plan, called the Aldrich Plan. Three years later they used much of its design in the law they did pass.

President Wilson signed the Federal Reserve Act on December 23, 1913. The act provided for twelve Reserve Banks in different parts of the country, run under a board in Washington. The Reserve Banks opened on November 16, 1914.

The Federal Reserve is a bank for banks. It holds their reserves, the money a bank keeps on hand instead of lending it out, and its officers move money between banks. They can lend to a sound bank that is facing a run, so the bank can pay its depositors and stay open.

### Black-owned banks, and Greenwood's losses

Black Americans started their own banks in the early 1900s, among them Maggie Lena Walker in Richmond and Jesse Binga in Chicago. Black depositors and business owners later lost money when banks failed and when a white mob burned Tulsa's Black district in 1921.

Maggie Lena Walker opened the St. Luke Penny Savings Bank in Richmond, Virginia, in November 1903, and became its first president. She was the first Black woman to found a bank in the United States. On the first day, people deposited more than $8,000, in amounts from 31 cents to over $100.

During the Great Depression of the 1930s, Walker merged her bank with other Black-owned banks into the Consolidated Bank and Trust Company. That bank lasted into the 2000s as the longest continuously run Black-owned bank in the country. Walker lived from 1864 to 1934.

Jesse Binga opened a private bank in Chicago in 1908, mainly for Black customers, because many bank managers turned them away. In 1921 he opened the Binga State Bank. Binga lived at 5922 South Park Avenue, in a white neighborhood. His home and his offices were bombed at least five times. The records do not say who set the bombs.

Illinois state officials closed the Binga State Bank in 1930, when it could not meet a requirement to hold $400,000 in cash. Accounts date the closing to June or to July 31, 1930. Binga lost his own fortune. Many depositors lost their savings, and the records do not count them.

A jury found Binga guilty in 1933 of embezzlement, taking money a person was trusted to look after. A judge sentenced him to ten years in prison. Governor Dwight H. Green of Illinois pardoned him in 1941, an official act that forgave the crime and ended the punishment.

**Greenwood, 1921.** A white mob attacked Greenwood, the Black district of Tulsa, Oklahoma, where about 10,000 people lived, on May 31 and June 1, 1921. The mob included men whom the Tulsa police had deputized, or sworn in as temporary officers, and National Guard units took part in the attack. The attackers destroyed more than 1,000 homes and businesses.

Estimates of the number of people killed run from 50 to 300. The count is uncertain because many of the dead were never identified and lie in unmarked graves. Most Black Tulsans lost their homes, and thousands lived in tents through the winter of 1921 to 1922.

No white person went to prison for the murders or the burning. An all-white grand jury, a group of citizens who decide whether to charge people with crimes, blamed Black Tulsans.

Greenwood's residents filed more than $1.8 million in damage claims with the city of Tulsa between June 1921 and June 1922. All but one of the claims were turned down. A 2021 Brookings study of the claims does not name the officials who turned them down. The one claim paid went to a white shop owner, for guns taken from his store.

Officers of the insurance companies refused to pay for the burned property. They called the attack a "riot," and their policies did not cover riot damage. No rebuilding money came from the city, the state or the federal government.

Greenwood's residents rebuilt the district. Members of the National Negro Business League, whose name used the common word of the time for Black people, held their national meeting in Greenwood in 1925. By the 1940s Greenwood had 242 Black-owned businesses.

### 1930 to 1933: the runs, the holiday and deposit insurance

More than one American bank in three failed from 1930 to 1933, and their depositors lost about $1.34 billion. Federal deposit insurance did not begin until 1934, so the losses fell on the depositors.

**The count.** Banks had failed at a rate of more than 600 a year even in the 1920s, mostly small banks in farm country. The count grew after 1929. The records of the Federal Deposit Insurance Corporation, or FDIC, the government agency that insures bank deposits, list 9,096 banks that suspended from 1930 to 1933, meaning they closed their doors or stopped paying depositors. The country had about 25,000 banks. By one estimate, about nine million savings accounts had been lost by March 1933.

The Bank of United States in New York City failed on December 11, 1930, the largest bank failure in the country up to then. It had about 400,000 depositors. Many were immigrants who worked in the clothing factories, and small savers in the Bronx and Brooklyn.

A history published by the FDIC in 1998 states that officials of the Federal Reserve, the bank for the nation's banks, "did little to ease the liquidity problems of banks," meaning the banks' lack of cash on hand to pay depositors. Most of the banks that failed in 1930 had not joined the Federal Reserve system, and its officials felt no responsibility for them.

The governor of Michigan closed every bank in the state on February 14, 1933, for eight days. That left 900,000 depositors unable to reach their money. Runs, when many people rush to take their money out of a bank at once, then spread from state to state.

Franklin Roosevelt became president in March 1933. On March 6, two days after he took office, he closed every bank in the country, and this was called the bank holiday. On March 9 members of Congress passed the Emergency Banking Act.

**The fireside chat.** On the night of Sunday, March 12, Roosevelt gave the first of his radio talks called fireside chats, and about 60 million people listened. He explained in simple terms how banks work, and he said money was safer in a reopened bank than under the mattress. Banks reopened from March 13 to 15, after federal officials reviewed them. When they opened, people put in more money than they took out.

**Deposit insurance.** Members of Congress created the Federal Deposit Insurance Corporation in the Banking Act of June 16, 1933. Its insurance began on January 1, 1934, and covered each depositor up to $2,500. In July 1934 the limit rose to $5,000. If an insured bank failed, its depositors would be paid back from the insurance fund, up to the limit. With that promise, depositors no longer had a reason to rush to the bank to get their money out first.

### Lydia Lobsiger

> **Who:** The first depositor in the United States to be paid back by federal deposit insurance.
>
> **When and where:** East Peoria, Illinois, 1934. Her grave record gives her life as 1870 to 1956.

**A check for $1,250, dated July 3, 1934.**

Lydia Lobsiger received the first federal deposit insurance check ever paid. She was about 64 years old, and the $1,250 was her life savings, by the FDIC's own history.

Her bank was the Fond du Lac State Bank of East Peoria, Illinois, and it failed in the spring of 1934. It was the first bank with FDIC insurance to fail, a few months after the insurance began.

When Lobsiger's bank failed, reporters at newspapers across the country wrote that a depositor with a small account had not lost her savings.

### What happened to Americans' gold?

Roosevelt and members of Congress took gold out of Americans' hands in 1933 and 1934. Roosevelt signed Executive Order 6102, a written order from the president, on April 5, 1933. It required Americans to turn in their gold coins, gold bars and gold certificates, paper notes that could be traded for gold, to the government at $20.67 an ounce. Americans could keep small keepsakes and collections.

Members of Congress moved all the gold the country used as money to the Treasury in the Gold Reserve Act of January 30, 1934. They set a new price of $35 an ounce. From then on, Americans could not trade their dollars for gold. Foreign governments still could.

### War bonds

About 85 million Americans, roughly half the country, lent money to the government during World War II by buying war bonds. Together they paid in about $185.7 billion.

One kind was the Series E bond. A buyer paid $18.75 for it and got back $25 ten years later. Children bought war stamps for 10 cents or 25 cents each and saved them toward a bond.

Officials of the Treasury and the Office of Education ran a program called Schools at War from 1942 to 1945. Students bought stamps and bonds toward goals set at their schools. About 200,000 schools and 30 million students took part, and they raised more than $2 billion.

Their money paid the price of at least 90,000 jeeps and several thousand airplanes for the armed forces. Eleanor Roosevelt spoke in support of the program on the radio on September 25, 1942.

## 1950 to 2000

**Era 9 of 10 · 1950 to 2000 · about 9 minutes**

President Nixon cut the dollar's last tie to gold on August 15, 1971, when he ended the right of foreign governments to trade dollars for gold. Since then no metal has stood behind the dollar. In the same years Americans began to pay with plastic cards and take cash from machines.

Prices rose fast for about seventeen years, from about 1965 to 1982, and a dollar saved in 1965 bought about a third as much in 1982. Paul Volcker, head of the Federal Reserve, stopped that rise in the early 1980s by letting interest rates rise past 20 percent.

### Plastic: the charge card and the credit card

The first card that people could use to pay at many different businesses was the Diners Club card, in 1950. Frank McNamara started the company with Ralph Schneider and other partners. The cards were made of cardboard, and at first a couple dozen restaurants in New York took them. The card was first used at Major's Cabin Grill in February 1950.

The Diners Club card was a charge card: the holder had to pay the whole bill each month.

**The forgotten wallet.** A story often told says that McNamara had the idea in 1949 after he forgot his wallet at dinner. Matty Simmons, the company's first publicity man, was there, and he said later that the story was made up for publicity. According to Simmons, McNamara simply had the idea and worked on it.

Officers of Bank of America mailed about 60,000 ready-to-use cards, called BankAmericards, to people in Fresno, California, in September 1958. None of those people had asked for a card. The BankAmericard was a true credit card: the holder could pay part of the bill and owe the rest later.

About 22 percent of the accounts fell behind on payments, against the 4 percent the bank's officers had planned for. There was fraud too, cheating to get money or goods. The bank lost millions of dollars in the card's first years.

Members of Congress banned mailing credit cards to people who had not asked for them in 1970. Officers of Bank of America licensed the card to other banks across the country, and in 1976 it was renamed Visa.

A lender who turned down a woman for credit because she was a woman broke no federal law until 1974. A blog post by the Consumer Financial Protection Bureau, a federal agency, states that "discrimination against women applying for credit was common."

Lenders who made mortgages, or home loans, "often discounted a married woman's income, especially if she was of childbearing age," counting her pay as worth less when they decided whether to lend to her. Lenders were more likely to turn down single women.

**The law.** Members of Congress passed the Equal Credit Opportunity Act in October 1974. Under the act, it became illegal for lenders to treat people differently because of their sex or whether they were married. In March 1976 members of Congress added race, color, religion, national origin, age, and receiving public assistance, money from a government aid program.

### The ATM

The first automated teller machine in the United States, a machine that pays out cash without a bank clerk, opened on September 2, 1969. It stood at a Chemical Bank branch in Rockville Centre, New York. Docutel, a company in Dallas, built the machine, called the Docuteller, from an idea by Don Wetzel. The bank's advertisement stated: "On September 2, our banks will open at 9:00 and never close again."

### August 15, 1971: the last tie to gold

Foreign governments could still trade dollars for gold after 1934, at $35 an ounce, though Americans could not. This deal was part of an agreement that the governments of many countries made after World War II, called the Bretton Woods system.

Far more dollars were held outside the country by 1971 than the United States had gold to pay for them. Foreign governments were trading in dollars for American gold, and the country's gold was running down. It was a run on the nation's gold.

President Nixon spent a weekend at Camp David with his advisers. They included Arthur Burns, the chairman of the Federal Reserve, John Connally, the Treasury Secretary, and Paul Volcker, a Treasury official. On Sunday night, August 15, 1971, Nixon announced that Treasury officials would no longer trade gold for the dollars foreign governments turned in. He called the change temporary. No president has reversed it.

Since that night the dollar has been fiat money, money backed by no metal and worth what it can buy. People accept it because the law makes it legal tender and because they trust the government that prints it. The greenbacks of 1862 worked the same way.

### The Great Inflation

Prices in the United States rose fast year after year from about 1965 to 1982. Economists call it the Great Inflation, because inflation is the word for prices rising so that each dollar buys less.

Prices had risen only 1 or 2 percent a year in the early 1960s. Food prices rose more than 20 percent over the year to late 1973, and prices overall rose about 11 percent in 1974.

**WIN buttons.** President Ford started a campaign called "Whip Inflation Now" in 1974, with buttons printed with the word WIN. Prices went on rising. At the peak, in 1979 and 1980, they rose more than 1 percent a month, and for all of 1980 they rose 13.5 percent.

A dollar saved in 1965 bought about a third as much in 1982, so savings put aside in 1965 had lost about two-thirds of their buying power. Borrowing became costly. In October 1981 the average interest rate on a 30-year home mortgage was 18.63 percent. That is the highest rate ever recorded in the Freddie Mac survey of home loan rates.

### Bruce Bent and Henry Brown

> **Who:** Two men who set up the first money market fund, a way for small savers to earn more than the legal limit on bank interest.
>
> **When and where:** The United States, 1969 to 1973. Bent was born in 1937. Brown lived from 1926 to 2008.

**By federal rule, a bank could pay savers no more than 5 percent.**

Bruce Bent and Henry Brown set up a fund that let ordinary savers earn the higher interest that only large investors could get before.

Federal Reserve officials put a rule called Regulation Q in place in September 1933. It forbade banks to pay more than a set rate of interest on a savings account. In July 1973 they raised the limit on an ordinary savings account from 4.5 percent to 5 percent. Most banks paid exactly the limit. Prices rose about 11 percent in 1974, so money in a savings account at 5 percent lost about 6 percent of its buying power that year.

Large investors could earn more by buying short-term debt from the government and from large companies, such as Treasury bills, short loans to the government. Only large investors could buy that debt directly.

Bent and Brown met while working at TIAA-CREF, a company that manages retirement money. In August 1969 Bent proposed a fund that would pool the money of many small savers and buy that debt for them.

They set up the Reserve Fund in 1970. A saver needed $1,000 to start, and each share cost $100. Sources differ on whether the fund opened to savers in 1971 or 1972.

Bent and Brown had no sales staff, so they phoned financial advisers and handed out brochures. The reporter Robert D. Hershey Jr. wrote an article about the fund in the *New York Times* on January 7, 1973. By the end of that year the fund held $100 million.

Federal Reserve History lists 1 money market fund in 1972, 36 in 1975, 90 in 1980 and 649 in 1990. The limits of Regulation Q were phased out by 1986 under a law members of Congress passed in 1980. The Reserve Fund later grew into the Reserve Primary Fund, which held about $62 billion in 2008.

### Paul Volcker

> **Who:** The chairman of the Federal Reserve who brought down the Great Inflation with interest rates above 20 percent, at the cost of a recession with 10.8 percent unemployment.
>
> **When and where:** Washington, D.C., 1979 to 1983.

**Interest rates passed 20 percent, and farmers drove tractors to Washington.**

Paul Volcker stopped the Great Inflation by letting interest rates rise past 20 percent. He was six feet seven inches tall and known for smoking cheap cigars. President Jimmy Carter appointed him chairman of the Federal Reserve in August 1979.

Volcker announced a new policy on Saturday night, October 6, 1979. He and the other Federal Reserve officials would control how much money was in the economy. They would let interest rates rise as high as that took them. The federal funds rate, the rate banks charge one another for overnight loans, passed 20 percent in 1981.

In the recession of 1981 and 1982, a time when business shrank and people lost jobs, unemployment reached 10.8 percent, the highest since the 1930s. Farmers drove tractors to the Federal Reserve's building in protest. Home builders in debt mailed sawed-off pieces of two-by-four lumber to the Federal Reserve.

Inflation fell from 13.5 percent in 1980 to 3.2 percent in 1983.

### The savings and loan crisis

Federal officials closed 747 failed savings and loans from 1989 to 1995. These were businesses, also called thrifts, that took in people's savings and made long-term home loans at fixed interest rates. Kenneth Robinson, writing for the Federal Reserve's history website, estimates that taxpayers paid as much as $124 billion of the cost.

When interest rates climbed in the late 1970s and early 1980s, the thrifts lost money in two ways. Under Regulation Q, federal officials kept the interest thrifts could pay on savings far below what savers could earn elsewhere, so savers took their money out. And the thrifts' old home loans kept paying the low fixed rates of years before, while the rates the thrifts had to pay to attract savers' money rose sharply.

**Riskier loans.** In the Garn-St Germain Act of 1982, members of Congress let thrifts make new kinds of loans beyond home mortgages. Many of those loans carried more risk. By 1983 closing the thrifts that could not pay their debts would have cost about $25 billion. Their insurance fund, the Federal Savings and Loan Insurance Corporation, or FSLIC, held only $6 billion.

Members of Congress closed the FSLIC in a 1989 law and moved thrift deposit insurance to the FDIC. They also created the Resolution Trust Corporation to shut down failed thrifts. By the end of 1995 its officials had closed the 747 savings and loans, which together held more than $407 billion in loans and other property. Savers with insured accounts were paid in full.

Banks failed in the same years. In 1984 federal officials rescued Continental Illinois National Bank, which held $45 billion in loans and other property, instead of letting it fail. FDIC records list 748 failed insured banks from 1985 through 1988.

## 2000 to Today

**Era 10 of 10 · 2000 to Today · about 10 minutes**

Most Americans pay with cards today, and the runs came back where deposit insurance did not reach. Cards made up 65 percent of payments in 2024, according to the Federal Reserve's yearly payment diary. Cash was used for 14 percent of payments in 2025.

Savers ran from money market funds in 2008, and depositors ran from Silicon Valley Bank and other banks in 2023. Both times, federal officials promised to cover money that no insurance protected. Since 2009 people have also used digital coins such as bitcoin, which no government and no bank puts out.

### 2008: the run comes back

The run of September 2008 hit money market funds, the kind of fund Bruce Bent and Henry Brown had started. In such a fund, the managers pool many people's money to buy short-term loans to the government and to large companies. Many people treated these funds like bank accounts. A share was meant to stay worth exactly $1. The funds had no deposit insurance.

The large financial firm Lehman Brothers failed on September 15, 2008. The next day the Reserve Primary Fund "broke the buck": its shares fell below $1, to 97 cents. The fund held $62.5 billion, and $785 million of it was in Lehman's debt.

According to a study in the *Journal of Financial Crises*, published by Yale University, investors pulled more than $40 billion out of the fund in two days. On September 17 alone they pulled about $144.5 billion out of money market funds across the country.

Treasury officials announced a guarantee for money market funds on September 19, 2008. President George W. Bush approved it, and Treasury Secretary Henry Paulson put up to $50 billion of the Treasury's Exchange Stabilization Fund behind it. The guarantee worked like deposit insurance, set up within a week, and the run stopped.

Banks failed too. According to a history the FDIC published in 2017, 489 insured banks failed from 2008 through 2013. Their failures cost the deposit insurance fund about $73 billion.

IndyMac failed on July 11, 2008, with losses of about $12 billion, the most costly failure in the FDIC's history. Washington Mutual, which held $307 billion in loans and other property, failed on September 25, 2008, the largest bank failure in the country's history. Members of Congress raised the deposit insurance limit from $100,000 to $250,000 on October 3, 2008, and made it permanent in 2010.

**The trial.** Officials of the Securities and Exchange Commission later charged Bruce Bent and his son with fraud over the Reserve Primary Fund's collapse. In 2012 a jury cleared both of fraud and found the son careless, which the law calls negligence, on one charge.

### Money issued by nobody

Bitcoin is a digital coin that no government and no bank puts out. It runs on a public record of who owns which coins, kept by many computers that check one another's work.

A person or group using the name Satoshi Nakamoto published a paper describing Bitcoin on October 31, 2008. On January 3, 2009, Nakamoto started the system by creating its first block of records.

The code of that first block includes a headline from that day's *Times* of London: "Chancellor on brink of second bailout for banks." The headline was about the British government's top money official, the Chancellor, and a bailout, government money given to businesses in trouble. No one has shown who Nakamoto is.

People hold bitcoin as an investment, hoping its price will rise, and others use it to pay for things. Economists disagree about whether it is money, property owned for its value, or a bet on a price.

### Laszlo Hanyecz

> **Who:** A programmer who made the first recorded purchase with bitcoin: two pizzas for 10,000 coins.
>
> **When and where:** Florida, May 22, 2010.

**Two pizzas for 10,000 bitcoins, later worth about $1.1 billion.**

Laszlo Hanyecz paid 10,000 bitcoins for two pizzas on May 22, 2010. It was the first recorded time anyone traded bitcoin for a real thing.

Hanyecz was a programmer in Florida who had worked on Bitcoin's code. He wrote the first version of the Bitcoin program for Apple's Mac computers. He was the first to use a computer's graphics card to create new bitcoins, a job called mining.

In May 2010 he posted an offer on the Bitcoin forum, a website where users wrote to one another. He would give 10,000 bitcoins to anyone who got two large pizzas delivered to him. A forum user named jercos took the deal and ordered the pizzas, which cost jercos about $25. At the time of the offer, the 10,000 bitcoins were worth about $41, according to the bitcoin.it wiki.

The same wiki estimates that at the high point of May 2025, those 10,000 coins would have been worth about $1.1 billion. In a 2019 interview, reported by the news site CoinDesk, Hanyecz said, "A trade happens because both parties think they're getting a good deal." May 22 is now marked each year as Bitcoin Pizza Day.

### Payday loans

A payday loan is a small loan meant to be paid back from the borrower's next paycheck. Researchers at the Consumer Financial Protection Bureau released a study of these loans on April 24, 2013. They looked at a $350 payday loan with the typical fee of $15 for every $100 borrowed. Its annual percentage rate, the cost over a full year as a share of the amount borrowed, came to 391 percent.

Storefront payday lenders charged fees of $10 to $20 for every $100 borrowed, the study found. Nearly half of payday borrowers took out more than 10 loans in a year, and 14 percent took out 20 or more. The typical borrower was in debt to a payday lender 199 days of the year, more than half of it.

### Inflation returns, 2021 to 2026

Prices rose fast again from 2021 to 2023, and Federal Reserve officials raised interest rates faster than at any time since Volcker. Prices rose 9.1 percent in the 12 months to June 2022, according to the Bureau of Labor Statistics, the largest rise since November 1981. Energy prices rose 41.6 percent that year and food prices 10.4 percent.

Federal Reserve officials raised their main interest rate from near zero in March 2022 to more than 5 percent in 2023. By the middle of 2023, prices were rising at close to 3 percent a year.

According to a report by the Congressional Research Service, which does research for members of Congress, economists still disagree about the causes. The causes they name include broken supply chains (the network of factories, ships and trucks that moves goods), federal spending on pandemic relief and higher energy prices.

Prices rose 3.4 percent in the 12 months to August 2026, the Bureau of Labor Statistics reported. Energy prices rose 16.3 percent, and food prices 2.7 percent.

### FTX and stablecoins

FTX was a company where people bought, sold and kept cryptocurrency, digital money such as bitcoin. It went bankrupt in November 2022: it could not pay what it owed and went to court to settle its debts. Its founder was Sam Bankman-Fried. According to the *Washington Post*, he had used customers' money to buy luxury real estate, to make investments and to give political donations.

A federal jury found him guilty in November 2023 of wire fraud, cheating people by phone, email or the internet. The jurors also found him guilty of two conspiracies, plans made with other people to commit a crime. One was to commit fraud, and the other was to commit money laundering, hiding where money from a crime came from. Judge Lewis Kaplan sentenced him on March 28, 2024, to 25 years in prison and ordered him to give up more than $11 billion.

The people running the bankruptcy paid customers back what their accounts were worth on the day FTX filed for bankruptcy in November 2022. On that day one bitcoin sold for $16,080. By May 2024 it sold for close to $62,675, according to CBS News. Customers who had held bitcoin did not get back that later value.

Another payment went out to customers on July 31, 2026. An FTX press release in 2026 states that, after it, customer claims had received 105 percent of their value in all, and small claims 120 percent. Payments above 100 percent were interest added to the claims. FTX's chief executive, John Ray, described the plan in 2024 as "100% of bankruptcy claim amounts plus interest."

President Trump signed the GENIUS Act on July 18, 2025. The law contains rules for stablecoins, digital coins whose makers promise to trade each one for a fixed amount, such as one dollar. Under the law, a company that puts out stablecoins must hold at least one dollar of approved reserves, such as cash, insured bank deposits or Treasury bills, for every coin. The law states that stablecoins are not federally insured, according to a 2025 report by the Congressional Research Service.

**Like the old state banknotes.** In the 1800s, before national paper money, banks chartered by the states printed their own notes. Each note was only that bank's promise to pay in coin. A stablecoin works the same way: a private promise to pay, backed by what the company holds, with no federal insurance behind it.

### 2023: the run on Silicon Valley Bank

Federal officials protected every depositor at two failed banks in March 2023, including money above the insurance limit. Depositors took $42 billion out of Silicon Valley Bank in California in a single day, March 9, 2023. About 88 percent of the bank's deposits were above the $250,000 insurance limit. If the bank failed, the owners of that money stood to lose it.

Officials of California's Department of Financial Protection and Innovation closed the bank on March 10. On Sunday, March 12, officials of New York's Department of Financial Services closed Signature Bank, where about 90 percent of the deposits were uninsured.

**The rescue.** Treasury Secretary Janet Yellen, after consulting the president, used an emergency power that same Sunday and protected every depositor at both banks, insured or not. FDIC Chairman Martin Gruenberg told Congress on March 27, 2023, that FDIC officials estimated the cost at about $20 billion for Silicon Valley Bank and $2.5 billion for Signature Bank. They planned to collect that money from other banks through special fees, not from taxpayers.

California officials closed First Republic Bank on May 1, 2023, and JPMorgan Chase took over all its deposits.

### Cash fades, and the penny ends

Cash was the third most used way to pay in the United States in 2025, after credit cards and debit cards. Federal Reserve researchers track this with the Diary of Consumer Payment Choice, in which people record the payments they make.

Cash was the most used way to pay in 2016, at about a third of all payments. By 2024 cash was used for 14 percent of payments, credit cards for 35 percent and debit cards for 30 percent. Adults aged 18 to 24 paid by phone 45 percent of the time that year.

People made about 47 payments a month in 2025, according to the diary's report released in May 2026. Cash was 14 percent of them, about 6 a month. It was the sixth year in a row that cash came third.

**Who still uses cash.** People aged 55 and older paid cash about 10 times a month, against about twice for people aged 18 to 24. In the countryside the count was about 9 a month, and in cities and suburbs about 6. Ninety percent of people said they planned to keep using cash.

Each penny cost the US Mint 3.69 cents to make and ship in the 2024 budget year. The Mint's losses on pennies came to about $85 million that year. On February 9, 2025, President Trump said he had told the Treasury Secretary to stop making new pennies. A PBS and Associated Press report at the time stated that it was unclear whether he had that power, because members of Congress set the rules for coins.

**The last pennies.** The last pennies made for everyday use were struck at a ceremony at the Philadelphia Mint on November 12, 2025. The first federal cents had been made 232 years earlier, in 1793. The expected savings were about $56 million a year. Pennies already made are still legal tender.

Members of the House of Representatives passed the Common Cents Act on September 14, 2026, and senators passed it on September 28. Under the bill, penny production would end in law. When a customer paid cash and exact change was not available, the total would round up or down to the nearest five cents. Payments by card or check would not round. As of October 2, 2026, the bill was waiting for President Trump's signature.

**The three questions, answered**

- What has stood behind the dollar, and what stands behind it now? Silver and gold stood behind it, then gold alone. Since August 15, 1971, only the law and people's trust in the government that prints it have stood behind it.
- Why did people rush to pull their money out of banks, and who lost when a bank failed? A bank keeps only part of its money in cash, so the first in line got paid. Until deposit insurance began in 1934, the rest took the loss, about $1.34 billion from 1930 to 1933.
- How did enslavers and bankers use enslaved people to raise money? Enslavers pledged them for loans, and in the 1830s Louisiana banks lent out their own paper money against them. When the loans went unpaid, the people were sold.

**What changed:** People here went from living without money to paying with cards, and the dollar went from silver and gold to paper backed only by the law.

**Five dates to keep**

- December 1690: Massachusetts lawmakers vote for paper money.
- July 6, 1785: members of Congress vote for a dollar counted in tens.
- December 23, 1913: President Wilson signs the Federal Reserve Act.
- January 1, 1934: federal deposit insurance begins.
- August 15, 1971: President Nixon ends the dollar's last tie to gold.

**Not known:** No surviving record counts the depositors who lost savings when banks failed in 1837, 1873 and 1893.

**Where to go:** The National Archives keeps the Freedman's Savings Bank's signature books, which list depositors' names, ages and jobs.

**Next:** Chapter 18, Marketplace and Consumer Life. It asks how Americans bought things, from the peddler at the door to the online store.
