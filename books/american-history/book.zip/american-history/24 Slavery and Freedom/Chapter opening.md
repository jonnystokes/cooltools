**Part 6: Freedom and Fairness**

# Chapter 24: Slavery and Freedom

**Chapter 24 of 37 · Slavery and Freedom · 10 eras · about 110 minutes**

**Judges, lawmakers and traders built slavery here on purpose, one law and one sale at a time. Enslaved people fought it until it ended in 1865, then fought again when white lawmakers and mobs took much of their new freedom away.**

In October 1865 a freed man named Thornton Copeland placed a few lines in the *Colored Tennessean*, a Black newspaper in Nashville. "INFORMATION is wanted of my mother," they began. Her name was Betty. He had last seen her in Fauquier County, Virginia, in 1844, the year he was sold in Richmond to a man named Samuel Copeland. His advertisement is now one of more than 5,000 like it that anyone can read online. No record shows whether he ever found her.

This chapter follows slavery from the captives of Native wars before 1500 to today's arguments over repair, meaning payments or other steps to make up for what slavery did. Watch for two things as you read.

First, watch who made each rule: the Virginia judges who sentenced John Punch to serve for life in 1640, the lawmakers who made a child's status follow the mother's in 1662, the traders who sold a million people south. Second, watch what enslaved people did back. They ran away, sued and learned to read in secret, and some rose up with weapons.

After 1877 the chapter follows the forced labor that replaced slavery and the vote taken from Black men. It also describes the court ruling and new laws of 1954 to 1965, under which federal officials began to enforce Black Americans' rights. Chapter 25 describes the campaigns people organized for those rights.

**Three questions this chapter answers**

- How did a servant in Virginia become a slave for life, and a child a slave from birth?
- How did enslaved people fight back?
- What happened to the freedom people won in 1865?

**Five minutes?** Read "How did a servant become a slave for life?" in The 1600s, the Robert Smalls story in 1850 to 1900, and "The promises broken" in the same era.

**Can skip:** "The ships from Rhode Island", "Enslaved builders of the capital", "Slavery exhibits in the national parks, 2025 and 2026". The chapter still makes sense without them.

## Before 1500

**Era 1 of 10 · Before 1500 · about 1 minute**

Native nations took captives in war long before Europeans arrived, but in most of them a captive could become a member of a family.

Holding a person as property for life, and passing that status on to the person's children, is called chattel slavery, from chattel, an old word for property. Europeans later wrote chattel slavery into the laws of the colonies they set up here.

### Captives who could become family

Warriors in some Native nations took captives in raids on their enemies. Among the Haudenosaunee, the nations also called the Iroquois, a family that had lost someone in war could adopt a captive to take the dead person's place. People call this custom the mourning war, and the records describe it more fully than any other kind of captive-taking. In most of these nations a captive could stop being a captive, and a captive's children did not automatically become captives too.

On the Northwest Coast, among the Tlingit, the Haida and the nations near them, slaves were property. Their owners traded them, and a slave's children were born slaves. Leland Donald studied this system in a 1997 book and found that it was slavery in the full sense of the word.

## The 1500s

**Era 2 of 10 · The 1500s · about 3 minutes**

The first people Europeans enslaved in what is now the United States were Native people. Spanish raiders took them captive on the coasts of Florida and the Carolinas from the early 1500s. Enslaved Africans came with the Spanish too. About 100 of them rebelled at a Spanish colony on the Atlantic coast in October 1526 and escaped. It is the first known revolt of enslaved Africans in what became the United States.

### Spanish slavery and the first revolt

**The encomienda.** In their colonies, Spanish colonists ran a system called the encomienda. Under it they forced Native people to work for them and to hand over goods. King Charles I of Spain issued the New Laws on November 20, 1542. They said that no one could enslave Native people, and that an encomienda ended when its holder died. Spanish colonists opposed the New Laws and kept forcing Native people to work.

**The first revolt.** Lucas Vázquez de Ayllón founded a colony called San Miguel de Gualdape in 1526, on the coast of what is now Georgia or South Carolina. Nobody knows the exact spot. Between 600 and 700 colonists came with him, and about 100 of them were enslaved Africans. Ayllón died, and the colonists fought among themselves.

In October 1526 the enslaved Africans rose up and escaped. Where they went is not certain. The accounts say they most likely found shelter with Native people nearby, probably the Guale. Within months the surviving colonists gave up the colony.

**St. Augustine.** Pedro Menéndez de Avilés and about 800 Spanish colonists founded St. Augustine, in Florida, on September 8, 1565. They moved into the Timucua town of a chief named Seloy and made his council house their first fort. Africans were among St. Augustine's first residents, some free and some enslaved. They worked as craftsmen, farmers and house servants.

Spanish slave law came from an old code called the *Siete Partidas*. It listed rights for enslaved people that English colonial law later left out. Under it, owners were not to split up families. Enslaved people could join the Catholic Church and marry in it, and the code listed ways for them to become free.

### Estevanico

> **Who:** An enslaved man from Morocco who walked across the south of the continent after a shipwreck, then was killed while guiding a Spanish expedition into Zuni country.
>
> **When and where:** Shipwrecked on the Texas coast in 1528. Reached Mexico City in 1536. Killed at the Zuni town of Hawikuh in 1539.

**Shipwrecked in 1528, he walked to Mexico City as a healer.**

Estevanico was born in about 1500 in Azemmour, in Morocco. In 1522 a Spanish nobleman named Andrés Dorantes de Carranza bought him. Six years later both men were on a Spanish expedition that was wrecked on the coast of Texas. Native people on that coast held the survivors, Estevanico among them, as slaves for several years.

In 1534 four of the survivors escaped: Estevanico, Dorantes, Álvar Núñez Cabeza de Vaca and Alonso del Castillo Maldonado. They walked west, working as healers along the way, and reached Mexico City in July 1536.

The Spanish official who ruled Mexico, Viceroy Antonio de Mendoza, then got Estevanico from Dorantes, either by buying him or as a gift. Some evidence suggests Mendoza freed him. On March 7, 1539, Estevanico set out as the guide for Marcos de Niza, a friar, a member of a Catholic religious order, who was heading north. Estevanico went ahead of the friar with Native men from Sonora.

The people of Hawikuh, a Zuni town, killed him there in 1539. The Spanish accounts give three different reasons. The commander Coronado wrote in 1540 that they killed him because he had "killed and assaulted their women." Pedro de Castañeda wrote that he had demanded turquoise and women. Hernando de Alarcón reported that he had boasted that armed men were coming behind him.

**Known:** The people of Hawikuh killed Estevanico in 1539.

**Not known:** why they did it. Zuni tradition does not agree with the Spanish accounts.

## The 1600s

**Era 3 of 10 · The 1600s · about 9 minutes**

English colonists made slavery part of their law step by step in the 1600s, one court case and one new law at a time. When about twenty Africans reached Virginia in 1619, Virginia's law had no category for a person held as property for life. Judges and elected lawmakers in Virginia, Massachusetts and Carolina created that category between 1640 and 1705. In 1662 Virginia's lawmakers ruled that a child born to an enslaved mother was enslaved for life, whoever the father was.

Ship crews fed the system from across the ocean. Over the whole Atlantic slave trade they loaded about 12.5 million captive Africans onto ships bound for the Americas. About 1.8 million of them died on the way, about one person in every seven.

### Who landed at Point Comfort in 1619?

An English ship called the *White Lion* landed at Point Comfort, in Virginia, in late August 1619. It carried "20. and odd Negroes," in the words of the colonist John Rolfe, using Negro, the word English writers of the time used for Black Africans. The *White Lion* was a privateer, a privately owned armed ship that attacked the ships of enemy countries. Its crew had taken these Africans from a Portuguese slave ship.

The Africans came from the Ndongo and Kongo region of West Central Africa. The exact day they landed is disputed. The National Park Service says late August. Some writers give August 20, and the Hampton historian Beth Austin argues for about August 25.

**Whose land it was.** Point Comfort belonged to the Kecoughtan, one of the Powhatan nations, who lived where the city of Hampton stands today. Their language belonged to the Algonquian family, a large group of related Native languages. English colonists built a fort beside their main village in 1609.

Soon after Lord De La Warr arrived, on July 9, 1610, the colonists seized the village. They drew the people out with a man playing a tambourine and then attacked them. The records do not say how many Kecoughtan they killed. The survivors fled to other towns of the Powhatan nations.

**Known:** In 1619 Virginia's law did not yet have a category for slaves.

**Not known:** whether the colonists held the Africans of 1619 as servants for a set number of years or as slaves for life. The records that survive do not settle it.

### The Middle Passage

The Middle Passage was the crossing of the Atlantic Ocean that ship crews forced captive Africans to make. Over the whole history of the trade, crews loaded about 12.5 million Africans onto slave ships. About 10.7 million lived through the crossing, and about 1.8 million died at sea. These figures come from the SlaveVoyages database of slave-ship voyages.

The average voyage took just over two months, and the trip from Upper Guinea, in West Africa, about three weeks. Crews chained the captives below the deck, in spaces too low for a person to stand up. They held the women apart from the men and kept the men in chains for long periods so they could not revolt.

Crew members often raped the women and children, which means they forced them into sex. About one captive in four was a child.

People died of disease and of thirst, and some killed themselves. The crew threw the bodies of the dead into the sea. Historians at the College of Charleston report that 13 to 19 percent of the people on board died during a crossing.

Ship crews landed most of the captives who survived in the Caribbean and in Brazil. Fewer than 4 percent came to mainland North America. Crews brought about 305,000 people there straight from Africa. Counting those who came by way of the Caribbean, the total is close to 388,000.

### One survivor's account

Olaudah Equiano wrote that slave traders carried him across the ocean on a slave ship when he was a child. He published his account in London in 1789, in a book called *The Interesting Narrative of the Life of Olaudah Equiano*. Two other records list his birthplace as Carolina. If they are right, he never made the crossing he describes.

In his account, the crew put Equiano below deck, and he was too sick to eat. Two white crewmen tied him across the windlass, the winch that pulled up the anchor chain, and flogged him for refusing food. Flogging means that a person is tied down and struck over and over on the bare body with a whip. Each stroke cuts the skin, and deep or repeated flogging leaves raised scars for life. Equiano wrote that captives were "hourly whipped for not eating."

He wrote that the hold was "so crowded that each had scarcely room to turn himself." The heat and the foul air made people sick, "of which many died." Children fell into the tubs the captives used as toilets and nearly smothered.

One day two men who were chained together broke through the netting around the deck and jumped into the sea. A third man followed them. The crew lowered a boat. The two chained men drowned. The crew pulled the third man out "and afterwards flogged him unmercifully."

The ship landed at Barbados, an island in the Caribbean, and from there traders sold him on to Virginia.

**Known:** Equiano's own book says he was born in Africa.

**Not known:** whether that is true. In 2005 the historian Vincent Carretta reported the two records, a 1759 baptism record in London and a 1773 Royal Navy crew list. The book and the records cannot both be right.

### John Punch

> **Who:** The first African known to have been sentenced by a Virginia court to serve for life.
>
> **When and where:** Virginia. Sentenced on July 9, 1640.

**Three servants ran away together. Only the African got life.**

The three men were servants of a man named Hugh Gwyn. The court record calls them "Victor, a dutchman, the other a Scotchman called James Gregory, the third being a negro named John Punch." They ran away together toward Maryland and were caught.

The judges of the General Court of Virginia heard the case on July 9, 1640. They ordered that "the said three servants shall receive the punishment of whipping and to have thirty stripes apiece," thirty strokes of the whip each. Victor and James Gregory then had to finish their time with their master, serve him one more year, and serve the colony for three years after that.

For John Punch the judges wrote a different sentence. He "shall serve his said master or his assigns for the time of his natural Life here or elsewhere." His assigns meant anyone the master sold or handed him to. Punch was the only African among the three.

It is the first known sentence of lifetime slavery in Virginia.

### How did a servant become a slave for life?

Judges and lawmakers made a separate rule for Africans, one case and one law at a time between 1640 and 1705. Under it, Africans could be held for life, and so could their children. In the early years of Virginia, many workers were indentured servants, bound by a contract to work for a master for a set number of years and then set free.

**Massachusetts, 1641.** Lawmakers in New England wrote slavery into law too. The lawmakers of the Massachusetts Bay colony, called the General Court, adopted a code of laws named the Body of Liberties on December 10, 1641. It allowed slavery for "lawful captives taken in just wars, and such strangers as willingly sell themselves or are sold to us."

That meant people captured in a war the colonists called fair could be held as slaves. So could outsiders who sold themselves or were sold to the colonists. The Massachusetts Bay lawmakers were the first in any English colony on the mainland to put slavery into a written law.

**John Casor.** Anthony Johnson, an African, had arrived in Virginia in about 1621, gained his freedom and become a landowner on the Eastern Shore. He claimed a Black man named John Casor as his servant for life. Casor said the time on his contract had run out and he was free, and he went to work for Johnson's white neighbor, Robert Parker. In 1654 Johnson took Parker to court in Northampton County to get Casor back.

The county judges ruled for Johnson on March 8, 1655. They ordered Casor back to Johnson as his servant for life, which made Casor Johnson's slave, and they made Parker pay the costs of the case. It was the first court ruling in the English mainland colonies that a person who had committed no crime could be held for life.

**The child follows the mother.** Virginia's House of Burgesses, the colony's elected assembly, passed a law about children in 1662. Under the old rule in English law, a child's place in the law, free or bound, came from the father. Virginia's lawmakers broke with that on purpose. A child born to an enslaved mother was now enslaved for life, whoever the father was. Lawyers called the rule by a Latin phrase, *partus sequitur ventrem*, "the child follows the womb."

**Baptism.** Some colonists were unsure whether baptism, the ceremony that made a person a Christian, set an enslaved person free. Virginia's lawmakers, meeting as the General Assembly in September 1667, passed a law that said it did not. It stated that "the conferring of baptisme doth not alter the condition of the person as to his bondage or ffreedome."

The lawmakers gave their reason in the law itself. With that doubt gone, they wrote, masters would be more willing to let enslaved people be baptized.

### The slave codes

Virginia's lawmakers gathered the colony's earlier slave laws into one slave code in 1705: a set of laws listing what enslaved people could not do, how they could be punished and what their owners could do to them. Under it, enslaved people counted as real estate, the same kind of property as land. The code said that baptism did not free anyone. A master who killed an enslaved person while "correcting" him, which meant punishing him, faced no penalty.

**Carolina's codes.** Carolina's lawmakers, who met as the colony's assembly, passed their first slave law in 1690. The Lords Proprietors, the English noblemen who owned the colony, struck that law down. The assembly's members passed a new code in 1696. They based both laws on the slave code that lawmakers in Barbados had written in 1661.

The 1690 Carolina law already allowed branding, nose-slitting and castration as punishments. Branding meant pressing a metal iron, heated red-hot, into the person's skin. The iron burned a mark, often a letter, that stayed on the body as a scar for life. Nose-slitting meant cutting the person's nose open.

Under the Barbados code, an enslaved person who hit a Christian a second time was to be whipped hard, have the nose slit and be burned on the face with a hot iron. Castration meant cutting off a man's testicles, which left him unable to father children.

These codes of the 1600s set rules for enslaved people's bodies and for who could be held for life. They said nothing about reading or writing. South Carolina's lawmakers passed the first law against teaching enslaved people to write in 1740.

## 1700 to 1750

**Era 4 of 10 · 1700 to 1750 · about 10 minutes**

Enslaved people rose up in the North and in the South between 1700 and 1750, and after each revolt colonial lawmakers wrote harsher laws. Their slave codes ordered whipping, branding and cutting off ears. South Carolina planters grew rice to sell overseas, a crop that enslaved West Africans already knew how to grow. In 1739 about 20 enslaved men near Charleston took up arms and marched toward Spanish Florida, where the king of Spain had promised freedom to people who escaped from the English colonies.

English colonists enslaved Native people as well as Africans. Slavery was a Northern business too: in New York City in 1712, about one person in five was enslaved.

### How many Native people did Carolina's traders enslave?

English traders in Carolina enslaved between 24,000 and 51,000 Native people of the Southeast from 1670 to 1715. That range comes from the historian Alan Gallay. The traders shipped many of the captives to the Caribbean. In those years they shipped more enslaved Native people out of Charleston than slave ships brought enslaved Africans in.

### The ships from Rhode Island

Merchants in the northern colonies sent out slave ships too. Rhode Island merchants paid for about 1,000 slaving voyages, and about half of all the slave ships that left mainland North America sailed from Rhode Island ports. The historian Jay Coughtry counted 934 of these voyages, which carried about 106,000 Africans. In the 1700s, Rhode Island merchants controlled between 60 and 90 percent of the American trade in African captives.

The DeWolf family of Bristol, Rhode Island, sent out about twice as many slaving voyages as the families closest behind them. Bringing captives into the United States from abroad became illegal in 1808. George DeWolf kept sending out slave ships anyway, against the law, until 1825.

### New York, 1711 and 1712

New York City had about 5,000 people in 1700, and at least 750 of them were enslaved. The city's aldermen, the men who governed the city, set up a market at the foot of Wall Street on November 30, 1711. There, enslaved people were sold, rented out and inspected by buyers. The market stood from 1711 to 1762. The accounts of the market do not name the men who bought and sold people there.

**The fire on Maiden Lane.** More than 20 enslaved people in New York City set fire to a building on Maiden Lane on April 6, 1712. Accounts describe most of them as Coromantee, Akan people from the Gold Coast of West Africa, which is Ghana today. When white people came to fight the fire, the rebels attacked them. They killed 8 or 9 white people and wounded 6 or 7. Six of the rebels killed themselves before they could be captured.

Governor Robert Hunter called out the militia, the colony's armed citizens. Officials arrested more than 70 Black people. They put 27 on trial, found 21 guilty and put all 21 to death.

One account says 20 were burned alive and one was broken on the wheel. Breaking on the wheel was a public execution: the person was tied to a large wheel, and the executioner broke the person's arms and legs with an iron bar and left the person to die. Other accounts say only that the punishments ran from burning alive to breaking on the wheel.

Afterward, the members of the colony's assembly made it illegal for enslaved people to gather in groups of more than three or to own guns.

### Rice and the Lowcountry

The Lowcountry is the coast of South Carolina around Charleston. Rice planters there relied on the skill and the labor of West Africans from rice-growing parts of Africa, and they paid more for captives from those coasts. Rice shipped out of Carolina rose from about 268,602 pounds a year around 1700 to more than 30 million pounds a year around 1740, more than a hundred times as much. Charleston became the largest port on the mainland where slave ships landed their captives.

**Sullivan's Island.** Ships arriving at Charleston stopped first at Sullivan's Island, in the harbor. The island had a quarantine station, called the pest house, where captives who might carry disease were held apart from everyone else.

Many accounts say about 40 percent of all the enslaved Africans brought to mainland North America passed through the island itself. The Charleston historian Nic Butler and others say that figure is too high, because many ships landed elsewhere in the harbor. Their doubt is about the island's share only.

**Whose land it was.** The rice plantations stand on Native land. When English colonists settled Charleston in 1670, about fifteen Native groups lived in the Lowcountry, among them the Stono, the Kiawah, the Etiwan, the Edisto and the Combahee. By the middle 1700s these groups were nearly gone. Many of their people had died of disease or been killed in wars, and English colonists had taken their land.

**The runaway law.** South Carolina's assembly passed a law in June 1712 that listed punishments for any enslaved person who stayed away for twenty days or more. For a first escape, it ordered a public whipping of up to forty lashes, forty strokes of the whip. For a second escape, it ordered the person "branded with the letter R, on the right cheek." For a third, it ordered forty lashes and one ear cut off.

A man caught a fourth time was to be castrated. A woman caught a fourth time was to be whipped, branded with an R on the left cheek, and have her left ear cut off. The 1712 law does not name the people who carried out these punishments.

For a fifth escape, the law let two justices of the peace, who were local judges, and three landowners decide. They could order the person killed. Or they could order the person's Achilles tendon, the cord just above the heel, cut through, so that the person could never run again. From 1723 on, South Carolina's lawmakers dropped these lists from their codes and left punishment to the enslaver.

### A free town to run to

Florida belonged to Spain. In 1693 the king of Spain promised freedom to enslaved people who escaped from the English colonies and reached Florida, if they became Catholics. Men also had to serve in the militia.

Florida's governor, Manuel Montiano, set up a town for these free people in 1738, about two miles north of St. Augustine. Its Spanish name was Gracia Real de Santa Teresa de Mose, and people call it Fort Mose. It was the first free Black town in what is now the United States to be recognized by law. About 100 people lived there, in more than 20 households.

British forces surrounded St. Augustine and attacked it in 1740. Fort Mose was destroyed in the fighting, which people remember as the battle of Bloody Mose. The people rebuilt it in 1752. In 1763, when the Spanish left Florida, the people of Mose left with them for Cuba. The site is now Fort Mose Historic State Park.

### Francisco Menéndez

> **Who:** A man from West Africa who escaped slavery in Carolina and became captain of the free Black militia at Fort Mose.
>
> **When and where:** Born in the Gambia region of Africa. Enslaved in Carolina. Led the militia at Fort Mose, Florida, from 1738.

**He escaped slavery in Carolina and became a captain in Florida.**

Francisco Menéndez was a Mandinga man, born in the Gambia region of West Africa. Slave traders carried him to Carolina, where he was enslaved.

He escaped south to Spanish Florida. There he was baptized as a Catholic and took the name Francisco Menéndez. From 1738 he led the militia at Mose, the armed men who defended the town of people who had escaped from the English colonies.

Spanish colonial records document his life. Of all the people who lived at Mose, he is the one the records describe most fully.

### The Stono Rebellion, 1739

About 20 enslaved men rose up at the Stono River, south of Charleston, on September 9, 1739. It was the largest uprising of enslaved people in the mainland colonies before the American Revolution. A report written in 1739 describes them as Angolan and says "one who was called Jemmy was their Captain."

The rebels seized weapons and marched south toward Spanish Florida, and others joined them along the way. The same report says they were "calling out Liberty" and marched "with Colours displayed, and two Drums beating." The rebels killed about 25 white colonists.

Lieutenant Governor William Bull met the rebels on the road that day. He rode off to warn the planters and raised the militia, which attacked the rebels the same day. Bull also hired Chickasaw and Catawba men, and some enslaved men, to hunt down those who got away. About a week later, the militia fought a group of rebels again, about 30 miles from the first fight.

**The count.** The militia killed between 35 and 50 rebels in the first fight. A historical marker says at least 54. The 1739 report gives its own count: "about 40 Negroes and 20 whites were killed."

**What the colonists did to the captured.** The report says the militia "shot on the Spot" rebels they took in the field. Colonists cut off the heads of rebels and set them on stakes along the main roads as a warning to others. The colonists put most of the captured rebels to death. One account says the militia took 43 rebels who had no weapons and hanged them. The colonists sold the survivors to the West Indies, the islands of the Caribbean.

### What the Negro Act took away

South Carolina's assembly passed the Negro Act on May 10, 1740, in answer to Stono. Under it, enslaved people could not gather in groups, grow their own food, earn money or move about freely. Teaching an enslaved person to write became a crime. That was the first law in what became the United States against teaching enslaved people. It named writing, not reading.

Under the Negro Act, a white person who murdered an enslaved person was guilty only of a misdemeanor, a minor crime punished by a fine. Any white person, not only an owner, could arrest and punish a Black person who broke the act. A court could put an enslaved person to death for plotting a revolt, running away, setting fires, or teaching others about poisonous plants.

### New York, 1741

New York officials put about 200 people on trial in 1741 for a plot to burn the city. Their main witness told of the plot only after a judge had threatened her and promised her a reward.

A string of fires began in New York City in March 1741, the first at Fort George, the governor's home. City officials claimed that enslaved people and poor white people had plotted to burn the city. Three judges of the colony's Supreme Court heard the cases, among them Daniel Horsmanden. The trials began on May 11, 1741.

**The witness.** Mary Burton was a young servant bound to a tavern owner named John Hughson. When officials threatened her with jail, she testified about a robbery. Judge Horsmanden threatened her again and promised her an end to her contract and a reward in money. After that, she began to describe a plot she had never mentioned before. The New York courts' historical society says the sentences rested on doubtful testimony.

**The count.** The same society counts 30 people sentenced to death and 70 sentenced to be sold into slavery in the Caribbean. The historian Jill Lepore counts 34 put to death between May 11 and August 29, 1741.

By Lepore's count, officials burned 13 Black men at the stake and hanged 17 Black men, two white men and two white women. John Hughson, his wife Sarah and their daughter Sarah were among the white people put to death. In 1744 Horsmanden published his record of the trials.

## 1750 to 1800

**Era 5 of 10 · 1750 to 1800 · about 9 minutes**

The men who led the Revolution wrote in 1776 "that all men are created equal," and enslaved people used words like those to claim their freedom. Elizabeth Freeman won hers in a Massachusetts court in 1781 with the words of the new state constitution. About 20,000 Black people joined or fled to the British during the war, after Virginia's royal governor promised freedom to enslaved men who fought for Britain. In 1796 Ona Judge walked out of President George Washington's household and never went back.

Slavery stayed legal in most of the new country. The first census, a count of every person in the United States, found 697,681 people held in slavery in 1790. Lawmakers and judges in Vermont and six northern states began to end slavery between 1777 and 1804, but most of their laws freed only children born after a set date, and only once those children grew up. The men who wrote the Constitution in 1787 protected slavery in three of its clauses, or parts, without once using the word slave.

### Phillis Wheatley

> **Who:** A girl kidnapped from West Africa who became the first African American to publish a book of poetry.
>
> **When and where:** Landed in Boston in 1761. Her book was published in London on September 1, 1773. Freed by November 1773. Died in 1784.

**Her first name came from the slave ship that carried her.**

Slave traders kidnapped her from West Africa when she was about seven years old. In 1761 she landed in Boston on a slave ship called the *Phillis*. John Wheatley, a Boston merchant, and his family bought her. Her first name came from the ship, and her last name from the family who bought her.

She never went to school. John Wheatley wrote that she learned "by only what she was taught in the Family." Within sixteen months of landing, he wrote, she had learned English well enough to read the hardest parts of the Bible.

Twelve years after she landed, she was a published poet. Her book, *Poems on Various Subjects, Religious and Moral*, was published in London on September 1, 1773. It was the first book of poetry by an African American. The Wheatleys freed her by November 1773, shortly after it appeared.

She married John Peters in 1778. She died poor in 1784, at about 31 years old.

### Crispus Attucks, 1770

Crispus Attucks was the first person British soldiers killed in the Boston Massacre. The soldiers fired on a crowd of colonists in King Street, in Boston, on March 5, 1770. Attucks was a sailor with African and Wampanoag ancestors. Most accounts say he had escaped from slavery in Framingham, Massachusetts, around 1750. Accounts differ about whether he was legally free by 1770 or still an escaped slave.

### Two promises of freedom in the Revolution

Both sides in the Revolution promised freedom to some of the enslaved men who would fight for them. Neither side kept that promise to all of them.

**Lord Dunmore's promise.** Virginia's royal governor, Lord Dunmore, made a promise on November 7, 1775, to the men enslaved by Virginians who were fighting the British. Any of them who joined the British army would be free. About 300 men joined his Ethiopian Regiment within a month, and it grew to about 800.

**The Patriot promise.** The Patriots, the colonists fighting the British, made promises too. Rhode Island's lawmakers voted on February 14, 1778, that any enslaved man in the state could join the army for the rest of the war. He would be set free as soon as he passed the army's inspection, and the lawmakers promised to pay his owner up to 120 pounds.

**The count.** Over the whole war, by the estimates of the Gilder Lehrman Institute and the American Battlefield Trust, about 20,000 Black people joined or fled to the British. About 9,000 served the Patriots, and about 5,000 of those fought as soldiers.

### Which states ended slavery first?

Vermont's constitution of 1777 was the first constitution to ban slavery. It banned holding adults in slavery. Vermont then governed itself as its own country, and it joined the United States in 1791.

**Pennsylvania, 1780.** Pennsylvania's lawmakers passed the Act for the Gradual Abolition of Slavery on March 1, 1780, a law to end slavery step by step over many years. No elected lawmakers anywhere in the world had passed a law to end slavery before. No enslaved person went free on the day it passed. Children born after it were to go free when they turned 28.

In Massachusetts, juries and judges ended slavery in court cases decided between 1781 and 1783. Lawmakers in Connecticut and Rhode Island passed gradual laws in 1784. New York's lawmakers passed one in 1799, and the last enslaved people in New York were freed in 1827. New Jersey's lawmakers passed theirs last, in 1804. Under these gradual laws, people in the North stayed enslaved for decades.

The members of Congress passed the Northwest Ordinance on July 13, 1787, a law for the lands north of the Ohio River. It banned slavery there.

### Elizabeth Freeman ("Mum Bett")

> **Who:** An enslaved woman who sued for her freedom under the new Massachusetts constitution and won.
>
> **When and where:** Sheffield and Great Barrington, Massachusetts. Jury verdict in August 1781. Died in 1829.

**Her lawyer argued that seven words in a constitution set her free.**

Before she was Elizabeth Freeman, she was known as Bett, or Mum Bett. She was enslaved in the household of Colonel John Ashley in Sheffield, Massachusetts.

The new Massachusetts constitution of 1780 states that "all men are born free and equal." Bett and an enslaved man named Brom sued Ashley for their freedom. Their lawyer, Theodore Sedgwick, argued that those words made slavery illegal.

A jury in Great Barrington set them free in August 1781. The jury also ordered Ashley to pay them 30 shillings for the harm done to them. The case was called *Brom and Bett v. Ashley*, Brom and Bett against Ashley. The juries and judges in that case and in the cases of an enslaved man named Quock Walker, decided from 1781 to 1783, ended slavery in Massachusetts.

Bett took the name Elizabeth Freeman. For the rest of her life she worked for pay as a housekeeper and a nurse. She died in 1829.

### Sally Hemings and Thomas Jefferson

Thomas Jefferson was the main author of the Declaration of Independence. Over his lifetime he owned more than 600 enslaved people. One of them was Sally Hemings. Jefferson owned her and used her for sex from the time she was a girl, and she had his children.

**Her family.** Sally Hemings was born enslaved in 1773. Her mother, Elizabeth Hemings, was enslaved. Her father was most likely John Wayles, the man who owned her mother. By law Wayles owned Elizabeth Hemings, and she had no legal right to refuse him sex. Wayles was also the father of Jefferson's wife, Martha. That made Sally Hemings the half-sister of Jefferson's wife.

**Paris, 1787.** Jefferson was the United States minister to France in 1787, the man who spoke for his country in Paris. That year Sally Hemings went to Paris with his daughter Polly. Sally was 14 and enslaved by Jefferson. He was 44. By law he owned her, and she could not refuse him. He had the legal power to sell her or her family.

Her son Madison Hemings said in 1873 that in Paris she "became Mr. Jefferson's concubine," using an old word for a woman a man kept for sex without marrying her. Madison Hemings said she was pregnant when they came back to Virginia.

Under French law she could have claimed her freedom in Paris. Madison Hemings said Jefferson promised that her children would be freed at age 21 if she went back with him. She had children from 1790 to 1808. Four lived to be adults: Beverly, Harriet, Madison and Eston.

**The DNA.** In 1998 scientists compared DNA and found that a man of the Jefferson family was the father of Eston Hemings. That test could not tell Thomas Jefferson apart from other men of his family, such as a brother or a nephew. In January 2000 the Thomas Jefferson Foundation, which runs Jefferson's home at Monticello, concluded that Jefferson "was probably the father" of her children. By 2018 the foundation's historians treated this as a fact.

In September 2026 a study paid for by the Smithsonian tested DNA from a lock of Thomas Jefferson's own hair, cut on the day he died. Richard Kurin of the Smithsonian said some Hemings descendants "had more Thomas Jefferson DNA than the known Jefferson descendants." The scientists concluded that Jefferson himself fathered her children.

Historians disagree about the right word for what Jefferson did. Jessica Marie Johnson, a historian of slavery at Johns Hopkins University, wrote in 2026 that Jefferson was a rapist. In her 2008 history of the Hemings family, the historian Annette Gordon-Reed argued that Jefferson and Sally Hemings loved each other. Another historian, Eric Foner, answered in a review that neither of them left any record of their feelings.

Jefferson died in 1826. Neither he nor anyone after him ever legally freed Sally Hemings. His daughter Martha Jefferson Randolph let her live in Charlottesville with her sons. There she lived as a free woman, though no paper made her free by law, and the census of 1833 listed her as free. She died in 1835.

### The Constitution's protections for slavery, 1787

The men who wrote the Constitution in 1787 put three protections for slavery into it. None of the three clauses uses the word slave.

**Three-fifths.** Under the three-fifths clause, each enslaved person counted as three-fifths of a person. The number of seats a state got in the House of Representatives depended on that count. Enslaved people could not vote, but their owners' states got extra seats for them. The slave states held 47 of the 105 seats in the House in 1793. Counting only their free people, they would have had 33.

**Runaways.** The fugitive clause said that a person "held to Service or Labour" who escaped to another state had to be "delivered up," handed back to the person who claimed that person's work.

**The trade.** The slave-trade clause barred Congress from ending the import of enslaved people before 1808.

### Enslaved builders of the capital

Enslaved people worked at every stage of building the White House and the Capitol in Washington. The cornerstone of the White House was laid on October 13, 1792, and that of the Capitol on September 18, 1793.

Enslaved men cut sandstone at the quarries on Aquia Creek, the open pits where the stone was dug. They also cut timber, made bricks, sawed lumber and did carpentry. The officials in charge of the building hired them from their owners, and the owners kept the pay.

The payroll of the President's House for May 1795 names five enslaved carpenters: Tom, Peter, Ben, Harry and Daniel. The architect James Hoban owned four of them, and his assistant Pierce Purcell owned one. The payroll records the days four of the men worked that month: Peter 28, Ben 28, Daniel 25 and Harry 9. Hoban signed for their wages.

### Ona Judge

> **Who:** An enslaved woman who escaped from President George Washington's household and was never caught.
>
> **When and where:** Walked out of the President's House in Philadelphia on May 21, 1796. Lived free in New Hampshire. Died in 1848.

**She walked out while the Washingtons were eating dinner.**

Ona Judge was enslaved as Martha Washington's personal servant. On May 21, 1796, while the Washingtons sat at dinner in the President's House in Philadelphia, she left. She boarded a sloop, a small sailing ship, called the *Nancy*, and sailed to Portsmouth, New Hampshire.

Three days later a runaway advertisement ran in the *Philadelphia Gazette*, offering ten dollars for her capture. George Washington tried for years to get her back. She refused an offer to return. She married and lived in New Hampshire until she died in 1848.

In the 1840s she told her own story to newspaper interviewers, including one from *The Granite Freeman* in 1845. She told them that she was poor and that she was free.

## 1800 to 1850

**Era 6 of 10 · 1800 to 1850 · about 24 minutes**

Cotton planters spread slavery west and south between 1800 and 1850. The number of people held in slavery kept rising, even after a federal law against bringing captives from abroad took effect on January 1, 1808. Most of the growth came from children born into slavery. Census takers counted 697,681 enslaved people in 1790 and 3,953,760 in 1860, almost six times as many.

Slave traders moved more than a million people from the older slave states of the Upper South, such as Virginia, to the new cotton states of the Deep South and sold them to planters there. Traders and buyers split families by selling husbands, wives and children to different owners.

Enslaved people resisted every day, and some rose up in armed revolt. Thousands escaped to the free states and to Canada. In most of the slave states, lawmakers made it a crime to teach an enslaved person to read.

### Cotton

Eli Whitney built a cotton gin, a machine that pulls the seeds out of cotton, in 1793. With the gin, planters could make money growing upland cotton, the kind that grows away from the coast. Enslavers took enslaved people west to clear and plant new cotton lands. Cotton growers in the United States produced fewer than 9,000 bales, big pressed bundles, a year around 1790. By 1800 they produced more than 200,000 bales, and by 1860 about 4 million, more than 400 times the crop of 1790.

The number of slave states grew from six in 1790 to fifteen in 1860. By 1860 enslaved people on Southern plantations grew about 75 percent of the world's cotton. Cotton made up more than half of everything Americans sold to other countries, measured in dollars.

**People as money.** By 1860 the people who held four million people in slavery valued them at $3 billion or more. That was more than all the money invested in the country's railroads and factories put together. Enslavers bought, sold and priced people as property. They also mortgaged them: they borrowed money and promised to hand the enslaved people over to the lender if they could not pay it back.

**Whose land it was.** The cotton land of these years was Native land. Choctaw leaders signed the Treaty of Dancing Rabbit Creek, a written agreement with the United States, on September 27, 1830. In it they signed away more than 10 million acres in Mississippi and Alabama. It was the first treaty signed after members of Congress passed the Indian Removal Act of 1830. The Chickasaw signed away their land in the Treaty of Pontotoc Creek in 1832.

Under the Removal Act, United States officials then forced both nations west to Indian Territory, today's Oklahoma. They moved the Choctaw in groups in 1831, 1832 and 1833. By the Choctaw Nation's own count, more than a quarter of the Choctaw people removed in those years died.

Enslavers then brought in enslaved people to clear and plant the land the Choctaw and Chickasaw had lost. Mississippi's cotton crop grew from about 20 million pounds in 1820 to 193.2 million pounds in 1839. The number of enslaved people in Mississippi grew from 65,659 in 1830 to 195,211 in 1840.

### Sold south

Slave traders moved more than one million people from the Upper South to the cotton lands of the Deep South between about 1790 and 1860. From 1820 on, they moved about 200,000 people every ten years. They marched people overland in coffles, lines of people chained together. They also shipped people along the coast to New Orleans, which had the largest slave market in the country.

**Franklin and Armfield.** The biggest trading firm belonged to Isaac Franklin and John Armfield. From 1828 to 1836 they ran it from 1315 Duke Street in Alexandria, Virginia. Their compound took up half a city block, with separate pens for men and for women. At their busiest they moved between 1,000 and 1,500 people a year, and about 8,500 in the nine years of the partnership. They marched people to Natchez, in Mississippi, and shipped others to New Orleans on their own ships.

Franklin and Armfield also sold enslaved women and teenage girls to men who bought them in order to rape them, to force them into sex. This was known as the "fancy" trade, and the traders charged much higher prices for these women and girls. The historian Joshua Rothman read the partners' own letters. He found that Franklin, Armfield and their partner Rice Ballard also raped some of these women themselves, and joked about it in their letters.

**Families.** Traders and buyers broke families apart as a matter of routine. The Equal Justice Initiative, a group that studies racial injustice, has added up the effects. Its researchers found that traders separated nearly half of the people they moved from a husband, a wife or a parent. About one enslaved marriage in three ended because an owner sold the husband or the wife away. Traders sold children away from their mothers.

### Work, food and home

Enslaved people worked from sunup to sundown, six days a week. On cotton and sugar plantations, an overseer, a man the owner paid to run the work, drove them in gangs, row by row across the fields. This was called the gang system.

On the rice plantations of the Lowcountry, the coast around Charleston, the overseer gave each person a set task for the day. When it was done, the rest of the day was the person's own. This was called the task system.

**Two hundred pounds.** Solomon Northup, a free New Yorker whom two men drugged and sold into slavery in 1841, picked cotton in Louisiana in the 1840s. His own story comes later in this era. In his book *Twelve Years a Slave* (1853), he wrote: "An ordinary day's work is two hundred pounds."

Every night each person's cotton was weighed at the gin-house, the building where the cotton gin stood. When a person's cotton came up short, the owner or the overseer whipped that person.

On the plantation where Northup was held, the owner, Edwin Epps, did the whipping himself in the yard. Northup wrote that "Twenty-five are deemed a mere brush," fifty lashes were "the ordinary penalty," and "one hundred is called severe."

**Food and clothes.** Frederick Douglass lived as an enslaved child on a plantation in Maryland. In his *Narrative* (1845), he recorded the food allowance there for one month: eight pounds of pork, or the same amount of fish, and one bushel, about a big basketful, of cornmeal.

The enslaver gave out clothing once a year. It was so thin that small children too young for field work often had only a long shirt to wear. Enslaved people added to their food with gardens, fishing and trapping where their owners allowed it.

Formerly enslaved people interviewed in the 1930s remembered cabins of one room, with dirt floors and beds made of boards. Under the law, their marriages did not count. An owner could sell a husband, a wife or a child on any day.

### Punishment

Owners and overseers flogged enslaved people for picking too little cotton, for arriving late and for running away. A flogging meant being tied and whipped again and again on the bare body. Each stroke cut the skin, and deep or repeated whipping left raised scars for life. The whip named most often in Southern sources is the cowskin, also called the cowhide, a whip made of dried, twisted cow's hide.

Frederick Douglass described a flogging he saw as a child. His enslaver, Aaron Anthony, stripped Douglass's Aunt Hester from her neck to her waist. He tied her crossed hands to a hook in a ceiling beam, so that she stood on her toes. Then he whipped her with "the heavy cowskin" until her blood dripped to the floor.

**The enslavers' own words.** Theodore Weld, an abolitionist, one of the people working to end slavery, published *American Slavery As It Is* in 1839. It collected reports from eyewitnesses and advertisements from Southern newspapers. One witness saw an overseer whip a man named Joe "with a heavy cow-hide full six feet long" for arriving five minutes late.

The enslavers wrote the advertisements themselves. Micajah Ricks of Nash County, North Carolina, placed one in the Raleigh *Standard* on July 18, 1838. It began: "Ranaway, a negro woman and two children," using negro, an old word for a Black person. The ad went on: "a few days before she went off, I burnt her with a hot iron, on the left side of her face, I tried to make the letter M." The advertisement does not give the woman's name.

In another advertisement that Weld printed, Robert Nicoll of Mobile, Alabama, offered ten dollars for "my woman Siby, very much scarred about the neck and ears by whipping."

### Sexual violence

By law, an enslaved woman or girl had no right to refuse the man who owned her, and no right to defend herself from him. Harriet Jacobs later wrote a book about what one of those men tried to do to her.

Jacobs was born enslaved in Edenton, North Carolina, in 1813. In 1825 she was left in a will to a three-year-old girl, Mary Matilda Norcom. That put her under the control of the girl's father, Dr. James Norcom. From her early teens, Norcom tried again and again to rape her. He held her as property, and for years she could not get away from him.

To protect herself she began a relationship with a white lawyer, Samuel Tredwell Sawyer, and had two children with him, Joseph and Louisa.

**Seven years in a crawl space.** Jacobs ran away in 1835. She hid in a crawl space above a storeroom in her grandmother's house for seven years. The space was so small she could barely sit up. In 1842 she escaped north by boat. Ten years later the wife of her employer, Cornelia Grinnell Willis, bought her freedom.

Jacobs told her story in *Incidents in the Life of a Slave Girl*, dated 1861 and published under the name "Linda Brent." Historian Jean Fagan Yellin later proved from Jacobs's letters that she wrote it herself. She died in Washington, D.C., in 1897.

### Churches and hush harbors

Richard Allen was born enslaved. In Philadelphia he founded the African Methodist Episcopal Church, known as the AME Church, which was formally organized in 1816. It was the first Black church denomination, a group of churches that share the same beliefs and leaders, in the country.

In the slave states, enslaved people also worshipped out of their owners' sight. They met in brush arbors, shelters built of branches, which they called "hush harbors." They sang spirituals, religious songs that expressed their faith and also had hidden messages in them.

**By 1830:** Cotton planters were moving onto Choctaw land in Mississippi, Franklin and Armfield were marching people south from Alexandria, and Georgia's lawmakers had just passed a new law against teaching enslaved people.

### Reading made a crime

The first laws against teaching enslaved people named writing, not reading. South Carolina's lawmakers banned teaching enslaved people to write in 1740, and Georgia's followed in 1755.

Later laws banned teaching reading too. Virginia's lawmakers banned enslaved people in 1819 from any school "for teaching them reading or writing." Between 1829 and 1834 lawmakers in Georgia, Louisiana, North Carolina, Virginia, Alabama and South Carolina passed new laws or made their old ones harsher. North Carolina's law of 1830 forbade any free person to "teach or attempt to teach any slave within this State to read or write." Most of the slave states had such a law, but not all of them.

**The punishments.** The punishments depended on who broke the law. A white person who taught was fined. In North Carolina the fine was up to $200. The laws of Georgia and other states added jail. For Black teachers and learners, the laws ordered whipping. North Carolina's law set the punishment at 39 lashes, and in Virginia a person caught at a school could get up to 20 lashes. Several of these laws covered free Black people as well as the enslaved.

Enslavers had several fears. With writing, an enslaved person could forge, or fake, a pass, a note from an owner that allowed an enslaved person to travel. Readers could get the newspapers of the abolitionists, and they could read the Bible without an owner choosing which parts they heard. After Nat Turner, an enslaved preacher, led a revolt in Virginia in 1831, enslavers feared organized revolt most of all.

Enslaved people learned to read anyway. Estimates reported by Encyclopedia Virginia and History.com say about 5 to 10 percent of enslaved people could read by 1860. Some estimates for the last years of slavery run as high as 20 percent.

### Frederick Douglass

> **Who:** A man born enslaved who learned to read in secret against the orders of the man who held him, escaped, and became the most heard abolitionist of his century.
>
> **When and where:** Born in Talbot County, Maryland, in February 1818. Escaped on September 3, 1838. Died in 1895.
>
> **Movie:** *Becoming Frederick Douglass* (2022), a documentary by Stanley Nelson, shown on PBS. It is about Douglass's life.

**He traded bread with hungry white boys for reading lessons.**

As a boy Frederick Douglass lived in Baltimore, in the household of Hugh and Sophia Auld. Sophia Auld began to teach him the alphabet. Hugh Auld stopped her. Teaching a slave to read was against the law, he told her, and reading "would forever unfit him to be a slave."

Douglass saw in those words how white men kept Black people enslaved: by keeping them from learning. "From that moment," he wrote in his *Narrative* (1845), "I understood the pathway from slavery to freedom." In a later book, in 1855, he called Auld's words "the first decidedly anti-slavery lecture" he ever heard.

He kept learning in secret, paying hungry white boys with bread for lessons. At about age twelve he bought a book of speeches called *The Columbian Orator*.

When Douglass was a teenager, the man who owned him, Thomas Auld, took him away from Baltimore to St. Michael's, Maryland. Thomas Auld hired him out for a year to Edward Covey, a farmer known for "breaking young slaves." Covey whipped him until his back bled. After six months Douglass fought back. They fought for nearly two hours, and Covey never whipped him again.

Thomas Auld later sent him back to Baltimore to learn a trade in the shipyards. Douglass earned $1.50 a day, and every Saturday night he had to hand "every cent" of it to Hugh Auld. He escaped on September 3, 1838. He rode a train north through Baltimore, dressed in a sailor's clothes and carrying a sailor's papers that he had borrowed. Anna Murray, a free Black woman, helped him, and he married her.

He published his *Narrative of the Life of Frederick Douglass* in 1845, and two years later he started a newspaper, the *North Star*. For the rest of the century he spoke and wrote against slavery. More people heard him speak than any other abolitionist, and he was photographed more than any other abolitionist.

No record gives the day he was born, in February 1818. He chose February 14 as his birthday. He died in 1895.

### Milla Granson (Lilly Ann Granderson)

> **Who:** An enslaved woman who ran a secret night school in Natchez, Mississippi, and by her own count taught hundreds of people to read and write.
>
> **When and where:** Born in Petersburg, Virginia, about 1816. Enslaved in Kentucky, then near Natchez, Mississippi. Died in 1889.

**Her school opened at midnight and closed at two in the morning.**

Milla Granson ran a school at night in Natchez, Mississippi, while she was enslaved. Her pupils were enslaved people who came after a full day's work. In March 1864 she told her story to Laura Haviland, a teacher who belonged to the Quakers, a Christian group. Haviland printed it in a book in 1881, and it is the only record of the school.

Granson was enslaved in Kentucky, where the children of her enslaver taught her to read and write. When that enslaver died, she was sold south to an owner near Natchez and put to work in the fields. She could not keep up with the field hands, and the overseer whipped her. She told Haviland: "sometimes I thought I would die from such cruel whippings upon my bared body." The record does not give the overseer's name.

The school opened "at eleven or twelve o'clock at night, and closed at two o'clock A. M." Every door and window was shut so no one would find out. Her pupils came into a back alley, "each with a bundle of pitch-pine splinters for lights."

She taught twelve at a time. When those twelve could read and write, she sent them off and took twelve more, "until she had graduated hundreds." Some of her pupils wrote their own passes and set out for Canada. She never heard from them again, and she believed they got away.

After slavery ended, she pushed for the founding of Natchez Seminary, the school that became Jackson State University. She married Oliver Granderson. She died in 1889 and is buried in the Natchez City Cemetery.

### Resistance and revolt

Enslaved people resisted slavery in small ways every day. They worked slowly, broke tools, pretended to be sick and took food. Most of all, they ran away.

Southern newspapers were full of advertisements for runaways, placed by enslavers who wanted them back. Some of the ads warn that the person "can read," or "can write and may forge a pass." Researchers at Cornell University, in a project called Freedom on the Move, are putting thousands of these ads online.

**Gabriel, 1800.** An enslaved blacksmith named Gabriel planned to lead a march on Richmond, Virginia, in 1800. On August 30, the day it was to begin, two enslaved men, Pharoah and Tom, who belonged to members of the Sheppard family, told Mosby Sheppard about the plan. Sheppard told Governor James Monroe. A storm that day scattered those who had gathered.

Virginia judges, sitting in special courts with no juries, found 26 men guilty, Gabriel among them. On the judges' orders, all 26 were hanged. Encyclopedia Virginia's account does not name the men who carried out the hangings.

**The German Coast, 1811.** Charles Deslondes led an uprising in January 1811 on the German Coast of the Territory of Orleans, upriver from New Orleans. Between 64 and 125 enslaved people began it, and accounts put the number who joined at 200 to 500. They marched about twenty miles down the river road toward New Orleans and killed two white men, Gilbert Andry and François Trépagnier.

Governor William C. C. Claiborne, General Wade Hampton and a militia, a band of armed local men, put the uprising down. Hampton led U.S. Army troops and Navy sailors. Manuel Andry and Charles Perret led the militia, which was made up of planters. On January 10, in about half an hour of fighting, they killed 40 to 45 rebels. They killed others without any trial as they caught them.

Over the next two weeks, planters sat as judges in special courts called tribunals. Planters and U.S. officials put 44 more captured rebels to death. About 95 rebels were killed in all. The militia cut off the heads of the dead and set nearly 100 of them on poles along the levee, the river wall, from New Orleans upriver. Deslondes was captured on January 11 and given no trial. Militiamen cut off his hands, shot him several times and burned him alive.

**Charleston, 1822.** White officials in Charleston, South Carolina, accused Denmark Vesey, a free Black carpenter, of planning a revolt to free thousands of enslaved people. No revolt ever took place, and no white person was harmed. Officials in Charleston put Vesey and 34 other men to death.

The officials claimed the city's African Methodist Episcopal church had helped plan the revolt. They ordered its members to scatter and destroyed the church. The Equal Justice Initiative says they burned it to the ground, and other accounts say it was torn down. Black Charlestonians rebuilt their church. In 1834 Charleston's white city leaders outlawed independent Black churches, the historian Manisha Sinha writes. The accounts do not name the officials who passed that ban. The congregation later became the church known today as Mother Emanuel.

### Nat Turner

> **Who:** An enslaved preacher who led the deadliest slave revolt in United States history.
>
> **When and where:** Southampton County, Virginia, August 21 to 23, 1831. Hanged on November 11, 1831.
>
> **Movie:** *The Birth of a Nation* (2016), a feature film about Turner's revolt. Its makers took the title on purpose from a 1915 film by D. W. Griffith that inspired a new Ku Klux Klan.

**After his three-day revolt, white militias killed more than 100 Black people.**

Nat Turner was an enslaved preacher in Southampton County, Virginia. In jail after the revolt, he told a lawyer, Thomas R. Gray, that "the Spirit" had appeared to him in 1828. It told him that "the first should be last and the last should be first," and that signs in the sky would show him when to begin. When the sun went dark in an eclipse in February 1831, he took it as the sign to "slay my enemies with their own weapons."

Turner and a few other enslaved men began on the night of August 21, 1831. They killed the man who held him, Joseph Travis, and Travis's family as they slept. Then they went on from farm to farm, killing white men, women and children.

More men joined them until they were fifty or sixty, on horseback and armed. They headed for Jerusalem, the town where the county court met. About three miles from the town, armed white men fired on them, and the rebels scattered. By August 23 the rebels had killed at least 55 white people.

Militias and bands of armed white men answered by killing more than 100 Black people. Many of them had nothing to do with the revolt. Some estimates put the number killed at 200.

Turner hid until he was caught on October 30. Judges in Southampton County put about 30 people on trial, and Virginia officials put to death 19 of those found guilty. They hanged Turner on November 11, 1831. Gray published Turner's account that year as *The Confessions of Nat Turner*.

Lawmakers in Virginia and other slave states answered the revolt with new laws against teaching enslaved people to read and against their gathering in groups.

### Sengbe Pieh (Joseph Cinqué)

> **Who:** A Mende man who led the captives of the ship *Amistad* in taking control of it, and who won freedom for them in the United States Supreme Court.
>
> **When and where:** From the Mende country, in the region of Sierra Leone in West Africa. Took the ship on July 1, 1839. Freed by the Supreme Court in 1841. Home in 1842.
>
> **Movie:** *Amistad* (1997), a feature film about the case.

**Fifty-three captives took over the ship that was carrying them.**

Spanish slave traders had carried Sengbe Pieh and the others, most of them Mende people from the region of Sierra Leone, to Cuba. There the 53 were bought for a Cuban plantation and put aboard a sailing ship, the *Amistad*. On July 1, 1839, led by Pieh, they rose up and took control of the ship. Pieh is also known as Joseph Cinqué.

In late August 1839, the U.S. Navy ship *Washington*, commanded by Lieutenant Thomas R. Gedney, seized the *Amistad* off Long Island. Officials took the Africans to New London, Connecticut, and jailed them. Some died at sea or in prison while they waited for trial.

Their lawyers took the case all the way to the Supreme Court, and former president John Quincy Adams argued part of it for them. On March 9, 1841, the justices set them free. In 1842, 35 of the survivors sailed home to Sierra Leone. They had never been enslaved on American soil.

### Solomon Northup

> **Who:** A free man from New York who was kidnapped and held in slavery in Louisiana for twelve years, and who named the people who did it.
>
> **When and where:** Kidnapped in Washington, D.C., in 1841. Freed on January 4, 1853. Where and when he died is not known.
>
> **Movie:** *12 Years a Slave* (2013), directed by Steve McQueen. It won the Academy Award for Best Picture.

**He woke up "alone, in utter darkness, and in chains."**

Solomon Northup was born free in Minerva, New York, in 1808, and worked as a farmer and a fiddler. In 1841 two white men who called themselves Merrill Brown and Abram Hamilton offered him work playing music for a circus. They took him to Washington, D.C. There they gave him a drink that left him "insensible," or unconscious.

He woke in a slave pen, a building where traders locked up enslaved people until they sold them. It was Williams's slave pen, called the Yellow House, near the U.S. Capitol. A slave trader named James H. Burch held him there. When Northup said he was a free man, Burch beat him with a paddle, "a piece of hard-wood board, eighteen or twenty inches long," and with a cat-o'-nine-tails, a whip of rope with many strands, each with a knot tied at the end.

Burch told Northup that if he ever again said he was free, what came next would be worse. "He swore that he would either conquer or kill me."

**Twelve years.** In New Orleans, Burch's partner, a trader named Theophilus Freeman, told Northup that his name was now Platt. Freeman sold him under that name to William Ford, a preacher who owned a lumber mill. In the winter of 1842 Ford sold him to a carpenter, John Tibeats. Then Edwin Epps held him for almost ten years on a cotton plantation on Bayou Boeuf, in Louisiana.

**The letter.** A Canadian carpenter named Samuel Bass mailed letters for Northup to people he knew in Saratoga Springs, New York. Two storekeepers there sent one on to Northup's wife, Anne. She went to Henry B. Northup, a lawyer who had been Solomon's friend since childhood, and whose family had once enslaved Solomon's father, Mintus, and freed him in a will. With help from the governor of New York, Washington Hunt, Henry B. Northup won Solomon's freedom on January 4, 1853.

**No one punished.** That year Northup published *Twelve Years a Slave*, which sold about 30,000 copies. Burch was tried in Washington in 1853 and found not guilty, because the law did not allow Northup, a Black man, to testify against a white man. In May 1857 the New York case against the kidnappers ended without a trial, in a dispute over which court had the power to hear it. No one was ever convicted.

**Not known:** where and when Northup died. After about 1857 he disappears from the records.

**By 1840:** Lawmakers in Virginia and other slave states had answered Nat Turner's revolt with new laws against reading and gathering, the *Amistad* captives were waiting in Connecticut for the Supreme Court, and thousands of enslaved people were escaping north anyway.

### The Underground Railroad and the abolitionists

The Underground Railroad was a network of people who helped enslaved people escape to the free states and to Canada, with guides and safe houses. Free Black communities and their churches did much of the work. By an estimate the National Park Service uses, it helped about 100,000 people escape over several decades. Many more tried to escape and were caught.

In the free states, Black people started their own churches, newspapers and groups. Samuel Cornish and John Russwurm published the first issue of *Freedom's Journal* in New York on March 16, 1827, the first newspaper in the United States owned by Black people. Free Black communities in the North ran vigilance committees, groups that hid people who had escaped and helped them move on.

### Sojourner Truth

> **Who:** A woman who walked away from slavery in New York, then sued to get back her son, who had been sold south against the law, and won.
>
> **When and where:** Ulster County, New York. Walked to freedom in 1826. Won her son's return in 1828. Died in 1883.

**Her five-year-old son was sold to Alabama. She sued and won.**

She was born enslaved in about 1797 in Ulster County, New York, and her name then was Isabella Baumfree. In 1826 she walked away from her enslaver, carrying her baby daughter. One year later, on July 4, 1827, New York's law ending slavery took effect.

Her son Peter was five years old. A little before she walked away, her enslaver, John Dumont, sold the boy for $20 to a doctor, who sold him on to his brother, Solomon Gedney. Solomon Gedney sent Peter to his sister's husband, a planter in Alabama. Selling a child out of the state that way was against New York law. She did not find out for months.

She sued, and in 1828 she won his return. The Historical Society of the New York Courts says she was the first Black woman to win a case of this kind against a white man in an American court.

She took the name Sojourner Truth in 1843. Her life story, the *Narrative of Sojourner Truth*, was published in 1850.

### Harriet Tubman

> **Who:** A woman who escaped slavery in Maryland and went back about 13 times to lead about 70 people out.
>
> **When and where:** Born in Dorchester County, on Maryland's Eastern Shore, in March 1822. Escaped in September 1849. Died in 1913.
>
> **Movie:** *Harriet* (2019), a feature film about her life, with Cynthia Erivo as Tubman.

**At 13 she was hit in the head with a two-pound weight.**

She was born in March 1822 in Dorchester County, on Maryland's Eastern Shore, and her name then was Araminta Ross. In 1835, when she was 13, she was at a store when an enslaved person tried to escape. An overseer threw a two-pound weight. It hit her in the back of the head and broke her skull. For the rest of her life she had pain and "sleeping spells," times when she fell asleep suddenly. The accounts of her injury do not name the overseer.

She escaped to Philadelphia, Pennsylvania, in September 1849. Between 1850 and 1860 she went back into Maryland about 13 times and brought out about 70 people, most of them family and friends, among them her parents, Rit and Ben.

An old story says she made 19 trips and freed 300 people. The National Park Service calls that story a legend. The numbers 13 and 70 come from her own statements and the records.

During the Civil War she worked as a scout for the Union army, the army of the United States. She died of pneumonia in 1913, at about 91 years old, in a home for elderly Black people.

**If you remember one thing:** Cotton planters spread slavery onto land the Choctaw and Chickasaw had been forced to leave, traders sold about a million people south to work it, and enslaved people answered by running, learning to read in secret and rising up.

In 1830: Mississippi had 65,659 enslaved people.

In 1840: it had 195,211, three times as many, on the land the Choctaw and Chickasaw had lost.

**Next:** In 1854 federal troops marched Anthony Burns, a man who had escaped from slavery, through Boston to a ship that took him back to Virginia.

## 1850 to 1900

**Era 7 of 10 · 1850 to 1900 · about 30 minutes**

Slavery ended in this era, and the people it had held spent the rest of the century fighting to keep the freedom they had won. In 1850 the members of Congress passed a law that forced people in the free states to help catch those who escaped.

Fifteen years later, after the Civil War, the 13th Amendment, a change added to the Constitution, forbade slavery, and about four million people became free. Many of them had already freed themselves during the war by escaping to the Union army, the army of the United States.

Freed people searched for family members who had been sold away. They married in law, chose their own names, built churches and schools, voted and served in Congress. White men answered with new laws that forced Black people to work, with whippings and burnings, and with massacres, the killing of many people who could not defend themselves. President Rutherford B. Hayes ordered the last federal troops out of the Southern statehouses in April 1877. That ended the period of rebuilding called Reconstruction.

### The Fugitive Slave Act, 1850

The Fugitive Slave Act, a law about fugitives, people who had escaped, became law on September 18, 1850. Under it, federal officials called commissioners, who worked for the national government, decided whether a captured person was a runaway slave. There was no jury. The captured person was not allowed to testify, to speak as a witness in court.

A commissioner was paid $10 for ruling that a person was a slave and $5 for ruling that the person was free. Officials could force bystanders to help catch people. The law's rules held in the free states too, and free Black people in the North fled to Canada.

**Anthony Burns.** Anthony Burns escaped from slavery in Virginia by stowing away on a ship. Charles F. Suttle, the man who held him in slavery, came to Boston with William Brent to claim him. On May 24, 1854, the two men had Burns arrested there. After a hearing that lasted a week, federal troops marched him through the city on June 2, 1854, to a ship that took him back to Virginia. He passed crowds draped in black, the color of mourning.

### Celia, 1855

A Missouri judge refused in 1855 to tell a jury that an enslaved woman had the right to fight off a man who was raping her. Her name was Celia. Robert Newsom, a farmer in Callaway County, Missouri, bought her in 1850, when she was 14 years old. From 1850 to 1855 he raped her again and again. She had two children, and at least one was his. In 1855 she was pregnant again.

Newsom told Celia on the night of June 23, 1855, that he would come to her cabin. She had put a large stick in the corner. When he came, she struck him on the head with it twice, and the second blow killed him. She burned his body in her fireplace.

**The trial.** Missouri's law made it a crime to force "any woman" into sex against her will, and it allowed a woman to use force to resist. Celia's trial began in October 1855. Her lawyer, John Jameson, asked Judge William Hall to tell the jury that Celia could be found not guilty if she had been resisting rape. Hall refused. That left the jury no way to treat the killing as self-defense.

A jury of twelve white men found her guilty of murder. Her lawyers appealed, asking a higher court to look at the case again. The judges of the Missouri Supreme Court turned the appeal down on December 14, 1855. Celia was hanged in Fulton, Missouri, on December 21, 1855. The accounts of her death do not name the officials who hanged her.

Missouri's governor pardoned her in 2024, at the request of her descendants.

### Dred and Harriet Scott

> **Who:** An enslaved couple who sued for their freedom and lost in the United States Supreme Court, whose justices ruled that no Black American could be a citizen.
>
> **When and where:** Suit filed in St. Louis, Missouri, in 1846. Supreme Court decision on March 6, 1857. Freed in May 1857.

**A chief justice wrote that Black Americans could never be citizens.**

Dred Scott was born enslaved in Virginia in about 1800. Peter and Elizabeth Taylor Blow held him. The Blows moved to St. Louis in 1830 and sold him to Dr. John Emerson, an army surgeon.

Emerson took Scott to Fort Armstrong, in Illinois, in 1833, and then to Fort Snelling, in Wisconsin Territory, in 1836. Slavery was banned in both places. At Fort Snelling, Dred Scott married Harriet Robinson, who was also enslaved. They had two daughters, Eliza and Lizzie. Eliza was born on a steamboat in free waters. After Emerson died in 1843, his widow, Irene Emerson, claimed the family as her property.

**Eleven years in court.** The Scotts sued for their freedom in St. Louis on April 6, 1846. They argued that living where slavery was banned had made them free. A jury ruled in their favor on January 12, 1850. The judges of the Missouri Supreme Court reversed that ruling on March 22, 1852, and Irene Emerson held the Scotts as her property again.

The Scotts and their lawyers took the case to the United States Supreme Court. On March 6, 1857, the justices ruled against them, 7 votes to 2. Chief Justice Roger Taney wrote that Black Americans were not and could never be citizens, and that Black people "had no rights which the white man was bound to respect." The justices also ruled that Congress could not ban slavery in the territories of the West.

**Freedom.** Irene Emerson's second husband, Calvin Chaffee, handed ownership of the family to Taylor Blow, who freed them on May 26, 1857. Dred Scott worked as a porter, a man who carried guests' bags, at Barnum's Hotel in St. Louis, and he helped Harriet with her laundry work. He died of tuberculosis, a disease of the lungs, on September 17, 1858.

### Sold and smuggled, 1858 to 1860

Pierce Mease Butler sold between 429 and 436 men, women and children at a racetrack near Savannah, Georgia, on March 2 and 3, 1859, to pay his gambling debts. The National Park Service describes it as the largest single sale of people in the United States. The slave dealer Joseph Bryan ran it and advertised it for weeks in newspapers from Charleston to Richmond. The sale brought in $303,850.

A reporter from the *New York Tribune*, Mortimer Thomson, went disguised as a buyer. He wrote a long article about the sale for the *Tribune*, "What Became of the Slaves on a Georgia Plantation?" Black Georgians remembered those two days as "the weeping time."

**The *Wanderer*.** Bringing captives from Africa had been against the law since 1808, but some men kept doing it. In 1858 Charles A. L. Lamar led a group of investors who paid for a ship called the *Wanderer* to bring captives from Africa. Its captain, William R. Corrie, bought 487 Africans at the Congo River. About 409 of them were still alive when the ship landed at Jekyll Island, Georgia, on November 29, 1858. The others died on the voyage. Six trials followed, and none of them ended in a conviction.

**The *Clotilda*.** Timothy Meaher, a businessman and shipbuilder in Mobile, Alabama, bet in 1860 that he could sneak a ship full of captives into Mobile Bay. Captain William Foster sailed the ship *Clotilda* to West Africa. He bought 125 people and carried 110 of them across the ocean. On July 8, 1860, the ship entered the Gulf of Mexico. Later that month Foster anchored it near Twelve-Mile Island and set it on fire to destroy the evidence. The only punishment anyone received was a $1,000 fine charged to Foster.

### Oluale Kossola (Cudjo Lewis)

> **Who:** A man carried to Alabama on the *Clotilda*, the last known slave ship to reach the United States, who helped found the town of Africatown after he was freed.
>
> **When and where:** Born about 1841 in what is now Benin, in West Africa. Landed near Mobile, Alabama, in July 1860. Freed in 1865. Died in 1935.
>
> **Movie:** *Descendant* (2022), a documentary by Margaret Brown about the *Clotilda*, Africatown and the families of the survivors.

**The crossing took 45 days. He was one of 110 aboard.**

Oluale Kossola was born in about 1841 in what is now the country of Benin, among the Yoruba Isha people. The army of Ghezo, the King of Dahomey, attacked his town in April 1860. Kossola was captured and held in a barracoon, a pen for captives, at the port of Ouidah. There he was sold to William Foster, the *Clotilda*'s captain. The crossing to Alabama took 45 days, and Kossola suffered from terrible thirst.

In Mobile, James Meaher, Timothy Meaher's brother, enslaved him. Kossola worked on a steamship and lived with others from the *Clotilda* under Meaher's house, which stood high off the ground. He was freed in 1865. He took the name Cudjo Lewis and married Abile, a woman who had also been on the *Clotilda*.

**Africatown.** The people from the *Clotilda* could not afford to sail home. Timothy Meaher was responsible for what had been done to them, so they decided to ask him to give them land, free. They chose Kossola to speak for them. Meaher refused. So they bought land from him and from others, and about 30 of them founded Africatown, north of Mobile.

Kossola and Abile had six children, and all six died young. In 1902 he was hurt in a train accident and sued the railroad company. He became the caretaker of the Africatown church.

The writer Zora Neale Hurston interviewed him in 1927. Her book about his life, *Barracoon*, was not published until 2018. Kossola died on July 26, 1935, at about 94. In May 2019 officials of the Alabama Historical Commission announced that the burned wreck of the *Clotilda* had been identified in the Mobile River.

**By 1861:** The justices of the Supreme Court had ruled that no Black American could be a citizen, the *Clotilda* had landed its captives near Mobile, and Southern states had broken away from the United States.

### Freedom taken during the war

Three enslaved men, Frank Baker, Shepard Mallory and James Townsend, rowed to Fort Monroe, a Union fort at Old Point Comfort in Virginia, on May 23 and 24, 1861. It was the same ground where the *White Lion* had landed Africans in 1619. The men were about to be taken south to build batteries, gun positions, for the Confederate army, the army of the Southern states that had broken away.

General Benjamin Butler refused to send them back. He called them "contraband of war," meaning property of the enemy that an army may seize. Word spread, and enslaved people walked, rowed and rode to Union lines across the South. By the end of the war, about half a million people had freed themselves by reaching the Union army. The people who escaped to Fort Monroe called it "Freedom's Fortress."

**The camps.** Union army officials, and later officials of the Freedmen's Bureau, the federal office set up to help freed people, ran camps for people who had escaped slavery. These were called contraband camps, and they were crowded and dirty.

More than 60,000 freed people died of smallpox between 1862 and 1868, according to the historian Jim Downs. Smallpox is a disease caused by a virus that spreads from person to person. It brings a fever and a rash that spreads over the skin and turns to scabs. About 3 in every 10 people who caught it died, and many who lived had scars for life, most of all on their faces.

Doctors knew how to prevent it. They could vaccinate people by scratching fluid from the sores of cowpox, a mild disease of cows, into the skin. They could also keep the sick away from the well, which is called quarantine. The quarantine tents for freed people were made of old, ripped army cloth.

**Philip Reid.** Philip Reid was an enslaved craftsman at the foundry of Clark Mills in Washington, D.C., a workshop where metal is melted and cast. Mills owned him. Mills's workers were casting the Statue of Freedom for the top of the Capitol dome. The paid foreman demanded more money before he would take apart the plaster model, and Reid worked out how to separate it with a pulley and tackle. He was paid $1.25 a day, but he kept only the pay for Sundays. Mills took the rest.

Members of Congress passed a law that freed the enslaved people of Washington, D.C., on April 16, 1862, and Reid was one of them. The government of the District of Columbia counts 3,100 people freed there, and the US Senate's history office counts 2,989. Under the law, owners loyal to the Union could be paid up to $300 for each person freed. The statue was set on the dome on December 2, 1863. In his later life Reid signed his name Reed.

### Robert Smalls

> **Who:** An enslaved harbor pilot who sailed himself, his family and his crew out of slavery on a Confederate ship, and later served five terms in Congress.
>
> **When and where:** Charleston, South Carolina, before dawn on May 13, 1862. Later Beaufort, South Carolina. Died in 1915.

**He wore the captain's straw hat and sailed past Fort Sumter.**

Robert Smalls was 23 years old and enslaved. He worked as the pilot, the man who steered the ship, on a Confederate transport ship called the *Planter*, in Charleston harbor.

Before dawn on May 13, 1862, Smalls took the *Planter* out with an enslaved crew and their families aboard. He wore the captain's hat and gave the right signals as they passed Fort Sumter. Out at sea he surrendered the ship to the Union navy ships that were blockading, or closing off, the harbor.

Smalls went on to become a ship's captain in United States service. After the war he served as one of South Carolina's state lawmakers. He was elected to the United States House of Representatives five times. He died in 1915.

### Who did the Emancipation Proclamation free?

President Abraham Lincoln's Emancipation Proclamation declared free the enslaved people in the states that were fighting against the United States. Emancipation means setting people free from slavery. Lincoln announced it on September 22, 1862, and it took effect on January 1, 1863. Wherever the Union army advanced after that, its soldiers freed the enslaved people they reached. In the proclamation, Lincoln also opened the army to Black men.

Lincoln left out the slave states that had stayed loyal to the Union: Delaware, Maryland, Kentucky and Missouri. He also left out Tennessee and the parts of Virginia and Louisiana that the Union army already held. Enslaved people in those places had to wait for their state's lawmakers to end slavery, or for the 13th Amendment.

### Black soldiers and the scourged back

About 180,000 Black men served in the Union army in the regiments called the U.S. Colored Troops. By the end of the war, about one Union soldier in ten was Black. About 19,000 more Black men served in the navy. At the Battle of New Market Heights in Virginia, on September 29, 1864, fourteen Black soldiers earned the Medal of Honor, the highest award for bravery in battle.

**Peter.** A man named Peter escaped in March 1863 from the 3,000-acre plantation of Captain John Lyons in St. Landry Parish, Louisiana, and reached Union troops at Baton Rouge. Army doctors examined him before he joined the army. His back was covered in thick raised scars, called keloid scars, which grow over a healed wound.

Peter said the overseer, Artayou Carrier, had whipped him in October 1862. He said he lay in bed for two months, sore "from the whipping and salt brine" that was poured on the wounds. The accounts do not say who poured it.

The photographers William D. McPherson and J. Oliver photographed his back about April 2, 1863. The picture became known as "The Scourged Back," scourged meaning whipped. *Harper's Weekly* printed pictures made from the photograph on July 4, 1863, and called the man "Gordon." Historians now think the magazine's staff put "Gordon" together from pictures of three different men, and that the man in this photograph was Peter. No record shows what became of Peter after he joined the Union army.

### William Harvey Carney

> **Who:** A man born enslaved in Virginia who carried the flag at Fort Wagner with the 54th Massachusetts, a Black regiment. His actions there were the earliest act of bravery by a Black American to be recognized with the Medal of Honor.
>
> **When and where:** Born in Norfolk, Virginia, on February 29, 1840. Fort Wagner, South Carolina, July 18, 1863. Died on December 9, 1908.

**"The dear old flag never touched the ground!"**

William Harvey Carney was born enslaved in Norfolk, Virginia, on February 29, 1840. Accounts differ about how he became free. Some say he escaped on the Underground Railroad. Others say his father escaped and then bought his freedom. The family settled in New Bedford, Massachusetts.

Carney joined Company C of the 54th Massachusetts, a regiment of Black soldiers, in February 1863, and he became a sergeant in March. On July 18, 1863, the 54th attacked Fort Wagner, in South Carolina. The soldier carrying the flag was shot.

Carney took the flag and went forward with several serious wounds. He planted it on the wall of the fort and then carried it back to the Union lines. The National Park Service quotes his words afterward: "Boys, I did but my duty," and then, "the dear old flag never touched the ground!" The attack appears in the film *Glory* (1989), which is about the 54th Massachusetts.

He received the Medal of Honor in May 1900. The National Park Service says his actions were "the earliest act of African American bravery to be recognized with the medal." He was one of 22 African Americans to receive it for service in the Civil War. He died at Boston City Hospital on December 9, 1908.

### Combahee Ferry, the 13th Amendment and Juneteenth

Harriet Tubman guided Union gunboats and soldiers of the 2nd South Carolina Volunteers up the Combahee River in South Carolina on the night of June 2, 1863. More than 700 enslaved people escaped to freedom on the boats that night.

**The 13th Amendment.** The members of Congress passed the 13th Amendment on January 31, 1865. It became part of the Constitution on December 6, 1865, when lawmakers in enough states had approved it. Its text forbids slavery everywhere in the United States, "except as a punishment for crime whereof the party shall have been duly convicted." That exception still allowed forced labor for people convicted of crimes.

**Juneteenth.** Major General Gordon Granger arrived in Galveston, Texas, on June 19, 1865, with about 2,000 federal soldiers. He issued General Order No. 3. It said that "all slaves are free," with "absolute equality of personal rights." More than 250,000 people were still enslaved in Texas, two and a half years after the Emancipation Proclamation, because the Union army had not been there to enforce it. June 19 became a day of celebration, called Juneteenth.

### Slavery in the Five Tribes

Slaveholders in the Choctaw and Chickasaw nations, the nations that United States officials forced west to Indian Territory in the 1830s, had also held Black people in slavery. So had slaveholders in the Cherokee, Muscogee (Creek) and Seminole nations. Together these five nations were known as the Five Tribes. At emancipation as many as 2,500 people were enslaved in the Cherokee Nation.

The leaders of each of these nations signed treaties with the United States in 1866. In them the leaders agreed to free the people held in slavery in their nations and to make them citizens of the nation. In Article 9 of the Cherokee treaty, Cherokee leaders promised the freed people, called Freedmen, "all the rights of native Cherokees."

**By 1866:** Slavery was illegal everywhere in the United States, about four million people were free, and Union soldiers had announced freedom as far away as Galveston, Texas.

### Freedom, day to day

For decades after slavery ended, freed people searched for family members who had been sold away. They placed advertisements in Black newspapers, under headings such as "Information Wanted," asking for news of mothers, children, husbands and wives. The searches ran into the 1900s. Few ended in a reunion, and when one did, people wrote about it with joy.

Researchers at Villanova University and Mother Bethel AME Church in Philadelphia, in a project called "Last Seen: Finding Family After Slavery," have put more than 5,000 of these ads online.

**Marriages and names.** Enslaved people's marriages had never counted in law. After the war, officers of the Freedmen's Bureau recorded thousands of marriages. Couples who had been together for decades stood up to be married in law. The Bureau's marriage registers survive at the National Archives.

Freed people chose and registered their own last names. Some kept a former owner's name, so that family members who had been sold away could find them. Others chose new names. Freeman was one.

**Churches.** Congregations that had met in hush harbors built their own churches. Within ten years of the war, freed people had joined or founded AME and AME Zion churches across the South. They used their churches as schools, as meeting halls and as places to organize for elections.

**The bank.** Members of Congress set up the Freedman's Savings Bank by law to hold the savings of freed people, and President Lincoln signed the law on March 3, 1865. The bank's managers ran it badly and lost money on risky deals. It failed in June 1874, holding nearly $3 million saved by about 61,000 people.

The officials in charge of closing the bank, called commissioners, paid back 62 percent of what was owed between 1875 and 1883. Only about 30,000 depositors turned in their bank books to collect, and about 31,000 never got anything back.

### Thornton Copeland

> **Who:** A freed man who placed a newspaper advertisement in 1865 searching for his mother, from whom he had been sold away 21 years earlier.
>
> **When and where:** The *Colored Tennessean*, a newspaper in Nashville, Tennessee, October 1865. He had been sold in Richmond, Virginia, in 1844.

**He had not seen his mother in 21 years.**

Thornton Copeland was sold away from his mother in 1844. The buyer was Samuel Copeland, in Richmond, Virginia. The ad does not say who sold him. Before that, a man named Robert Rogers had held him.

In October 1865, after slavery ended, he placed an advertisement in the *Colored Tennessean*, a Black newspaper in Nashville, to look for her. Her name was Betty. His advertisement reads: "INFORMATION is wanted of my mother, whom I left in Fauquier county, Va., in 1844, and I was sold in Richmond, Va., to Saml. Copeland."

His advertisement is item 918 in the "Last Seen" collection. No record shows whether he ever found his mother.

### Schools, the moment freedom came

People who had been forbidden to read started schools as soon as the Union lines reached them. They opened schools in churches, in army camps and in buildings the Union army had taken over. Grandparents and grandchildren learned in the same rooms. Grown men and women came to night classes after a full day's work.

**Who paid.** Freed people paid for schools themselves wherever they could. They paid school fees out of their first wages, and they gave land and their own labor to build schoolhouses. Northern aid societies helped, the American Missionary Association most of all. Thousands of teachers came south, many of them women, and a growing number of them Black.

Freedmen's Bureau officials had counted more than 2,600 day and night schools with about 150,000 students by 1870. Counts that include every kind of school are higher.

New colleges opened for freed people. Fisk, in Nashville, opened in January 1866. Members of Congress passed a law that set up Howard University in 1867. By 1872 there were about 25 colleges for freed people.

Delegates in the Southern states wrote new state constitutions in 1868 and 1869. Their conventions were the first public bodies in United States history with many Black members. The delegates created the South's first statewide systems of free public schools, open to white children too.

### Susie King Taylor

> **Who:** A girl who learned to read in secret schools in Savannah, escaped at 13, and became the first Black teacher of freed children in a school working openly in Georgia.
>
> **When and where:** Born in Liberty County, Georgia, on August 6, 1848. Taught on St. Simons Island, Georgia, in 1862. Died in 1912.

**At 14 she taught 40 children by day and adults at night.**

As a child in Savannah, Georgia, Susie King Taylor went to two secret schools run by Black women. Two white young people also taught her, breaking the law to do it.

In April 1862, at 13, she escaped with others to St. Simons Island, which the Union army held. She turned 14 that August. There she became the first Black teacher of freed students in a school for freed people working openly in Georgia. She taught about 40 children by day and grown people at night, until the Union army moved everyone off the island in October 1862.

She married Edward King, a Black noncommissioned officer, a soldier who had risen through the ranks to lead other soldiers. She served with the 33rd U.S. Colored Troops as a nurse and laundress, and she taught soldiers to read. In 1902 she published a book about those years, *Reminiscences of My Life in Camp*. She died in 1912.

### Memphis and New Orleans, 1866

White mobs in Memphis, Tennessee, attacked the city's Black neighborhoods in early May 1866. The mobs included city policemen, firemen and some businessmen. The attacks began after a clash between the police and Black Union soldiers who had just left the army. General George Stoneman had taken the soldiers' guns away. The mobs killed 46 Black people. Two white people also died.

Members of Congress formed a committee to look into the killings. Its members counted 75 people injured, 100 robbed and five women raped. The mobs burned 91 homes, 4 churches and 8 schools, every Black church and school in the city. No one was ever punished for the killings, as far as the records show.

**Frances Thompson.** Frances Thompson testified to the committee. She said that on May 1, 1866, seven white men broke into her home and raped her and her roommate, 16-year-old Lucy Smith. Accounts of her testimony differ on whether two or three of the men were police officers. The men also stole about $300.

Memphis police arrested Thompson in July 1876 for wearing women's clothing. Dr. Joseph Nuttall, who worked for the city, and three other doctors examined her body against her will and declared that she was a man. She could not pay the fine, and she was sentenced to 100 days on the chain gang, a crew of prisoners chained together and forced to work, cleaning streets.

Her opponents used the arrest to attack her testimony about the rapes. She died of dysentery, a disease of the gut, in the city hospital on November 1, 1876.

**New Orleans.** The men who wrote Louisiana's constitution of 1864 ended slavery in the state but did not give Black men the vote. In 1866 Republicans who wanted Black men to vote called these delegates back together to change the constitution. Mayor John T. Monroe declared the meeting unlawful and asked the army for help arresting the delegates.

The delegates met anyway, at the Mechanics' Institute in New Orleans, on July 30, 1866. About 200 unarmed Black men, most of them Union veterans, marched in support.

Sheriff Harry T. Hays had given police powers to many men, a lot of them former Confederate soldiers. These police attacked, with white mobs and firemen. By the National Park Service's count, they killed 34 Black people and wounded 119, and they killed 3 white delegates and wounded 17. The official report records higher totals: 38 killed and 146 wounded in all. General Philip Sheridan called it "an absolute massacre by the police."

**By 1868:** Under the 14th Amendment, Black Americans born in the United States were citizens, and white mobs and police had killed dozens of Black people in Memphis and New Orleans.

### Black political power

The 15th Amendment became part of the Constitution on February 3, 1870. It states that the right to vote "shall not be denied or abridged by the United States or by any State on account of race, color, or previous condition of servitude," where abridged means cut down and servitude means slavery.

In the ten years that followed, 16 Black men served in Congress, 14 in the House and 2 in the Senate. All of them were Republicans from the South. Joseph Rainey of South Carolina became the first Black member of the House of Representatives on December 12, 1870. Robert Smalls served five terms in the House.

Across the South, about 2,000 Black men held public office during Reconstruction, some elected and some appointed. The historian Eric Foner has found more than 1,500 of them by name and listed them in his book *Freedom's Lawmakers*.

### Hiram Revels and Blanche K. Bruce

> **Who:** The first two Black United States senators. Revels was the first to serve. Bruce, born enslaved, was the first to serve a full six-year term.
>
> **When and where:** Both represented Mississippi. Revels served from 1870 to 1871. Bruce served from 1875 to 1881.

**Senators argued he had not been a citizen long enough.**

Hiram Revels was born free in Fayetteville, North Carolina. He was a minister in the African Methodist Episcopal Church and a teacher. During the Civil War he served as a chaplain, a minister to soldiers, for Black regiments. In 1869 he won a seat in the Mississippi state senate.

Mississippi's state lawmakers voted 85 to 15 on January 20, 1870, to send him to the United States Senate. Democrats in the Senate argued against seating him. Some said he had not been a citizen until the 14th Amendment was adopted in 1868, so he had not been a citizen long enough to serve. The senators voted 48 to 8 to seat him, and on February 25, 1870, he became the first Black United States senator.

Revels served until March 3, 1871. That year he became the first president of Alcorn University. He died in 1901.

**Blanche K. Bruce.** Bruce was born enslaved near Farmville, Virginia, and Pettus Perkinson held him in slavery. When the Civil War began, Bruce escaped to Lawrence, Kansas, where he taught school. After the war he moved to Mississippi, where he was a sheriff and a tax collector in Bolivar County and the county's superintendent of education.

He was elected to the Senate on February 4, 1874. He served from March 4, 1875, to March 3, 1881, the first Black senator to serve a full term. Later he served as Register of the Treasury, an office in the federal government. He died in Washington, D.C., in 1898.

### The promises broken

Within a year of the war's end, President Andrew Johnson and Southern lawmakers had taken back much of what freed people had been promised. Johnson had become president in April 1865, when John Wilkes Booth shot and killed President Lincoln.

**Forty acres.** Union general William T. Sherman issued Special Field Orders No. 15 on January 16, 1865. In it, Sherman set aside about 400,000 acres of coastal land, from Charleston to northern Florida, for freed families in plots of forty acres. About 40,000 people settled on the land. In the fall of 1865, President Andrew Johnson reversed the order and gave the land back to its former owners. The phrase "forty acres and a mule" comes from this broken promise.

**The Black Codes.** Mississippi's lawmakers passed the first Black Codes in November 1865, and lawmakers in other Southern states followed. Under the new vagrancy laws, which made it a crime to have no job or home, officials could arrest a Black person who could not prove he had a job. Under apprenticeship laws, officials could force Black children to work for white employers. Other laws required licenses to work in certain jobs. Officials hired out the people they arrested under these laws to work for others.

**Citizens.** The members of Congress answered with the Civil Rights Act of 1866. President Johnson refused to sign it, and they made it law anyway on April 9, 1866. Under it, people born in the United States were citizens, except Native people who paid no taxes. Black citizens had the same right as white citizens to make contracts, go to court and own property.

The members of Congress also approved the 14th Amendment, which became part of the Constitution on July 9, 1868. It states that people born in the United States are citizens, and that no state may deny any person "the equal protection of the laws," the same protection the laws give everyone else.

**Sharecropping.** Without land of their own, many freed families became sharecroppers. A sharecropper farmed a landlord's fields in exchange for a share of the crop. The landlord lent the family tools, seed and food, charged at the plantation store's prices, and took the cost out of the family's share. The debt carried over from year to year, and families could not leave the land until it was paid.

### Convict leasing

The 13th Amendment allowed forced labor as a punishment for crime, and Southern officials used that exception. Sheriffs arrested Black men, often for vagrancy or small crimes under the new codes, and county judges sentenced them. State officials then leased the prisoners, or rented them out, to planters, mine owners and railroads. The prisoners worked without pay. This was called convict leasing.

**Alabama.** Alabama officials leased the state's prisoners to companies from 1875 to 1928. State officials signed the leases, and company managers ran the prison camps. Officials sent most of the prisoners to coal mines run by companies such as the Tennessee Coal, Iron and Railroad Company, Sloss Iron and Steel, and Pratt Coal and Iron.

More than 95 percent of the county prisoners and 90 percent of the state prisoners were Black. In one count from the 1890s, 181 of 745 county prisoners in the mines died within two years, about one in four. County prisoners also had to work off their court costs, which made their sentences longer. In 1912 Alabama's state government took in more than $1 million from prison mining.

### Terror

Confederate veterans founded the Ku Klux Klan in Pulaski, Tennessee, in December 1865. Klansmen, armed and in disguise, whipped freed people and the white people who worked with them, burned their homes and murdered them. They attacked mostly at night.

**Schools and teachers.** Klansmen went after schools and teachers. In late 1869, at Greensboro, Georgia, they drove away a teacher named R. H. Gladding. Abram Colby, a Black man, had just been elected to Georgia's state lawmaking body, and he supported the school. Klansmen took him out of his house and beat him nearly to death.

In Alabama, Klansmen burned many Black schools and churches. On July 11, 1870, at Cross Plains, Alabama, they killed a teacher of freed people, William Luke, a preacher from Ontario in Canada. Accounts say six or eight people were killed there.

Under the Enforcement Acts of 1870 and 1871, federal officials broke up the Klan for a time.

**Colfax, 1873.** White men carried out a massacre at Colfax, Louisiana, on Easter Sunday, April 13, 1873. The historian Eric Foner calls it the bloodiest single act of racial violence in Reconstruction. After a disputed election, Black militiamen and Republicans held the courthouse of Grant Parish, a parish being what other states call a county.

Christopher Columbus Nash, who claimed to be the sheriff, led more than 150 armed white men against them. Other accounts say about 300. The attackers fired a small cannon, set the courthouse on fire and shot the men who came out. That night some of the attackers killed their prisoners, most of them with shots to the head. Estimates of the number of Black men killed run from about 60 to 153. Two white men died.

A jury found three of the attackers guilty of conspiracy, planning a crime together. On March 27, 1876, in the case *United States v. Cruikshank*, the justices of the Supreme Court threw out the convictions. They ruled that the rights at stake protected people only against actions by governments, not against private men. No one was ever punished for the killings.

Louisiana officials put up a marker in 1950 calling it a riot in which "three white men and 150 Negroes were slain." It was taken down in 2021.

### The end of Reconstruction, 1877

The presidential election of 1876 ended in dispute. Five senators, five representatives and five Supreme Court justices decided it. They voted 8 to 7, Republicans against Democrats, to give the Republican, Rutherford B. Hayes, every disputed vote.

Democrats in Congress then stopped blocking the count. In return, Republicans agreed to end the army's control over the South. No written copy of this deal has ever been found. It is called the Compromise of 1877.

President Hayes then ordered the last federal troops out of the Southern statehouses. The last ones left the Louisiana statehouse in New Orleans on April 24, 1877. The 13th, 14th and 15th Amendments stayed in the Constitution, but federal officials stopped enforcing them in the South.

**Plessy.** The justices of the Supreme Court ruled 7 to 1 in *Plessy v. Ferguson*, on May 18, 1896, that states could keep Black and white people separate by law, under the rule known as "separate but equal." Justice Harlan was the only one to disagree. With that ruling, the justices upheld the segregation laws, laws separating people by race, that Southern lawmakers had already passed.

**If you remember one thing:** Hundreds of thousands of enslaved people freed themselves during the war, the 13th Amendment ended slavery in 1865, and within twelve years white lawmakers, mobs and judges had taken back much of what freedom had promised.

- January 1, 1863: Lincoln's Emancipation Proclamation takes effect.
- December 6, 1865: The 13th Amendment becomes part of the Constitution.
- April 24, 1877: The last federal troops leave the Louisiana statehouse.

**Next:** Sheriffs, judges and mine owners kept Black people working without pay well into the 1900s, and white mobs lynched thousands of Black people, killing them with no trial.

## 1900 to 1950

**Era 8 of 10 · 1900 to 1950 · about 7 minutes**

Southern lawmakers, sheriffs, judges and company managers spent the first half of the 1900s running a system that took slavery's place. Lawmakers passed laws that kept Black and white people apart, and they took the vote from most Black men. Sheriffs arrested Black men for small crimes, judges sentenced them, and state officials rented them to mine companies, whose managers worked them without pay. White mobs lynched Black people by the thousands. Researchers at the Equal Justice Initiative have counted more than 4,400 such killings between 1877 and 1950.

The people who had been born into slavery were old by the 1930s. Writers paid by the federal government wrote down the life stories of more than 2,300 of them between 1936 and 1938.

### Segregation and the stolen vote

**Jim Crow.** The justices' 1896 ruling in *Plessy v. Ferguson*, told at the end of the last era, let states keep Black and white people apart by law. Lawmakers across the South then passed laws that kept them apart in schools, railroad cars, waiting rooms, courtrooms and cemeteries, and at water fountains. This segregation, the separating of people by race, was written into what people called the Jim Crow laws.

**The stolen vote.** Southern lawmakers also took the vote from most Black men. The men who wrote Mississippi's constitution of 1890, the state's set of basic laws, set the pattern with three rules for voters. One was a poll tax, a fee a man had to pay before he could vote. Another was a literacy test, a reading test.

The third was the understanding clause, and it let one local officer decide who passed. Under it, a man had to be able to read any part of the state constitution. A man who could not read could still sign up to vote if the officer judged that he understood a part read aloud to him, or gave "a reasonable interpretation" of it.

**Henry Williams.** In Mississippi only qualified voters could sit on a jury, and officials made their jury lists from the books of registered voters. So the same rules that kept Black men from voting kept them off juries. An all-white jury found Henry Williams, a Black man, guilty of murder, and the judge sentenced him to be hanged.

Williams's lawyer took the case to the Supreme Court. In 1898 he told the justices that the officer who signed up voters was "the sole judge" of each test, so the officer could turn away any man he chose. The justices ruled against Williams.

Much later, in a 1965 case about the same rules, lawyers for the United States government told the Supreme Court that Black men had once been more than half of Mississippi's qualified voters. By 1899 they were about 9 percent.

**The grandfather clause.** The men who wrote Louisiana's new constitution added a grandfather clause in 1898. It let a man vote if his father or grandfather had voted before January 1, 1867. At that time most Black Southerners had been enslaved, so the clause let white men who could not pass the tests vote anyway.

Louisiana had about 130,000 registered Black voters in 1896. By 1900 there were 5,320. By 1904, by the count of Equal Justice Initiative researchers, there were about 1,000.

### Lynching

Researchers at the Equal Justice Initiative have documented more than 4,400 lynchings, killings by a mob with no trial, of Black people carried out as racial terror between 1877 and 1950. Other counts, which use different years and different rules for what counts, give different totals. Mobs hanged people and shot them.

**Ed Johnson.** An all-white jury in Chattanooga, Tennessee, found a Black man named Ed Johnson guilty of rape in 1906, though about a dozen witnesses said he was somewhere else. His lawyers asked the Supreme Court to look at the case again, and the justices stopped his execution while they did.

That night the sheriff, Joseph F. Shipp, took away the jail's usual guard and left only the night jailer. A mob broke into the jail, took Johnson to a bridge over the Tennessee River, hanged him from a beam and shot him. In 2000 a Tennessee judge threw out the guilty verdict.

White mobs used lynching to frighten Black people into staying in low-paid work and into obeying white Southerners. Black Southerners left the South to get away from the terror, in a movement known as the Great Migration.

### Forced labor after slavery

Sheriffs, judges, state officials and company managers kept Black people working without pay well into the 1900s, through convict leasing and debt peonage. Under convict leasing, state officials rented prisoners out to companies, and company managers worked them without wages. Debt peonage meant forcing a person to work to pay off a debt.

Douglas Blackmon told this history in his book *Slavery by Another Name*, which won the Pulitzer Prize, one of the top American prizes for writing. In 2012 PBS showed a film made from the book.

**The mines.** Alabama's convict leasing, told in the last era, went on until 1928. In 1911, 123 Black county prisoners whom officials had leased to the Banner Mine were killed in an explosion there.

A prisoner named James Knox, from Mobile, died at the Flat Top mine in 1924. The first report of his death stated that he had killed himself by swallowing poison. An autopsy, an examination of the body after death, showed something else, according to a City of Birmingham article. He had died of heart failure, and the poison had been put into his body with a needle after he was dead.

The same article states that the injuries that killed him came from being whipped with a steel wire and lowered into hot water. The historian Mary Ellen Curtin writes that he was tortured by being lowered into a vat, a large tub, of boiling water.

Both accounts state that Knox was tortured to death, and they differ only on whether the water was hot or boiling. Neither account names who whipped him and put him in the water, who put in the poison, or who first called his death a suicide.

Alabama officials ended convict leasing on June 30, 1928. Alabama was the last state to end it.

**Alonzo Bailey.** Alonzo Bailey, a farm worker in Alabama, signed on to work for the Riverside Company for $12 a month and took $15 in advance, paid before the work was done. After about a month he left. Under Alabama law, leaving a job after taking an advance was a crime, and the law barred him from telling the court why he had left. He was fined $30 and sentenced to 136 days of hard labor.

Booker T. Washington secretly helped pay for Bailey's lawyers. On January 3, 1911, in *Bailey v. Alabama*, the justices of the Supreme Court ruled 7 to 2 that the law broke the 13th Amendment, the part of the Constitution, added in 1865, that forbids slavery.

Lawmakers in other Southern states kept laws like it for decades. The justices struck down Georgia's law in 1942 and Florida's in 1944.

### The last voices

Federal officials running the Federal Writers' Project, a government program that gave jobs to writers, sent interviewers to talk with people who had been born into slavery. Between 1936 and 1938 the interviewers worked in 17 states, wrote down more than 2,300 life stories and took 500 photographs. The Library of Congress keeps them in a collection called "Born in Slavery."

The Library of Congress also keeps sound recordings of people who were born into slavery, made between 1932 and 1975. The collection is called "Voices Remembering Slavery."

### Fountain Hughes

> **Who:** A man born into slavery in Virginia, one of the few people born enslaved whose own voice survives on a recording.
>
> **When and where:** Born in Charlottesville, Virginia. Recorded by the Library of Congress in Baltimore, Maryland, on June 11, 1949.

**"They'd sell us like they sell horses and cows and hogs."**

Hermond Norwood of the Library of Congress interviewed Fountain Hughes in Baltimore on June 11, 1949, and the recording still exists. Hughes began: "My name is Fountain Hughes. I was born in Charlottesville, Virginia."

His grandfather, Wormley Hughes, was the enslaved head gardener at Monticello, Thomas Jefferson's plantation. Fountain Hughes said his father "got killed in the Army," and that left the children "to live on whatever people choose to give us."

He was never sold, he said, because "I was too young to sell." But he described how others were sold: "They'd sell us like they sell horses and cows and hogs and all like that. Have an auction bench, and they'd put you on up on the bench and bid on you."

He could not go anywhere without his enslaver's permission: "I couldn't go from here across the street, or I couldn't go through nobody's house without I have a note or something from my master." He said of being enslaved: "You're nothing but a dog. You're not a thing but a dog!"

**Not known:** the year he was born. He said he was 101 years old, which would mean about 1848. Some reference books give 1854, and other accounts argue for a later year.

## 1950 to 2000

**Era 9 of 10 · 1950 to 2000 · about 3 minutes**

Federal judges and lawmakers began to enforce the promises of the Civil War amendments in these fifty years, almost a hundred years after they were written.

The 14th and 15th Amendments, described in the 1850 to 1900 era, are changes added to the Constitution in 1868 and 1870. The 14th states that no state may deny any person "the equal protection of the laws," the same protection the laws give everyone else. Under the 15th, no one may be kept from voting because of race. For almost a hundred years, federal officials did not enforce them in the South.

The justices of the Supreme Court ruled in 1954 that public schools kept separate by race were against the Constitution. Members of Congress passed two laws in 1964 and 1965 that gave federal officials the power to enforce the amendments. After Alex Haley's book *Roots* came out in 1976 and ABC showed it on television in 1977, many Black families began tracing their ancestors back to slavery.

### The amendments enforced

The justices of the Supreme Court all agreed in *Brown v. Board of Education*, on May 17, 1954, that "separate educational facilities are inherently unequal," unequal by their very nature. With that ruling, the justices threw out the "separate but equal" rule of *Plessy v. Ferguson* for public schools.

**Two laws.** The Civil Rights Act became law on July 2, 1964, and the Voting Rights Act on August 6, 1965. Under the Civil Rights Act, hotels, restaurants and other places open to the public could no longer turn people away or keep them apart because of race, and employers could no longer refuse people jobs because of race. Under the Voting Rights Act, no state or county could use any rule to keep a citizen from voting because of race.

With these laws, the members of Congress who voted for them gave federal officials the power to enforce the 14th and 15th Amendments. They came about a hundred years after the 13th Amendment forbade slavery.

**Mississippi, 1995.** Mississippi's state lawmakers voted in 1995 to approve the 13th Amendment, 130 years after it became part of the Constitution. No one filed the paperwork that would have made their vote official.

### Roots and the search for family

An estimated 130 million people watched the *Roots* miniseries, a story told on television over several nights, when ABC showed it in January 1977. It was the largest audience a television series had ever had.

### Alex Haley

> **Who:** A writer whose book *Roots* told his family's story back to an enslaved African ancestor, and whose work led many Black Americans to search for their own families.
>
> **When and where:** Born in Ithaca, New York, in 1921. *Roots* published in 1976. Died in Tennessee in 1992.
>
> **Movie:** *Roots* (1977), a television miniseries on ABC based on Haley's book. It tells his family's story as drama. It is not a documentary about Haley.

**A family story said an ancestor insisted "his real name was Kin-te."**

Alex Haley spent part of his childhood in Henning, Tennessee, his mother's hometown. There his aunts and grandmothers told the family's stories. One was about an African ancestor named Toby, who "insisted that his real name was Kin-te."

Haley served twenty years in the United States Coast Guard, and he became a writer while he was in it. Later he traveled to Gambia, in West Africa. There a griot, a keeper of history who tells it from memory, told him the story of "his ancestor Kunta Kinte, captured by slave traders."

*Roots* came out in 1976 and won a special Pulitzer Prize in 1977. The television miniseries ran on eight nights in a row in January 1977 and won 145 awards, including nine Emmys, the top awards for television.

**The challenges.** In 1978 Haley agreed to pay the writer Harold Courlander $650,000 to settle a lawsuit claiming that Haley had copied passages from Courlander's novel *The African*. Professional genealogists, people who trace family histories from records, have challenged links in the chain of records behind Haley's family story. Haley died in a Tennessee hospital in February 1992, of problems caused by diabetes.

**Not known:** whether the records support every link Haley drew between his family and Kunta Kinte.

## 2000 to Today

**Era 10 of 10 · 2000 to Today · about 10 minutes**

Americans since 2000 have built museums about slavery, opened its records to anyone who wants to search them, and argued over whether to repair what it did. The Smithsonian's National Museum of African American History and Culture opened in Washington in 2016. In a project begun in 2015, volunteers made about 1.8 million names from the records of the Freedmen's Bureau, the federal office set up after the Civil War to help freed people, searchable online.

Lawmakers and city leaders have argued over payments or other repairs to the descendants of enslaved people. Federal officials removed or changed exhibits about slavery at some national parks in 2025 and 2026, and judges were still deciding in September 2026 whether that was lawful.

### Museums, a holiday and a late vote

The Smithsonian's National Museum of African American History and Culture opened in Washington, D.C., on September 24, 2016. Its history galleries begin with the slave trade. Among the things on display is a cabin where enslaved people lived. The International African American Museum opened in Charleston, South Carolina, on June 27, 2023. It stands at Gadsden's Wharf, one of the main places where slave ships landed their captives.

Members of Congress passed the Juneteenth National Independence Day Act, and President Joe Biden signed it on June 17, 2021. Under it, June 19 is a federal holiday. It marks the day in 1865 when Union soldiers announced freedom in Galveston, Texas.

Two Mississippi residents found in 2012 that the paperwork for the state's 1995 vote approving the 13th Amendment had never been filed. It was officially recorded on February 7, 2013.

**Celia's pardon.** Celia was the enslaved girl Robert Newsom bought at 14 in 1850 and raped again and again until 1855, when she killed him. She was hanged that December, and the accounts do not name the officials who hanged her. On December 20, 2024, at the request of her descendants, Missouri's governor, Mike Parson, pardoned her, an official act that forgave her for the crime.

### The records opened

For millions of Black Americans, the records of the Freedmen's Bureau are the first papers in which their ancestors appear by name, according to FamilySearch and the Smithsonian. The records include marriage registers, work contracts and school lists. Volunteers for FamilySearch, a genealogy group, typed up about 1.8 million names from them so that people could search them, in a project begun in 2015. The names can be searched at discoverfreedmen.org.

**The GU272.** The Maryland Jesuits, priests of a Catholic religious order, sold 272 enslaved people to plantations in Louisiana in 1838. They sold them in part to keep Georgetown College, now Georgetown University, from running out of money. It is one of the best-documented mass sales of people in American history. The people sold are now called the GU272.

Georgetown's leaders announced in 2016 that descendants of the GU272 would get an advantage when they applied to the university, and they renamed buildings. Genealogists have traced thousands of descendants, according to the Georgetown Memory Project in 2021.

The Jesuits and leaders of the descendants set up the Descendants Truth and Reconciliation Foundation in 2021, reconciliation meaning making peace after a wrong. The Jesuits promised to give $100 million to it. The Boston Globe reported that it is the largest pledge of its kind by a religious group in the United States.

**The Cherokee Freedmen.** The Cherokee treaty of 1866, told in the 1850 to 1900 era, promised the people Cherokee slaveholders had held in slavery, called Freedmen, "all the rights of native Cherokees."

In 2017, in the case *Cherokee Nation v. Nash*, a federal judge ruled that the treaty still bound the Cherokee Nation. Descendants of Cherokee Freedmen had a right to full citizenship in the nation. Cherokee leaders accepted the ruling. In 2021 the justices of the Cherokee Nation's own Supreme Court struck the words "by blood" out of its rules on citizenship.

### Mélisande Short-Colomb

> **Who:** A descendant of two people sold by the Maryland Jesuits in 1838, who enrolled at Georgetown University at the age of 63.
>
> **When and where:** From New Orleans. Entered Georgetown University in Washington, D.C., in the fall of 2017.

**She enrolled at Georgetown at 63, 179 years after the sale.**

Mélisande Short-Colomb was a retired chef from New Orleans. She descends from Abraham Mahoney and Mary Ellen Queen, two of the 272 people the Jesuits of Maryland sold in 1838 to keep the college going.

She grew up hearing family stories from her grandmother and her great-aunts. In the summer of 2016 she learned that Mahoney and Queen had been part of the 1838 sale. In April 2017 Georgetown's leaders held a Liturgy of Remembrance, a religious service honoring the people who were sold. After that, she applied to the university, and she started there that fall.

At Georgetown she wrote a play, *Here I Am*, about her ancestors and the university.

### Repair debated

Reparations are payments or other actions meant to make up for a wrong. Members of Congress have argued since 1989 over whether the United States should pay reparations for slavery.

**H.R. 40.** Representative John Conyers first introduced a bill called H.R. 40 in 1989. It would set up a commission, a group of people chosen to study slavery and its effects and to recommend ways to repair them, including a formal apology and payments. The number 40 comes from the forty-acre plots that General William T. Sherman set aside for freed families in January 1865, land President Andrew Johnson took back that fall.

The members of the House Judiciary Committee voted to move the bill forward for the first time in 2021. Representative Ayanna Pressley of Massachusetts introduced it again on January 3, 2025. As of September 2026, neither the full House nor the full Senate had voted to pass it, according to the records of Congress.

**Evanston.** The members of the city council of Evanston, Illinois, voted in 2019 to create the first reparations program paid for by a city. Council member Robin Rue Simmons led the effort. City officials set aside $10 million and in March 2021 approved its first grants of $25,000 for housing. The program is for Black residents who lived in Evanston between 1919 and 1969.

In those years Evanston's city officials used city laws to separate where Black and white people could live. The members of the city council passed Evanston's first zoning law, a law that sets what may be built in each part of a city, in January 1921, and Mayor Harry P. Pearsons signed it.

The law marked almost every block where Black people lived outside the west side of town for stores and businesses. As those blocks were turned over to businesses, the Black families living there were pushed out to the west side, the historian Andrew Wiese writes.

By August 2026, according to the Evanston RoundTable newspaper, 137 people had received a total of $3.47 million. A conservative group called Judicial Watch sued the city in May 2024, arguing that paying people based on race breaks the 14th Amendment. On June 16, 2026, lawyers for the U.S. Department of Justice asked to join the lawsuit against the city. The case was still open in September 2026.

**California and Maryland.** In California, a state task force, a group the state set up to study reparations, delivered its final report on June 29, 2023. According to the state's Department of Justice, it made more than 115 recommendations, including a formal apology. Governor Gavin Newsom signed the state's apology in September 2024.

Newsom signed a law on October 10, 2025, creating a state Bureau for Descendants of American Slavery. The bureau is to check who qualifies, handle claims and recommend forms of repair. The law provides for no payments.

In Maryland, Governor Wes Moore vetoed a bill for a state reparations commission in May 2025, which means he refused to sign it into law. On December 16, 2025, Maryland's state lawmakers passed it over his veto, 31 to 14 in the Senate and 93 to 35 in the House. The 23-member commission is to study state and local policies from 1877 to 1965.

### Slavery exhibits in the national parks, 2025 and 2026

President Donald Trump signed an executive order, a written command from the president to the people who run the federal government, on March 27, 2025. It was called "Restoring Truth and Sanity to American History." Interior Secretary Doug Burgum, who is in charge of the national parks, then ordered a review of how the signs and exhibits in the parks present the history of the United States.

**Peter's photograph.** Reporters for the Washington Post and the New York Times wrote in September 2025 that officials had ordered a copy of an 1863 photograph removed from an exhibit at Fort Pulaski National Monument, near Savannah, Georgia. The photograph shows the back of Peter, a man who escaped slavery in Louisiana in 1863, covered in scars from whipping. On September 16, 2025, Elizabeth Peace, who spoke for the Interior Department, told The Hill newspaper that park sites "were not asked to remove the photo." The two accounts differ.

**The President's House.** Officials removed the exhibits about slavery at the President's House site in Philadelphia in January 2026. That was the house where President George Washington lived, and where Ona Judge, an enslaved woman, walked out to freedom in 1796. On February 16, 2026, Judge Cynthia M. Rufe ordered the exhibits put back. Government lawyers appealed, and the judges of an appeals court, a higher court that hears appeals, later ruled that the administration had the power to replace that exhibit.

**The national case.** In a separate case, Judge Angel Kelley of the federal court in Massachusetts ruled on June 12, 2026, that the order could not be carried out at any of the park system's 433 sites. She ordered the removed exhibits put back by July 3. On July 2, 2026, the judges of the First Circuit Court of Appeals paused her order, so removals could go on while the case continued.

By the government's own count, in court papers filed in June 2026, exhibits had been removed or changed at 37 park sites. The case was still undecided in September 2026.

### Joycelyn Davis

> **Who:** A descendant of Charlie and Maggie Lewis. Charlie Lewis was one of the Africans smuggled into Mobile, Alabama, as captives on the *Clotilda* in 1860.
>
> **When and where:** Africatown, in Mobile, Alabama, where she has lived all her life.
>
> **Movie:** *Descendant* (2022), a documentary by Margaret Brown about the *Clotilda*, Africatown and the survivors' families. Joycelyn Davis appears in it.

**"Our community is suffering, and you're asking about a ship?"**

Joycelyn Davis descends from people who survived the last known slave ship to reach the United States, and she organizes gatherings in their honor in the town they founded. Her ancestors Charlie and Maggie Lewis were among the 110 Africans whom Captain William Foster carried from West Africa and smuggled into Mobile on the *Clotilda* in 1860, more than fifty years after bringing captives into the country became illegal.

She has lived in Africatown all her life. As a child she visited her great-grandmother in Lewis Quarters, one of the first pieces of land the *Clotilda* survivors bought, named for Charlie and Maggie Lewis. She went to the school and the church that her ancestors founded. In 2017 she sued the International Paper Company over pollution from its old mill near Mobile. She is a cancer survivor.

**The ship.** She said those words early in the search for the wreck of the *Clotilda*. After the wreck was confirmed in 2019, she came to see the ship as a way to bring money and attention to Africatown. That year she organized a reunion of *Clotilda* descendants. Of the crowd that came, she told National Geographic: "I never in a million years thought it would be that big."

A yearly festival she organizes is called Spirit of Our Ancestors. The 2021 festival, the third, honored the women who survived the *Clotilda*. She appears in *Descendant*, the documentary by Margaret Brown. It won a special jury award at the Sundance Film Festival in January 2022 and was released in theaters and on Netflix on October 21, 2022.

**The three questions, answered**

- How did a servant in Virginia become a slave for life, and a child a slave from birth? Virginia's judges and lawmakers did it one ruling at a time. Judges sentenced John Punch to serve for life in 1640, and in 1662 lawmakers ruled that a child born to an enslaved mother was enslaved for life.
- How did enslaved people fight back? They worked slowly, ran away, sued, learned to read in secret and rose up with weapons. During the Civil War about half a million freed themselves by reaching the Union army.
- What happened to the freedom people won in 1865? Freed people voted, built schools and sent 16 men to Congress. But within twelve years Southern lawmakers passed Black Codes, Klansmen whipped and murdered freed people, and federal officials stopped enforcing their rights in the South until members of Congress passed the laws of 1964 and 1965.

**What changed:** Slavery grew from a few court rulings in Virginia into a system that held four million people, and the freedom that ended it in 1865 took another hundred years to enforce.

**Five dates to keep**

- July 9, 1640: John Punch is sentenced to serve for life.
- 1662: Virginia's law makes a child follow the mother into slavery.
- January 1, 1808: Bringing captives from abroad becomes illegal.
- December 6, 1865: The 13th Amendment ends slavery.
- July 2, 1964: The Civil Rights Act becomes law.

**Not known:** whether Virginia's colonists held the Africans of 1619 as servants for a set number of years or as slaves for life.

**Where to go:** The Smithsonian's National Museum of African American History and Culture, in Washington, D.C., whose history galleries begin with the slave trade.

**Next:** Chapter 25, Rights and Movements. It follows the campaigns for the rights the Constitution promised, from 1877 on.
