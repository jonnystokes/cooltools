# Chapter 10: Energy

**Chapter 10 of 37 · Energy · 10 eras · about 75 minutes**

**Americans moved from burning wood to burning coal, oil and natural gas, and getting that energy cost many people their freedom, their land or their lives.**

A tavern keeper named Jesse Fell burned hard coal on an iron grate in his fireplace in Wilkes-Barre, Pennsylvania, on February 11, 1808. Most people thought that coal was too difficult to burn at home, but Fell showed that it could warm a house. From the 1820s to the 1840s, people put stoves and furnaces made for that coal into their homes. Miners dug that coal in northeastern Pennsylvania, and on September 6, 1869, a fire in one of their mines, the Avondale mine near Wilkes-Barre, killed 110 people.

This chapter describes the fuels in order, from the fires Native people set on purpose before 1500 to the wind turbines and solar panels of 2025. Watch for two things. One is the main fuel. Wood came first, then coal, which passed wood around 1885, and then oil and natural gas. In 2016 natural gas passed coal as the fuel that made the most American electricity. The other is who did the work and who paid for it: the enslaved people who made charcoal for the iron furnaces, the coal miners killed underground, and the Native nations whose rivers were dammed and whose land held oil and uranium.

**Three questions this chapter answers**

- Did kerosene really save the whales?
- How did electricity reach almost every American home?
- Who paid for America's energy with their freedom, their land or their lives?

**Five minutes?** Read "The current war" in 1850 to 1900.

**Can skip:** "A stove to save wood", "Oil for a world war", "Panels on the White House roof", "New and restarted reactors". The chapter still makes sense without them.

## Before 1500

**Era 1 of 10 · Before 1500 · about 2 minutes**

People here did their work with the strength of their own bodies and with fire, and wood was the fuel they burned. They burned it to heat their homes, to cook and to see after dark.

North of Mexico there were no horses, oxen or mules. People carried and dragged loads with their own muscle, and they moved heavy goods by canoe. Dogs were the only animals that hauled loads. On the Plains, dogs dragged a travois, two long poles tied together at one end to form a narrow V. The load rode on the poles, and their far ends dragged along the ground.

### Why did Native people set fires on purpose?

Native people lit small fires and kept them under control to help the plants and animals they used for food, clothing and ceremonies. They also burned land to clear space for crops and travel, and they used fire to hunt game. They burned on regular cycles, and the practice is now called cultural burning.

In the eastern part of the continent, oak and chestnut trees fill many forests. According to the National Park Service, those forests grew that way because people burned them on purpose to get certain nut crops. In what is now northern California, Karuk and Yurok people burned their hazel shrubs so that the shrubs would grow new stems for weaving baskets.

**After 1500.** Native people went on burning land long after 1500. For most of the 1900s, though, federal officials in charge of forests tried to put out wildfires, to protect water supplies, towns and timber for sale. Under the rules those officials made, Native people could do far fewer burns.

Yurok people worked with California's state fire department on a small burn on Yurok land in 2013. In May 2014, organizers with the Cultural Fire Management Council held the first Yurok training event for this kind of burning. Writers for The Nature Conservancy reported in 2020 that Native people who burn in the old way still face punishment. Their report does not say who punishes them.

**Basket stems today.** Karuk and Yurok people still burn their hazel shrubs. Four researchers studied those burns and published their findings in 2021, and the study appears among the US Forest Service's research papers. Burning every three to five years gave the best stems. In the first season after a fire, the shrubs grew 13 times as many basket stems.

## The 1500s

**Era 2 of 10 · The 1500s · about 2 minutes**

Spanish explorers and soldiers brought horses here in the 1500s, and at the very end of the century Spanish colonists built water mills. A horse could drag a travois farther and faster than a dog could, and it could carry more weight. Still, most people living here did their work with muscle, fire and wood for the whole century.

The mills stood in New Mexico. A history of the state's mills, printed in a Santa Fe newspaper, calls them the first mills powered by water in what is now the United States.

### Horses come ashore

Hernando de Soto landed near what is now Tampa Bay, Florida, in May 1539, with 11 ships. He brought about 250 horses, 1,000 soldiers on foot, many dogs and a herd of pigs.

**Hymahi.** De Soto's army reached Hymahi, a small Native village where two rivers meet, in April 1540. Writers for the National Park Service say the rivers must have been the Congaree and the Wateree, in what is now South Carolina. De Soto took all of the village's food. He burned at least one of the people who lived there to death while questioning that person about a town called Cofitachequi.

Francisco Vázquez de Coronado led a large party north from Mexico into the Southwest in 1540, and his men brought horses too. He had more than 300 armed Europeans and at least 1,200 Native people who marched on the Spanish side. Many dozens of servants and enslaved people went with them. Coronado's party went as far as what is now Kansas and returned in 1542.

### The first water mills, 1598

Juan de Oñate led Spanish colonists north into what is now New Mexico in 1598. That year they founded a town called San Juan de los Caballeros on the Rio Grande, on land that belonged to the Tewa, one of the Pueblo nations. Pueblo is the Spanish word for town or village. The Spanish used it for the Native peoples of the Southwest who lived in towns built of stone and of adobe, brick made of mud and dried in the sun.

Early in 1599 the colonists moved to a new capital, San Gabriel, which they built at a pueblo town near Ohkay Owingeh, a Tewa town. Writers for the National Park Service call that site abandoned. They do not say whether Tewa people had been made to leave it.

**Tub mills.** Oñate's colonists built their first water mills in 1598. These were small tub mills, with the water wheel lying flat in the stream. The moving water spins the wheel, and the wheel turns the millstone directly, so the stone grinds grain into flour. The colonists hauled their millstones north on the Camino Real, the Royal Road, which ran about 1,600 miles north from Mexico City.

## The 1600s

**Era 3 of 10 · The 1600s · about 5 minutes**

Wind and falling water began turning mills in the English colonies in the 1600s. The mills ground grain and sawed logs. All other work still took muscle, and colonists burned wood in open fireplaces to heat their homes and cook.

Two other kinds of energy came into use in these years. Native people rode horses and fed them corn, and along the coast colonists began to hunt whales for oil to burn in their lamps.

### The first wind and water mills

George Yeardley, the governor of the Virginia colony, had a windmill built at Flowerdew Hundred, on the James River, in 1621. It is the first windmill recorded in English America. Members of the colony's council, its group of leaders, wrote to the company in London that was in charge of the colony. Their letter records Yeardley's "good example" of building a windmill.

**What the diggers found.** Archaeologists, scientists who dig up the past, later dug at the spot. They found a round pit five feet across with iron hoops and brackets still in place, and they took it to be the remains of Yeardley's windmill.

**Whose land, and whose work.** Flowerdew Hundred was land of the Weyanock, a Native nation whose language belonged to the Algonquian family of languages. Yeardley brought 15 men from England in 1619 to grow tobacco there.

That same year, the crews of two armed ships, the *White Lion* and the *Treasurer*, attacked a Portuguese ship carrying 350 enslaved Africans and seized 50 to 60 of the captives. The *White Lion* brought its share to Point Comfort, Virginia, in late August 1619. Yeardley and a merchant named Abraham Peirsey bought them in exchange for food.

At least 11 of these Africans were taken to Flowerdew Hundred, Yeardley's land. The archaeologists' account of Flowerdew does not say who moved them there. A count of the colony's people taken in 1624 and 1625 records seven Africans at Flowerdew as laborers. It gives no names for them. The records do not say what happened to the other four.

Records from 1621 also list a gristmill, a mill that grinds grain, near Jamestown. It is the first gristmill recorded in the English colonies. Farther north, three English carpenters built a sawmill and a gristmill run by water at Newichawannock, in what is now South Berwick, Maine, in 1634. They were among the first water mills in New England.

### William Chadbourne

> **Who:** An English carpenter who helped build one of the first sawmills run by water in New England.
>
> **When and where:** What is now South Berwick, Maine, from July 1634.

**The mill's model arrived three years before the men who built it.**

William Chadbourne, James Wall and John Goddard arrived from England in July 1634 on a ship called the *Pied Cow*. They worked under a contract with the Laconia Company of Captain John Mason. Under it, the three carpenters were to build a sawmill, to cut logs into boards, and a gristmill on the Little Newichawannock River.

**The model.** Thomas Eyre wrote in a letter of May 1631 that a model of a sawmill had been sent to Newichawannock on the *Pied Cow*, the same ship the carpenters took three years later. Chadbourne and his partners built the sawmill in a rocky gorge. The spot is now below the Great Works bridge on Brattle Street in South Berwick. In 1652, in a lawsuit, James Wall made a sworn statement, a promise under the law to tell the truth, about where the 1634 mills had stood.

**The wheel.** Writers for the Old Berwick Historical Society say the sawmill is "thought to be the first" mill in America with an overshot wheel. On an overshot wheel, water pours onto the top of the wheel, and the weight of the water turns it. People in other towns of the region say that their town had the first sawmill.

**Whose river.** Newichawannock is an Abenaki word, and Abenaki people lived there. Between 1616 and 1618, before the carpenters came, diseases brought by Europeans, such as measles or smallpox, killed seven out of every ten of them. The society's histories of the mills do not say that Mason's men asked the Abenaki for permission to build. A leader named Rowls survived the diseases. In 1650 he sold his village land, Quamphegan, to a man named Thomas Spencer for five pounds.

Mason died in 1638, and after that the mills fell apart. People stole their materials, and the society's timeline of the mills does not name the thieves. Later one of the mills burned.

**Not known:** what became of William Chadbourne after he built the mills. The society's histories of the mills do not say.

### How much wood did a family burn?

Wood was the main fuel in colonial homes, and one household burned about 15 to 40 cords of it a year. A cord is a stack of wood 4 feet high, 4 feet wide and 8 feet long. Forty cords stacked in one row 4 feet high would run 320 feet, longer than a football field from goal line to goal line.

The low figure, 15 cords, comes from one New England estimate of the 1600s. The high figures, 30 to 40 cords, are for a home that heated and cooked with open fireplaces. An open fireplace sent most of its heat up the chimney, so a family had to burn a great deal of wood to stay warm.

### Horses in Native hands

Native people were riding horses, putting bridles on them and feeding them corn by the early 1600s. A team of scientists showed this in a study published in the journal *Science* in 2023. The team, which included Lakota, Comanche and Pawnee scholars, studied the bones of horses found in what are now Wyoming, Kansas and New Mexico.

**The old account.** For a long time, the usual account said that Native people got their horses only after the Pueblo Revolt, decades later. In August 1680, Pueblo people led by Po'pay, a Tewa religious leader, rose against the Spanish colonists in New Mexico and drove them out. Perhaps 1,500 or more horses came into Native hands at one time.

### Oil from whales

English colonists on Long Island and in New England began killing whales close to shore for their oil in the 1600s. From about 1690, whale oil was one of the main fuels that Americans burned in their lamps, and it stayed one for about 150 years. By the 1840s it cost too much for most families, and they burned cheaper fuels instead.

## 1700 to 1750

**Era 4 of 10 · 1700 to 1750 · about 3 minutes**

Iron furnaces in the colonies, tall ovens where fire melts iron out of rock, ran on charcoal, a fuel made from wood. Many of the workers who fed the fire at the Baltimore Iron Works, in Maryland, were enslaved people and convicts shipped from Britain. They hauled charcoal to the furnace around the clock.

Lamps burned whale oil, and families who could pay the most bought candles made from a waxy oil in the head of the sperm whale. Benjamin Franklin designed an iron stove in 1741 to heat a room with less wood.

### Charcoal for iron

Iron furnaces burned charcoal, wood that has been heated with too little air for it to burn away. The heat drives off the water and gases in the wood. What is left is nearly pure carbon, and it burns hotter than wood. The men who made charcoal were called colliers.

**The owners.** Five planters started the Baltimore Iron Works on the Patapsco River in Maryland in 1731. Dr. Charles Carroll, a surgeon, gave 2,200 acres of land and ran the works at first. Two of his cousins, along with Daniel Dulany and Benjamin Tasker, put in money and enslaved workers. In the 1600s, the land around the Patapsco lay within the hunting grounds of the Susquehannock nation, whose villages stood farther north, along the Susquehanna River.

**The workers.** The Baltimore Iron Works opened with 89 workers, and 42 of them were enslaved. Many of its workers were enslaved people or transported convicts, people found guilty of crimes in Britain and sent to the colonies to be sold into 7 to 14 years of forced work. Judges in English courts gave that sentence. Merchants shipped the convicts across the ocean, and merchants and ship captains sold them in the colonies, some of them to iron makers.

The workers hauled cartloads of charcoal, oyster shells and iron ore, the rock that iron comes from, to the top of the furnace in 12-hour shifts. The work went on around the clock, six or seven days a week. The owners did not give the workers enough food. Some workers ran away, and others worked slowly on purpose.

**The profits.** In a good year the partners made back more than half of what they had put in, a profit of 55 percent. By 1785 an advertisement for the Baltimore Iron Works listed "more than 200 Negroes," the word then used for Black people. The people it listed were enslaved.

The surviving records of these early furnaces list the owners. They do not list the men who made the charcoal.

### What gave the brightest light?

The brightest light in the colonies came from candles of spermaceti, a waxy oil found in the head of the sperm whale. Candle makers turned it into candles that burned brighter and cleaner than any others, and they cost the most. Writers at the New Bedford Whaling Museum call spermaceti "the most valuable product of the Yankee whaling industry," Yankee meaning someone from New England.

### A stove to save wood

Benjamin Franklin designed what he called the Pennsylvania fireplace in 1741. It was a stove of cast iron, iron poured into a mold while it is melted. Franklin meant it to give more heat and less smoke from less wood than an open fireplace. Few people bought it at first. David Rittenhouse later improved the design, and after that it sold better.

## 1750 to 1800

**Era 5 of 10 · 1750 to 1800 · about 7 minutes**

The first steam engine in America pumped water out of a copper mine in New Jersey from 1755 on. A fire under a boiler, a closed tank of water, made the steam that ran it.

The iron furnaces still burned charcoal, and they burned it by the acre. Hopewell, in Pennsylvania, used the charcoal from about an acre of forest every day it ran. At Catoctin Furnace in Maryland, enslaved Black workers and some free Black workers cut the wood, made the charcoal and hauled it to the furnace. After dark, spermaceti candles still gave the brightest light.

### The first steam engine in America

Water flooded John Schuyler's copper mine at Second River, now North Arlington, New Jersey, in 1748, and the mine had to shut down. Schuyler paid an English engine maker, Jonathan Hornblower, 1,000 pounds to send him a "fire engine" and mechanics to set it up. Fire engine was the name people then used for this kind of steam engine.

**The crossing.** The parts arrived in New York in September 1753 on a ship called the *Irene*, after twelve weeks at sea, and Jonathan's son Josiah came with them. The parts were taken to Newark, New Jersey, and put together there. By early 1755 the engine was pumping water out of the mine.

**How it worked.** The engine was a kind invented in England by Thomas Newcomen. The fire under the boiler turned water into steam, and the steam flowed into a cylinder, a tall round tube. Inside the cylinder, the steam filled the space under a piston, a heavy disk that could slide up and down. Then a jet of cold water sprayed into the cylinder. The cold turned the steam back into water, which left almost nothing under the piston, so the weight of the air above pushed the piston down.

The piston was joined to one end of a beam that rocked up and down like a seesaw. The other end of the beam lifted long pump rods that hung down the mine shaft, and the pumps raised the water. Then the weight of the pump rods pulled the piston back up, and the engine started again. Engines of this kind stood about two stories high. Their power was about ten horsepower, a measure based on the work one horse can do.

### Josiah Hornblower

> **Who:** The young English engine builder who came over with the first steam engine in America and later ran it.
>
> **When and where:** The Schuyler copper mine at Second River, now North Arlington, New Jersey, 1753 to 1773.

**The engine house burned the same night he shut the mine.**

For twenty years after it started, the engine worked only part of the time. Josiah Hornblower, who had been about 24 when he came over with it, later ran it himself. In 1761 he and a partner, John Stearndall, leased the mine from the Schuyler family. They paid one seventh of the ore they dug as rent.

**The first fire.** The building around the engine caught fire in March 1762 and burned to the ground. A report in the *New York Mercury* of March 22 states that the engine works had cost nearly ten thousand pounds. People at the time guessed that a careless workman had left a candle burning. The engine was working again by 1767. Richard McCormick, the historian who wrote the engine's history, does not say who repaired it or when.

**Out of fuel.** Hornblower told what happened next in a letter of July 1768, in which he called the engine "the Fire engine." Late in 1767, he had to stop it because he had run out of fuel. He got more, put the old pumps back in, made the repairs and started it again in April 1768.

Soon the vein, the band of ore running through the rock, dipped deep. He tried to follow it with hand pumps, but they could not keep the water out, and his partners had not sent money they owed him.

**The second fire.** On a Monday in July 1768, he stopped the mine and let all the workers go. At about eight o'clock that evening, the engine house caught fire. It burned to ruins in a few minutes while a crowd of people tried to save it. Hornblower wrote that a man had gone into the engine house two hours before to light his pipe, and the man said he could not find any fire there to light it with.

A report in the *Pennsylvania Chronicle* states that the fire was "supposed to be by Design," because no one knew of any fire being used there lately. People thought someone had set it on purpose. Mining at Schuyler's stopped in 1773, and Hornblower stayed in New Jersey for the rest of his life.

**Known:** Half of the engine's cylinder is now in the Smithsonian Institution.

**Not known:** what became of the rest. One account says the engine was broken up around 1800, and another says it was repaired in 1793 and pumped water into the 1800s.

### Charcoal by the acre

Hopewell Furnace burned the charcoal from about an acre of forest every day it ran. Mark Bird built it on French Creek, in Berks County, Pennsylvania, in 1771. When the furnace was in blast, lit and making iron, it burned up to 800 bushels of charcoal a day, a bushel being a measure for dry goods such as grain.

In a year the furnace used 5,000 to 7,000 cords of wood, from more than 200 acres of woodland. A family heating its home with open fireplaces burned 30 to 40 cords. The owners held between 4,000 and 8,000 acres of forest to keep the furnace supplied. Woodcutters, using only axes, cut an average of two cords a day each.

**Whose land.** The land around Hopewell had belonged to the Lenni Lenape. After the colony's founder, William Penn, left Pennsylvania in 1701, his agent James Logan handled Penn's land deals. Under Logan, the colony's land deals with the Lenni Lenape were often dishonest, and some were frauds, deals built on lies.

By about 1750, nearly all Native people had been driven out of the lower Delaware and Susquehanna river valleys, and most moved west to the Allegheny, Monongahela and Ohio river valleys. The history of Hopewell written for the National Park Service does not name the people who drove them out.

### How a collier made charcoal

A collier made charcoal in a pile called a pit, built on flat, cleared ground. He drove a green pole, freshly cut and 18 feet long, into the middle of that ground and built a chimney with three corners around it. Then he stacked about 30 cords of wood around the chimney in three layers and covered the whole pile with leaves and dust.

To light the pit, he shoveled red-hot coals from his cooking fire down the chimney. The wood inside smoldered, burning slowly with very little air. The collier watched it day and night, walking on top of the pit to find soft spots where air was getting in and filling them. After 10 days to two weeks, the wood had turned into charcoal. One pit made about 1,100 bushels, enough to run the furnace for a day and a half.

### Who made the charcoal?

At Catoctin Furnace, in Maryland, enslaved Black workers and free Black workers made it. Four brothers, James, Baker, Roger and Thomas Johnson, built the furnace, and it was making iron by 1776. The Johnson family enslaved more than 80 people there. One of them was a skilled man recorded only as Collier Sam, and the Catoctin Furnace Historical Society's history gives only his name and his trade.

Over the life of the furnace, at least 271 enslaved African Americans worked at Catoctin, along with an unknown number of free African Americans. They mined ore, cut wood, made charcoal, drove wagons and worked the forge, the shop where iron was heated and hammered into shape. Woodcutters cut, hauled and stacked the wood for the colliers, and other workers carried the finished charcoal to the furnace.

**At Hopewell.** Mark Bird enslaved 18 people in 1780: 10 men, 4 women, 3 boys and 1 girl. No one else in Berks County enslaved as many people that year. That same year Pennsylvania lawmakers passed a law to end slavery in stages, but under it mainly children born after the law passed could become free. The last record of slavery at Hopewell is from 1821, when Matthew Brooke freed one person he enslaved.

Hopewell's owners hired free Black workers only for jobs that took little training, as woodcutters, laborers and teamsters, who drove wagons. According to the National Park Service, no record from Hopewell's 112 years shows a Black worker in a skilled job or as a manager.

## 1800 to 1850

**Era 6 of 10 · 1800 to 1850 · about 5 minutes**

Hard coal from northeastern Pennsylvania went into American stoves and furnaces in these years, and gas made from coal lit city streets. A tavern keeper showed in 1808 that the coal could heat a home, and boats, first on the rivers and then on canals, carried it to the cities. The country's first public gas street lamp was lit in Baltimore in 1817, with gas made from coal and sent through pipes.

The American whaling fleet reached its largest size in 1846, with 735 ships. Whale oil cost too much for most families, and most homes burned cheaper fuels.

### Stone coal

Northeastern Pennsylvania has a hard kind of coal called anthracite, which people then called stone coal. Two brothers named Gore, who were blacksmiths, had burned it in their forges, the fires where blacksmiths heat metal, since 1769. For use at home, though, most people thought anthracite was too difficult to burn.

**Fell's grate.** Jesse Fell ran a tavern in Wilkes-Barre, Pennsylvania. He had believed for some time that a big enough pile of anthracite would keep burning once it was lit. He built a grate shaped like the letter L out of "Small Iron rods," to hold the coal up off the floor of the fireplace so air could flow in underneath.

Fell set his grate in the fireplace of the tavern's main room on February 11, 1808, and lit the coal. He later wrote that "on first lighting" he "found it to burn excellently well."

After Fell showed that anthracite could heat a home, the anthracite business grew. A company called Lehigh Navigation was formed in 1818, and anthracite floated down the Lehigh River to Philadelphia in boats called arks. Later, boats on canals carried the coal into the cities. From the 1820s to the 1840s, people put stoves and furnaces made to burn anthracite into homes and other buildings.

### Gaslight

Heating coal makes a gas that burns, a mix of gases that includes hydrogen and a gas called carbon monoxide. Rembrandt Peale, who ran a museum on Holliday Street in Baltimore, lit a room of his museum with gas made from coal in 1816.

**The first gas company.** The Gas Light Company of Baltimore received its charter, a legal paper that allowed the company to form, on June 17, 1816. It was the first gas company in the United States. Gas makers stored the gas in large tanks called gasometers and sent it through pipes. The company's first public gas street lamp, the first in the country, was lit at Market and Lemon Streets in Baltimore on February 7, 1817.

About 50 American cities and towns had gas works, plants that made gas, by 1850. Gaslight was expensive, and most Americans could not pay for it. It lit streets, shops and the homes of richer families in the larger cities.

### Whale oil, and who could pay for it

The American whaling fleet counted 735 ships in 1846, the most in any year, out of about 900 whaling ships in the whole world. Other counts put the peak of the whaling business as late as 1852. New Bedford, Massachusetts, was the leading whaling port, and at its peak more than 400 whaling ships sailed from there.

**Who could pay.** Whale oil cost $1.30 to $2.50 a gallon, so mainly richer families burned it. Oil from sperm whales lit their homes, along with lighthouses and public halls. Most families burned cheaper fuels: tallow candles made of animal fat, lard oil made from pig fat at about 90 cents a gallon, and camphene at about 50 cents.

Camphene was one part turpentine, a liquid made from pine trees, mixed with four parts alcohol and a little camphor, added for its smell. Its fumes caught fire easily, and camphene lamps could start sudden fires.

### Nelson Cole Haley

> **Who:** A New Bedford harpooner whose book tells how a whaling crew turned a whale into lamp oil.
>
> **When and where:** At sea on the whaling ship *Charles W. Morgan*, 1849 to 1853.

**The crew boiled the whale's fat over a fire of whale scraps.**

Nelson Cole Haley hunted whales for the oil that Americans burned in their lamps. He grew up in New Bedford, Massachusetts, and his father died when he was a boy. In 1844, when he was twelve, he ran off to sea to become a whaleman, even though his mother did not want him to go.

**The chase.** Haley became a harpooner on the *Charles W. Morgan* in 1849, when he was seventeen. A harpooner threw the harpoon, a heavy iron spear, into the whale from a boat that the crew rowed out from the ship. Haley called the harpoon an iron.

He later wrote about driving it into the whale's blubber, the thick layer of fat under its skin. "I raised the iron, and with all the force I was capable of, I sent it to the socket into the vast mass of blubber and meat that was now only a foot or two clear of the boat."

He drove a second harpoon in beside the first. Then the second mate, one of the ship's officers, killed the whale with a lance, a long spear with a sharp blade, and the crew rowed the dead whale back to the ship.

**Whale into oil.** The next morning, men stood on the dead whale and peeled off strips of blubber. The crew hoisted the strips on board and cut them into chunks they called bibles, then boiled the chunks in two big metal pots on the try-works, a brick furnace built on the deck.

The heat melted the fat into oil, which the crew poured into barrels below deck. For fuel under the pots, they burned the crisp bits of blubber left over from the boiling.

Haley's voyage lasted four years, from 1849 to 1853. Whaling ships of that time stayed at sea three to five years on a voyage. Haley wrote a book about it, *Whale Hunt*, which the Mystic Seaport Museum first published in 1948, almost fifty years after he died.

The *Charles W. Morgan* was built in New Bedford in 1841 and made 37 voyages between 1841 and 1921, with sailors from fifty countries. It is the last wooden whaling ship left in the world, and it is kept at the Mystic Seaport Museum, in Mystic, Connecticut.

## 1850 to 1900

**Era 7 of 10 · 1850 to 1900 · about 12 minutes**

Americans began to buy two new kinds of energy in these years: kerosene for their lamps, made from oil, and electricity sent through wires. Edwin Drake's crew drilled a well in Pennsylvania that reached oil in 1859, and refiners made the oil into kerosene. Thomas Edison's workers began sending electric current to paying customers from a station in New York City in 1882.

Coal became the country's main fuel in these years. By the count of the US Energy Information Administration, coal supplied 9 percent of the energy Americans used in 1850 and 27 percent by 1870. Around 1885, Americans began to burn more energy from coal than from wood for the first time. Miners died digging it. A fire at the Avondale coal mine in Pennsylvania killed 110 people in 1869.

### Drake's well, 1859

Edwin Drake's crew struck oil 69.5 feet down near Titusville, Pennsylvania, on August 27, 1859. It was the first well in the United States drilled on purpose to find oil and sell it. Writers at the American Oil & Gas Historical Society date the start of the American oil business to that day.

Drake worked for the Seneca Oil Company of New Haven, Connecticut, whose owners wanted oil to make kerosene, a cheap fuel for lamps. The driller, William Smith, known as Uncle Billy, cut through rock and shale, a soft rock made of hardened mud, at about three feet a day. A steam engine of six horsepower drove the drill.

### Edwin Drake

> **Who:** The man whose 1859 well started the American oil business, though he lost his money afterward.
>
> **When and where:** Titusville, Pennsylvania, 1859.
>
> **Movie:** *Born in Freedom: The Story of Colonel Drake* (1954). A 30-minute drama paid for by the oil industry's American Petroleum Institute, with Vincent Price as Drake. It first played in Titusville on March 29, 1954.

**The title "Colonel" was made up to impress the town.**

People called him Colonel Drake, but he never held that rank. An investor named James Townsend made up the title and addressed letters to "Colonel E. L. Drake" to impress the people of Titusville.

**The drive pipe.** Water from Oil Creek kept seeping into the hole, and the sides kept caving in. Drake had a pipe driven down to the rock, and then the drill worked inside the pipe, which kept the water and loose ground out.

**After the well.** Drake never patented the drive pipe, which means he never got a government paper giving him the only right to make and sell it. The Seneca Oil Company fired him, and he lost his money on Wall Street, a street in New York City where people buy and sell shares in companies. When he came back to Titusville years later, he had little money, and his health was failing.

His friends raised about $4,000 for him in the late 1860s. In 1873 people of Titusville won him a pension from the state of Pennsylvania, $1,500 paid to him every year. Drake died in November 1880 in Bethlehem, Pennsylvania.

### Did kerosene save the whales?

A common saying holds that kerosene saved the whales, but writers at the University of Houston's engineering college and at the website environmentalhistory.org call that claim a myth. Whaling was already shrinking before kerosene came, and in most homes kerosene replaced camphene, not whale oil.

**What families burned.** American families switched to kerosene for their lamps in the 1860s. Refiners made it by heating oil until parts of it boiled off as vapor, then cooling the vapor back into separate liquids. Kerosene sold for about 50 cents a gallon.

The whaling fleet had been largest in 1846, and whalers caught fewer whales through the 1850s. Whale oil cost $1.30 to $2.50 a gallon, so mainly richer families burned it. Most families burned camphene and lard oil.

**The tax.** During the Civil War, members of Congress passed the Internal Revenue Act to pay for the Union Army, the army of the Northern states. Under that law, alcohol was taxed at up to $2.08 a gallon from 1862 to 1864. The lawmakers meant to tax alcohol that people drank, but they did not leave camphene out of the law, and camphene was about three quarters alcohol.

Before the tax, camphene and kerosene each sold for about 50 cents a gallon. At the top rate, the tax on the alcohol in one gallon of camphene came to more than a dollar, while kerosene was taxed at 10 cents a gallon. People stopped buying camphene, and families switched to kerosene.

### Avondale, 1869: one way out

A fire at the Avondale coal mine, near Wilkes-Barre, Pennsylvania, killed 110 people on September 6, 1869. The Steuben Coal Company owned the mine.

Mine operators then kept small fires burning at the bottom of their shafts, the deep holes that lead down into a mine. A fire like this, called a ventilating furnace, made a draft that moved fresh air through the mine.

**One way out.** Sparks from the ventilating furnace set fire to the wooden timbers in the shaft, and the flames spread up to the breaker, the wooden building where coal was broken and sorted. The breaker stood right over the shaft, and the shaft was the only way into or out of the mine. The men who ran the Steuben Coal Company had the mine and its breaker built that way.

The fire filled the mine with smoke and gas, and 108 men and boys underground died because they could not breathe. Five of the dead were boys between 12 and 17 years old. Two men who went down to rescue the miners also died.

Pennsylvania lawmakers passed a mine law in 1870. It required every mine to have more than one way out, and it forbade using a single passage both to bring fresh air in and to let bad air out.

### From charcoal to coal

Hopewell Furnace in Pennsylvania burned charcoal from about 1771 until it closed in 1883. By then iron makers had built new ironworks that burned anthracite, the hard coal, and charcoal furnaces had fallen out of use. For more than a hundred years, workers at Hopewell had cut the forest around it for charcoal. Mark Bird, who built the furnace, enslaved some of those workers in its early decades, and the last record of slavery at Hopewell is from 1821.

### Lafayette Houck

> **Who:** One of the last colliers at Hopewell Furnace, who later taught the National Park Service how charcoal was made.
>
> **When and where:** Hopewell Furnace, Berks County, Pennsylvania, in the later 1800s, and again in 1936.

**Fifty-three years after the furnace closed, he showed how charcoal was made.**

Lafayette Houck came from a family of colliers. Their work at Hopewell began in 1818, when Henry Houck worked there as a master collier, in charge of the pits and of the helpers who worked them. In winter Henry also repaired wooden wagon wheels or chopped wood to sell. In the 1830s the furnace's owners paid about 20 colliers, and each one tended eight or nine pits.

**The watch.** Lafayette made charcoal the way Hopewell's colliers had since the 1700s, in smoldering piles of stacked wood. A Hopewell collier lived in a rough hut near his pits from May to October, with one or two helpers, and together they tended up to eight or nine pits at once. They watched the pits day and night, from the moment a pit was lit until a teamster, a man who drove a wagon, hauled away the last load of charcoal.

**Teaching the trade.** Hopewell closed in 1883, and federal officials bought the land in the 1930s. In 1936 Houck and his son, William, showed workers of the Civilian Conservation Corps, a government jobs program, how a collier lived and worked. Houck taught the National Park Service how charcoal was made, and he told them what he remembered about life at the furnace.

**Not known:** his exact age, his pay, and the years he began and stopped work as a collier. One National Park Service page gives his life as 1846 to 1939, and another says he was 82 in 1936, which would put his birth around 1854.

### Pearl Street, 1882

Thomas Edison's workers started the first permanent central power station in the United States on September 4, 1882. It stood at 257 Pearl Street in Manhattan, in New York City, and it made electricity in one place for many buildings, sending it out through wires.

**Coal into current.** The station ran on coal. Four boilers burned coal to make steam, the steam ran engines, and the engines turned six dynamos, machines that turn motion into electric current. Wires carried the current to a district of about a quarter of a square mile around the station.

The station served 85 customers on its first day, with about 400 lamps among them. Within a year it served 513 customers with about 10,000 lamps. It ran until January 2, 1890, and in those years it went dark only once, for three hours.

### Thomas Edison

> **Who:** The inventor who built his electric system on direct current, a kind that could not travel far.
>
> **When and where:** Pearl Street, Manhattan, New York City, from September 4, 1882.

**When his station started, Edison stood in a banker's office.**

Thomas Edison was in the office of the banker J. Pierpont Morgan, at the bank of Drexel, Morgan and Company, when the Pearl Street station began sending out current. He had built the system to run on direct current, called DC, which flows in one direction only, like the current from a battery.

The station sent DC out at a low voltage, the force that pushes electric current through a wire. Low-voltage direct current loses a lot of its energy in the wires as it travels. Because of that loss, Pearl Street could serve only the small district around the station.

### The current war

Alternating current, called AC, flows back and forth, changing direction many times each second. In the United States today it changes direction 60 times a second. A machine called a transformer can easily raise or lower the voltage of AC, which could not easily be done with direct current.

George Westinghouse sold electric systems that ran on AC. Nikola Tesla received patents for motors that ran on alternating current in May 1888, and two months later Westinghouse paid for the right to use them. Chapter 8 tells how Tesla's motor worked and what Westinghouse paid for it.

**The dogs.** Edison and his supporters attacked AC as deadly. Harold Brown, an electricity salesman, ran tests at Edison's laboratory in West Orange, New Jersey, in 1888, killing dogs with alternating current to show that it was dangerous. The dogs were strays, bought from boys in the neighborhood for 25 cents each. Edison's supporters used the word "Westinghoused" to mean killed by electricity.

**The chair.** New York lawmakers replaced hanging with death by electricity in 1888, a change Governor David B. Hill had proposed. New York State officials hired Harold Brown to build the first electric chair, which kills a person by sending a strong electric current through the body. Edison secretly paid Brown to use alternating current in it. A chair that killed with AC fit Edison's campaign to convince Americans that alternating current was too dangerous to have in their homes.

The first man put to death in the electric chair was William Kemmler, of Buffalo, New York. Kemmler killed Matilda Ziegler, who lived with him as his wife, in their apartment in Buffalo, striking her more than 25 times on the head, neck and shoulders with a hatchet. At his trial in a Buffalo court in May 1889, he was found guilty of murder and sentenced to die by electricity in Auburn State prison.

His lawyer argued that death by electricity was a cruel and unusual punishment, which the New York State Constitution forbids, but judges all the way up to the US Supreme Court let the sentence stand.

**The execution.** Prison officials at Auburn put Kemmler in Brown's chair on August 6, 1890, and sent a current through him for 17 seconds. A doctor said he was dead, but then Kemmler groaned and began to breathe again. The officials turned the current back on, and this time it took between one and four minutes to kill him.

During the execution his fist clenched so hard that blood ran from his palm, and the back of his coat briefly caught fire. The room filled with the smell of burning flesh, and several witnesses fainted. Newspaper writers called the execution "a disgrace to civilization."

**Chicago and Niagara.** General Electric offered to light the World's Columbian Exposition, the world's fair in Chicago, with Edison's direct current for $554,000. Westinghouse offered to light it with alternating current for $399,000, and he got the job. In May 1893 his company's AC system lit about 100,000 electric lamps at the fair, 250 times the 400 lamps Pearl Street lit on its first day.

Westinghouse also won the job of building the three generators, machines that turn motion into current as Edison's dynamos did, for the Adams power plant at Niagara Falls. Each was rated at 5,000 horsepower. The Adams plant sent out its first alternating current, to factories in the town of Niagara Falls, on August 26, 1895. In November 1896 current from Niagara Falls lit Buffalo, New York.

### George Westinghouse and Nikola Tesla

> **Who:** The businessman who sold alternating current, and the inventor whose AC motors he bought the right to use.
>
> **When and where:** New York State, 1888 to 1890.
>
> **Movie:** *The Current War* (2017). A Hollywood drama, not a documentary. Michael Shannon plays Westinghouse and Nicholas Hoult plays Tesla.

**Westinghouse refused to sell New York three dynamos for its electric chair.**

George Westinghouse had owned the right to use Nikola Tesla's AC motors since 1888. Tesla was a Serbian immigrant who had come to the United States in 1884. Westinghouse stood to lose millions of dollars if Americans came to believe that alternating current would kill them in their homes.

New York State officials asked to buy three Westinghouse AC dynamos for the new electric chair, and Westinghouse refused to sell them. Harold Brown got AC dynamos anyway. Westinghouse then gave $100,000 toward the lawyers' fees for Kemmler's appeal to the US Supreme Court, and the appeal failed.

After Kemmler's execution in August 1890, Westinghouse said, "It has been a brutal affair. They could have done better with an ax."

**If you remember one thing:** Alternating current, which a transformer could raise or lower, won the current war against Edison's direct current.

- 1859: Edwin Drake's crew strikes oil near Titusville, Pennsylvania.
- 1869: A fire at the Avondale coal mine kills 110 people. The mine has only one way out.
- Around 1885: Coal passes wood as the country's main fuel.

**Next:** In the next fifty years, electric wires reached almost every American home, and oil shot out of a hill in Texas.

## 1900 to 1950

**Era 8 of 10 · 1900 to 1950 · about 14 minutes**

Electric wires reached almost every American home in these fifty years. About 8 households in 100 had electricity in 1890, and 94 in 100 did by 1950. Emanuela Cardia worked out those figures in a 2008 study from the census, the government's count of the people and their homes, taken every ten years. Most farms got their wires only after 1935.

Coal still heated most homes. The 1940 census found that more than half of American homes were heated mainly with coal, and about a quarter with wood.

A single well in Texas began to pour out an estimated 100,000 barrels of oil a day in 1901. In World War II, most of the oil burned by the Allies, the countries fighting Germany, Italy and Japan, came from the United States.

### Spindletop, 1901

A well on Spindletop hill, about 3 miles south of Beaumont, Texas, struck oil 1,139 feet down on January 10, 1901. Oil shot more than 100 feet into the air. The well poured out an estimated 100,000 barrels a day until workers capped it nine days later, on January 19.

**Nine days.** All of Texas had produced 836,000 barrels of oil in the whole year of 1900. At the estimated rate, the Spindletop well poured out about 900,000 barrels in its nine days, more than that whole year's total.

**The salt dome.** Anthony F. Lucas led the drilling. According to the Texas State Historical Association, he was the leading American expert on salt domes, large masses of salt buried deep underground, and Spindletop hill stood on one. Other geologists of the time doubted that oil lay in the salt domes along the coast of the Gulf of Mexico. Lucas was sure it did, and the well proved him right.

Several oil companies started at Spindletop or grew large there, among them the Texas Company, later called Texaco, and Gulf Oil.

### What coal cost the miners

Coal miners died at work by the thousands in the early 1900s. Officials of the federal Mine Safety and Health Administration, part of the national government, keep a count for every year. In 1900, 1,489 coal miners died in accidents at work. The worst year was 1907, when 3,242 died. The count was still 2,063 in 1930, and it fell to 643 in 1950.

The yearly counts from 1900 through 2025 add up to about 105,000 coal miners who died in accidents. The counts do not include miners who died of disease from their work.

**Monongah.** Explosions in mines No. 6 and No. 8 at Monongah, West Virginia, killed 362 men by the official count on December 6, 1907. It is the worst mine disaster in American history. Later estimates run above 500, because the explosion destroyed the system that kept track of which miners were underground, so no one could make a full count.

Some of the dead were boys as young as eight. Mine companies of the time hired more workers than they listed, and their lists left out many of the children who worked underground. The dead included immigrants from Italy, Poland and Hungary, and Black workers. About 1,000 children lost a father.

**What went wrong.** Experts at the time did not agree on what set off the explosions. According to Clio, a history website run from Marshall University, a loaded coal car broke loose near the top of a trestle, a raised track, and ran back into mine No. 6. Some experts blamed torn electrical wires. Others blamed miners' lamps.

C. W. Watson was the president of the Fairmont Coal Company, which Clio names as the owner of the mines. He said the explosion "could only have been caused by the careless use of a mining lamp." The West Virginia Mine Wars Museum names a different owner, the Consolidation Coal Company. Neither history names anyone charged with a crime. After Monongah, members of Congress created the federal Bureau of Mines.

**Ludlow.** Colorado National Guard soldiers, the state's own force of part-time soldiers, killed striking coal miners and their families at Ludlow, Colorado, in 1914. The coal miners of southern Colorado had gone on strike in 1913, stopping work to demand changes. The coal they mined supplied Colorado's steel mill and its railroads. Most of them worked for the Colorado Fuel and Iron Company, whose main owner was John D. Rockefeller Jr.

The miners wanted the company's owners to obey Colorado's mining laws and to accept their union, the United Mine Workers, a group workers form so they can bargain with owners together. The strikers and their families lived in tent camps. Governor Elias M. Ammons sent the Colorado National Guard, and the mine owners agreed to pay for it.

Fighting broke out at the tent camp at Ludlow on April 20, 1914. No one knows who fired the first shot. Guardsmen burned the tents. At least 19 people were killed: one guardsman, five miners, and thirteen women and children. The women and children had hidden in a pit under a tent, and fumes from the burning filled the pit, so they died because they could not breathe.

Guardsmen killed three strike leaders who were under a flag of truce, a white flag that asks for a pause in fighting. They shot the strike leader Louis Tikas, a Greek American, three times in the back.

In the days after, miners attacked mines across the region and killed mine bosses and guards. No one knows how many people died in those days, but more died than at Ludlow. President Woodrow Wilson sent the US Army on April 28. The strike ended in December 1914, and the miners won none of the union's goals.

### Samuel Insull

> **Who:** Edison's former secretary, who tied more than 85 electric companies into one chain that collapsed in 1932.
>
> **When and where:** Chicago, 1892 to 1932.

**Tried three times after his companies failed, he was never found guilty.**

Samuel Insull built a chain of electric companies that served millions of people, and the chain collapsed in 1932. He had worked for Thomas Edison as his private secretary. In 1892 Insull took over the Chicago Edison company, and he built it into Commonwealth Edison.

**The chain.** Insull tied together more than 85 companies through holding companies, companies that own shares, or pieces of ownership, of other companies. Insull's companies owned shares in one another, and they had borrowed much of the money behind them. Many small investors bought shares in his companies.

**The fall.** Insull's companies failed in 1932, during the Great Depression, and investors lost millions of dollars. Insull fled to Europe. In October 1932 a grand jury in Chicago, a group of citizens who decide whether there is enough proof for a trial, charged him with crimes.

He moved to Greece, and officials there refused to send him back. In 1934, after US officials pressed them, Greek officials told him to leave. Officials of Turkey arrested him, and US State Department officers brought him back to the United States to stand trial.

He was tried three times. One trial was for fraud, cheating people by lying. Another was for embezzlement, stealing money that others had trusted him to handle. The third was for breaking federal bankruptcy law, the rules for what happens when a person or a company cannot pay its debts. He was found not guilty all three times.

Franklin Roosevelt, running for president, named Insull in a campaign speech in 1932. In 1935 members of Congress passed the Public Utility Holding Company Act, which they wrote to stop anyone from building another chain of electric companies like Insull's.

### Rivers into power, and who lost their homes

Federal officials had large dams built to make electricity from 1933 to 1945. In the Tennessee Valley alone, they made an estimated 82,000 people leave their homes to do it. A hydroelectric dam holds back a river, and water rushing down through the dam turns machines that make electricity.

**The TVA.** President Franklin Roosevelt signed the law that created the Tennessee Valley Authority, or TVA, on May 18, 1933. The TVA was a federal corporation, a company owned by the national government. Its board and staff ran it, and TVA officials had dams built in the Tennessee Valley. Before the TVA, about 3 in 100 families in the valley had electricity. Work on the first TVA dam, Norris Dam, began in October 1933.

**Who had to leave.** TVA officials bought or took about 1.3 million acres from their owners from 1933 to 1945, and they made those 82,000 people leave to make room for 16 hydroelectric dams. For Norris Dam alone, TVA officials made more than 3,000 families leave.

**The price.** TVA officials set the price of each piece of land, and an owner who would not sell at that price lost the land anyway. TVA lawyer John Snyder put it this way: "a price is set and we buy at that price or we condemn." To condemn land is to take it by law without the owner's agreement, at a price the government sets. TVA's own economists estimated that condemning land got it for about 60 percent of what a private buyer would pay.

The TVA's board and staff made these choices together. Wayne Moore's 1995 history of the TVA land-taking does not name one official who made them.

**Hoover Dam.** Hoover Dam stands on the Colorado River, between Arizona and Nevada, and it was one of the big federal dams that made electricity in these years. Its first generator began sending electricity over 266 miles of wire to Los Angeles on October 9, 1936. Some records date the start to October 26, 1936, the day that generator reached full operation. Chapter 12, Landmarks, tells how many men died building the dam.

**Grand Coulee.** Officials of the federal Bureau of Reclamation had Grand Coulee Dam built on the Columbia River, and it was finished in 1941. The dam stands 550 feet high, and its builders gave it no fish ladders, the rising pools that let salmon swim upstream past a dam. Salmon and steelhead, a trout that swims to the sea and back, could no longer reach the whole upper Columbia Basin, and their runs there ended.

The lake behind the dam flooded Kettle Falls, where Native people had fished for salmon for about 9,000 years. The catch there had averaged about 644,500 fish a year. Native people also lost thousands of acres of low, flat land beside the river where they grew food, and they lost their way to the places where they gathered roots and berries.

As the dam neared completion in June 1940, the Colville Confederated Tribes held a three-day Ceremony of Tears to mourn the loss of the fishery at Kettle Falls. Between 8,000 and 10,000 people came, from the Spokane, Yakima, Nez Perce, Coeur d'Alene and other nations.

### Osage oil

Some of the oil Americans burned in the 1920s came from under the Osage Nation's land in Oklahoma. Under the Osage Allotment Act of 1906, the Osage kept the rights to the oil and minerals under their land, owned in common. Each Osage person with a share, called a headright, received part of the oil money. Under a law passed in 1921, local judges put many Osage adults' money under the control of white guardians, people the judges chose to handle it.

**The murders.** From about 1920 to 1925, husbands, guardians and others killed Osage headright holders to inherit their shares of the oil money. A cattleman named William Hale planned to have members of one Osage family killed so that his nephew, Ernest Burkhart, would inherit their headrights. It was the family of Ernest's wife, Mollie. Federal agents later proved that Hale ordered the murders.

**Mollie's family.** Mollie Burkhart's mother was Lizzie Q. Kyle. Her sisters were Anna Brown and Rita Smith, and Rita's husband was Bill Smith. Henry Roan was Mollie's cousin.

**The killings.** Kelsie Morrison shot Anna Brown in May 1921. He later admitted that he killed her at Hale's request. Henry Roan was shot and killed in January 1923. A cowboy named John Ramsey admitted that Hale had hired him to kill Roan, though Ramsey later took back his confession.

A bomb blew up Rita Smith's home on March 10, 1923. It killed Rita, Bill Smith and Nettie Brookshire, who worked for them. Ramsey confessed that he took part in those murders too, and he named Hale as the leader, along with two other men.

**The sentences.** Ernest Burkhart admitted his guilt in June 1926 and got life in prison for the murder of Bill Smith. Morrison got life that November for killing Anna Brown. Burkhart testified against his uncle and Ramsey. Hale got life in January 1929, and Ramsey got life that November, both for the murder of Henry Roan. Chapter 2 tells how Osage leaders brought in the federal agents who solved the case.

**Not known:** whether Mollie's mother, Lizzie Q. Kyle, was poisoned when she died in July 1921, or by whom. Poison was suspected, but the Oklahoma Historical Society's and the FBI's accounts do not say.

**Disputed:** the number of dead. Writers for the Oklahoma Historical Society count about 24 violent or suspicious deaths, and the FBI's history of the case says at least two dozen. The Osage Nation counts more than 60 murders and suspicious deaths.

### The night the lights came on

Fewer than 11 farms in 100 had electricity from a central power station in 1935. A Tennessee farmer, whose name was not recorded, had said in 1930 that "the greatest thing on earth is to have the love of God in your heart." The next greatest thing, he said, "is to have electricity in your house." David Nye records the words in his book *Electrifying America*. In 1984 the national association of electric cooperatives named its history of the program *The Next Greatest Thing*.

**The REA.** President Roosevelt created the Rural Electrification Administration, or REA, on May 11, 1935, with Executive Order 7037, a rule a president issues on his own authority, without a vote of Congress. He signed the Rural Electrification Act on May 20, 1936. Under that law, REA officials made long-term, low-cost loans to cooperatives, businesses owned by the people who use them. Farmers' cooperatives used the loans to build power lines.

Louisan Mamer, who worked for the REA teaching farm families to use electricity in their homes, toured farm towns in the 1930s and 1940s with a traveling show called the electric circus. She showed families electric appliances and how to cook with electricity.

**Pedernales.** In the Texas Hill Country, power first ran through the lines of the Pedernales Electric Cooperative on October 27, 1939. The cooperative had 1,800 miles of line and 422 first customers. Families coming home that night saw their farmhouses lit for the first time. About half of American farms had electricity by 1945, about 9 in 10 by 1950, and about 97 in 100 by 1960.

### Pearl Yates

> **Who:** A country schoolteacher in western North Carolina who remembered when the lights first came on in her home.
>
> **When and where:** Haywood County, North Carolina, 1939.

**She and her children walked room to room, looking at the lights.**

Pearl Yates taught high school English in the countryside of western North Carolina. When the electric lights came on in her home, she walked from room to room with her small children. "We'd stop and look and they were so pretty and we'd go look at another room and another room," she said. The power reached her part of Haywood County in July 1939.

**Before the lines.** She cooked on a wood stove, and washing clothes took a whole day, in a large pot. Officials of the power company, Carolina Power and Light, would not run lines into the countryside where the Yates family lived, so people there formed a cooperative. Many neighbors did not trust it at first, because outsiders ran it and members had to pay money up front. Organizers went from door to door and signed many of them up.

Bonnie Bishop interviewed Pearl Yates and her husband, Oral Yates, a former North Carolina state lawmaker, on May 29, 1984. The interview was part of a set recorded for the 50th anniversary of the REA, and it is kept in the Southern Oral History Program at the University of North Carolina.

### Oil for a world war

Six of every seven barrels of oil the Allies used in World War II came from the United States. Writers at the American Oil & Gas Historical Society count about 6 billion of the 7 billion barrels.

**Pipelines.** Tanker ships carried oil from Texas along the coast, and German submarines were sinking them, so workers built two pipelines on land. The Big Inch, a pipe 24 inches wide, ran from East Texas to Illinois and on to the East, and it was finished in August 1943. Together with a second line, the Little Big Inch, it carried more than 350 million barrels of oil east before the war in Europe ended.

**If you remember one thing:** Electric wires reached almost every American home in these fifty years.

In 1890: About 8 American households in 100 had electricity.

In 1950: About 94 households in 100 had it, and about 9 farms in 10, most of them wired by farmers' own cooperatives after 1935.

**Next:** After 1950 Americans began splitting atoms to make electricity, and in 1973 a cutoff of foreign oil left drivers waiting in long lines for gasoline.

## 1950 to 2000

**Era 9 of 10 · 1950 to 2000 · about 12 minutes**

Splitting atoms became a new way to make American electricity after 1951, when a test reactor in Idaho lit four light bulbs. The first full-scale American plant built only for civilian power began sending electricity into a power company's lines in Pennsylvania in 1957. A reactor at Three Mile Island, also in Pennsylvania, partly melted in 1979, and after that American power companies stopped ordering new reactors.

Americans kept burning more oil and natural gas after World War II, according to the US Energy Information Administration. Officials of the Arab members of OPEC, a group of countries that sell oil, cut off oil sales to the United States in October 1973, and drivers waited in long lines for gasoline. Members of Congress then passed new energy laws and set up a federal Department of Energy, which opened in 1977.

### How does a nuclear power plant make electricity?

A nuclear power plant makes electricity from the heat of splitting atoms. Inside the reactor, the machine where the atoms are split, atoms of uranium split in two, and each split gives off a large amount of energy as heat. This splitting is called fission.

The fuel is uranium, a heavy metal dug out of the ground as ore, rock that holds a metal, and it sits in the core, the center of the reactor. The heat boils water into steam. The steam spins the blades of a turbine, a wheel with many blades, and the turbine turns a generator, which turns that motion into electric current.

**Four light bulbs.** A test reactor in Idaho called EBR-1 made the first usable electricity ever produced from nuclear energy on December 20, 1951. It lit four 200-watt light bulbs. The town of Arco, Idaho, about 1,200 people, ran on electricity from a nearby reactor called BORAX III for about an hour on July 17, 1955. Arco was the first town lit only by nuclear power.

**Shippingport.** President Eisenhower gave a speech called "Atoms for Peace" to the General Assembly of the United Nations on December 8, 1953. Work on a nuclear power plant at Shippingport, Pennsylvania, began in 1954. The plant sent its first electricity into the lines of Duquesne Light, a power company, on December 18, 1957. Five days later it reached its full power of 60,000 kilowatts, or 60 million watts. That was enough to light 300,000 bulbs like the ones EBR-1 lit.

Shippingport was the first full-scale nuclear power plant in the United States built only to make electricity for civilian use, meaning not for the military. It was not the first to make nuclear electricity. EBR-1 and smaller American reactors came before it, and so did reactors built for more than one purpose. A British plant, Calder Hall, began sending power in 1956.

### Garrison Dam and the Three Affiliated Tribes

Members of Congress paid for Garrison Dam on the Missouri River in North Dakota in 1947. The dam was part of the Pick-Sloan Plan of the Army Corps of Engineers, the part of the Army that builds dams and waterways. Under that plan, the dams were to stop floods and make electricity. The Army Corps was in charge of Garrison Dam, and it was finished in 1953.

**Under the lake.** The dam's lake, Lake Sakakawea, flooded the farmland along the river on the Fort Berthold Reservation, the home of the Mandan, Hidatsa and Arikara, called the Three Affiliated Tribes. It covered the river bottomlands, the low, flat lands beside the river where the tribes farmed. Counts of the flooded land run from 153,000 to about 155,000 acres.

Farms, homes, schools, a hospital, businesses, churches, cemeteries, roads and whole towns went under the water, among them Elbowoods, Sanish and Van Hook. By 1954 the Elbowoods school building stood under 50 feet of water.

**Who had to leave.** Under the federal act for taking the tribes' land, about 300 families had to leave their homes before the lake covered them. By one count, that was more than 90 percent of the tribes' people.

**How the land was taken.** Federal planners had chosen the dam's plan without asking the tribes. In May 1948 tribal leaders signed a contract giving up the tribes' land for $5,105,625. Tribal chairman George Gillette was in tears as he signed. He said the contract broke the Treaty of Fort Laramie, a signed agreement the tribes had made with the United States: "The truth is, as everyone knows, our Treaty of Fort Laramie ... and our constitution are being torn to shreds by this contract."

Members of Congress passed a law in 1949 that set out how the tribes would be paid for their land, and the president signed it. In 1950 the tribes' adults voted on whether to accept the terms of that law. Of the 991 adults, 525 voted yes. Tribal members feared that if they refused, they would be paid even less later.

**Not known:** whether a vote against the terms could have stopped the dam.

### Black lung and the 1969 law

An explosion at the Consol No. 9 coal mine in Farmington, West Virginia, killed 78 miners on November 20, 1968. Members of Congress then passed the Federal Coal Mine Health and Safety Act of 1969, which became law on March 30, 1970. Under it, federal inspectors had to check every underground coal mine four times a year and every surface mine twice a year, and they could close a mine where they found a danger to life. Miners with black lung disease could also get federal payments.

**What black lung does.** Black lung is a group of lung diseases caused by breathing coal mine dust. The body's defending cells try to break down the grains of dust and cannot, so the cells burst and release chemicals that damage the lung. Over the years, scar tissue and hard lumps form in the lungs.

Miners cough up dark, inky phlegm, the thick slime that comes up from the lungs. In the worst form, large masses of scar tissue fill the lungs, and the miner gasps for every breath. According to US Department of Labor figures reported in *Smithsonian* magazine in 2017, more than 76,000 miners had died of black lung since 1968.

Officials of the Mine Safety and Health Administration count the coal miners who died in accidents at work each year. They counted 311 in 1968, the year of Farmington, and 260 in 1970, the year the law took effect. By 2000 the count had fallen to 38, and in 2014 it was 16, the lowest ever recorded.

### 1973: the gasoline runs short

Officials of the Arab members of OPEC announced an embargo, an order that stops trade, on oil sales to the United States in October 1973. They acted because US officials were sending military supplies to Israel in the Yom Kippur War, which began on October 6, 1973, when Egypt and Syria attacked Israel's forces. The embargo lasted until March 1974. In about six months, the price of a barrel of oil rose from about $2.90 to $11.65, about four times as much.

**Long lines.** Gas stations ran out of gasoline, and drivers waited in long lines. Officials in many states let drivers buy gas only on certain days, by license plate number: cars with odd numbers on odd-numbered days, and cars with even numbers on even-numbered days. Members of Congress set a national speed limit of 55 miles an hour, which became law in January 1974. A US Department of Energy report gives the average price of gasoline as 39 cents a gallon in 1973 and 53 cents in 1974.

More energy laws followed. The Energy Policy and Conservation Act became law on December 22, 1975. Under it, federal officials set up the Strategic Petroleum Reserve, a store of crude oil, the oil that comes straight out of the ground, kept for emergencies.

The law also contained the first fuel-economy standards for cars, rules for how far a car must go on a gallon of gas. New cars had to average 27.5 miles per gallon by 1985, about twice what they got then. The federal Department of Energy opened on October 1, 1977.

### David Falconer

> **Who:** A government photographer who recorded Oregon's gasoline shortage in pictures and in his own captions.
>
> **When and where:** Oregon, October 1973 to May 1974.

**In Portland he photographed a man in line with a gas can.**

David Falconer photographed the gasoline shortage in Oregon and wrote down what he saw. He worked for Project DOCUMERICA, which officials of the Environmental Protection Agency started in 1972 to photograph environmental problems around the country. About 120 photographers took part, and the National Archives keeps Falconer's pictures and captions.

**Closed pumps.** At Sutherlin, on Interstate 5, he photographed closed pumps in October 1973. His caption states, "By midday gasoline was becoming unavailable along interstate highways." That month in Lincoln City, gas stations closed early and stayed closed on weekends, and "No Gas Today" signs went up.

**Portland.** In December 1973 he photographed a man who had run out of gas and was standing in line with a gas can. The man's name was not recorded. By February 1974, drivers there with even-numbered license plates lined up for gas on even-numbered days, Monday through Friday. Anyone could try on Saturday if gas was left, and all Portland stations closed on Sundays.

Falconer wrote that Oregon was the first state to use this odd-even plan. In May 1974, after the embargo had ended, he photographed a sign at a downtown Portland station saying its gas for the day was sold out.

### What went wrong at Three Mile Island?

A stuck valve let cooling water escape from the Unit 2 reactor at the Three Mile Island power plant in Pennsylvania on March 28, 1979, and the reactor's core overheated and partly melted down. It was the worst accident in American history at a nuclear power plant that sold its electricity. In a meltdown, the reactor's fuel gets so hot that it melts.

**The valve.** General Public Utilities ran the reactor. A small fault in the cooling system came first. Then a relief valve, a valve that opens to let out pressure, stuck open. The operators had no gauge that showed the valve was open, and they believed the system held too much water, so they cut back the water flowing into it. The core lost its water and overheated, and at least 45 percent of it melted.

Governor Dick Thornburgh advised pregnant women and preschool children living within 5 miles to leave on March 30, and he told people within 10 miles to stay indoors. Officials gave out messages that conflicted with each other. About 140,000 people left on their own.

A small amount of radiation escaped. Radiation is energy that substances such as a reactor's fuel give off, and it can damage the cells of the body. The average dose to people within 10 miles was 0.08 millisieverts, about the same as one chest X-ray. A millisievert is a unit that measures how much radiation a body takes in. No one got more than 1 millisievert, about a third of the radiation an average American gets from nature in a year.

Scientists at the Nuclear Regulatory Commission, the federal agency that oversees nuclear plants, and more than 12 health studies since 1981, found no health effects they could detect. No deaths are linked to the accident.

### Where the uranium came from

Miners dug uranium on Navajo land for the federal government and later for power plants. Federal officials did not warn them about radon, a gas from the uranium that caused lung cancer. Until 1966 the federal Atomic Energy Commission was the only buyer, and after that uranium was also sold to fuel power plants.

Miners dug nearly 30 million tons of uranium ore from Navajo land from 1944 to 1986, according to the Environmental Protection Agency. About 10,000 people worked in uranium, and about a quarter of them were Navajo.

**No warning.** Uranium gives off radon, a radioactive gas, which means it gives off energy that can damage the cells of the body. Navajo miners say that no one taught them about the dangers of uranium mining, and that no one gave them protective gear or fresh air in the mines.

A federal committee, the Advisory Committee on Human Radiation Experiments, reported in 1995 that "at least several hundred" uranium miners had died of lung cancer from breathing radon. Its members found that federal officials did not require the mine owners to pump fresh air into the mines. They also did not warn the miners.

**Church Rock.** A dam holding radioactive waste, owned by the United Nuclear Corporation, broke near Church Rock, New Mexico, on July 16, 1979, four months after Three Mile Island. About 94 million gallons of radioactive liquid and 1,100 tons of solid waste poured down the Rio Puerco, past about 1,700 Navajo people.

A 2013 study estimated that the spill released 46 curies of radioactivity, against 13 curies for Three Mile Island. Curies measure how much radioactive material was let loose. The millisieverts given for Three Mile Island measure something else: how much radiation a person's body took in. The US Geological Survey called the spill "the largest accidental radioactive release in the United States."

No official declared an emergency or ordered anyone to leave. A New Mexico state agency called the effects on people and the environment "quite limited," but its report also warned that water pumped out of the mines into the river might be a greater danger over time. Governor Bruce King turned down the Navajo Nation's request for a federal disaster declaration. Chapter 13, The Elements, tells the spill in full.

**Not known:** how many of the people living along the river were harmed by the spill.

### Panels on the White House roof

President Carter held a ceremony for 32 new solar panels on the roof of the West Wing of the White House on June 20, 1979. The panels used sunlight to heat water. They were in use for about seven years. In 1986, while President Reagan was in office, workers took the panels down to repair the roof, and no one put them back.

Some of the panels went to Unity College in Maine in 1991, where workers put 16 of them back up to heat water for the cafeteria. One panel went to the Smithsonian's National Museum of American History in 2009. Others are at the Carter Library and at a solar museum in Dezhou, China.

## 2000 to Today

**Era 10 of 10 · 2000 to Today · about 11 minutes**

Natural gas took coal's place as the fuel that makes the most American electricity. Drillers got more and more of that gas by fracking, which cracks rock deep underground to free the gas inside. Natural gas made more electricity than coal over a full year for the first time in 2016, according to the US Energy Information Administration, or EIA. Wind and solar power made a record share of the country's electricity in 2025, about 17 to 18 percent, by EIA figures.

Americans produced more energy than they used in 2019, for the first time since 1957. A winter storm shut down power plants across Texas in February 2021, and more than 4.5 million households lost power. A new nuclear reactor began running in Georgia in 2023, the first new American reactor to start since 2016.

### What is fracking?

Fracking, short for hydraulic fracturing, is a way of getting gas and oil out of rock deep underground. Drillers pump water, sand and chemicals down a well at high pressure. The pressure cracks the rock, and the sand holds the cracks open so that gas or oil can flow out. Many of these wells turn and run sideways through the rock for thousands of feet, which is called horizontal drilling.

**From Texas shale.** George Mitchell's company, Mitchell Energy, began working the Barnett Shale, a layer of rock made of hardened mud, in Texas in the early 1980s. Mitchell and his company spent about twenty years trying to get gas out of it. In the late 1990s an engineer, Nick Steinsberger, used a cheaper way of fracking called slickwater fracturing, which cut the cost enough that selling the shale gas made money. In the 2000s drillers joined fracking with horizontal drilling.

American wells produced 16 times as much shale gas in 2023 as in 2007, according to the EIA. By 2018 the United States was the world's largest producer of both natural gas and crude oil.

**The argument.** People disagree about fracking. Supporters say it brought cheaper energy and jobs. They add that natural gas burns cleaner than coal, and that power companies have replaced coal-burning plants with gas-burning ones.

Critics worry that fracking fluid can pollute groundwater and that methane, the main gas in natural gas, leaks from wells and pipes. Earthquakes are a third worry.

Drillers pump wastewater from oil and gas wells deep underground. Scientists at the US Geological Survey wrote in 2017 that the sharp rise in Oklahoma's earthquakes is widely seen as the result of that deep pumping of waste fluids. An earthquake near Pawnee, Oklahoma, measured 5.8 in magnitude, the number that states an earthquake's size, on September 3, 2016. It was the largest ever recorded in the state.

### Mine deaths and black lung

An explosion of gas and coal dust killed 29 miners at the Upper Big Branch mine in Montcoal, West Virginia, on April 5, 2010. It was the worst mine disaster in the United States in 40 years. Performance Coal Company, part of Massey Energy, ran the mine.

The federal Mine Safety and Health Administration's report on the explosion identifies Massey's "corporate culture," its habits and ways of working, as the root cause. Officials of the agency issued 369 citations and orders, written notices of broken safety rules, with fines of $10.8 million.

**The trial.** Massey's former chief executive, Don Blankenship, was convicted in December 2015 of conspiring, or planning with others, to break federal mine safety laws. It was a misdemeanor, a less serious kind of crime. Judge Irene Berger gave him the longest sentence the law allowed on April 6, 2016: one year in prison and a $250,000 fine. A year of supervised release followed, when a court officer checks on him. He was not convicted of causing the miners' deaths.

Black lung came back among coal miners in the 2000s. Researchers at NIOSH, the federal agency that studies workers' health, found 60 cases of the worst form of the disease in 20 months at one small clinic in Kentucky in 2016. Reporters at National Public Radio found 962 cases of advanced black lung in the 2010s, more than double the 441 cases NIOSH had recorded in the 40 years before. *Smithsonian Magazine* reported both counts in 2017.

### Standing Rock and the pipeline

Pumping more oil also meant moving it. A company called Energy Transfer Partners built the Dakota Access pipeline to carry crude oil from the Bakken oil field in North Dakota to Illinois. Members of the Standing Rock Sioux Tribe opposed it in 2016 where it crosses under Lake Oahe, upstream of their reservation. The lake is the tribe's water supply, and they feared that a spill would pollute it.

Protest camps began in April 2016. Army Corps of Engineers officials denied the easement for the crossing, the permission to cross federal land under the lake, on December 4, 2016. President Trump ordered the Army Corps to review and approve the easement quickly on January 24, 2017. Army Corps officials approved it on February 8, 2017, and oil moved through the pipeline later that year. The tribe's lawsuits continued.

### Natural gas, wind and solar, 2016 to 2025

Natural gas passed coal for a full year for the first time in 2016, when it made 34 percent of American electricity, according to the EIA. By 2025 it made about 41 percent, more than twice coal's share of about 17 percent. Nuclear power made about 18 percent.

**Renewables.** Wind, solar, flowing water and other sources that do not run out are called renewable energy. In 2025 they made about 24 percent of American electricity: wind about 11 percent, solar about 7 and hydropower, from flowing water, about 6.

Wind and solar together made a record share. The EIA's yearly report puts it at about 17 percent, but its rounded shares for wind and solar add up to 18, so the share was about 17 to 18 percent.

Analysts at the federal Bureau of Labor Statistics expect wind turbine service technicians to be the fastest-growing job in the country from 2024 to 2034, up 49.9 percent. Solar panel installers come second, up 42.1 percent. The two jobs together are projected to add fewer than 20,000 jobs.

**Electric cars.** Americans also began buying cars that run partly or fully on electricity: hybrids, which have both a gasoline engine and an electric motor, and battery electric cars, which run on electricity alone. According to the EIA, about 20 percent of the new cars, SUVs and pickups sold in 2024 were hybrids or electric, and in 2025 the share rose to about 22 percent.

But 2025 was also the first year that sales of battery electric cars fell. Federal tax credits for buyers of these cars, money taken off the buyer's tax bill, ended on September 30, 2025. In each of the months left in 2025, battery electric cars made up less than 6 percent of sales.

### Why did the Texas lights go out in 2021?

Texas power plants of every kind broke down in the cold during a winter storm named Uri in February 2021. To keep the state's whole power grid from failing, the people who run it cut off power to millions of customers. More than 4.5 million households, about 10 million people, lost power, some of them for days. Reports on the failure by federal energy regulators and by researchers at the University of Texas give these figures, and so do news reports.

**The grid.** The Electric Reliability Council of Texas, called ERCOT, runs the Texas grid, the network of power plants and wires that serves the state. Some of its gas, coal, nuclear and wind plants stopped working. ERCOT's operators cut 20,000 megawatts, a megawatt being a million watts. That was more than 300 times the 60 megawatts the Shippingport nuclear plant made in 1957, and the largest cutoff of its kind in American history.

ERCOT officials later said the grid came within 4 minutes and 37 seconds of a total collapse. Texas state health officials counted 246 deaths from the storm in 2022, but others have argued that the official count is much too low. Reporters at BuzzFeed News compared the number of Texans who died in the week of the worst blackouts with the number who would normally die. They estimated that about 700 people were killed by the storm in that week alone. Damage estimates run above $195 billion.

### Cristian Pavón Pineda

> **Who:** An 11-year-old sixth grader who died in his family's mobile home during the Texas blackout.
>
> **When and where:** Conroe, Texas, February 16, 2021.

**He had seen snow for the first time the day before.**

Cristian Pavón Pineda was 11 years old when he died in his family's mobile home in Conroe, Texas, on February 16, 2021. The home had been without power since the Sunday before, and the temperature there fell to about 10 degrees. Al Día News reported that he had seen snow for the first time the day before he died.

The family of five slept in one room to keep warm. Cristian shared a bed with his younger brother. His aunt, Jaliza Yera, told a TV station that he went to bed in "a shirt, a sweater, two pairs of pants, socks on." His stepfather put another blanket over him. In the morning his family could not wake him.

**The cause.** Early reports, and his family's lawsuit, said he died of hypothermia, which means the body's temperature has fallen too low to keep a person alive. But an autopsy, an examination of a body to find the cause of death, found on February 18, 2021, that he died of carbon monoxide poisoning, Conroe police said in May 2021.

Carbon monoxide is a gas with no color or smell that comes from burning fuel. When a person breathes it in, it stops the blood from carrying oxygen. Across Texas, more than 30 people had died in the storm by February 21, Al Día News reported. Many of them died of carbon monoxide poisoning after using cars or generators to keep warm.

**The lawsuit.** His mother, Maria Elisa Pineda Guzman, sued ERCOT and Entergy Texas, the power company, for more than $100 million on February 22, 2021. Her lawyer was Tony Buzbee. Officials had called the power cuts temporary rolling outages, planned cuts that move from area to area. The suit states that ERCOT and Entergy Texas did not give his family good enough information about how long the outages would last.

"Accurate information might have saved Cristian Pineda's young life," the suit states. In a statement, ERCOT officials called his death a "tragedy" and said they were "confident that our grid operators made the right choice to avoid a state-wide blackout."

**Not known:** where the carbon monoxide in the home came from, and how the lawsuit ended. Published reports do not say.

### New and restarted reactors

Two new nuclear reactors at the Vogtle plant in Georgia began selling power in 2023 and 2024: Unit 3 on July 31, 2023, and Unit 4 on April 29, 2024, according to the EIA. Unit 3 was the first new reactor to start in the United States since Watts Bar Unit 2 in Tennessee, owned by the TVA, began running in 2016.

Work on Watts Bar 2 had begun in 1973. Workers stopped building it in 1985 and started again in 2007, so the two Vogtle reactors were the first American reactors begun after the 1970s to start running.

**Palisades.** The owners of two closed plants plan to run them again. Holtec International owns the Palisades plant in Michigan, which shut down in May 2022, and it got a $1.52 billion federal loan to restart it. Its targets of 2025 and early 2026 passed without a restart.

Workers began loading fuel into the reactor in late August 2026. On August 30 a fuel assembly, a tall bundle of fuel rods, tilted while it was being loaded, and the loading was paused. Officials of the Nuclear Regulatory Commission, the federal agency that oversees nuclear plants, began a review, and their first results showed no radiation had escaped and no workers were harmed. Holtec's officials had given no date for the restart as of late September 2026, a Michigan TV station reported.

**Three Mile Island again.** Three Mile Island Unit 1 is the reactor that did not melt down in 1979, and it closed in 2019. It now carries the name Christopher M. Crane Clean Energy Center. Leaders of its owner, Constellation Energy, signed a 20-year agreement to sell its power to Microsoft. Members of the Nuclear Regulatory Commission are expected to decide in May 2027 whether to give Constellation an operating license, permission to run the reactor, the news outlet WITF reported in July 2026.

### What energy independence means

Americans produced more energy than they used in 2019, for the first time since 1957, according to the EIA. They produced less than 1 percent more than they used.

People call this energy independence: Americans produce more energy in total than they use. It does not mean Americans stopped buying fuel from other countries. In November 2019 Americans still bought nearly twice as much crude oil from other countries as they sold to them, by EIA figures.

Americans sold a record amount of energy to other countries in 2025, about one and a half times as much as they bought from them, the EIA reported in May 2026. Oil and products made from it were 63 percent of the energy sold abroad, and natural gas was 29 percent.

**The three questions, answered**

- Did kerosene really save the whales? No. Whaling was shrinking before kerosene came, and in most homes kerosene replaced camphene, after a Civil War tax on alcohol raised camphene's price.
- How did electricity reach almost every American home? Edison's Pearl Street station began selling current in 1882, and alternating current, which a transformer could raise or lower, carried power from Niagara Falls to Buffalo by 1896. After 1935 federal loans paid for farmers' own power lines, and by 1950, 94 households in 100 had electricity.
- Who paid for America's energy with their freedom, their land or their lives? Enslaved people fed the iron furnaces, at least 271 at Catoctin alone, and about 105,000 coal miners died in accidents from 1900 through 2025. Federal officials made 82,000 people in the Tennessee Valley leave their homes for dams, other dams flooded Kettle Falls and the Fort Berthold farmlands, and husbands, guardians and others murdered Osage people for their oil money.

**What changed:** Americans went from fires of wood to coal, oil, natural gas, the atom, the wind and the sun.

**Five dates to keep**

- February 11, 1808: Jesse Fell burns hard coal in his tavern fireplace.
- August 27, 1859: Drake's crew strikes oil in Pennsylvania.
- September 4, 1882: Edison's Pearl Street station starts selling electricity.
- December 6, 1907: The Monongah explosions kill at least 362 miners.
- 2016: Natural gas passes coal in making American electricity.

**Not known:** The surviving records of the early colonial iron furnaces list the owners, not the men who made the charcoal.

**Where to go:** The *Charles W. Morgan*, the last wooden whaling ship left in the world, is kept at the Mystic Seaport Museum in Mystic, Connecticut.

**Next:** Chapter 11, Transportation. It asks how Americans moved people and goods, from trails and canals to railroads, cars and planes.
