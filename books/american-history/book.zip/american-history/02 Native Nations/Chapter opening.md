# Chapter 2: Native Nations

**Chapter 2 of 37 · Native Nations · 10 eras · about 100 minutes**

**Native nations were governments long before the United States existed, and through every war, treaty and law aimed at ending them, 574 of them still govern themselves today.**

The Haudenosaunee (hoe-dee-no-SHOW-nee), five nations that had joined together under one council, recorded their first agreement with the Dutch on a belt of shell beads. It is called the Two Row Wampum, or Guswenta. Two purple rows of beads run along a white background. They stand for two boats traveling the same river side by side, with neither one steering the other. Haudenosaunee tradition dates the agreement to 1613.

This chapter follows the nations through ten eras. It starts before 1500, with cities and confederacies, groups of nations acting together, and ends in today's courtrooms and classrooms. Watch for the nations acting as governments. Their leaders make alliances, sign treaties, write constitutions, go to war and go to court. Against them, United States officials and soldiers take most of the nations' land, through removal at gunpoint, massacres and allotment, the cutting of a nation's shared land into private pieces. Officials also take children from their homes and send them to boarding schools. After 1950 the story turns. Nations win back schools, fishing rights and, in 2020, a reservation that five Supreme Court justices said had never ended.

**Three questions this chapter answers**

- How did Native nations govern themselves and deal with other nations before the United States existed?
- What did United States officials and soldiers do to take the nations' land and break the nations up?
- How did Native nations hold on to their governments, their languages and some of their land?

**Five minutes?** Read "Removal and the Trail of Tears" in 1800 to 1850.

**Can skip:** "Comanche power" and "Treaty councils" in 1700 to 1750, and "Ironworkers from Kahnawake" in 1900 to 1950. The chapter still makes sense without them.

## Before 1500

**Era 1 of 10 · Before 1500 · about 4 minutes**

The nations of this land governed themselves, traded and made war and peace for thousands of years before any ship came from Europe. At Celilo Falls, on the Columbia River, archaeologists, the scientists who dig up and study old camps and tools, date the first signs of people to at least 10,000 years ago. Some accounts say 15,000. In those thousands of years, some peoples built cities and later left them.

When Europeans first arrived, people in what are now the United States and Canada spoke more than 300 languages. That is the count of Lyle Campbell, a scholar who studies languages, in Britannica. He sorts them into 57 families of related languages, and 20 of those families were found only in California. The nations built towns and carried goods hundreds of miles to trade. They made agreements with other nations and fought wars against them.

Nobody knows how many people lived here before 1500. Scholars have used different methods and reached different answers. Their estimates for North America north of Mexico run from about 1 million to about 18 million, and no number is settled.

### Cities and kingdoms

People built Cahokia, the largest city north of Mexico, near where St. Louis, Missouri, stands today. They lived there from about 700 to about 1400. The city was biggest around 1100, when roughly 10,000 to 20,000 people lived in it. London had about as many people at the same date. Some estimates put as many as 50,000 in the country around the city.

**Why they left.** Cahokia's people had scattered by about 1350, and by about 1400 nobody lived there. Why they left is still argued. The causes put forward are drought, floods, and running short of the wood and food its people needed. No single cause is settled.

Ancestral Puebloan people, the ancestors of today's Pueblo peoples (*pueblo* is the Spanish word for town), built large stone buildings called great houses in Chaco Canyon, in what is now New Mexico. After long droughts, people began leaving Chaco around 1140, and by 1200 most of them had gone. They moved into the Pueblo communities of the Southwest.

The Calusa of southwest Florida built a kingdom without farming. Fish and shellfish fed about 20,000 people. Their capital, Calos, stood on mounds of shell at Mound Key. The Calusa kept live fish in pens with walls of shell, called watercourts. Scientists have dated the watercourts to between 1300 and 1400.

The Calusa also collected tribute, regular payments in goods, from other groups. Those groups lived along the coast from south of Tampa Bay down to the Florida Keys.

Traders carried turquoise, seashells, copper and obsidian, a black volcanic glass that chips to a sharp edge, hundreds of miles from nation to nation. Native trails crossed the continent, and later newcomers traveled along them.

The ancestors of the Navajo (Diné) and the Apache moved south toward the Southwest from what is now western Canada and eastern Alaska. Accounts differ about when they arrived. Some date the arrival to the 1200s, and others put it in the 1400s or as late as about 1525.

### How did five warring nations become one?

Five nations that had been fighting one another, the Mohawk, the Oneida, the Onondaga, the Cayuga and the Seneca, accepted an agreement called the Great Law of Peace, or Gayanesshagowa. Under it they formed one confederacy, the Haudenosaunee, a group of nations that keep their own governments but act together on matters they share. The five nations came together under one Grand Council.

According to Haudenosaunee tradition, two men brought the five warring nations together under the Great Law. They were the Peacemaker and Hiawatha. The Haudenosaunee kept the law in memory and recited it aloud. Instead of writing it on paper, they recorded it on wampum belts, shell beads woven into patterns in which each pattern stands for the terms of an agreement.

Scholars disagree about when the Confederacy began. Barbara Mann and Jerry Fields date the founding to 1142, from an eclipse of the sun described in the founding tradition. Most other estimates place the founding between the middle 1100s and the late 1400s, and many favor the middle or late 1400s.

Writers for the Library of Congress describe the Haudenosaunee Confederacy as one of the oldest democracies, governments in which the people have a say, still existing in the world.

Few records of single persons survive from these centuries.

## The 1500s

**Era 2 of 10 · The 1500s · about 9 minutes**

Spanish armies marched inland in the 1500s, and the diseases they carried reached many Native towns before the soldiers did. These expeditions were large armed groups traveling into country new to them. The diseases spread ahead of them and behind them. A town could lose many of its people before any European arrived there, and the diseases killed large shares of whole communities. Some writers call these deaths the Great Dying.

No one can give a single death toll, because the number of people living here at the start is not known. A death toll worked out from the lowest estimate, about 1 million, and one worked out from the highest, about 18 million, differ by millions of people.

United States census takers, the officials who count the people of the country, counted about 250,000 Native people in 1900. Even the lowest estimate for 1500, about 1 million, is four times that count. Disease killed many of the missing people. Over the four centuries after 1500, soldiers, settlers and militias killed many others in wars and massacres and while forcing whole nations off their land.

### The entradas

Spanish leaders called their armed expeditions into the north entradas. Hernando de Soto led one across the Southeast from 1539 to 1543. Francisco Vázquez de Coronado led another across the Southwest and the southern Plains from 1540 to 1542, with more than 300 armed Europeans and at least 1,200 Native allies.

De Soto sailed from Havana in May 1539 and landed in Florida with more than 620 men and 220 horses. For four years his men marched through the chiefdoms of the Mississippians, the town-building peoples of the Mississippi Valley and the Southeast in these centuries. Each chiefdom was a group of towns under a single ruler.

**What de Soto's men did.** They attacked the people of the towns on their route and forced people to work for the expedition. At the town of Hymahi, de Soto took all of the town's food. Later he burned at least one of its people to death while he questioned them about another town, Cofitachequi. His men also carried disease with them.

De Soto died of a fever in the spring of 1542, and the survivors of his expedition reached Mexico on September 10, 1543. His men were the first Europeans to see those chiefdoms, and almost the last. In the decades after they attacked the towns, forced the people to work and spread disease among them, the chiefdoms broke apart. Over the century that followed, the survivors regrouped and took in refugees, people who had fled their own towns. They formed the new nations and confederacies of the Southeast.

Spanish colonists also brought horses back to North America. Horses had lived here long before, but they had died out thousands of years earlier. Christopher Columbus carried horses on his second voyage, in 1493, and Spanish colonists brought more to the mainland through the 1500s. Coronado's expedition brought horses in 1540, and Juan de Oñate's colonists brought them to New Mexico in 1598.

### Paquiquineo (Don Luís)

> **Who:** A young man from the Chesapeake Bay country who came home with a Spanish mission in 1570 and then led an attack on it.
>
> **When and where:** Left the Chesapeake in 1561. Landed back on the James River in September 1570.

**He met the king of Spain, then spent nine years getting home.**

Paquiquineo left the Chesapeake Bay country on a Spanish ship in 1561, as a young man. The Spanish records do not settle whether he went willingly or was taken.

He appeared before King Philip II in Spain. In Mexico City he was baptized, made a member of the Christian church in a ceremony. He was given the name of the viceroy, the man who governed the colony for the king: Don Luís de Velasco.

He came home in September 1570. He landed on the James River as guide and translator for a small Jesuit mission, a group of priests from the Jesuit order of the Catholic church, with helpers, sent to turn people to Christianity. Father Juan Bautista de Segura led this mission.

**Back among his people.** Paquiquineo soon left the priests. A Jesuit's letter of 1572 states that he slept in their hut no more than two nights and then went to live with his brothers, a day and a half's journey away. One of the priests wrote that the people there had lived through six years of drought and famine, a long shortage of food. The priests were trading copper and tin to other villages for corn.

Paquiquineo led an attack on the mission in February 1571, and the attackers killed the missionaries. They spared the altar boy, Alonso de Olmos, who helped the priests at church services. The Spanish records do not state why Paquiquineo attacked. The anthropologist Seth Mallios argues that the priests' trading for corn broke his people's rules of gift-giving and insulted them.

**The Spanish answer.** Pedro Menéndez de Avilés, the Spanish governor of Florida, sent soldiers to the James River in August 1572. They captured some of Paquiquineo's people in a fight. The Spanish found several of the captives guilty of killing the missionaries and hanged them from the yardarms, the crossbeams on the masts, of their ship. The Spanish records do not give the names of the men they hanged.

The Powhatan people returned Alonso de Olmos to the Spanish. The soldiers did not find Paquiquineo. Spanish officials sent no more missions to the Chesapeake. English colonists landed at Jamestown, in the same country, 36 years after the mission, in 1607.

**Not known:** what became of Paquiquineo. European records after 1572 do not include him, and no story passed down by word of mouth that can be checked describes him.

### Acoma, 1598 and 1599

Juan de Oñate led Spanish colonists north from Mexico in 1598 and founded a colony in New Mexico, the country of the Pueblo nations. Acoma Pueblo, the town of the Acoma people, stands on a mesa, a hill with a flat top and steep sides.

**The paper.** Before any fighting, Oñate had gathered the Acoma elders for a ceremony in which they promised to obey the king of Spain. The Spanish wrote it down as the "Act of Obedience and Vassalage by the Indians of Acoma." (A vassal is a person bound to obey a ruler.) From then on the Spanish treated the Acoma as subjects of the king of Spain, bound by Spanish law. Spanish officials later used that paper to argue that their war on Acoma was legal.

Oñate's nephew Juan de Zaldívar came to Acoma in December 1598 with about thirty soldiers. He took some of them up the mesa to demand food. In the Acoma people's own account, as reporters for the Rio Grande Sun newspaper told it in 2019, the soldiers raped an Acoma woman, forcing her into sex.

The All Pueblo Council of Governors is a council of the leaders of the Pueblo nations. In a public statement in October 2023, its leaders said that the soldiers "had demanded food and supplies, assaulted an Acoma woman, and forced allegiance to the Spanish crown," which means the soldiers made the Acoma promise loyalty to the king of Spain. Then the Acoma killed Zaldívar and eleven to fourteen of his men. Accounts differ on the number.

Oñate opened a formal inquiry, an official hearing to find out what had happened, on December 28. He questioned the survivors of Zaldívar's party. He asked the Franciscan friars with him, Catholic religious brothers of the Franciscan order, whether a war against Acoma would be just. The friars answered that he "possessed both the authority and sufficient cause," which meant he had the right to make war and a good enough reason.

**The attack.** Juan de Zaldívar's brother Vicente led about seventy soldiers up the mesa in January 1599. Over two or three days of fighting, his soldiers killed Acoma men, women and children. They took the town and burned much of it.

Nobody counted the dead. The only detailed written story of the fighting by someone who was there is a long poem published in 1610 by Gaspar Pérez de Villagrá, a captain who rode with the expedition. He wrote it to praise the expedition.

Estimates of the dead run from about 300 to about 1,500. The figure given most often is about 800 Acoma men, women and children, and it is the figure the leaders of the All Pueblo Council of Governors use today. The National Park Service's figure is about 1,500.

Vicente de Zaldívar's soldiers captured about 500 Acoma men, women and children. One record gives the number put on trial as 507. Oñate tried them at Santo Domingo Pueblo, though some accounts place the trial at San Juan Pueblo.

**The sentences.** Oñate passed sentence on February 12, 1599. He sentenced men over twenty-five to have one foot cut off and to be forced to work for the Spanish without pay for twenty years. Males from twelve to twenty-five, and females over twelve, got the same twenty years of forced work. He sentenced the old people to be handed over as slaves to the Plains Apache.

Oñate sentenced two Hopi men captured in the fighting to have their right hands cut off. Then he had them released to carry word of the punishment to their own people.

Oñate declared the Acoma children under twelve innocent. He still ordered them taken from their parents and handed to the friars. On Oñate's order, Acoma girls under twelve were sent south along the road to Mexico, to convents there, houses of nuns, women who have promised their lives to the Catholic church. Neither the National Park Service's account nor the Pueblo council's statement names the men who took the girls.

**How many.** The two accounts differ on the number. The National Park Service's account records about seventy girls. The Pueblo council's 2023 statement records sixty children taken to Mexico and states that none of them returned. The National Park Service's account states that almost certainly none ever came home. According to PBS, some scholars believe the children were later sold as slaves.

**The feet.** Oñate's sentence is in the written record. Whether anyone carried out the cutting of feet is disputed. Acoma people have passed down their own account since 1599: Oñate had the right feet of 24 captive men cut off. The New York Times reported that account in 1998. Two historians who worked for years in these records doubt that the feet were cut off. Marc Simmons first wrote that they were, and he later came to doubt it. John Kessell notes that no record describes a one-footed Acoma man.

Spanish officials charged Oñate with thirty crimes. Accounts date the charges to 1612 or 1613 and the judges' decision to 1614. The judges found him guilty of twelve, among them using too much force against Acoma. They banished him from New Mexico for life, ordering him never to return. They also barred him from Mexico City for four years (PBS gives five) and fined him 6,000 ducats, Spanish gold coins.

Oñate had rebuilt a fortune in his family's mines at Zacatecas. Rebecca Carlson, who wrote about his trial in a 2008 university paper, calls the fine unimportant to him. He spent years working to have the decision undone. Accounts differ on whether the king ever pardoned him, which means officially forgave him. Carlson writes that he was pardoned in 1623. Other accounts say the proof of a pardon is unclear.

## The 1600s

**Era 3 of 10 · The 1600s · about 12 minutes**

Native nations still held nearly the whole continent through the 1600s. Along the eastern coast, the European settlements were a thin strip. Those settlers needed food and trade from the nations around them, and they stayed only as long as those nations let them. In New Mexico, Spanish colonists had ruled the Pueblo nations by force since 1598. Native leaders chose which newcomers to deal with, the Dutch, the French, the English or the Spanish, and used each group's rivalry with the others to bargain.

Haudenosaunee leaders made alliances with the newcomers and recorded them on wampum belts. In New England, English colonists fought two wars against coastal nations, the Pequot War of 1636 to 1638 and Metacom's war of 1675 and 1676. In the Southwest in 1680, the people of the Pueblo nations rose together and drove the Spanish off their land. They kept the Spanish out for twelve years.

### Who ruled the land where Jamestown stood?

Wahunsenacawh ruled the country where English colonists founded Jamestown in 1607. He had inherited rule over six tribes in eastern Virginia and built them into a group of more than thirty tribes that paid him tribute. His country was called Tsenacommacah. The English called him "the Powhatan." His own title was mamanatowick, or paramount chief, a chief whom other chiefs answer to.

About 15,000 people lived in his country, spread across some 10,000 square miles between the James River and the Potomac. Each tribe there was a people with its own leader, called a weroance, and each weroance paid tribute to Wahunsenacawh.

### Wampum diplomacy and the Covenant Chain

Haudenosaunee diplomats, the people who spoke for their nations with other nations, recorded agreements on wampum belts. Speakers kept the words of each agreement in memory, and the pattern of the belt recorded its terms.

The Two Row Wampum, Guswenta, records the Haudenosaunee account of their first agreement with the Dutch: two boats side by side on one river, neither one steering the other. A paper document dated 1613, the year Haudenosaunee tradition gives for the agreement, also exists, and accounts differ about whether it is genuine.

The Haudenosaunee alliance with the English colonies was called the Covenant Chain, from covenant, a serious promise. The oldest surviving record of the Silver Covenant Chain dates from 1677. That year Haudenosaunee leaders and the New York governor, Edmund Andros, made the alliance official at Albany.

**Polishing the chain.** Silver tarnishes, turning dark over time, so a silver chain has to be polished to stay bright. Haudenosaunee and English leaders "polished" the Covenant Chain again and again. They renewed the alliance at councils, with speeches and wampum.

### The coastal wars

In Connecticut, English colonists and their Mohegan and Narragansett allies fought the Pequot from 1636 to 1638. The war began with the killing of two English traders. Pequot men killed one trader and his crew in 1634. In 1636 people from Block Island, who were not Pequot, killed the other. The leaders of Massachusetts Bay sent 90 soldiers in answer, and the soldiers burned the Block Island villages and then a Pequot village.

**Mystic.** An English-led force set fire to the walled Pequot town at Mystic before dawn on May 26, 1637. In under an hour they killed hundreds of people, most of them elders, women and children.

The English colonists and their Mohegan and Narragansett allies ended the war with the Treaty of Hartford of 1638, a treaty being a formal written agreement between nations. In it the winners declared that the Pequot nation no longer existed and made it illegal to use the name Pequot. Under the treaty, they took Pequot survivors for themselves or sold them into slavery. The Mashantucket Pequot Tribal Nation is in Connecticut today.

**Sold overseas.** Colonists had already begun selling captives during the war. Captain William Peirce sailed the ship *Desire* out of Boston in July 1637 with seventeen Pequot captives, fifteen of them children. Governor John Winthrop of Massachusetts wrote, "We sent fifteen of the boys and two of the women to Bermuda, by Mr. Pierce." Peirce sold them in the Caribbean.

Metacom, the Wampanoag sachem, or leader of the nation, led a coalition of nations, a group that agreed to act together, against the New England colonies. His coalition fought the colonists from 1675 to 1676, nearly forty years after the Pequot War.

The war began in June 1675, just after a hanging at Plymouth. A jury of English colonists there had found three Wampanoag men guilty of murdering John Sassamon, a Christian Native man. By report, Sassamon had warned Plymouth's governor that Metacom's men planned an attack. Plymouth officials hanged two of the three men on June 8 and shot the third a month later.

**The toll.** About 9,000 people died in all, and estimates put Native deaths at roughly half of all the Native people in New England. By one estimate, about two of every three of the dead were Native people, and many of them starved. For the size of the population, writers for Britannica and other histories call it the bloodiest war in American history.

The men who governed the Massachusetts colony ordered on October 13, 1675, that Native people from the praying towns, villages of Native people who had become Christians, be taken to Deer Island in Boston Harbor and kept there. The colonists feared these people would turn against the English and join Metacom. Colonists took the people of Natick to the island first.

**Deer Island.** The National Park Service puts the number held there at about 500 to 1,100, most of them women and children. They had too little food and shelter through a freezing winter. The two accounts of the deaths differ. The National Park Service says that very few of them survived. The Partnership of Historic Bostons, a Boston history group, says that more than half of them died over the winter.

Colonists released the survivors in May 1676. An unknown number had been smuggled off the island and sold as slaves in the West Indies or in Tangier, in North Africa. No surviving record names the men who voted for the island prison, and the National Park Service's account does not name the men who sold the captives. Every year, descendants of the nations in the war hold a gathering on Deer Island to remember them.

Inland, from the middle to the late 1600s, Haudenosaunee warriors fought the Beaver Wars against nations to the west and north. They fought for control of the fur trade, the trade in animal furs with Europeans. More than 1,000 Seneca and Mohawk warriors attacked the two main towns of the Wendat, also called the Huron, in 1649. The warriors destroyed the Wendat nation as a single people.

Some Wendat survivors fled to Quebec, and others went to the Neutral nation. Haudenosaunee warriors defeated the Neutral in 1651. They absorbed the Erie in 1657, taking the Erie survivors into the Haudenosaunee nations. By 1675, the writers of the Canadian Encyclopedia say, they had absorbed the Susquehannock to the south and moved west into the Ohio Valley.

### Metacom (King Philip)

> **Who:** Wampanoag sachem, son of Massasoit, who led the coalition war of 1675 and 1676 against the New England colonies. The English called him King Philip.
>
> **When and where:** Southern New England. Killed at Mount Hope, August 12, 1676.

**"Philip's boy goes now to be sold," a minister wrote in 1677.**

Metacom's father, Massasoit, had made an arrangement with the Plymouth colonists in 1621. In 1675 Metacom took a coalition of nations to war against the New England colonies. The company of the Plymouth captain Benjamin Church captured Metacom's wife and his nine-year-old son in early August 1676.

**Mount Hope.** A Native man named Alderman, who was serving with Church's company, shot Metacom dead at Mount Hope on August 12, 1676. Church wrote his own account of what came next. He ordered that "not one of his bones should be buried," because Metacom had left English dead unburied. Church told a Native man he called his "old Indian Executioner" to cut off Metacom's head and to quarter his body, cutting it into four pieces.

Church gave the head and one of Metacom's hands to Alderman, who showed the hand to colonists who paid him to see it. Plymouth's leaders paid Church's men thirty shillings, a sum in English money, for each enemy they had killed or captured, and they paid the same for Metacom's head. At Plymouth the head was set on a pole. Church's book does not say who put it there. By the account of a later editor of Church's book, it stayed there for more than 24 years.

**The boy.** The leaders of Plymouth Colony asked ministers what to do with Metacom's son. Two ministers, Samuel Arnold and John Cotton, wrote on September 7, 1676, that the children of such enemies could be put to death. Cotton wrote the line about "Philip's boy" in a letter in March 1677. The boy and his mother were sold into slavery. Cotton's letter does not say who sold them. Most accounts say the two were sent to Bermuda, and others say they were sent to the West Indies.

Colonial leaders sold hundreds of other captives into slavery to pay what the war had cost the colonies. The selling began early in the war. On August 4, 1675, the men of Plymouth's council of war ruled that 112 Native men, women and children held at Plymouth were "to be sold," and they named the colony's treasurer to sell them.

A month later the council condemned 57 more people to slavery for life. Church wrote that these people had surrendered because of promises made to them, and that about 160 in all were "sold, and transported out of the Country."

### The Pueblo Revolt

The people of the Pueblo nations along the Rio Grande drove the Spanish out of New Mexico in 1680. They had lived under Spanish rule since Juan de Oñate founded the colony in 1598.

**The arrests.** The Spanish governor, Juan Francisco Treviño, ordered 47 Pueblo religious leaders arrested in 1675. The Spanish called their religious practice sorcery, using magic to do harm. Spanish officials sentenced four of the leaders to be hanged. Three were hanged, and the fourth killed himself. Spanish officials whipped the others in public and put them in prison. Pueblo people went to Santa Fe and demanded that the prisoners be freed, and the Spanish let them go. One of the freed leaders was Po'pay.

The people of many separate towns rose against the Spanish on the same day, August 10, 1680. They spoke Tewa, Tiwa, Towa, Tano, Keres and other languages, and the Zuni and the Hopi also promised to help. Pueblo fighters besieged Santa Fe, surrounding the town and cutting it off. They took the town and drove the Spanish out of New Mexico. In the rising they killed 401 settlers and 21 Franciscan friars. The Pueblo fighters let most of the Spanish leave, and the Spanish went south.

The Pueblos governed themselves for the next twelve years, through drought, raids and famine, a long shortage of food. Diego de Vargas led Spanish forces back into New Mexico in 1692 to retake it, and Pueblo fighters kept up armed resistance for years after that. Writers of the EBSCO Research Starters history guide call the Pueblo Revolt the most successful uprising by Native people against European rule in North America.

### Po'pay (Popé)

> **Who:** A Tewa religious leader from Ohkay Owingeh who organized the 1680 rising across dozens of towns and several languages.
>
> **When and where:** New Mexico, August 1680.

**Knotted cords counted down the days to the rising.**

Po'pay had to get the people of dozens of towns to rise on a single day, and the people of those towns did not all speak the same language.

Pueblo accounts say that runners carried knotted cords from town to town. The knots on each cord marked the days left until the rising. Po'pay set the rising for August 11, by one account, or August 13, by another.

**The runners.** The Spanish captured two of the runners, Pedro Omtua and Nicolás Catua of Tesuque Pueblo, on August 9. Spanish officials tortured them, hurting them on purpose to force them to explain the knotted cords. The Smithsonian's account of the runners does not say how they were hurt. Later the Spanish hanged them. No surviving record names the men who did it.

When Po'pay learned that the runners had been caught, he ordered the rising to begin early. It began on August 10, 1680.

A statue of Po'pay stands in the United States Capitol. It is one of New Mexico's two statues in the Capitol's Statuary Hall collection, which holds statues of two people from each state's history.

### Where the Plains horses came from

When the Spanish went south out of New Mexico in 1680, they left their horses. An estimated 1,500 or more horses passed into Native hands at once. Writers for the Smithsonian's National Museum of the American Indian call it the largest single transfer of horses. According to the traditional account, Native people then traded horses west and north along Native trade routes. The horses reached the Ute, the Navajo, the Apache, the Comanche, the Kiowa, the Shoshone and the nations of the northern Plains.

**A newer finding.** A team led by William Taylor published a study in the journal *Science* in 2023, and its findings do not fit this account. Lakota, Comanche and Pawnee people were among the study's writers, and other Native partners worked on it too. The team used radiocarbon dating on the remains of horses from Wyoming, Kansas and New Mexico. Radiocarbon dating measures a form of carbon that breaks down at a steady rate, so the amount left shows how old a bone is.

The horses had been ridden and had eaten corn that people fed them. They had also worn bridles, straps around a horse's head used to steer it. They were there by the early 1600s, decades before the revolt. Native oral histories, accounts passed down by telling, had said the same thing.

**Known:** Plains nations had horses by the 1700s.

**Not known:** whether most of their horses came from the Spanish herds left in 1680 or had spread north decades earlier.

## 1700 to 1750

**Era 4 of 10 · 1700 to 1750 · about 3 minutes**

Haudenosaunee leaders bargained with French and British officials for fifty years, because both sides wanted Native allies. Native nations also went on making their own agreements with one another.

The Haudenosaunee accepted the Tuscarora as a member nation in these years, after South Carolina forces had defeated the Tuscarora and colonists had taken their land in North Carolina. On the southern Plains, the Comanche built the strongest power in the region on horses and trade.

The printed speeches of the Onondaga speaker Canasatego, from these years, are among the best records of Native diplomacy, the work of dealing with other nations through talks and agreements, from that century.

### Staying neutral

About 1,300 delegates, people sent to speak for their nations, came from more than thirty nations to meet at Montreal on August 4, 1701. There they made peace with the leaders of New France, the French colony in what is now Canada. As part of the same peace, the Haudenosaunee promised to stay neutral. That meant they would fight for neither France nor Britain.

For half a century, Haudenosaunee leaders used their neutrality to bargain with both sides.

### How did the Five Nations become six?

The Five Nations of the Haudenosaunee became six after the Tuscarora lost a war, and their land, in North Carolina. The Tuscarora moved north and asked to join them.

**The war.** More than 400 Swiss and German settlers, led by Baron Christoph von Graffenried, founded the town of New Bern, North Carolina, on Tuscarora land in 1710. They pushed the people of the Native town of Chattoka off the spot where the Neuse and Trent rivers meet. Slave raiders were also capturing Tuscarora people to sell them as slaves. The State Library of North Carolina's history of the war does not name the raiders.

Tuscarora fighters struck back on September 22, 1711, in attacks they had planned together. The war lasted until 1713. South Carolina colonial forces, with Native allies of their own, defeated the Tuscarora. By that library's count, 1,400 Tuscarora were dead and 1,000 had been captured and enslaved.

About 1,500 Tuscarora survivors then moved north, roughly 500 miles. They asked the Five Nations of the Haudenosaunee to sponsor them, which meant to speak for them and accept them. The Oneida took them in. In 1722 the whole Tuscarora nation became the sixth nation of the Haudenosaunee Confederacy. Since then the Confederacy has had six member nations, and it is also known as the Six Nations.

### Comanche power

The Comanche moved onto the southern Plains in the early 1700s and became the most powerful nation there. Comanchería, the country they controlled, later covered about 240,000 square miles. That is twenty-four times the size of Wahunsenacawh's country in Virginia.

The Comanche built their power on horses. They bred, trained and traded horses, and they controlled the horse trade from the southern Plains to the northern Plains. In the 1740s they traded bison robes and horses to French traders for guns, which were better than the weapons the Comanche could get from the Spanish. Comanche fighters also raided other peoples, making quick attacks to seize goods, horses or people. Comanche leaders made agreements with other nations as well as fighting them.

### Treaty councils

At treaty councils, Native leaders and colonial officials met to bargain and make agreements. Speakers on both sides made speeches and exchanged wampum.

At Lancaster, Pennsylvania, in June and July of 1744, colonial officials paid the Haudenosaunee to give up their claims to the Shenandoah Valley.

### Canasatego

> **Who:** Onondaga leader and the Haudenosaunee's speaker at treaty councils, whose 1744 speech on union Benjamin Franklin printed.
>
> **When and where:** Lancaster, Pennsylvania, June and July 1744. He gave the union speech on July 4, 1744.

**On July 4, 1744, he told the colonies to unite.**

Canasatego spoke for the Haudenosaunee Confederacy at treaty councils with colonial officials. He closed the council at Lancaster by advising the colonies to unite, as his own nations had done centuries earlier: "We heartily recommend Union and a good Agreement between you our Brethren... you, as well as we, will become the stronger."

Benjamin Franklin printed the minutes of the council, the written record of what was said there, including the speech.

## 1750 to 1800

**Era 5 of 10 · 1750 to 1800 · about 7 minutes**

French and British armies fought their wars on Native land after 1750. Then the leaders, soldiers and settlers of a new country, the United States, moved onto that land and fought the nations for it.

When British forces beat the French in 1763, Native nations lost the second empire they had bargained with against Britain. Then the colonists went to war with Britain in the American Revolution. The Haudenosaunee nations took different sides in that war, and their Confederacy split for the first time in centuries. During the war, in 1778, United States officials signed their first treaty with a Native nation. In 1791 fighters from a confederacy of nations in the Ohio Country destroyed a United States army.

### Pontiac, smallpox and the Line

French and British commanders both needed Native allies in the French and Indian War, which lasted from 1754 to 1763. A loose confederacy of nations from the Great Lakes, the Illinois Country and the Ohio Country rose against the British in 1763. Under the Odawa leader Pontiac, their fighters took or besieged British forts across the west. Pontiac lifted his siege of Detroit in October 1763, but the fighting went on until 1766.

**Fort Pitt.** British officers at Fort Pitt tried to give smallpox, a disease that spreads from person to person and can kill, to the Native fighters around them in 1763. Delaware, Shawnee and Mingo fighters had besieged the fort, where Pittsburgh stands today, and smallpox had broken out among the British soldiers inside.

**The blankets.** The fort's commander, Captain Simeon Ecuyer, and the trader William Trent gave two Delaware men, Turtle's Heart and Mamaltee, two blankets and a handkerchief from the fort's smallpox hospital on June 24, 1763. Trent wrote in his journal, "I hope it will have the desired effect." In July the British commander in North America, General Jeffery Amherst, asked Colonel Henry Bouquet in a letter whether smallpox could be sent among the nations at war. Bouquet answered that he would try to spread it with blankets.

**Whether it worked.** A month after the June meeting, Trent saw the two Delaware men again, and they showed no sign of smallpox. A man named Gershom Hicks later said that about 100 Native people died of smallpox between the spring of 1763 and April 1764. The historian Elizabeth Fenn writes that no one can know whether the attempt to spread smallpox worked.

**The Line.** British officials answered the war by drawing a line. They issued the Royal Proclamation, an official public announcement of an order, on October 7, 1763. In it they forbade colonists to settle west of the Appalachian Mountains, and they set aside the land beyond for the Native nations. Colonists were angry about the line and crossed it anyway. Writers for Encyclopedia Virginia call the Proclamation a foundation of later treaty law, the set of rules for agreements between governments.

### The Conestoga killings

While Pontiac's war went on, settlers in Pennsylvania attacked Native people who were not fighting in it. Armed settlers from Paxton Township killed the twenty Conestoga people who lived in a small town near Lancaster in December 1763. The Conestoga were unarmed. Fifty-seven men came at daybreak on December 14 and found three men, two women and a boy at home. They shot them, stabbed them and killed them with hatchets.

One of the dead was Shehaes, a very old man who had helped make a treaty with William Penn in 1701. They killed him in his bed. The attackers scalped all six, cutting away the skin and hair from the top of each head, and burned the huts.

**The workhouse.** To keep them safe, Lancaster's officials put the other fourteen Conestoga in the town workhouse, a building where poor people were made to work. Franklin called it "a strong Building." On December 27 about fifty men broke down the workhouse door and killed all fourteen with guns and hatchets, children a year old among them.

The Paxton men claimed the Conestoga had hidden enemy spies. The historian Michael Goode writes that the charge was made up. British soldiers stationed nearby did nothing to stop the killings, and no one was ever put on trial for them. Benjamin Franklin wrote down the names of the dead in 1764.

### The Revolution splits the Haudenosaunee

Under the Great Law, the Five Nations, and then the Six, had stayed united for centuries. In the American Revolution they split. The Oneida and the Tuscarora sided with the Americans. The Mohawk, the Seneca, the Cayuga and the Onondaga fought with the British. Many of them fought under the Mohawk leader Joseph Brant, whose own name was Thayendanegea. At the Battle of Oriskany, on August 6, 1777, Haudenosaunee men fought on both sides.

George Washington ordered an expedition into Seneca and Cayuga country in 1779. In his written orders, he directed "the total destruction and devastation of their settlements." From July 31 to October 15, General John Sullivan's soldiers burned more than forty Seneca and Cayuga towns and the crops in their fields. Thousands of people fled to the British at Fort Niagara. That winter many of them starved or froze to death there.

Seneca chiefs spoke to Washington directly in 1790. "When your army entered the country of the Six Nations, we called you the Town-destroyer," they said. They told him that "to this day, when that name is heard, our women look behind them and turn pale." The name was older than the burning of their towns. Washington had been given the name Conotocaurius, Town Destroyer, in 1753, and his great-grandfather had been given it before him.

### The treaty system begins

United States officials signed their country's first treaty with a Native nation at Fort Pitt on September 17, 1778. The Lenape leaders White Eyes, John Kill Buck Jr. and Pipe signed for their nation, which the treaty calls the Delaware. In the treaty, the American officials recognized Lenape sovereignty, the right of a nation to govern itself. They also asked the Lenape to let American troops cross their land safely.

**A fourteenth state.** The negotiators raised the idea of a Native fourteenth state, which would join the thirteen and send its own representatives to Congress. No one in Congress ever acted on that idea.

In all, United States officials and Native leaders made 374 treaties that were formally approved, or ratified. The last of them date from the 1860s. The National Archives holds all 374, and its archivists, the people who keep its records, have put every one online. Each of the 374 is an agreement between the United States and a Native nation.

### The Northwest Confederacy

North of the Ohio River, the nations built a confederacy to defend their country. Its leaders included Little Turtle of the Miami, Blue Jacket of the Shawnee and Buckongahelas of the Lenape.

About a thousand confederacy fighters fought the army of General Arthur St. Clair on November 4, 1791. About 930 of his soldiers began the fight, and the confederacy's fighters destroyed his army. Counts of the soldiers they killed run from more than 630 to more than 650, and counts of the wounded from 264 to more than 270. Of every 100 soldiers who fought, about 97 were killed or wounded. No battle in the history of the United States Army has had a higher share.

Native casualties, the killed and wounded together, were roughly 100. St. Clair's defeat is still the largest defeat Native forces have ever given a United States army, larger than the Battle of the Little Bighorn, fought 85 years later. After the defeat, members of Congress held the first investigation by Congress in the country's history.

Anthony Wayne led a legion, an army unit of 3,300 men, against the confederacy in 1794. Wayne's legion defeated the confederacy at Fallen Timbers, near where Toledo, Ohio, stands today, on August 20, 1794. The confederacy's leaders had lost the war. At Greenville, on August 3, 1795, they signed a treaty with Wayne, who signed for the United States, and in it they signed away most of Ohio and part of Indiana.

### Little Turtle (Mishikinaakwa)

> **Who:** Miami war leader who co-led the confederacy that destroyed St. Clair's army in 1791, then decided the war could not be won and argued for peace.
>
> **When and where:** The Wabash and Maumee country, in present-day Indiana and Ohio, in the 1780s and 1790s.

**He beat two American armies, then argued for peace.**

A year before St. Clair's defeat, in 1790, warriors led by Little Turtle beat another American army, under General Josiah Harmar.

After the confederacy lost at Fallen Timbers in 1794, Little Turtle decided that the war could not be won. He signed at Greenville the next year and spent his last years arguing against more war with the United States.

At his urging, members of Congress passed a law in 1802 that let the president stop traders from selling liquor to Native nations. War Department officials then banned traders from bringing alcohol onto Native land, but they did little to enforce the ban.

## 1800 to 1850

**Era 6 of 10 · 1800 to 1850 · about 9 minutes**

East of the Mississippi River, Native leaders tried several ways to keep their nations' land. North of the Ohio River, people from many nations joined a confederacy and fought American armies. In the Southeast, Cherokee leaders wrote a constitution, a written plan for their government and its basic laws, and took their fight to court. In Florida, Seminole fighters went to war against removal.

Two Shawnee brothers, Tecumseh and Tenskwatawa, built the northern confederacy around one idea. Tecumseh said that the land belonged to all the nations together, so no single nation could sell any part of it. Soldiers under the American commander William Henry Harrison burned the confederacy's center in 1811, and American soldiers killed Tecumseh in battle in 1813.

The Cherokee changed their nation fast in the eleven years from 1821 to 1832. Sequoyah showed a way to write the Cherokee language in 1821. Cherokee leaders approved their constitution, with three branches of government, in 1827, and the nation began printing a newspaper the next year. Then, in 1832, Chief Justice John Marshall, the head of the Supreme Court of the United States, wrote the court's ruling in the Cherokee Nation's favor.

Members of Congress passed the Indian Removal Act in 1830. Under it, United States soldiers forced the nations of the Southeast out of their homes and moved them west. In the Cherokee removal alone, soldiers held about 16,000 people in stockades, pens fenced with upright logs, and more than 4,000 of them died of cold, hunger and disease. In the West, the people of those nations built their governments again.

### Tecumseh and Tenskwatawa

A Shawnee man named Tenskwatawa began preaching around 1805 that Native people should return to Native ways of living. People called him the Prophet. His brother Tecumseh took the movement to other nations and asked them to join it. In 1808 the brothers built a town on the Wabash River as the center of a confederacy of many nations. The town was called Prophetstown.

William Henry Harrison, an American governor, was buying Native land through treaties. Native leaders signed the Treaty of Fort Wayne with him in 1809 and sold him land.

**At Vincennes.** Tecumseh answered Harrison at Vincennes in August 1810. The land, he said, "never was divided, but belongs to all for the use of each." He added, "No part has a right to sell, even to each other, much less to strangers." He called the latest sale "bad," because "it was made by a part only." By that argument, the Fort Wayne sale counted for nothing, and so did every sale made by one nation alone.

Harrison marched about a thousand men to Prophetstown on November 7, 1811, while Tecumseh was away asking more nations to join the confederacy, and fought the people there. The fight became known as the Battle of Tippecanoe. On the next day, November 8, Harrison burned the town.

Fighters from the confederacy fought on beside the British in the War of 1812. They fought the Battle of the Thames at Moraviantown, in the British colony of Upper Canada, on October 5, 1813. Their British ally, Major General Henry Procter, left the battlefield in the middle of the fight. British army officers later put Procter on trial for his failures in that campaign. American soldiers killed Tecumseh in the battle. After his death the confederacy broke apart.

### Tecumseh

> **Who:** Shawnee leader who went from nation to nation arguing that Native land belonged to all the nations together, so no single nation could sell it.
>
> **When and where:** the Wabash River country and the South, 1805 to 1813. Killed in battle at the Thames, October 5, 1813.
>
> **Movie:** *We Shall Remain: Tecumseh's Vision* (PBS, 2009), a documentary about him and his brother.

**He carried his argument to a Creek council of 5,000 people.**

Tecumseh arrived at the yearly great council of the Creek Nation at Tuckabatchee in October 1811. More than 5,000 Creek people had gathered there. He asked them to join the confederacy of the northern nations.

The Creek leader Big Warrior refused to join him, because he was afraid of losing the support of the United States.

Tecumseh was still away in the South a month later, when Harrison marched on Prophetstown.

### How did the Cherokee learn to read in a few years?

A Cherokee man named Sequoyah showed a syllabary he had made in 1821, a set of 86 written characters in which each character stands for a whole syllable, not a single sound. Within a few years most Cherokee people could read and write it. Writers at the website History.com state that by the 1830s a larger share of Cherokee people could read than of the white settlers around them.

Cherokee leaders set up a capital at New Echota in 1825. Two years later they approved a written constitution, modeled on the United States Constitution, with three branches of government. Officials of the state of Georgia answered by declaring the Cherokee government abolished, ended by law.

The Cherokee began printing the *Cherokee Phoenix*, the first Native American newspaper, in 1828. They printed it in Cherokee and in English.

### Sequoyah

> **Who:** Cherokee silversmith who could not read or write any language, and made a way to write his own. He is the only person in recorded history known to have created a writing system alone, without first being able to read and write another language.
>
> **When and where:** born in Taskigi, Tennessee, about 1770. First showed his syllabary in 1821. Died 1843 in Mexico.

**He could not read any language, and he wrote one down.**

Sequoyah could not read or write English or any other language. He worked on the problem for about twelve years before he showed his syllabary in 1821.

Seven years later, half of what the nation's newspaper, the *Cherokee Phoenix*, printed was in his characters. He died in 1843, in Mexico.

**Not known:** the year he was born. The years given for it run from 1770 to 1778, and the Library of Congress lists 1770 with a question mark.

### Removal and the Trail of Tears

President Andrew Jackson signed the Indian Removal Act into law on May 28, 1830. Under it, the president could give Native nations land west of the Mississippi River in exchange for their land in the East. Cherokee leaders took their fight with Georgia to the courts.

**The court case.** Georgia's lawmakers had made it a crime for a white person to live in the Cherokee Nation without a license from the state. Samuel Worcester, a missionary who translated parts of the Bible into Cherokee, refused to leave. Georgia guards arrested him and other missionaries in July 1831. They were tried in Georgia that September, and each was sentenced to four years in prison at hard labor, which means forced hard work. The New Georgia Encyclopedia's account of the case does not name the judge.

Chief Justice John Marshall ruled in *Worcester v. Georgia*, in 1832, that the laws of Georgia had no force inside the Cherokee Nation, which was under the protection of the United States. That ruling is still one of the foundations of tribal sovereignty law, the law about a Native nation's right to govern itself. Georgia's officials ignored it. Worcester stayed in prison until January 1833, when he accepted a pardon, an order forgiving the crime, from Georgia's governor.

**The treaty.** Three years after the ruling, in late 1835, a small group of Cherokee men who favored moving signed the Treaty of New Echota with United States officials. The signers gave up all of the nation's land east of the Mississippi for $5 million. Members of the Senate approved the treaty in May 1836, and United States officials treated it as an agreement by the whole nation to move west.

**The roundup.** President Martin Van Buren sent General Winfield Scott with about 7,000 soldiers in May 1838 to round up the Cherokee people who had not moved west. Georgia's militia, its citizen soldiers, joined them. In 1838 and 1839, soldiers came to Cherokee houses in the Southeast and took families out at gunpoint, often with no time to pack. They held about 16,000 Cherokee people in stockades in Tennessee and Alabama.

Then the soldiers forced them to go to Indian Territory, in what is now Oklahoma. More than 4,000 of them died of cold, hunger and disease, about one in every four of the people the soldiers had held.

**How many died.** That figure is the traditional estimate, and the counts differ. The National Park Service counts more than a thousand deaths on the trip itself, and perhaps several thousand more from what the removal did to people afterward. Russell Thornton, a scholar at the University of Minnesota, wrote in 1984 that the number of deaths "may have been twice" the traditional figure.

The Cherokee named the removal *Nunna daul Tsuny*, the Trail Where We Cried. In English it is called the Trail of Tears.

United States officials and soldiers forced all five of the large southeastern nations to move to Indian Territory: the Cherokee, the Muscogee (Creek), the Choctaw, the Chickasaw and the Seminole. They removed more than 14,000 Choctaw people from 1831 to 1833, and hundreds died. They removed more than 14,500 Creek people in 1836 and 1837. Several hundred Creek people died on the way, and about 3,200 died after they arrived, of disease, hunger and cold.

**Rebuilding.** In Indian Territory, the people of those nations rebuilt their governments, their courts, their newspapers and their schools.

### Rebecca Neugin

> **Who:** a Cherokee woman who was about three years old when soldiers took her family out of their home in Georgia in 1838.
>
> **When and where:** Georgia to Indian Territory, 1838 and 1839. Interviewed in 1932.

**Ninety-four years later, she told a historian what she remembered.**

Soldiers took Rebecca Neugin's family out of their home in Georgia in 1838, when Rebecca was about three years old. The soldiers held the family in a camp in Tennessee, and in September 1838 the family set out west. Rebecca and the smaller children rode in a wagon, while her mother, her father and her older brother Dick walked the whole way.

The historian Grant Foreman interviewed her in 1932, when she was about 97 years old, and she told him what she remembered of the journey. She was one of the last people still alive who had been on it. She died on July 15, 1932.

### The Seminole resistance

In Florida many Seminole people refused to leave, and United States soldiers fought them in the Second Seminole War, from 1835 to 1842. It was the longest war between United States forces and a Native nation east of the Mississippi, and the one that cost the most. National Park Service writers give its cost in a count. For every Seminole person soldiers killed, they forced four out of Florida. For every four forced out, three soldiers died and United States officials spent $32,000.

General Thomas Jesup lured the Seminole war leader Osceola to a talk on October 21, 1837, under a white flag of truce, a sign that both sides promise not to attack or seize anyone while they talk. Osceola came in under the flag, and Jesup had him seized. Many people in the United States protested the trick in public at the time. Osceola died a prisoner at Fort Moultrie, South Carolina, on January 30, 1838.

Most of the fighting stopped in 1842. A few hundred Seminole people never surrendered and stayed in the Everglades. Their descendants belong to two tribes today. Federal officials, the officials of the national government, recognized the Seminole Tribe of Florida in 1957 and the Miccosukee Tribe in 1962, accepting each tribe as a nation with its own government. Leaders of both tribes point out that the Seminole were never conquered.

### Osceola

> **Who:** Seminole war leader in the fight against removal from Florida.
>
> **When and where:** Florida. Seized by General Thomas Jesup under a flag of truce, October 21, 1837. Died a prisoner at Fort Moultrie, South Carolina, January 30, 1838.

**He was born Billy Powell, in a Creek town in Alabama.**

Osceola was born in 1804 in the Creek town of Talisi, in what is now Alabama. His name at birth was Billy Powell.

He died a prisoner at Fort Moultrie three months after Jesup seized him. Frederick Weedon, the army doctor there, cut off Osceola's head before the burial and put it on display in his drug store.

## 1850 to 1900

**Era 7 of 10 · 1850 to 1900 · about 21 minutes**

United States officials and soldiers forced one Native nation after another onto reservations, pieces of land set aside for each nation in a treaty or by an order, between 1850 and 1900. Soldiers and officials held the people there, and officials and settlers took the rest of each nation's country.

United States soldiers killed hundreds of Native people at a time in these years. Army officers hanged 38 Dakota men together at Mankato, Minnesota, in 1862. At Bear River in 1863 soldiers killed an estimated 250 to 500 Shoshone people, and at Sand Creek in 1864 about 230 Cheyenne and Arapaho people, most of them women, children and elders.

Cavalry, soldiers on horseback, killed about 177 Piikani people on the Marias River in 1870, by the best estimate. Soldiers at Wounded Knee in 1890 killed between 250 and 300 Lakota people.

Hunters killed off the bison herds that fed the Plains nations, and army officers encouraged the killing. Navajo leaders signed a treaty in 1868 in which United States officials agreed to let their people go home. Members of Congress stopped making treaties with Native nations in 1871. Lakota, Cheyenne and Arapaho fighters beat George Custer's soldiers at the Little Bighorn in 1876, and the next year the Nez Perce fled toward Canada with the army behind them.

An Army officer named Richard Henry Pratt opened the first federal boarding school for Native children built far from the reservations in 1879. Federal officials used Pratt's school as the model for many more. Pratt stated his aim in his own words: "Kill the Indian in him, and save the man." Federal investigators later counted at least 973 children who died at the federal boarding schools.

Members of Congress passed a law in 1887 under which federal officials cut nations' shared land into private pieces. The officials opened what was left over to white settlers.

### The wars, from the nations' side

**The Dakota War.** In Minnesota in 1862, United States officials failed to deliver the food and the payments that they had promised the Dakota in treaties. Dakota fighters went to war, and the war lasted six weeks.

**The trials.** Afterward, army officers sitting as military commissions, courts run by the army, tried 392 Dakota men. Some of the trials took less than five minutes. The men had no defense lawyers and no interpreters, the people who translate between two languages. The officers on the commissions sentenced 303 of the men to death by hanging.

President Abraham Lincoln and his lawyers read the trial records. Lincoln looked first for men found guilty of rape, forcing a person into sex, and found two. Then he added men found to have taken part in killing people who were not soldiers. He cut the list of men to be executed down to 39. One of the 39 was reprieved, which means his execution was called off.

**Mankato.** Army officers hanged 38 Dakota men together at Mankato on December 26, 1862, while about 4,000 people watched. It is the largest mass execution, the most people put to death at one time, in United States history. Captain William Duley cut the rope. Several members of his family had been killed in a Dakota attack on the Lake Shetek settlement.

The bodies were put in a shallow grave on a sandbar. The Minnesota Historical Society's account does not say who buried them. Before morning, doctors had dug up most of the bodies to use for medical study.

**Hanged by mistake.** Two of the 38 men were hanged by mistake, by the Minnesota Historical Society's account. The first was Wicaŋȟpi Wastedaŋpi. He went by Caske, a common name that means first-born son. Dakota families gave it to a first-born boy, so many men had it. When the name Caske was called for another man on the list, Wicaŋȟpi Wastedaŋpi stepped forward. He was hanged in that man's place.

The second was Wasicuŋ, a young white man whom the Dakota had adopted as a child. The commission had found him not guilty at his trial.

**Bear River.** A month after the hangings, soldiers attacked a Shoshone camp far to the west. Colonel Patrick Edward Connor led them against a winter camp of Northwestern Shoshone people on the Bear River, near what is now Preston, Idaho, on January 29, 1863. Connor had announced that he would take no prisoners. His soldiers killed an estimated 250 to 500 Shoshone people. Afterward army leaders promoted Connor to brigadier general, a higher rank.

**The Long Walk.** Far to the south, in 1863 and 1864, United States soldiers marched about 8,500 Navajo people more than 300 miles to Bosque Redondo and held them there. This forced march is known as the Long Walk. Thousands of the Navajo died while soldiers held them at Bosque Redondo. In 1868 Navajo leaders negotiated a treaty in which United States officials agreed to let the survivors go home. The Navajo were one of the very few removed nations who got their homeland back.

**Sand Creek.** Colonel John Chivington led about 675 volunteer soldiers against Black Kettle's Cheyenne and Arapaho camp at Sand Creek in Colorado on November 29, 1864. The camp was flying a United States flag and a white flag.

Earlier that month Major Scott Anthony, the commander at nearby Fort Lyon, had told Black Kettle's people to camp at Sand Creek. In his report of November 16 he wrote that he told them "no war would be waged against them." That promise was to hold until his own commander decided what to do. When Chivington arrived, Anthony agreed to the attack.

The attack lasted eight hours. The soldiers killed about 230 people, most of them women, children and elders.

Captain Silas Soule, one of the officers there, refused to let his men fire. He wrote to his mother that he saw "a Massacre of three hundred Indians mostly women and children." In another letter he wrote that it was "hard to see little children on their knees have their brains beat out." Soldiers cut scalps and other body parts from the dead.

Members of a committee of Congress later wrote, using an old word for cowardly and cruel, that Chivington "deliberately planned and executed a foul and dastardly massacre." Chivington left the army and was never put on trial, and no officer or soldier was punished.

A man shot Soule dead on a Denver street in April 1865, about two months after Soule spoke against Chivington before investigators. No one was ever punished for killing him. National Park Service staff look after the place of the massacre today as the Sand Creek Massacre National Historic Site.

### From Red Cloud to Geronimo

**Red Cloud's War.** Gold was found in Montana in 1863, and the Bozeman Trail was opened as a road for white settlers to reach it. The trail ran through Lakota country, and the Lakota had never given permission for it. When soldiers built forts along it to protect the settlers, Lakota fighters went to war, from 1866 to 1868. The war is named for the Lakota leader Red Cloud.

After the war, United States officials and Lakota leaders signed the Treaty of Fort Laramie in 1868. In it, the officials agreed to close the Bozeman Trail. They also set up the Great Sioux Reservation "for the absolute and undisturbed use" of the Lakota. It covered all of what is now South Dakota west of the Missouri River, including the Black Hills.

**The Marias River.** Major Eugene Baker's cavalry came to a camp of Piikani (Piegan Blackfeet) people on the Marias River in Montana on January 23, 1870. His scout, Joe Kipp, told him it was the camp of Heavy Runner's band, a group of families who lived and traveled together, and that the band was at peace with the United States. By one account, Baker answered, "That makes no difference, one band or another of them, they are all Piegans and we will attack them."

By the best estimate, Baker's soldiers killed 37 men, 90 women and 50 children. The army's own count was 173 dead, and the National Parks Conservation Association's figure is more than 200. Neither Baker nor any of his men was ever punished.

**Gold in the Black Hills.** Members of an expedition led by George Custer announced in 1874 that there was gold in the Black Hills, inside the reservation promised to the Lakota in 1868. Federal officials ignored their own treaty. In December 1875 they ordered the winter camps that were off the reservation to come onto it by January 31, 1876. When the camps did not come in, the officials sent the army.

**The Little Bighorn.** George Custer led part of the 7th Cavalry, an army unit of soldiers on horseback, on June 25, 1876. He attacked a camp where Lakota, Cheyenne and Arapaho people had gathered as allies, meaning they had agreed to fight on the same side. The camp stood by the Little Bighorn River, also called the Greasy Grass. Fighters from the camp killed Custer and about 200 of the soldiers with him in about an hour. Those soldiers made up five companies, smaller units of the 7th Cavalry.

**Crazy Horse.** The Lakota leader Crazy Horse, who had led fighters at the Little Bighorn, surrendered on May 6, 1877, less than a year after the battle. Soldiers were arresting him at Fort Robinson on September 5, 1877. A Lakota man named Little Big Man jumped on his back and held him, and a soldier on guard stabbed him with a bayonet, a blade fixed to the end of a rifle. Crazy Horse died of the wound.

**Who stabbed him.** Most accounts say a soldier on guard stabbed him. The name most often given is Private William Gentles, but only one witness named him, so who the soldier was is disputed. Little Big Man later told a different story, in which Crazy Horse was cut by his own knife.

**The last surrender.** In the Southwest, Geronimo, of the Chiricahua Apache, surrendered on September 4, 1886. He was the last Native leader to formally surrender to the United States. United States officials then held the Chiricahua people as prisoners of war, people an army holds after capturing them in a war, for 27 years.

**By 1886:** Geronimo had surrendered, the last Native leader to do so, and United States officials held most Native nations on reservations. The Black Hills, promised to the Lakota in 1868, had been taken after the gold strike.

### Sitting Bull

> **Who:** Hunkpapa Lakota leader and holy man. The camp that fought at the Greasy Grass gathered around him.
>
> **When and where:** the northern Plains. Canada from 1877 to 1881. Killed by Indian police at Standing Rock, December 15, 1890.
>
> **Movie:** *Sitting Bull: A Stone in My Heart* (2006), a documentary built from his own recorded words.

**Buffalo Bill's show paid him fifty dollars a week.**

The camp on the Greasy Grass in June 1876 formed around Sitting Bull, and Crazy Horse was one of its battle leaders.

Sitting Bull took his people north into Canada in 1877. Hunters were killing off the bison, and by 1881 there were not enough left to feed his people. He surrendered at Fort Buford in July of that year.

He signed a contract with Buffalo Bill's Wild West, a traveling show, at the Standing Rock Agency on June 6, 1885. The show paid him fifty dollars a week for a four-month season, and only he could sell his own photographs and autographs.

Indian police, Native men who worked as police for the agency that ran the reservation, came to arrest him at Standing Rock on December 15, 1890. Indian agents, the federal officials who ran the reservations, were alarmed by the Ghost Dance, a new religious dance spreading across the reservations. The policemen killed Sitting Bull.

### Chief Joseph

> **Who:** Nez Perce leader in the flight of 1877, when his people fled toward Canada with the United States Army behind them.
>
> **When and where:** the Wallowa Valley of Oregon to the Bear Paw Mountains of Montana, 1877. Surrendered October 5, 1877, forty miles from Canada.
>
> **Movie:** *I Will Fight No More Forever* (1975, television film).

**They stopped forty miles short of Canada.**

Joseph's band of the Nez Perce lived in the Wallowa Valley of northeastern Oregon. General Oliver O. Howard told the Nez Perce chiefs in 1877 that their people had 30 days to move onto the reservation in Idaho, or the army would move them by force. That year about 750 Nez Perce people fled with the army behind them. Only about 200 of them were fighters, and the rest were families.

They traveled about 1,170 miles, the National Park Service's figure for the trail. Some accounts state a longer distance, up to about 1,700 miles.

They surrendered on October 5, 1877, at the foot of the Bear Paw Mountains in Montana, forty miles short of the Canadian border. Lieutenant C. E. S. Wood recorded Joseph's words at the surrender: "From where the sun now stands I will fight no more forever."

**The promise.** Colonel Nelson Miles had promised Joseph that his people would be taken back to the reservation in Idaho. General William Tecumseh Sherman, the commanding general of the army, overruled the promise, cancelling it. He wanted the Nez Perce punished as an example to other nations and never allowed to go home. "I believed General Miles, or I never would have surrendered," Joseph said afterward.

United States officials sent his people to Kansas, then to Indian Territory. There, many of them were sick and short of supplies, and their number fell from 410 to 391. Two hundred sixty-eight Nez Perce people left Indian Territory for the Northwest in May 1885. Officials sent Joseph to the Colville reservation in Washington, and he died there, at Nespelem, in 1904. Officials never allowed him back to the Wallowa Valley.

### The bison, and the end of treaties

There were roughly 30 million bison on the Plains in the early 1800s. One count in 1884 found 325, about one bison left for every 90,000 there had been. By 1900 there were fewer than a thousand.

Railroads carried hunters into the herds' country. Hunters made hide hunting into a large business, killing bison for their skins. Disease and drought killed others. Army officers encouraged the killing, because the herds were the Plains nations' food and the base of how they made a living, and the bison were part of their religion.

Members of Congress stopped making treaties with Native nations in 1871. They did it with a rider, a short passage attached to a spending bill called the Indian Appropriations Act. Treaties already made stayed in force. After 1871, United States officials dealt with Native nations through acts of Congress and orders from the president instead of treaties.

### How did the nations lose 90 million acres?

Native nations lost about 90 million acres between 1887 and 1934 through allotment, the cutting of land that a whole nation owned together into private pieces. Federal officials carried it out.

Members of Congress passed the Dawes Act, also called the General Allotment Act, in 1887. Under it, federal officials divided nations' land into separate parcels, or pieces. The head of a family got 160 acres, a single adult or an orphan got 80 acres, and each other child got 40 acres. On land fit only for grazing animals, each person got twice as much. Officials called everything left over "surplus," meaning extra, and opened it to white settlers.

The land Native nations held fell from about 138 million acres in 1887 to 48 million in 1934. The lost land was about two-thirds of all the land Native nations still had in 1887. The Meriam Report, a federal study published in 1928, states the figures as 137 million and 47 million acres. The loss is about the same by either count.

Allotment went on until members of Congress ended it in 1934.

### The boarding schools

Richard Henry Pratt, an Army officer, opened the Carlisle Indian Industrial School at Carlisle, Pennsylvania, on November 1, 1879. It was the first federal boarding school for Native children built far from the reservations. Federal officials used Carlisle as the model for the schools that followed.

Pratt stated the purpose himself. In 1892 he spoke to a national conference of charities in Denver. He said that "all the Indian there is in the race should be dead. Kill the Indian in him, and save the man." People often quote the line in a shorter form, "kill the Indian, save the man." Pratt's recorded words are the longer ones, printed in the conference's official report.

Members of Congress passed two laws to get the children into the schools. In 1891 they gave the Commissioner of Indian Affairs, the federal official in charge of Native affairs, the power to make and enforce rules forcing Native children to attend school. In 1893 they let federal officials hold back rations, clothing and annuity payments from parents who would not send their children. These were the food, goods and yearly payments that United States officials had promised a nation in its treaties.

Some Indian agents, the federal officials in charge of the reservations, sent reservation police to seize children. Some families sent their children willingly, hoping the schooling would help them. Many families had no real choice.

**Arrival.** When a child arrived, staff at school after school cut the child's hair and replaced the child's clothes with a uniform. They gave the child an English name and forbade the child to speak the language of home. Staff punished children for speaking their own languages. The federal investigation of the schools and survivors' own accounts document the punishments: beatings, solitary confinement, which means locking a child away alone, withholding food, and washing children's mouths out with soap.

Children spent half of each school day doing unpaid work that kept the school running. Pratt also ran what he called the outing system. Under it, he sent students to live and work with white families, in the summers and during school terms.

**The count.** Investigators at the United States Department of the Interior studied the schools and published their findings in 2022 and again on July 30, 2024. They counted 417 federal Indian boarding schools in 37 states and territories, open between 1819 and 1969. Their first report, in 2022, listed 408. They also found more than a thousand other places that had similar aims.

At least 973 children died at the federal schools. The investigators found at least 74 marked and unmarked burial sites at 65 of the schools. The report states that its count of the dead is low.

Children kept their languages by speaking them where the staff could not hear. At these schools, children made friends with children from other nations. Those friendships were one of the starting points of the Native organizing of the next century. Some students, Zitkala-Ša among them, used the reading and writing they learned at the schools to argue against the schools.

### Sarah Winnemucca

> **Who:** Northern Paiute writer, interpreter, and lecturer who argued her people's case in front of audiences across the East.
>
> **When and where:** Nevada, and the lecture halls of the East, in the 1870s and 1880s.

**"My people were only given one week to get ready in."**

Sarah Winnemucca was working as an interpreter when she learned, just before Christmas 1878, that President Rutherford B. Hayes had ordered her people taken to the Yakama reservation under an army guard. She wrote the line about the one week. Officials were punishing the whole group because a few Paiute men had fought in the Bannock War of 1878.

United States officials forced about 550 Northern Paiute men, women and children to move 350 miles north in 1879, from the Malheur reservation in Oregon to the Yakama reservation. The march took nearly a month through snow and over two mountain ranges. The officials in charge made some of the men walk in leg irons, chains locked around the ankles.

Five children, one woman and an old man died on the road. Their bodies were left beside it because the ground was too cold to dig graves. The Oregon Historical Society's account of the march does not say who decided to leave them. The historian Sally Zanjani estimated that more than one fifth of the group died far from home after they were sent away, mostly of hunger and disease.

**Schurz's promise.** Winnemucca went east and gave lectures about what officials had done to her people. She met with Secretary of the Interior Carl Schurz in Washington in 1880. He gave her a written promise that the Paiute could go back to Malheur, and then he broke it. Her people never returned there. President Chester Arthur ended the Malheur reservation in 1882 and 1883, and white settlers could then claim its land.

She published *Life Among the Piutes: Their Wrongs and Claims* in 1883. It is the first known autobiography, a book a person writes about their own life, by a Native American woman. She was also the first Native woman known to hold a United States copyright, the legal right to control who copies and sells a piece of writing. In 1884 she asked Congress to give her people back their reservation.

She opened a school of her own for Paiute children near Lovelock, Nevada, in the mid-1880s. Accounts of her life give the year as 1884 or 1885. Staff at the government boarding schools forbade children to speak their own languages, but at her school Winnemucca taught in both Paiute and English. The school ran out of money and closed within a few years.

### Zitkala-Ša

> **Who:** Yankton Dakota writer, musician, and organizer, taken as a child to a boarding school in Indiana.
>
> **When and where:** the Yankton reservation, South Dakota, and Washington, D.C. Born February 22, 1876. Died January 26, 1938.

**An interpreter promised her all the red apples she wanted.**

Zitkala-Ša wrote about how she left home in her essay "The Big Red Apples." She was in her eighth year, in March, when two white missionaries came to her village on the Yankton reservation. Her mother told her they had come "to take away Indian boys and girls to the East." A young white interpreter told the girl she could pick all the red apples she wanted and ride on "the iron horse," a train. "I had never seen a train, and he knew it," she wrote.

She begged to go. Her mother warned her, "Their words are sweet, but, my child, their deeds are bitter." Then her mother agreed. The missionaries took the girl to White's Indiana Manual Labor Institute. The essay does not name them.

The editors of the *Atlantic Monthly*, a magazine, published a set of her essays about her own life in 1900. One of them was "The School Days of an Indian Girl." In the essays she described her time at the school and criticized it. She was working at Carlisle when she published them. They appeared again in her book *American Indian Stories* in 1921.

She helped start the National Council of American Indians in 1926 and led it until she died in 1938.

### The Ghost Dance and Wounded Knee

A Northern Paiute man named Wovoka, from the Walker Lake country of Nevada, had a vision on January 1, 1889. It came during a solar eclipse, when the moon blocked the sun. He taught that if people lived rightly and danced a round dance, in which people move in a circle, the dead would return and the world would be made whole.

On reservations where people were hungry, they took up the dance, which became known as the Ghost Dance. Indian agents who were frightened by it called it the start of an uprising, an armed revolt. Newspaper writers printed stories that said the same.

Indian police killed Sitting Bull at Standing Rock on December 15, 1890, while they were trying to arrest him.

**Wounded Knee.** Soldiers of the 7th Cavalry under Colonel James W. Forsyth were disarming Spotted Elk's band, also called Big Foot's band, at Wounded Knee Creek on December 29, 1890, taking away the people's weapons. During the disarming, a rifle belonging to Black Coyote, a deaf man, went off. By some accounts he fired first, and by others a soldier tried to grab his gun and it went off. The soldiers opened fire.

They fired carbines, which are short rifles, and four Hotchkiss guns, small cannon set on a hill above the camp. The soldiers killed between 250 and 300 Lakota people. The killing is known as the Wounded Knee Massacre.

A burial party put 146 of the dead in one grave at the site in early January 1891. They were 84 men and boys, 44 women and 18 children. Others died later of their wounds, and some bodies were never found, so no count gives the women and children among all the dead.

Twenty-five soldiers also died. Writers for Britannica and History.com say that most of those soldiers were hit by their own side's fire. Twenty soldiers of the 7th Cavalry received the Medal of Honor, the top award the United States military gives for bravery in battle, for what they did that day. Some of the medal statements praise soldiers for driving out "Sioux Indians" who were hiding in a ravine, a narrow, steep valley.

**If you remember one thing:** In these fifty years United States soldiers and officials took most of the land the nations still held, forced the people onto reservations and began taking their children to boarding schools.

**One number:** about 250,000. That is how many Native people census takers counted in 1900, the lowest number on record. Even the lowest estimate for 1500, about 1 million, is four times as many.

**Next:** In the next fifty years Native people built national organizations of their own, while the boarding schools stayed open.

## 1900 to 1950

**Era 8 of 10 · 1900 to 1950 · about 10 minutes**

Native leaders founded national organizations of their own in these fifty years, the Society of American Indians in 1911 and the National Congress of American Indians in 1944. Federal boarding schools stayed open the whole time.

In Oklahoma in the early 1920s, killers murdered dozens of Osage people for their shares of the nation's oil money, in the years called the Reign of Terror.

Members of Congress made Native people citizens in 1924 and ended allotment, the cutting of nations' shared land into private pieces, in 1934. Native men fought for the United States in both world wars, and some of them sent messages in Choctaw and Navajo.

### Organizing

A group of Native doctors, lawyers and writers met in Columbus, Ohio, on October 12, 1911, and founded the Society of American Indians. It was the first national Native rights organization that Native people built and ran themselves. Its leaders included Dr. Charles Eastman, who was Santee Dakota, and Dr. Carlos Montezuma, who was Yavapai-Apache. Zitkala-Ša edited its journal.

Many of the members had gone through the boarding schools, and some of them used that schooling to argue against federal Indian policy. The Society lasted from 1911 to 1923.

Twelve men and one woman founded the Alaska Native Brotherhood at Sitka in 1912. They wanted citizenship for Alaska Natives. The Alaska Native Sisterhood began in 1915. For the next fifty years, these two groups were the only civil rights organizations Alaska Natives had, the only groups working for their right as citizens to equal treatment under the law.

Eighty delegates from more than fifty tribes and associations met in Denver on November 16, 1944, and founded the National Congress of American Indians. Native nations still use it as one of their main ways to act together.

### Ironworkers from Kahnawake

Mohawk men from Kahnawake had worked on structural iron, the metal frames that hold up bridges and tall buildings, since the 1880s. Kahnawake crews worked on the riveting gangs that put up the Empire State Building in New York in 1930 and 1931. A riveting gang joined the steel beams together with hot metal pins called rivets.

Kahnawake ironworkers kept building towers in Manhattan for generations. One of them, Harold McComber, is the subject of *High Steel*. Don Owen directed that documentary film for the National Film Board of Canada in 1965.

### The Osage and the Reign of Terror

Osage people in Oklahoma earned so much from oil in the 1920s that they were among the wealthiest people in the world, counted per person. White guardians and some of the men who married Osage women stole that money, and killers murdered Osage people to get it.

Osage leaders under Chief James Bigheart won their own terms in the Osage Allotment Act, which members of Congress passed in 1906. Under the Dawes Act, federal officials had given the head of a family 160 acres, single people and children less, and opened the rest of a nation's land to white settlers. The Osage divided all of their reservation among their own people instead, 657 acres each for 2,229 people, about four times a family head's 160 acres.

**Headrights.** The Osage kept the minerals under the ground as shared property. Oil companies paid royalties, which are payments for the oil they took out. Each Osage member got an equal share of that money. The share was called a headright.

Members of Congress passed a guardianship law in 1921. Under it, judges in local courts appointed white guardians over the money of many Osage adults. The guardian, not the Osage owner, controlled the money. Guardians stole from the people whose money they controlled. Some of the men who married Osage women stole from their wives.

Osage headright holders died in murders and in suspicious deaths, deaths that might have been murders, between about 1920 and 1925. These years are known as the Reign of Terror. Counts of the dead disagree. Osage Nation officials count more than sixty. Writers at the Oklahoma Historical Society count about 24, and FBI writers say at least two dozen.

**The investigation.** Members of the Osage Tribal Council asked the federal government to send detectives in 1923. Agents of the new Bureau of Investigation, which later became the FBI, took the case. They proved that William Hale, a cattle rancher whom people called "the King of the Osage Hills," had ordered the murders of Anna Brown and members of her family so that he could inherit their oil rights, getting them after they died. Hale's nephew, Ernest Burkhart, was married to Anna's sister Mollie.

**The killings.** Anna Brown was shot on Hale's orders in May 1921. Two months later her mother, Lizzie Q. Kyle, died, and poison was suspected. In January 1923 Hale had Anna's cousin Henry Roan killed for insurance money. In March 1923 a bomb blew up the house of Anna's sister Rita Smith, killing Rita, her husband Bill and their servant, Nettie Brookshire.

**Who went to prison.** Burkhart pleaded guilty in 1926 and was sentenced to life in prison. Hale was found guilty in 1929 and sent to prison for life. Two other men, Kelsie Morrison and John Ramsey, were also sentenced to life. Hale, Ramsey and Burkhart were all later let out on parole, which means freed early under watch.

### Citizenship and the end of allotment

Under the Indian Citizenship Act, which became law on June 2, 1924, every Native person born in the United States became a citizen. In some states they still could not vote, because each state's lawmakers wrote that state's voting rules. The Library of Congress records that officials in some states kept Native people from voting until 1957.

A federal survey called the Meriam Report came out in 1928. Its full title was *The Problem of Indian Administration*. It records that under allotment, tribal land had fallen from 137 million acres to 47 million. It also records the poverty and disease Native people lived with after that loss.

The Meriam Report's writers condemned the boarding schools in detail, judging them wrong and showing why. One of the things they condemned was the half-day system, under which school staff made children spend half of every school day on unpaid work that kept the schools running.

The Indian Reorganization Act became law on June 18, 1934. It was written while John Collier was Commissioner of Indian Affairs, the federal official in charge of dealings with Native nations, a job he held from 1933 to 1945. In the act, members of Congress ended allotment and extended the protections on land held in trust, land the United States holds on behalf of a Native nation or person.

Members of Congress also allowed up to $2,000,000 a year in the act for buying land for Native people. Nations could now write constitutions and set up their own governments. After 1934 federal officials began to recognize the governments that nations set up under the act. For the forty-seven years before, since 1887, federal officials had used allotment to break nations up into single landowners.

### The schools stay open

Federal boarding schools kept running after 1900. The federal investigators counted the schools that ran between 1819 and 1969, and some kept going after that. Enrollment, the number of children in the schools, kept climbing for decades and reached its peak of about 60,000 children in 1973.

Collier and the officials under him moved toward day schools, where children went home at night, in the 1930s. They allowed some teaching in Native languages, and they closed some boarding schools. Federal officials still took tens of thousands of children from their homes to the schools every year.

One of those children was Chester Nez, a Navajo boy at the Fort Defiance boarding school, who later helped build the Marines' code in Navajo.

### Why could no enemy read the code?

Code talkers were Native soldiers who sent military messages in their own languages, which the enemy could not understand. The first code talkers were Choctaw.

American soldiers were fighting in the Meuse-Argonne campaign, a long series of battles in France, in the autumn of 1918. German soldiers were tapping American telephone lines. They were also capturing about one in four runners, the soldiers who carried messages on foot. Choctaw soldiers of the 36th Division began passing orders in Choctaw.

They sent the first secure messages, ones the Germans could not read, on October 26, 1918. When Choctaw had no word for a piece of equipment, the men made one up. A machine gun became "little gun shoot fast."

In the Second World War, Marine Corps officers had Navajo speakers do the same work. Twenty-nine Navajo recruits arrived in San Diego on May 5, 1942, and built the code. Between 350 and 420 Navajo served as code talkers, in all six Marine divisions in the Pacific. At Iwo Jima, Major Howard Connor was the 5th Division's signal officer, in charge of its messages. He said: "Were it not for the Navajos, the Marines would never have taken Iwo Jima."

No enemy ever broke the code. It stayed classified, meaning officially secret, until 1968. The original twenty-nine received the Congressional Gold Medal, a medal that members of Congress vote to give, on July 26, 2001, and the code talkers who came after them received silver medals.

### Jim Thorpe

> **Who:** Sac and Fox athlete and Carlisle student, the first Native American to win an Olympic gold medal.
>
> **When and where:** Stockholm, July 1912. Olympic officials took his medals in 1913 and named him the sole champion again in 2022.
>
> **Movie:** *Jim Thorpe – All-American* (1951)

**Olympic officials took his gold medals over two dollars a game.**

Jim Thorpe was a citizen of the Sac and Fox Nation and a student at the Carlisle Indian Industrial School, the federal boarding school in Pennsylvania. There he was twice named a football All-American, one of the best college football players in the country.

He won the pentathlon, a contest of five track and field events, on July 7, and the decathlon, a contest of ten, on July 15, at the Stockholm Olympics in 1912. His decathlon score stood as the world record until 1927.

Olympic officials took both medals back in 1913. Thorpe had played minor-league baseball in 1909 and 1910 for a reported two dollars a game, up to $35 a week. The Olympic rules of the time allowed only amateurs, athletes who are not paid to play.

**Restored.** Officials of the International Olympic Committee named him co-champion in October 1982, sharing the titles with Hugo Wieslander in the decathlon and Ferdinand Bie in the pentathlon. On July 15, 2022, 110 years to the day after his decathlon win, they named him the sole champion of both events.

### Ira Hayes

> **Who:** Akimel O'odham (Pima) Marine from the Gila River community in Arizona, one of the six men who raised the second flag on Mount Suribachi.
>
> **When and where:** Iwo Jima, February 23, 1945. He died in Arizona on January 24, 1955.
>
> **Movie:** *The Outsider* (1961). Adam Beach also plays him in *Flags of Our Fathers* (2006).

**He raised the flag on Iwo Jima and died of exposure at 32.**

Ira Hayes, from the Gila River Indian Community in Arizona, was a Marine paratrooper, a soldier trained to jump from planes by parachute. He was one of the six men who raised the second American flag on Mount Suribachi, on Iwo Jima, on February 23, 1945. Americans celebrated the photograph of that flag-raising.

Hayes came home to a fame he had not asked for. He and two other men from the photograph raised a flag at a ceremony in Washington on May 9, 1945. The ceremony started a tour to sell war bonds, loans people made to the government to pay for the war. Later that month the Marines ordered Hayes back to his unit.

Americans celebrated the photograph, but Hayes got little help after the war. Police arrested him 52 times for being drunk in public. Years later President Dwight Eisenhower met him and called him a hero.

Hayes was found dead on the morning of January 24, 1955, near an empty mud-brick hut close to his home at Sacaton, in the Gila River community. He had been drinking the night before. The coroner, the official who decides how a person died, gave the cause as alcohol poisoning and exposure, dying from cold or other harsh weather without shelter. He was 32.

### Chester Nez

> **Who:** Navajo Marine, one of the twenty-nine who built the code. As a boarding-school student, he was punished for speaking the language the code was made from.
>
> **When and where:** the Fort Defiance boarding school, Arizona, then the Pacific, 1942 to 1945. He died June 4, 2014.

**He outlived the other twenty-eight who built the Navajo code.**

When Chester Nez spoke Navajo at the Fort Defiance boarding school, staff washed his mouth out with soap.

Marine Corps recruiters signed Nez up in 1942. He was one of the twenty-nine who went to San Diego and built the code out of the language.

He wrote about what happened to him in *Code Talker*, a memoir, or book about the writer's own life, published in 2011 with Judith Schiess Avila. It is the only memoir by one of the original twenty-nine. Nez died on June 4, 2014, the last of the twenty-nine still alive.

## 1950 to 2000

**Era 9 of 10 · 1950 to 2000 · about 14 minutes**

Native nations spent these fifty years fighting a federal plan to end them as nations, and winning back the running of their own affairs. Members of Congress declared in 1953 that the United States should end its recognition of Native nations, which means its dealings with each nation as a government. Twenty-two years later, in 1975, President Ford signed a law under which Native nations could take control of their own schools, clinics and police.

The Menominee, whose nation members of Congress had terminated, ending its recognition, organized until members of Congress restored it. Fishermen in the Northwest kept fishing until a federal judge ruled on their 1850s treaties. A group called Indians of All Tribes took Alcatraz Island and held it for nineteen months. In 1980, in the Sioux Nation's Black Hills case, the justices of the Supreme Court ruled that United States officials had broken the 1868 treaty when they took the hills.

### Termination and relocation

Members of Congress passed House Concurrent Resolution 108, a formal statement of policy that they voted on, on August 1, 1953. In it they declared that the United States should end its recognition of Native nations, along with the federal services that came with it. The policy's name was termination. Under it, members of Congress and federal officials stopped treating a tribe as a nation with its own government, and the tribe lost its federal services.

Members of Congress ran about sixty termination proceedings, the formal legal steps that ended a nation's recognition, between 1953 and 1970. Those proceedings covered more than a hundred tribes and bands. More than 3 million acres of land stopped being held in trust, which meant the United States no longer held that land on the nations' behalf.

**The Menominee.** The Menominee of Wisconsin ran a profitable timber business. Members of Congress passed the Menominee termination act in 1954. It took effect in 1961, and the Menominee, who had done well before, became poor. Menominee people organized a movement called DRUMS, with Ada Deer among its leaders. They kept pushing until members of Congress reversed the termination. The Menominee Restoration Act became law on December 22, 1973.

Officials of the Bureau of Indian Affairs, the federal agency in charge of Indian affairs, also moved Native people off reservations and into cities in these years. They began this relocation program between about 1948 and 1952, and members of Congress backed it with the Indian Relocation Act of 1956. People who signed up got a one-way ticket and short-term help. About 30,000 people moved in the 1950s, and more than 100,000 had moved by the time the program ended in the 1970s.

Many of them lived in poverty in the cities. They also built lasting Native communities in Minneapolis, Chicago, Oakland and San Francisco, Los Angeles, and Denver. The next Native movement started in those cities.

### Alcatraz, Blue Lake and Alaska

George Mitchell, Dennis Banks, Clyde Bellecourt and about 200 other people founded the American Indian Movement, known as AIM, in Minneapolis in July 1968. Its members began with street patrols against police abuse. Many Native people had moved to Minneapolis under relocation.

**Alcatraz.** A group calling itself Indians of All Tribes landed on Alcatraz Island in San Francisco Bay on November 20, 1969. They occupied the island's federal prison, closed since 1963, moving in and holding it. Richard Oakes, who was Mohawk, was among the leaders. In their proclamation, a public statement, they offered to buy the island for "$24 in glass beads and red cloth." They held it for nineteen months, until June 11, 1971. After the occupation began, President Nixon ended termination as federal policy.

**Blue Lake.** Nixon also signed H.R. 471, a law that members of Congress had passed, on December 15, 1970. Under it, Blue Lake and 48,000 acres of sacred land went back to Taos Pueblo.

**Alaska.** A year after Blue Lake, members of Congress settled the land claims of Alaska Natives, ending them by agreement. The Alaska Native Claims Settlement Act became law on December 18, 1971. Under it, the claims were settled for 44 million acres and $962.5 million.

That is nearly as much land as the 48 million acres all Native nations together held in 1934. The land and money went to twelve regional corporations, later thirteen, and to more than 200 village corporations. These were businesses, and Alaska Natives became their owners, called shareholders.

### Wounded Knee, 1973

About 200 Oglala Lakota and AIM members occupied the village of Wounded Knee, on the Pine Ridge Reservation in South Dakota, in 1973. They chose it because soldiers of the 7th Cavalry had killed between 250 and 300 Lakota people there in 1890. Of the 146 dead whom a burial party put in one grave there, 62 were women and children.

The occupiers held the village for seventy-one days, from February 27 to May 8, against federal marshals, officers who carry out the orders of the national courts, and agents of the FBI, the national police force that looks into federal crimes. The federal forces surrounded the village with armored vehicles.

**Why they came.** The occupiers were protesting against the treaties that United States officials had broken, and against Richard Wilson, the tribal chairman at Pine Ridge since 1972, who was Oglala himself.

His opponents accused him of corruption, of giving the few jobs and benefits to his family and friends, and of using an armed group of his own, the Guardians of the Oglala Nation, known as the GOONs, to attack people who opposed him. Three weeks before the occupation, members of the tribal council had brought charges against him at a hearing to remove him from office, and Wilson avoided a trial.

Both sides fired shots during the siege, the seventy-one days in which federal forces surrounded the village. Early in the siege, someone shot US Marshal Lloyd Grimm, and afterward he could not move his legs. Accounts of the siege do not say who shot him.

Frank Clearwater, an Eastern Cherokee man, was shot in the head on April 17 while he rested in a church during a gunfight with federal forces. He died on April 25. FBI officials released a report on deaths on the Pine Ridge Reservation in 2000. It found that Clearwater was killed by gunfire from federal officers, who were firing back after people shot at them.

A federal agent firing as a sniper, a hidden marksman, shot and killed Lawrence "Buddy" Lamont, an Oglala man, with a bullet through the heart on April 26.

**The charges.** Judge Fred Nichol threw out the charges against the AIM leaders Dennis Banks and Russell Means in 1974. He wrote that "the misconduct by the government in this case is so aggravated that a dismissal must be entered in the interests of justice." He meant that government officials had broken the rules so badly that the case had to end.

### The fish-ins and the Boldt decision

Leaders of the Northwest nations signed treaties with Isaac Stevens, the governor of Washington Territory, in the 1850s. In them they gave up land and kept the right to fish.

The Treaty of Medicine Creek, signed by the Nisqually, the Puyallup and other nations on December 26, 1854, says that "the right of taking fish, at all usual and accustomed grounds and stations, is further secured to said Indians." Those words promised that they could keep fishing at all the places where they had always fished. A century later, Washington State officers were arresting their people for fishing.

Through the 1960s and into the 1970s, the Nisqually, the Puyallup and other nations held fish-ins. At a fish-in, people fished in the open, in front of the state's officers, and let themselves be arrested. They did it to force the treaties into a courtroom. Frank's Landing on the Nisqually River was the center of the fish-ins.

Judge George Boldt heard the treaty case, *United States v. Washington*, in federal court. He ruled on February 12, 1974, that the treaty rights still stood. Under them, the tribes had a right to half the harvestable salmon, the salmon that could be caught each year.

Boldt also ruled that the tribes were co-managers of the fishery, the salmon catch and the waters it comes from, so that tribal governments and the state run it together. The justices of the Supreme Court upheld the ruling in 1979, which means they let it stand.

### Why do the Lakota refuse more than a billion dollars?

The Lakota have refused the money that Supreme Court justices awarded them for the Black Hills in 1980, which with the interest it has earned is now more than a billion dollars. Lakota leaders say that the Black Hills were never for sale.

United States officials guaranteed the Black Hills of South Dakota to the Lakota in the Fort Laramie treaty of 1868. Members of an Army expedition led by George Custer announced in 1874 that they had found gold there. United States officials ignored the treaty and took the hills.

The Lakota call one mountain in the Black Hills Tunkasila Sakpe, the Six Grandfathers. It is the mountain known in English as Mount Rushmore.

The justices of the Supreme Court held in *United States v. Sioux Nation*, in 1980, that United States officials had broken the treaty when they took the hills. They awarded the Lakota compensation, money paid to make up for a loss.

### Children taken and women sterilized

Workers at agencies took Native children from their families for decades before 1978. Writers at the National Indian Child Welfare Association state that 25 to 35 percent of Native children were taken, between one in four and one in three. They also state that 85 percent of them were placed outside their families, even when relatives or members of their tribe could care for them.

Members of Congress passed the Indian Child Welfare Act in 1978. In it they set federal standards for those cases, meant to keep Native children with Native families. They also gave tribal courts the power to decide the cases.

**Sterilized.** Doctors at hospitals of the Indian Health Service, the federal agency that runs hospitals and clinics for Native people, sterilized thousands of Native women in the same years. Sterilization is an operation after which a woman can never become pregnant. The doctors at these hospitals did two kinds of operation. In a tubal ligation, a surgeon cuts or ties the two tubes that carry eggs to the womb. In a hysterectomy, the surgeon cuts out the womb.

Investigators from the General Accounting Office, a federal office, studied 4 of the agency's 12 areas. In 1976 they reported 3,406 sterilizations of Native women there from 1973 to 1976. Writers at the National Library of Medicine state that the women had not given their permission. The investigators' report does not name the doctors. No surviving record says how many of the women had each kind of operation.

Thirty-six of the women were under 21, although a court had ordered a stop to sterilizing women that young. Two years before the report, Dr. Connie Pinkerton-Uri, a Choctaw and Cherokee doctor, had found that one in four Native women had been sterilized without agreeing to it.

### Self-rule, casinos and remains sent home

President Ford signed the Indian Self-Determination and Education Assistance Act in January 1975, self-determination meaning a nation deciding its own affairs. Under the act, a nation could sign a contract with the federal government and run federal programs itself, such as its own schools, clinics and police. The word Education is in the act's name because schools were at the center of it.

**Gaming.** Members of Congress set rules for gaming run by Native nations, meaning gambling businesses such as casinos. Their Indian Gaming Regulatory Act became law on October 17, 1988. For some nations gaming became a large source of income, and the amount varies a great deal from nation to nation.

Under the act, tribal gaming falls into three classes of games, and a nation and a state can make a compact, a formal agreement about the games. In the act, members of Congress also set up the National Indian Gaming Commission to watch over tribal gaming.

President George H. W. Bush signed the Native American Graves Protection and Repatriation Act, known as NAGPRA, on November 16, 1990. Under it, Native human remains and sacred objects held in museums and federal collections belong to the nations and families they came from, and the people holding them must send them home, which the law's name calls repatriation.

### Nations take the schools back

Navajo leaders founded a college of their own at Tsaile, Arizona, in 1968. It was called Navajo Community College, and today it is Diné College. It was the first college in the country controlled by a Native nation. Native nations have founded dozens of tribal colleges since.

Senators on a Senate subcommittee on Indian education, a small group of senators assigned to that one subject, published their report in November 1969. The report's title is *Indian Education: A National Tragedy, A National Challenge*. It is known as the Kennedy Report, because Senator Robert F. Kennedy led the work at first and Senator Edward Kennedy finished it.

The report states that federal policy had been "coercive assimilation," forcing a group of people to give up their own language and ways of life, with "disastrous effects." Its authors called for Native people to run Native schools.

Boarding-school enrollment peaked at about 60,000 children in 1973. After that it fell, as the leaders of Native nations took over schools under the 1975 law and other schools closed. A few boarding schools are still open, run by tribes or by the Bureau of Indian Education, the federal office in charge of Indian schools. People who had been children at the schools began publishing accounts of what had happened to them there.

### Wilma Mankiller

> **Who:** the first woman elected Principal Chief of the Cherokee Nation.
>
> **When and where:** Cherokee Nation, Oklahoma. She was chief from December 14, 1985 to August 14, 1995.
>
> **Movie:** *Mankiller* (2017)

**Cherokee voters re-elected her in 1991 with 83 percent of the vote.**

Wilma Mankiller was a child when her family moved to San Francisco under the relocation program. She joined the movement during the occupation of Alcatraz by Indians of All Tribes in 1969.

She went back to Oklahoma. There she worked on projects in which Cherokee communities built their own water lines and health clinics, with the people who lived there doing the work.

She became Principal Chief of the Cherokee Nation, the head of the nation's government, on December 14, 1985, when Ross Swimmer left the office. Cherokee voters elected her in her own right in 1987 and re-elected her in 1991. Until August 14, 1995, she led a nation of about 140,000 citizens.

She received the Presidential Medal of Freedom, an award given by the president of the United States, in 1998. Mankiller died on April 6, 2010.

### Billy Frank Jr.

> **Who:** Nisqually fisherman, a leader of the fish-ins, who later chaired the Northwest Indian Fisheries Commission.
>
> **When and where:** Frank's Landing on the Nisqually River, Washington. He was first arrested at fourteen.

**Officers arrested him more than fifty times for fishing the Nisqually.**

Billy Frank Jr. was fourteen, in 1945, the first time officers arrested him for fishing the Nisqually River. He kept fishing through the fish-ins of the 1960s and 1970s, and he went to jail more than fifty times.

After the Boldt decision of 1974, Frank chaired the Northwest Indian Fisheries Commission.

He died in May 2014 and received the Presidential Medal of Freedom after his death, in 2015. As of 2026, Washington State officials planned to place his statue in the National Statuary Hall in the United States Capitol.

### Adam Fortunate Eagle

> **Who:** Ojibwe writer. He was a Pipestone boarding-school student who became a lead organizer of the Alcatraz occupation.
>
> **When and where:** Pipestone Indian Boarding School, Minnesota, 1935 to 1945. San Francisco Bay, 1969 to 1971.

**He called his boarding-school days "a little bit of heaven."**

Adam Fortunate Eagle spent ten years at the Pipestone Indian Boarding School in Minnesota, from 1935 to 1945. In those years John Collier was Commissioner of Indian Affairs, and federal officials were changing some of the schools. Three decades later, Fortunate Eagle was one of the lead organizers of the occupation of Alcatraz.

He published his account of the school, *Pipestone: My Life in an Indian Boarding School*, in 2010. The line about heaven is from that book. In the same book he writes about the harm the boarding-school system did.

Other people who were children at the schools told it differently. Chester Nez was punished with soap for speaking Navajo at Fort Defiance, and Zitkala-Ša's essays of 1900 criticized her school.

**If you remember one thing:** Members of Congress set out to end the nations as governments in 1953, and by 2000 the nations were running many of their own schools, clinics and courts.

- 1973: Members of Congress restore the Menominee Nation, twelve years after its termination took effect.
- 1974: Judge George Boldt rules that the treaty tribes have a right to half the salmon that can be caught.
- 1978: Members of Congress pass the Indian Child Welfare Act and give tribal courts the power to decide Native children's cases.

**Next:** After 2000 the first Native cabinet secretary had her officials count the boarding-school dead, and five Supreme Court justices ruled that a reservation in Oklahoma had never ended.

## 2000 to Today

**Era 10 of 10 · 2000 to Today · about 9 minutes**

Native nations govern themselves today. There are 574 federally recognized Native nations in the United States, which means that United States officials deal with each one as a government. There are also nations recognized by their states, and nations still working to win federal recognition. More than 200 Alaska Native villages have their own corporations. Native Hawaiians have no federally recognized government of their own.

Census takers counted 9.7 million people who identified as American Indian or Alaska Native, alone or together with another group, in 2020. That was 2.9 percent of the people in the country, and almost forty times the 250,000 counted in 1900.

The Navajo Nation's land covers more than 27,000 square miles across Arizona, New Mexico and Utah. It is the largest reservation in the country. The number of Cherokee Nation citizens passed 450,000 in 2023, counting enrolled citizens, people officially listed as members. Some counts in 2024 and 2025 put it above 475,000.

The National Museum of the American Indian opened on the National Mall in Washington on September 21, 2004. About 25,000 Native people from across North and South America walked in the opening procession.

### Sovereignty in court and in office

Justices of the Supreme Court ruled on a question of Native sovereignty, a nation's right to govern itself, in 2020. When United States officials forced the Muscogee (Creek) Nation to move to Oklahoma, they promised it a reservation there. The justices decided *McGirt v. Oklahoma*, a case about whether that reservation still existed, on July 9, 2020. Five of the nine justices held that members of Congress had never ended it. Four justices disagreed.

Under the ruling, about 3.25 million acres of eastern Oklahoma, including much of Tulsa, are still reservation land. Because of that, Oklahoma's state officials can no longer put Native people on trial for major crimes there. Those cases go to federal and tribal courts instead. Justice Neil Gorsuch wrote the opinion, the written decision of the court. Its first sentence is: "On the far end of the Trail of Tears was a promise."

The Trail of Tears was the forced removal of the Cherokee and the other Southeastern nations to Indian Territory, in what is now Oklahoma, in the 1830s. In later rulings, judges applied the same reasoning to the reservations of the other nations that United States officials had forced out of the Southeast.

Seven of the nine justices upheld the Indian Child Welfare Act, which means they kept it in force, in *Haaland v. Brackeen* on June 15, 2023. The people challenging the act had claimed that it broke the Constitution. Two justices disagreed with the ruling.

Deb Haaland of Laguna Pueblo and Sharice Davids, who is Ho-Chunk, became the first Native American women elected to Congress in 2018. In 2021 Haaland became the first Native American cabinet secretary, as Secretary of the Interior, the head of the federal department in charge of the government's dealings with Native nations.

### Standing Rock, and land returned

Leaders of the Standing Rock Sioux Tribe opposed the Dakota Access Pipeline, a long pipe built to carry oil, in 2016. Its route ran under Lake Oahe, upstream of the reservation. The lake is the reservation's water supply.

People set up camps beginning in April 2016, among them one called Oceti Sakowin. Young people carried the tribe's message on foot. They ran a 500-mile relay to the office of the Army Corps of Engineers, the part of the army whose permission the pipeline needed, in Omaha, and then a 2,000-mile run to Washington, D.C. Thousands of people came to the camps. News reports at the time called the camps the largest gathering of Native nations in more than a century.

North Dakota's governor, Jack Dalrymple, declared an emergency in August 2016 and put the Morton County Sheriff's Office and other police forces under one command. On November 20, 2016, at the Backwater Bridge, officers fired tear gas, rubber bullets and bags filled with lead into a crowd of protesters. They also sprayed the protesters with a fire hose.

**Sophia Wilansky.** A protester named Sophia Wilansky was hit that night. In 2026 federal appeals judges wrote out her account of what happened, in a ruling on her lawsuit. In that account, three officers fired rounds at her as she ducked behind a metal sheet, and one hit her arm. She ran about 30 yards, and as she bent to pick up a piece of plywood, a round fired by Officer Jonathan Moll hit her.

The judges described the round, called an aerial warning munition, as an exploding flash-bang inside a bullet made to hurt rather than kill. "It tore the flesh off her arm, and she fell to the ground," the judges wrote. "Her left hand and forearm are permanently and severely injured." Federal judges threw out her lawsuits and those of the other injured protesters, and no officer was held responsible.

An Army official, the Assistant Secretary for Civil Works, turned down the easement, the legal permission the pipeline needed to cross under the lake, on December 4, 2016. That same week, more than 2,000 United States military veterans arrived to stand with the camps.

**The oil flows.** President Donald Trump ordered the Army to approve the pipeline quickly in January 2017. Army officials granted the easement two weeks later, and oil has moved through the pipeline since that June. A federal judge cancelled the easement in 2020, but the oil kept flowing for about five years without one. Army officials granted the easement again in 2026, and the tribe's leaders then asked the court to end their own appeal.

**Land returned.** Some land has gone back to Native nations. Federal officials took 18,800 acres out of the Flathead Reservation in Montana in 1908 for the National Bison Range, a federal wildlife refuge, land set aside to protect wild animals. Members of Congress passed a law in December 2020 that gave the range back to the Confederated Salish and Kootenai Tribes, and the tribes took over running it in 2022.

### The boarding-school investigation

Secretary Haaland started an investigation of the boarding schools in June 2021. Earlier officials of her own department had run them.

The first volume of the investigators' report came out in May 2022. It identifies 408 federal schools, and marked and unmarked burial sites at 53 of them. The final volume came out on July 30, 2024. It lists 417 federal Indian boarding schools in 37 states or places that were then territories, open from 1819 to 1969. It also lists 1,025 more places with similar aims that fell outside the four rules the investigators used to count federal schools.

The report records what school staff did to the children. Staff cut the children's hair, replaced their clothes with uniforms, gave them English names and forbade them to speak the languages they had grown up speaking. The punishments the report records for speaking those languages include beatings, solitary confinement, which means being locked up alone, holding back food, and washing children's mouths out with soap.

At least 973 children died at the schools. The investigators found at least 74 burial sites at 65 schools. The report states that the real number of deaths is higher than the number the investigators could count.

President Biden apologized on behalf of the United States for the boarding-school system on October 25, 2024. He spoke at the Gila River Indian Community in Arizona, which was Ira Hayes's home community. It was the first formal presidential apology for the system. He called the system "a sin on our soul."

**Coming home.** Children who died at the Carlisle Indian Industrial School are buried in a cemetery at the Carlisle Barracks, an Army post. Army officials have been digging up the children's remains and returning them to their nations.

Army officials returned two children, Little Chief and Horse, to the Northern Arapaho in 2017. When they opened the grave of a third child, Little Plume, they found two other children in it. They found Little Plume and returned him the next year. Nine Rosebud Sioux children went home to South Dakota in July 2021, and Rosebud young people escorted them.

### Schools in Native languages

Boarding-school staff punished children for speaking Native languages. In the two world wars, soldiers used two of those languages, Choctaw and Navajo, to send messages the enemy could not read. Today Native nations run schools that teach children in their own languages.

Hawaii's lawmakers banned teaching in Hawaiian in a law dating from 1896. The first Pūnana Leo immersion preschool, a school where teachers give every lesson in the language itself, opened at Kekaha on Kaua'i in 1984. Children there learn arithmetic and reading in Hawaiian instead of learning Hawaiian as one subject. The Pūnana Leo schools were the first immersion preschools in the United States in an Indigenous language, a language of the people who lived in a place first.

The ban on teaching in Hawaiian was lifted in 1986, and the first public immersion classes opened in 1987. According to ʻAha Pūnana Leo, the group that started the Pūnana Leo schools, students can now be taught in Hawaiian from preschool through graduate school, the university study that comes after a first degree.

Wôpanâak, the Wampanoag language of Massachusetts, had no living speakers after the middle of the 1800s. Jessie Little Doe Baird helped found the Wôpanâak Language Reclamation Project, reclamation meaning taking something back, in 1993. She began rebuilding the language from documents written in it.

Wôpanâak is the first American language with no living speakers to come back into living use. The project opened Mukayuhsak Weekuw, the Children's House, in September 2016. It is a school in Mashpee where Wampanoag children are taught mostly in Wôpanâak.

Cherokee, Lakota, Diné and many other nations run immersion schools of their own.

### Deb Haaland

> **Who:** Laguna Pueblo. She was one of the first two Native American women elected to Congress, and the first Native American cabinet secretary.
>
> **When and where:** New Mexico and Washington, D.C., from 2018.

**Her grandparents were taken to boarding school as children.**

Deb Haaland is a citizen of Laguna Pueblo. She describes herself as a 35th-generation New Mexican. Members of the Senate voted to approve her as Secretary of the Interior on March 15, 2021.

The line about her grandparents is from her own account, which does not name who took them. Three months after the Senate vote, she ordered officials of her department to count what earlier officials had done at the schools. They published the final count on July 30, 2024, while she was still the secretary.

### Jessie Little Doe Baird

> **Who:** Mashpee Wampanoag social worker who became a linguist and brought back a language that no one had spoken since the middle of the 1800s.
>
> **When and where:** Mashpee, Massachusetts, from 1993.
>
> **Movie:** *We Still Live Here: Âs Nutayuneân* (2011)

**She rebuilt a language using a Bible printed in 1663.**

By her own account, the work began with a dream about the language.

Among the written records of the language was the Eliot Bible, a Bible printed in Wôpanâak in 1663. Baird used that Bible and the other documents to rebuild the language.

After she helped found the project in 1993, Baird went to the Massachusetts Institute of Technology and earned a degree in linguistics, the study of how languages work. Her daughter grew up speaking Wôpanâak. In 2010 the MacArthur Foundation gave Baird a MacArthur Fellowship, a prize for people's work.

**The three questions, answered**

- How did Native nations govern themselves and deal with other nations before the United States existed? They ran their own councils and laws, as the Haudenosaunee did under the Great Law of Peace. Their leaders made alliances and treaties and recorded them on wampum belts.
- What did United States officials and soldiers do to take the nations' land and break the nations up? Soldiers forced whole nations west and onto reservations, and killed hundreds of people at a time at Sand Creek, Wounded Knee and other places. Officials cut the nations' land from about 138 million acres to 48 million and took children to boarding schools, where at least 973 died.
- How did Native nations hold on to their governments, their languages and some of their land? They went to court, from *Worcester v. Georgia* in 1832 to *McGirt v. Oklahoma* in 2020. They organized until members of Congress restored the Menominee, and they kept their languages, first in secret and now in schools of their own.

**What changed:** Nations that held nearly the whole continent in the 1600s had lost most of it by 1900, and after 1950 they won back the running of their own governments, schools and courts.

**Five dates to keep**

- 1680: Pueblo fighters drive the Spanish out of New Mexico.
- 1838: Soldiers force the Cherokee west on the Trail of Tears.
- 1887: Allotment begins under the Dawes Act.
- 1974: Judge George Boldt upholds the Northwest fishing treaties.
- 2020: Five justices rule that the Muscogee (Creek) reservation never ended.

**Not known:** whether anyone carried out Oñate's 1599 sentence to cut off the Acoma men's feet, which the Acoma account says happened to 24 men.

**Where to go:** The National Museum of the American Indian, on the National Mall in Washington, D.C.

**Next:** Chapter 3, Land and Environment. It asks how Americans cleared, used up and protected the land, and who lost most at each step.
