**Part 4: Work, Food, and Money**

# Chapter 14: Work and Workers

**Chapter 14 of 37 · Work and Workers · 10 eras · about 85 minutes**

**For most of American history, employers and masters decided how long people worked, how much they earned and how safe the job was, and workers won shorter days and higher pay mainly by acting together.**

In October 1836 the girls in one room of a Lowell mill, in Massachusetts, could not decide whether to turn out, their word for walking off the job together. The managers had just taken more money out of their pay for room and board. Harriet Hanson was 11 and had worked in the mill since she was 10. She later remembered telling them: "I don't care what you do, I am going to turn out, whether anyone else does or not." She walked out, and they followed her.

This chapter follows the people who did the work, era by era, from the farmers and hunters of the Eastern Woodlands before 1500 to the warehouse and delivery workers of today. Watch what happens when workers act together, the way Harriet's room did. Some won higher pay or a shorter day. Others were beaten, jailed or shot by police, hired guards and soldiers. Watch the deaths at work too. Some of the laws that made jobs safer came only after workers died, in a burning mine or behind a locked factory door.

**Three questions this chapter answers**

- Which workers were not free to leave their work?
- What happened when workers went on strike?
- What made work less deadly?

**Five minutes?** Read "The shirtwaist makers and the Triangle fire" in 1900 to 1950.

**Can skip:** "The telephone operators", "The Mohawk ironworkers", "The pandemic, 2020". The chapter still makes sense without them.

## Before 1500

**Era 1 of 10 · Before 1500 · about 1 minute**

The people of North America worked for their own households and towns before 1500, and they planned the work around the seasons. They farmed, hunted, fished and built canoes. Nobody worked for wages, pay from an employer, and no one hired another person, set their hours or fired them. Work for wages began here only after people from Europe arrived.

### Who did which work?

In the Eastern Woodlands, the forests of eastern North America, women and men did different work. Women farmed corn, beans and squash and gathered wild foods, and men hunted and fished. On the biggest jobs they worked together in larger groups: at planting time and at harvest, for building canoes, and for maple sugaring, boiling down the sap of maple trees to make sugar.

Where farmers grew enough food for whole towns, some people could spend their time on one kind of work. They became traders, stoneworkers or religious leaders.

## The 1500s

**Era 2 of 10 · The 1500s · about 2 minutes**

The first work that newcomers organized in this land was forced work. Spanish settlers in Florida and the Southwest made Native people work for them, with little pay or none. Spanish officials ran that forced work under two systems, the encomienda and the repartimiento.

### The encomienda and the repartimiento

Under the encomienda, a system set up by the king of Spain, Spanish settlers could force Native people to work for them and to hand over tribute, payments of goods or work that rulers force people to give. In return the settlers were supposed to give the Native people "protection and religious instruction." Settlers used the encomienda from Florida across the Southwest.

**The repartimiento.** Spanish officials in the colonies added a second system in the middle of the 1500s. Under it, the officials sent Native workers in groups, by turns, to work on Spanish projects, and they were supposed to pay them. In New Mexico, Spanish governors used the repartimiento to farm and to trade. They also forced enslaved people to do the work, though Spanish law forbade it.

### Acoma, 1599: forced work as a sentence

Juan de Oñate, the leader of the Spanish colony in New Mexico, sentenced the survivors of Acoma Pueblo to twenty years of forced labor in February 1599. That meant work they could not refuse and could not leave. Acoma Pueblo is the Acoma people's town, with their fields around it.

**What came before.** Spanish soldiers led by Oñate's nephew, Juan de Zaldívar, came to Acoma in December 1598 to demand food. In the Acoma people's own account, the soldiers raped an Acoma woman: they forced her into sex. The Acoma killed Zaldívar and eleven to fourteen of his men, and accounts differ on the number.

**The attack.** Oñate sent about seventy soldiers back to Acoma in January 1599, led by Vicente de Zaldívar. Over two or three days they killed Acoma men, women and children and burned much of the town. Nobody counted the dead, and estimates run from about 300 to about 1,500.

**The sentences.** Oñate gave the men over 25 two punishments: one foot cut off, and twenty years of forced labor in Spanish households, with no right to leave. Boys and men from 12 to 25 got the twenty years of forced labor only. So did girls and women over 12.

**The feet.** The sentences are in the written record, but whether anyone carried out the cutting of feet is disputed. In the Acoma people's own account, Oñate had the right feet of 24 captive men cut off. Two historians who studied the Spanish records for years, Marc Simmons and John Kessell, came to doubt it, and Kessell points out that no record describes an Acoma man with one foot.

## The 1600s

**Era 3 of 10 · The 1600s · about 5 minutes**

Three of every four newcomers around Chesapeake Bay between 1630 and 1680 were servants bound to a master for years, and they could not quit. Most got no wages. Over the whole colonial period, between one-half and two-thirds of the Europeans who came to the English colonies came this way.

Masters worked them in the tobacco fields, and a sickness in their first summer killed more than half of them. Virginia judges had runaways whipped and added years to their time. In the same century, English colonists began to hold Africans in slavery for life.

### Bound for years: indentured servants

An indentured servant was bound by a written contract, called an indenture, to work for a master for a set number of years. Most terms ran four to seven years, and the servant could not leave. Most servants got no wages. A skilled servant named Buckland was paid 20 English pounds a year on top of his food, drink, washing and a place to sleep, and his contract was unusual.

**How many.** Counts differ. Most estimates run from one-half to two-thirds of all European immigrants to the colonies, and some go as high as three-quarters. Around Chesapeake Bay, about 50,000 servants arrived between 1630 and 1680, three of every four newcomers. In the 1630s there were about six men for every woman among them.

Servants there worked tobacco "from dawn until dusk, six days a week through the growing season." Many fell sick in their first summer. People called this sickness the seasoning, and it killed more than half of the new arrivals. One writer of the time said immigrants died "like cats and dogs."

**Women servants.** Virginia's lawmakers punished a woman servant who had a baby without being married. She had an extra year added to her term, or she had to pay her master 1,000 pounds of tobacco.

At the end of the term, a master owed the servant "freedom dues," goods to start a free life with. In Virginia a man got ten bushels of corn (a bushel is about eight gallons), thirty shillings in English coins and a musket, a long gun. A woman got fifteen bushels of corn and forty shillings.

Masters also took children and teenagers as apprentices, who worked for them to learn a trade such as printing or shoemaking. At home, families did their own spinning, weaving, candle-making and brewing, the making of beer.

### Martin's Hundred, on the land of Tsenacomoco

**Why this place.** Richard Frethorne, an indentured servant whose letters home survive, worked at Martin's Hundred. He arrived in December 1622, nine months after a Powhatan attack there.

Martin's Hundred was an English plantation on the James River in Virginia, and its main settlement was Wolstenholme Towne. The plantation stood inside Tsenacomoco, the land of the Powhatan chiefdom, a union of many Native nations under one high chief.

Tsenacomoco ran north from the James River to the Potomac River, and from Chesapeake Bay west to the places where the rivers drop in falls from higher ground. About 15,000 people lived there.

**The attack of 1622.** The Powhatan leader Opechancanough led an attack on most of the English settlements on March 22, 1622. Colony officials recorded 347 colonists killed. They got no report from some settlements, so the real number was probably higher. The Powhatan fighters killed at least 58 colonists at Martin's Hundred. Its main settlement, Wolstenholme Towne, lost more people than any other settlement.

### Richard Frethorne

> **Who:** An indentured servant in Virginia, probably a young teenager, whose letters home to his parents survive.
>
> **When and where:** Martin's Hundred, Virginia, from December 1622 until his death, recorded by February 1624.

**"When we are sick there is nothing to comfort us," he wrote home.**

Richard Frethorne reached Martin's Hundred in December 1622 on a ship called the *Abigail*, nine months after the Powhatan attack. He had come as an indentured servant, and he was probably a young teenager.

**His letters.** He wrote to his parents in England in March and April 1623. He begged them to buy out his indenture, or else to send food. Since he left the ship, he wrote, he had eaten nothing but peas and loblollie, a thick porridge boiled in water.

**The muster list.** A muster list made by February 1624, a count of the living and the dead at each settlement, records Frethorne, spelled "Frethram," among the dead at Martin's Hundred.

### Runaways, and a sentence for life

Servants who ran away and were caught faced the whip and more years of work. The governor of Virginia and his council sat together as the colony's highest court, called the General Court.

**Three runaways.** These judges heard the case of three runaway servants of Hugh Gwyn, a planter, or owner of a plantation, on July 9, 1640. They ordered two of them, a Dutchman called Victor and a Scotsman named James Gregory, whipped thirty times each. Both men also had to serve extra years.

The third runaway was John Punch, a Black man. For the same escape, the same judges ordered him to serve his master "for the time of his natural Life," which meant for the rest of his life.

**Branding.** Thirteen days later, on July 22, the same judges ordered other runaways whipped thirty times. They also ordered three of them, Christopher Miller, Peter Wilcocke and a Black man named Emanuel, "to be Burnt in the cheek with the letter R." This punishment is called branding. To brand a person was to press a red-hot iron into the skin, and the burn left the letter on the cheek as a scar for life.

The court records name the letter R and the cheek, but they do not describe the iron used, and they do not name the men who did the whipping and the branding. The judges also ordered Miller and Emanuel to work in shackles, iron rings locked around the legs, for a year or more.

**The 1643 law.** Virginia's lawmakers wrote two punishments for runaways into law in March 1643. A runaway had to serve double the time he had been gone. A servant who ran away a second time was to be "branded in the cheek with the letter R." The law did not state who was to do the branding.

## 1700 to 1750

**Era 4 of 10 · 1700 to 1750 · about 2 minutes**

A boy who learned a trade between 1700 and 1750 climbed three ranks: apprentice, journeyman and master. A journeyman, the middle rank, was a skilled worker paid wages by the day. Sailors and dock workers were the other large group who worked for wages, and officers of the British navy could seize them and force them to serve at sea.

Around Chesapeake Bay and in the Lowcountry along the southern coast, colonists held more and more people in slavery. Slave traders brought about 8,600 enslaved Africans to Virginia between 1701 and 1710, about 6,200 between 1711 and 1720, and about 13,000 between 1721 and 1730. Chapter 24, Slavery and Freedom, tells the work and the lives of enslaved people in full.

### The ladder of a trade

A trade such as printing, shoemaking, carpentry or blacksmithing had those three ranks. A child or teenager started as an apprentice, bound to a master to learn the work. When the apprentice's time was up, he became a journeyman and worked for wages. A journeyman who set up a shop of his own became a master.

In the towns, enslaved men also worked at skilled trades. Owners "hired out" some of these men to other employers, who paid wages for the work, and the owners kept the wages.

### Benjamin Franklin

> **Who:** A runaway apprentice, bound at 12 to work in his brother James's print shop.
>
> **When and where:** Boston, New York and Philadelphia, 1718 to 1723.
>
> **Movie:** *Benjamin Franklin* (2022), a two-part documentary by Ken Burns, shown on PBS in April 2022. It is about Franklin's life.

**At 17, with about four years left to serve, Franklin ran away.**

Benjamin Franklin was 12 in 1718 when he was bound as an apprentice to his brother James, a printer in Boston. Under his indenture he had to work in James's shop until he was 21, and only in the last year would he get a journeyman's wages.

**The beatings.** Franklin later wrote that his brother beat him. He also admitted that he himself may have been "too saucy and provoking," which meant rude enough to make James angry. He ran away in September 1723, first to New York and then to Philadelphia. He reached Philadelphia on October 6, 1723, with almost no money.

### Sailors, press gangs and the Knowles Riot

Sailors and dock workers earned wages, and officers of Britain's Royal Navy could impress them: seize them and force them to serve on a navy ship. The groups of men sent to grab them were called press gangs.

**The Knowles Riot.** Press gangs working for Commodore Charles Knowles, a navy officer who commanded a group of ships, seized 46 men in Boston in November 1747. Among them were boatmen, sailors and even carpenters. Beginning on November 17, a crowd made up mostly of working people rioted in Boston for three days. They took some of Knowles's officers as hostages and forced Knowles to free the seized men in exchange.

## 1750 to 1800

**Era 5 of 10 · 1750 to 1800 · about 2 minutes**

Hired workers in Philadelphia began to act together against their employers in the late 1700s. In 1786 journeymen printers there went on strike, stopping work together until their employers met their demands, and they won pay of at least $6 a week. In 1794 journeymen shoemakers in the same city formed a trade union, a group of workers in one trade who join together to bargain, or make a deal, with their employers over pay and hours. Their union lasted.

### The printers' strike of 1786

The journeymen printers of Philadelphia struck in 1786 against a cut in their wages. A US Labor Department list of important events in labor history records the start of the strike as June 2, 1786. The printers won, and their employers agreed to pay at least $6 a week.

The printers also set up a fund of money to support one another during the strike, the first strike fund on record. The same Labor Department list calls theirs "the earliest authenticated strike of workers in the United States in a single trade" (authenticated means proven by records).

**The bakers of 1741.** The labor historian Selig Perlman, writing in 1922, noted that the usual list of American strikes began with New York's bakers, who stopped work in 1741. He found that those bakers were master bakers, the shop owners, protesting a city rule that set the price of bread. By his account, the 1786 printers' walkout was the earliest real strike of workers against their employers known in America.

### The shoemakers' union of 1794

Shoemakers in those days were called cordwainers. Journeymen shoemakers in Philadelphia formed the Federal Society of Journeymen Cordwainers in May 1794, the first trade union in the United States that lasted. Its members called a "turn-out," their word for a strike, to hold a standard wage, the same pay for the same work across the trade.

## 1800 to 1850

**Era 6 of 10 · 1800 to 1850 · about 9 minutes**

Factory owners in the first half of the 1800s ran their workers' days by bells. In the mills of Lowell, Massachusetts, young women worked about 12 hours a day. Children tended machines in the mills, and Irish immigrants dug canals and railroads. Through these years workers fought for a working day of ten hours.

Forming a union, a group of workers who join together to bargain with their employers, could be a crime. A Philadelphia jury found shoemakers guilty in 1806 for forming one to raise their pay. By 1842 a Massachusetts judge had ruled that a union could be lawful.

### Unions on trial, 1806

The union shoemakers of Philadelphia, the cordwainers, held a turn-out, their word for a strike, in November 1805. Four months later, in March 1806, lawyers led by Jared Ingersoll and Joseph Hopkinson put eight of them on trial. Judge Moses Levy heard the case in the Mayor's Court of Philadelphia, a city court.

**The verdict.** The jury found the eight men guilty of conspiracy, a secret plan by two or more people to break the law. In the jury's words, their crime was "a conspiracy to raise their wages." Each man had to pay a fine of $8 and the costs of the trial. After this verdict, prosecutors could take workers to court as criminals for forming a union to raise their pay.

### Children, diggers and charcoal burners

Children worked in the mills, and that was legal. They tended the machines and did the doffing: they took the full bobbins, the spools that held the spun thread, off a spinning machine and put empty ones on.

Gangs of laborers dug the new canals and graded the new railroad lines, which means they leveled the ground for the tracks. Many of these men were immigrants from Ireland.

Making iron took many workers too, and much of the work was cutting wood and turning it into fuel. At Hopewell Furnace, a place in Pennsylvania where workers made iron, the furnace burned charcoal, wood burned slowly with little air until only a black fuel is left. Hopewell paid more than 200 workers from 1835 to 1837, and more than 100 of them were woodcutters.

Most woodcutters worked part of the year, cutting and splitting hardwood through the winter with only axes. A woodcutter cut about two cords a day and was paid by the cord, a stack of cut wood of a set size.

About 20 colliers, the men who made the charcoal, worked there in the 1830s. A collier tended slowly burning mounds of wood day and night, for up to two weeks at a time, and lived in a hut beside them. He was paid by the bushel of charcoal, about eight gallons.

### Who killed the men at Duffy's Cut?

The records do not say. All 57 Irish workers at Duffy's Cut, in Pennsylvania, died in 1832, some of them of cholera, and their remains show that someone killed others.

The 57 men arrived on the ship *John Stamp* in late June 1832. They came from Donegal, Tyrone and Derry in Ireland, and their average age was 22. A contractor named Philip Duffy hired them to dig a cut for the Philadelphia and Columbia Railroad, a channel through high ground so the tracks could run level. They also built up a bank of earth for the tracks. The site was at mile 59 of the line, in Chester County.

**The cholera.** By early August cholera had reached their camp. Cholera is an infection of the gut, spread by water or food that carries traces of a sick person's waste. In bad cases it causes watery diarrhea and vomiting, and the body loses water so fast that a person can go into shock and die. Local people stayed away from the camp.

**The skulls.** A team of researchers dug up some of the men's remains from 2009 to 2012. Some of the skulls had been struck by blows at about the time of death, and one man had a bullet in his skull, fired at close range. None of the remains showed wounds from trying to defend themselves. Someone beat several of the men and shot one.

No record shows that anyone was charged. To explain the killings, the historian who led the dig, William E. Watson, points to fear of cholera and perhaps to nativism, hatred of immigrants.

### Lowell and the mill girls

The owners of the mills built the mill city of Lowell, Massachusetts, at Pawtucket Falls on the Merrimack River. Most of the mill workers were young New England women, aged 15 to 25, known as the mill girls. Under the companies' rules they had to work at least a year, live in a company boardinghouse and go to church. On average a mill girl stayed about three years.

The Lowell mills belonged to Francis Cabot Lowell and other Boston merchants, called the Boston Associates. Their mills spun cotton that enslaved people had grown in the South. The mills also made a cheap cloth that the owners sold to plantations to clothe enslaved people.

**The working day.** A report of the Massachusetts lawmakers in 1845 recorded the hours. From May through August, work began at 5 in the morning and ended at 7 at night, with half an hour for breakfast and 45 minutes for the midday meal. From September through April, work began "as soon as they can see" and ran until 7:30 at night. Across the year the mills ran an average of twelve hours and ten minutes a day, and bells rang the start and the end of work.

**Whose land it was.** The mill owners built on land where the Pennacook people had lived until a war in the 1670s. The falls were a Pennacook fishing and gathering place, and in the 1600s two Pennacook towns stood where Lowell stands now. Their leaders were the sachems, or chiefs, Passaconaway and his son Wannalancet.

**King Philip's War.** Native nations led by Metacom, a Wampanoag leader the English called King Philip, fought the English colonies of New England in 1675 and 1676. About 9,000 people died in the war. Wannalancet kept peace with the English.

**Cocheco, 1676.** Wannalancet led about 400 people from the nations allied with him to Cocheco, in New Hampshire, to make peace with an English captain named Richard Waldron. Waldron broke the peace and took them all prisoner. He later let Wannalancet and about half of the group go.

Waldron sent the others to Boston, where the governor and council of Massachusetts decided what to do with them. Officials in Boston hanged seven or eight of them. About 200 were enslaved for life and shipped to Barbados, an island in the Caribbean Sea, and the records do not name the men who sold them.

Wannalancet and his people moved north to St. Francis in Canada. By the end of the war they no longer lived in the lower Merrimack valley.

### The Lowell turn-outs of 1834 and 1836

The mill managers announced wage cuts of 12 to 25 percent in February 1834. About 800 women turned out, and the strike failed.

**The board increase.** The women who ran the boardinghouses told the mill managers in October 1836 that they could not make ends meet. The managers then took more money out of each woman's weekly pay for room and board, which was the same as a cut in pay. About 1,500 women struck and formed the Factory Girls' Association.

They were better organized than in 1834, and this time they won part of what they asked for. Managers at the Boott and Merrimack mills took back the whole increase. At the Hamilton mill, managers took it back only for workers paid by the day.

### Harriet Hanson Robinson

> **Who:** A child worker in a Lowell mill who led the girls of her room out on strike at age 11, and later wrote a book about the mill girls.
>
> **When and where:** Lowell, Massachusetts, 1835 to 1848. Born February 8, 1825. Died 1911.

**She was 11 when she led her room out on strike.**

Harriet Hanson had started work in a Lowell mill at 10, as a doffer. On the day of the turn-out in October 1836, the girls in her room could not decide whether to leave. She later remembered saying, "I don't care what you do, I am going to turn out, whether anyone else does or not." She walked out, and the others followed her.

She stayed at the mills until 1848. In 1898 she published a book about her years there, *Loom and Spindle, or Life Among the Early Mill Girls*, and in later life she worked for women's right to vote.

### The ten-hour day

Workers in Philadelphia, in Lowell and on federal building jobs wanted a working day of ten hours. Coal heavers, the men who moved coal on and off boats on the docks of the Schuylkill River in Philadelphia, stopped work in 1835, and other workers joined them.

**The first general strike.** By June 10, workers in more than forty trades, or kinds of skilled work, had struck, nearly 20,000 people in all. It was the first general strike in the United States, with workers in many different trades stopping work at the same time. Philadelphia's city officials agreed to the ten-hour day and to raises.

President Martin Van Buren ordered a ten-hour day on March 31, 1840, for laborers on building projects of the United States government. His order covered only workers paid by the federal government, not anyone who worked for a private employer.

### Commonwealth v. Hunt, 1842

The judges of the highest court in Massachusetts, the Supreme Judicial Court, heard a case called Commonwealth v. Hunt in 1842. Chief Justice Lemuel Shaw ruled that in Massachusetts a trade union was not a criminal conspiracy just for being a union. Workers there could lawfully form a union, and they could lawfully strike. Thirty-six years earlier, a Philadelphia jury had found union shoemakers guilty of a crime for doing the same thing.

### Sarah Bagley and the ten-hour petition

Lowell mill workers formed the Lowell Female Labor Reform Association in the winter of 1844 and 1845, with Sarah Bagley as its president. The women sent petitions, written requests signed by many people, to the Massachusetts lawmakers, asking for a ten-hour day. After the petitions came in, the lawmakers looked into conditions in the mills.

**The hearing.** Bagley spoke to a committee of the Massachusetts House in 1845 and told them that she had "worked in the Lowell Mills eight years and a half." The chairman, William Schouler, and all the other members agreed "that legislation is not necessary at the present time," meaning that no new law was needed. They turned down the ten-hour petition. Bagley said afterward that the committee had "misrepresented" what she told them.

## 1850 to 1900

**Era 7 of 10 · 1850 to 1900 · about 14 minutes**

Police, private guards, state militia (the part-time soldiers of each state) and federal soldiers broke many strikes between 1850 and 1900, and they shot and killed strikers. The workers had formed the first national unions, to fight for higher pay and an eight-hour day.

The work itself was dangerous, in mines, mills, rail yards and sweatshops, crowded workshops where people sewed clothing for long hours and low pay. Children worked beside adults. In the cotton mills of the South, they worked 12-hour days, six days a week.

### The Chinese railroad strike, 1867

Thousands of Chinese workers built the Central Pacific Railroad through the Sierra Nevada mountains of California in the 1860s. White workers on the line earned $40 a month, and the Chinese workers earned $35. Several thousand of them went on strike on June 25, 1867, and estimates of their number run from 2,000 to 5,000.

They asked for the same pay as white workers, shorter hours and an end to whipping. The records do not name the men who whipped them. The company's managers cut off the food supply to their camps. After eight days the strike ended with no promises from the company, though pay later rose a little. It was the largest strike by workers in the country up to that time.

### Why 110 people died at Avondale, 1869

A fire killed 110 people at the Avondale coal mine, in Plymouth Township near Wilkes-Barre, Pennsylvania, on September 6, 1869. Among the dead were five boys and two men who tried to rescue the workers.

**One way out.** Above the mine stood the breaker, a tall wooden building where coal was broken up and sorted. It stood over the mine's only shaft, the one way in and out. Sparks from the furnace that pushed air through the mine set the breaker on fire, and the men and boys below had no other way out. Pennsylvania's lawmakers passed a mine safety law in 1870 that required more than one exit from every mine.

### The Knights of Labor

A tailor named Uriah Smith Stephens founded the Knights of Labor in Philadelphia on December 9, 1869, as a secret society. Terence V. Powderly later led it and opened it up to the public. The Knights had fewer than 10,000 members in 1879 and about 700,000 by 1886.

The Knights let women join, and in some places Black workers too. Besides higher wages, they called for an eight-hour day, equal pay for equal work, and an end to child labor and to the work of prisoners leased to companies. They also wanted the public, not private owners, to own utilities, the companies that supplied things like gas and water.

### Servants, children and sweatshops

Census takers count everyone in the country for the United States government every ten years, and in 1870 they counted women's work carefully for the first time. They found 867,354 domestic servants, people paid to cook, clean and care for other families' homes, about half of all women who worked for pay. Domestic service stayed the largest job for women in every census from 1870 to 1940.

**Children at work.** At least 18 percent of all children aged 10 to 15 had jobs from 1890 to 1910, nearly 1 in 5. In Philadelphia, the pay children brought home made up 28 to 46 percent of their family's income, depending on the family's ethnic group.

In the South, cotton mill owners hired children in growing numbers. Of the nearly 100,000 textile workers in the South in 1900, 25,000 were children under 16. By 1904 there were 50,000 children in the mills, and 20,000 of them were under 12. They worked 12-hour days, six days a week. Mill owners said the fingers of adult farm workers were too "knotted and gnarled" for mill work.

In the hard-coal fields of Pennsylvania, breaker boys sat on benches in the breakers and picked slate, a kind of rock, out of the coal. In the cities, people sewed clothing in sweatshops set up in lofts, the open upper floors of buildings, and in tenements, cheap apartment buildings packed with families.

### The Great Railroad Strike, 1877

John W. Garrett, the president of the Baltimore and Ohio Railroad, cut his workers' wages by 10 percent in July 1877, and it was not the first cut. Workers at Martinsburg, West Virginia, walked off the job. The strike spread through West Virginia, Maryland, Pennsylvania, New York, Missouri and Illinois.

Governors called up their state militias, and President Rutherford B. Hayes sent federal troops. He issued the orders for West Virginia on July 18, Maryland on July 21 and Pennsylvania on July 23.

**Pittsburgh.** Militiamen brought in from Philadelphia opened fire on a crowd in Pittsburgh on July 21. They killed more than twenty people, among them a woman and three small children. The official death count for Pittsburgh was 26, and the real number was likely higher.

**Reading.** Two days later, in Reading, Pennsylvania, a crowd threw bricks and stones down on militiamen marching through a deep cut for the railroad. Some of the soldiers fired into the crowd and killed at least ten people. By September 1877, state and federal troops had broken the strike, and the workers won nothing at the time.

### The telephone operators

A new job came with the telephone. Calls went through a switchboard, where an operator connected each caller to the person being called, and the first operators were teenage boys. Emma Nutt became the first woman operator on September 1, 1878, at a telephone company in Boston, and her sister Stella started the same day. Emma Nutt earned $10 a month for a 54-hour week. The companies' managers replaced the boys with women, and by the late 1880s nearly all operators were women.

### The eight-hour day and Haymarket, 1886

Workers across the country went on strike for an eight-hour day on May 1, 1886, about 35,000 of them in Chicago. Two days later, Chicago police fired on strikers at the McCormick Harvesting Machine Company plant and killed at least two of them.

**The bomb.** Workers held a meeting in Chicago's Haymarket Square on May 4 to protest the killings. Inspector John Bonfield marched on the meeting with 176 police officers and ordered the crowd to break up. Then someone threw a dynamite bomb at the police, and the police drew their guns and fired wildly. No one has ever proved who threw the bomb.

**The dead.** Counts differ. A Library of Congress history page lists seven police officers and at least four people in the crowd killed. A Chicago History Museum page lists eight police officers dead and sixty wounded, and an unknown number in the crowd killed or wounded.

**The trial.** A Chicago jury convicted eight anarchists, people who believe there should be no government, of conspiracy. None was shown to have thrown the bomb. Judge Joseph E. Gary sentenced seven of them to death and the eighth, Oscar Neebe, to fifteen years in prison.

Officials at the Cook County Jail hanged four of the men on November 11, 1887: Albert Parsons, August Spies, George Engel and Adolph Fischer. A fifth, Louis Lingg, killed himself in his cell with a small bomb that someone smuggled in to him. The last two, Samuel Fielden and Michael Schwab, had asked for mercy, and the governor of Illinois at the time changed their sentences to life in prison.

**The pardon.** A later governor of Illinois, John Peter Altgeld, pardoned Fielden, Schwab and Neebe, the three men still in prison, in June 1893. The pardon freed them from the rest of their punishment. Altgeld found that the trial had been unfair, and he wrote that Judge Gary ran it with "malicious ferocity," meaning cruel, spiteful anger.

**Altgeld's reasons.** A court officer named Ryce had the job of calling in the men who would sit on the jury. The state's attorney, the lawyer who brought the case, had suggested Ryce for that job. Altgeld wrote that Ryce called in jurors who were already against the men on trial.

Altgeld also wrote that "much of the evidence given at the trial was a pure fabrication," which means it was made up. Some leading police officials, he wrote, had threatened men with torture and had offered money and jobs to anyone who would swear to what the police wanted.

**The Knights.** After Haymarket, most members left the Knights of Labor. By 1890 the Knights had about 100,000 members, down from about 700,000 in 1886.

### The American Federation of Labor

Leaders of craft unions, each made up of the skilled workers of one trade such as cigar makers or carpenters, met in Columbus, Ohio, on December 8, 1886. There they founded the American Federation of Labor, the AFL. Its union leaders bargained with employers for higher wages and shorter hours, a way of running unions called "pure and simple" unionism.

### Samuel Gompers

> **Who:** A cigar maker who became the first president of the American Federation of Labor.
>
> **When and where:** Born in London, January 27, 1850. Worked in New York. President of the AFL from 1886 to 1924, except for 1895.

**A cigar roller from London led the AFL for almost forty years.**

Samuel Gompers made cigars from boyhood, and in New York he rolled them in tenement shops. He became the first president of the American Federation of Labor and served from 1886 to 1924, except for one year, 1895.

Gompers built the AFL around wages and hours. Its unions had about 140,000 members in 1886 and nearly 3 million by 1924, about twenty times as many.

### Why brakemen lost their fingers

A brakeman on a railroad joined, or coupled, the cars of a train by hand. He stood between two cars as they moved together and guided an iron link into a socket. Brakemen's hands were crushed, and missing fingers were called "the badge of the experienced worker." Thousands of brakemen died.

**A safer way.** Eli Janney got a patent for an automatic coupler in 1873, the right to be the only one to make and sell it for a set time. The Westinghouse air brake, a brake worked by air pressure, had existed since 1869. Railroad owners did not put either one on most of their cars.

Members of Congress voted through the Safety Appliance Act in 1893, and it required both on trains by 1900. Coupling accidents fell from about 11,000 in 1892 to about 2,000 in 1902, while the number of railroad workers grew.

### Homestead, 1892

**The lockout.** The steelworkers' union contract at Carnegie Steel's works in Homestead, Pennsylvania, was running out in the summer of 1892. Henry Clay Frick, the chairman of Carnegie Steel, cut pay for hundreds of the workers and refused to bargain with the union. On June 29 he shut the plant and locked out all 3,800 workers, keeping them out of their jobs. The workers went on strike, and armed strikers surrounded the plant and closed off the town.

On July 6, 300 agents of the Pinkerton detective agency, a private company that Frick had hired, tried to land from barges and take the plant back. Strikers and Pinkertons fought a gun battle, and seven workers and three Pinkerton agents were killed. Some accounts count more.

Eight thousand state militiamen, sent by the governor of Pennsylvania, arrived at Homestead on July 12. By November the strike had failed, and the steelworkers at Homestead no longer had a union.

### Pullman, 1894

The Pullman Palace Car Company's workers made and repaired railroad cars near Chicago. They lived in Pullman, Illinois, a company town, where the company owned the houses and its managers collected the rent. The company's managers cut wages by about 25 to 35 percent in 1893 and 1894, and they did not cut the rents.

The workers belonged to the American Railway Union, founded in June 1893. It was the first industrial union, taking in every kind of railroad worker in one union instead of one craft at a time.

**The boycott.** The union's members held a convention, a big meeting of delegates sent by its branches, in June 1894, and the delegates voted for a national boycott of Pullman cars. In the boycott, railroad workers across the country refused to handle trains that carried Pullman cars. While it spread, on June 28, 1894, President Grover Cleveland signed a law making Labor Day a federal holiday.

**The court order.** Attorney General Richard Olney, the federal government's top lawyer, took the union to court. Federal judges William Woods and Peter Grosscup issued an injunction, a court order to stop doing something, on July 2, 1894. They ordered Eugene V. Debs, the union's founder, and its other officers to stop anything that got in the way of the mail or of trade between the states.

**The troops.** The next day, over the protest of Governor Altgeld, President Cleveland ordered federal troops into Chicago. More than 16,000 troops were called up across the country, and the soldiers arrested boycotters and rioters and sometimes shot them.

About 30 people were killed across the country, and some counts reach 34. Accounts of the strike do not say who killed each of them. Federal judges and soldiers ended the boycott.

### Jennie Curtis

> **Who:** A seamstress in the Pullman shops whose speech helped start the Pullman boycott.
>
> **When and where:** Pullman, Illinois, 1893 and 1894. Born 1871. Died 1917.

**Her pay fell from as much as $2.25 a day to 80 cents.**

Jennie Curtis spoke to the American Railway Union's convention in June 1894, and her speech helped persuade the delegates to vote for the Pullman boycott.

She had worked for five years as a seamstress in the sewing room of Pullman's repair shops. She told how the women there made "all the carpets, and all the silk, satin, plush, and velvet drapings for the dining cars," and they sewed the cloth covers for the seats.

**Two cuts in one week.** Before the depression of 1893, a time when many businesses failed and many people lost their jobs, she earned $1.50 to $2.25 a day. Pullman's managers cut her pay twice in one week in November 1893, and it fell to about 80 cents a day. Many of the girls she worked with averaged 40 to 50 cents.

Curtis was president of Local 269, the union's branch for young women workers, which had 125 members. Later in 1894 she told the United States Strike Commission, a panel that looked into the strike, about wages, rents and abusive supervisors. She said her father had worked for Pullman for 13 years. When he died, he owed back rent, and Pullman's managers collected it.

### Eugene V. Debs

> **Who:** A locomotive fireman who founded the American Railway Union and went to jail for leading the Pullman boycott.
>
> **When and where:** Terre Haute, Indiana, and Chicago. Founded the union in June 1893.
>
> **Movie:** *American Socialist: The Life and Times of Eugene Victor Debs* (2017), a documentary directed by Yale Strom. It is about Debs's life.

**He ran for president from a prison cell, as Convict 2253.**

As a young man in Terre Haute, Indiana, Eugene V. Debs was a locomotive fireman, the worker who shoveled coal into the engine's fire. He became an officer of the Brotherhood of Locomotive Firemen, a union for that one craft.

He founded the American Railway Union in 1893, for all railroad workers. After the Pullman boycott, judges found him guilty of contempt of court, disobeying a court's order, and he served six months in the jail at Woodstock, Illinois, in 1895.

**Convict 2253.** Debs later ran for president five times as a Socialist, one of those who wanted the public, not private owners, to own the big industries. He gave a speech against the war in 1918, and he was sentenced to ten years in prison for it.

He ran for the last time in 1920 from his prison cell, as Convict 2253, and got between 900,000 and 1 million votes. President Warren Harding shortened his sentence, and Debs went free at Christmas 1921.

### Lattimer, 1897

Nearly 400 immigrant coal miners marched from Harwood to Lattimer, Pennsylvania, on September 10, 1897, to support a strike, and they carried no weapons. Luzerne County Sheriff James Martin had deputized nearly 90 men, which means he had given them the power to act as officers of the law. The deputies fired on the marchers. They killed 19 men, who were Polish, Slovak and Lithuanian, and wounded 38. Many were shot in the back.

Martin and his deputies were tried for murder from February 1 to March 2, 1898, and the jury found every one of them not guilty. By 1900 the United Mine Workers, the coal miners' union, was the fastest-growing union in the country.

### Convict leasing

State officials in the South leased, or rented out, prisoners to mines, railroads and planters after the Civil War, and the people who leased them forced them to work. This was called convict leasing. Most of the prisoners were Black men, and in Alabama more than 90 percent of the state prisoners leased out were Black.

**The Black Codes.** Sheriffs arrested many of them for small offenses under the Black Codes, laws that Southern lawmakers passed from November 1865 to make Black people prove they had work. In Alabama, contractors whipped prisoners who tried to escape or did not work hard enough. Every year, 4 or 5 of every 100 leased state prisoners in Alabama died.

**If you remember one thing:** Workers built the first national unions in these fifty years, and police, deputies, militiamen and federal soldiers broke many of their strikes by force, firing on strikers and crowds from Pittsburgh to Lattimer.

- 1869: A fire at the Avondale mine kills 110 people, because the mine had only one way out.
- 1886: Workers strike for an eight-hour day, and after the Haymarket bomb officials hang four men who were never shown to have thrown it.
- 1894: Federal judges and soldiers end the Pullman boycott, and about 30 people are killed.

**Next:** After 1900 children still worked in the mines and mills, and a fire in a New York garment factory killed 146 workers.

## 1900 to 1950

**Era 8 of 10 · 1900 to 1950 · about 23 minutes**

Members of Congress passed the first federal laws for a lowest wage, a shorter work week and the right to form a union in the 1930s, after three decades of child labor and deaths on the job. Under the Wagner Act of 1935, forming a union became a legal right. A law of 1938 set a minimum wage of 25 cents an hour and a work week of 44 hours, falling to 40 by 1940, and it banned most work by children under 16.

Children still worked in mills and mines in the first years of the century. In 1900, 1,489 coal miners were killed at work, and in 1907, 3,242. A fire killed 146 workers in a New York garment factory in 1911.

At Ludlow, Colorado, in 1914, National Guard soldiers burned a camp of striking miners' tents, and the fire killed 13 women and children hiding in a pit under one tent. In Chicago in 1937, two years after the union law, police shot and killed ten people who were marching to support a steel strike.

### The hard-coal strike, 1902

In Pennsylvania, 147,000 hard-coal miners and breaker boys, the boys who picked waste rock out of the coal, went on strike in May 1902. They stayed out for about five months, until October. President Theodore Roosevelt stepped in as a mediator, a go-between who helps both sides reach a deal. It was the first time a president had done this in a strike. Earlier presidents had sent troops to break strikes, as in 1877 and 1894.

**The commission.** Roosevelt set up a commission, a group of people chosen to look into the strike. Its members heard 558 witnesses, and some of them were breaker boys younger than nine. The commission's members ruled in March 1903 that the miners should get a 10 percent raise and a nine-hour day.

### Mother Jones

> **Who:** Mary Harris Jones, a union organizer for coal miners whom a prosecutor called "the most dangerous woman in America."
>
> **When and where:** Baptized in Cork, Ireland. Organizing from the 1870s, and for the United Mine Workers from the 1890s. Died 1930.

**She led striking mill children on a march toward the president's home.**

**The children's march.** Children who worked in textile mills in Philadelphia were on strike in July 1903. Mary Harris Jones, known as Mother Jones, led them on the March of the Mill Children, from Philadelphia toward the home of President Theodore Roosevelt at Oyster Bay, New York. She wanted people across the country to look at child labor.

**How she became an organizer.** She had worked as a dressmaker. Her husband and all four of her children died of the disease yellow fever in Memphis, Tennessee, in 1867, and she lost her home and her shop in the great fire in Chicago in 1871. After that she became a full-time organizer, and from the 1890s she worked above all for the United Mine Workers. In 1902 a prosecutor in West Virginia called her "the most dangerous woman in America."

**Her age.** She celebrated her "100th" birthday on May 1, 1930, and died later that year. The record of her baptism in Cork gives August 1, 1837, which would have made her 92.

### How many miners died?

The worst year on record was 1907, when 3,242 coal miners were killed at work out of 680,492, about 1 miner in every 210. In 1900 the number killed had been 1,489.

**Monongah.** Explosions in mines No. 6 and No. 8 at Monongah, West Virginia, killed hundreds of men and boys on December 6, 1907, and some of the boys were as young as eight. The official count was 362 dead. The West Virginia Mine Wars Museum and later estimates put the dead at more than 500, and about 1,000 children lost their fathers.

Accounts differ on which company ran the mines, the Fairmont Coal Company or the Consolidation Coal Company. The Fairmont company's president, C. W. Watson, blamed "the careless use of a mining lamp." No record shows that anyone was charged.

### Lewis Hine photographs the children

Lewis Hine left his job as a teacher in 1908 to take photographs of working children. He worked for the National Child Labor Committee, a group trying to end child labor. From 1908 to 1917 he made thousands of pictures of children at work in mills, mines, food-canning plants and on city streets.

### Addie Card

> **Who:** A child spinner in a Vermont cotton mill whose photograph by Lewis Hine appeared on a United States postage stamp in 1998.
>
> **When and where:** North Pownal, Vermont, 1910. Died 1993.

**Hine wrote her name down wrong, as "Addie Laird."**

Lewis Hine photographed Addie Card at her spinning machine in the cotton mill at North Pownal, Vermont, in 1910. Hine wrote that she was 12, but the girls at the mill told him she was 10. He called her an "anemic little spinner," anemic meaning pale and weak because the blood is not carrying enough of what the body needs. The picture appeared on a United States postage stamp in 1998.

**Her real name.** A researcher named Joe Manning, working with the novelist Elizabeth Winthrop, found her real name and traced her life in 2005 and 2006. She married Edward Hatch in 1915, at 17. They split in 1925, and he won custody of their daughter. She married again, to Ernest Lavigne, and got another job in a mill in Cohoes, New York. In her last years she lived in a housing project in Cohoes, and she died in 1993.

### The shirtwaist makers and the Triangle fire

Many young immigrant women in New York City sewed shirtwaists, women's blouses, in garment shops. The shirtwaist makers held a meeting at Cooper Union, a hall in New York, on November 22, 1909.

**The Uprising of the 20,000.** Clara Lemlich, a shirtwaist maker, was still bruised from a beating by men hired by her company. She stood up and spoke in Yiddish, the language of many Jewish immigrants. "I have no further patience for talk," she said. "I move we go on strike." About 20,000 garment workers struck for eleven weeks.

**The fire.** A fire broke out on the top floors of the Triangle Waist Company's building near Washington Square on March 25, 1911, and it killed 146 workers. Most of them were young immigrant women, and some were only 14. On the ninth floor, the door to one stairway was locked, and no record proves who locked it. Dozens of workers jumped from the building.

**The trial.** The owners of the company, Max Blanck and Isaac Harris, were tried for manslaughter, the crime of killing someone without meaning to, through a wrongful act or through carelessness. The jury found them not guilty on December 27, 1911, because the prosecutors could not prove that the owners knew the door was locked. New York's lawmakers then set up the Factory Investigating Commission, and they rewrote the state's factory safety laws.

### Rose Rosenfeld Freedman

> **Who:** A worker who survived the Triangle fire and spent the rest of her life telling what happened there.
>
> **When and where:** New York City, March 25, 1911. Died February 15, 2001, at 107, the last survivor of the fire.

**For ninety years she told the truth about the locked doors.**

Rose Rosenfeld was two days short of her 18th birthday when the Triangle fire broke out. She got out by following the company's executives up the stairs to the roof of the building, on the tenth floor, and from the roof rescuers pulled the survivors across.

She later said that the owners offered her money to keep quiet about the locked doors, and that she turned it down. She died in Beverly Hills, California, in 2001, at 107, the last survivor of the Triangle fire.

### Frances Perkins

> **Who:** A woman who watched the Triangle fire, later became the first woman in a president's Cabinet, and pushed for the law that set the country's first federal minimum wage.
>
> **When and where:** New York, 1911. Secretary of Labor in Washington, 1933 to 1945.
>
> **Movie:** *Summoned: Frances Perkins and the General Welfare* (2020), a documentary by Mick Caouette, shown on PBS. It is about Perkins's life.

**Frances Perkins watched the Triangle workers jump from the building.**

She was having tea near Washington Square on March 25, 1911, when the fire broke out, and she ran to the building. She later said that the New Deal, the set of programs President Franklin Roosevelt started in the 1930s, began on that day.

**In the Cabinet.** After the fire, Perkins worked as an investigator for New York's Factory Investigating Commission. President Roosevelt made her Secretary of Labor in 1933. She was the first woman in a US Cabinet, the group of top advisers who run the government's departments, and she held the job until 1945. She pushed for the Fair Labor Standards Act and for Social Security, the government's program of payments to people who are old or cannot work.

### Lawrence, 1912

Massachusetts lawmakers cut the legal work week from 56 hours to 54 in 1912, and mill owners in Lawrence, Massachusetts, then cut their workers' pay. The workers struck on January 12, 1912. Most of them worked for the American Woolen Company. More than half of the mill workers were women and children, and they spoke more than a dozen languages. Leaders of a union called the Industrial Workers of the World sent organizers, who ran committees that gave out food and help.

**The children.** The strikers began sending their children to other cities in February, to live with relatives or with strangers who could feed them and keep them safe during the strike. On February 24, police at the Lawrence railroad station clubbed women and children who were trying to send children away, and they jailed 30 women. The owners agreed on March 12 to a 15 percent raise, double pay for overtime (extra hours of work) and no punishment for the strikers.

### The assembly line

Managers at Henry Ford's plant at Highland Park, Michigan, started a moving line to build car frames, called chassis, on October 7, 1913. The work moved past 140 assemblers along 150 feet of line, and each man did the same few motions over and over, at the speed of the line. Building a chassis had taken more than 12 hours. On the line it took about 93 minutes.

**The pace.** Many men could not stand the pace, and they quit. Worker turnover at the plant reached 370 percent in 1913, which means that for every job, Ford's managers had to hire nearly four men in a year. Ford announced a pay of $5 for an eight-hour day on January 5, 1914. Before that, pay had been about $2.34 for nine hours.

The $5 day came with conditions. Ford's managers called part of the money "profit-sharing," and they paid that part only to men who passed inspections of their homes. Company investigators, from an office that the managers called the Sociological Department, checked whether a man drank, whether he saved money, how clean his home was and whether he took in boarders, people who paid to live in a room of his home. The managers left out workers under 22 and, at first, most women.

### Ludlow, 1914

Coal miners in Colorado went on strike in September 1913. They wanted the state's mining laws enforced, and they wanted the mine owners to recognize their union, the United Mine Workers, which means to accept it and bargain with it. Most of them worked for the Colorado Fuel and Iron Company, whose main owner was John D. Rockefeller Jr. The strikers and their families lived in tent colonies.

**The Death Special.** Men in an armored car belonging to the company, called the "Death Special," fired on the tent colony at Forbes in October 1913 and killed one person. Governor Elias M. Ammons sent in the Colorado National Guard, the state's soldiers, and the mine owners paid for it.

**The fire at Ludlow.** Fighting broke out at the tent colony at Ludlow on April 20, 1914, and nobody knows who fired the first shot. Guardsmen burned the tents. At least 19 people were killed: one guardsman, five miners, and thirteen women and children who had hidden in a pit dug under a tent. The women and children suffocated, which means they died because they could not get air. Guardsmen shot the strike leader, Louis Tikas, three times in the back.

Miners then attacked mines across the region and killed supervisors and guards, and nobody knows exactly how many. President Woodrow Wilson sent in the US Army on April 28. The strike ended in December 1914, and the miners won none of their union's goals.

**By 1914:** Henry Ford paid $5 for an eight-hour day, and New York had rewritten its factory laws after the Triangle fire, but no federal law yet limited children's work or set a lowest wage.

### The first child-labor law, and the justices who threw it out

Members of Congress passed the Keating-Owen Act in 1916, the first federal law against child labor. Under it, a company could not ship goods to another state if it had used child workers to make them. It covered children under 14 in mills, food-canning plants and factories, and children under 16 in mines. Children aged 14 to 16 could not work more than 8 hours a day or 6 days a week, or at night.

**Hammer v. Dagenhart.** Roland Dagenhart and his sons Reuben, 14, and John, 12, worked in a cotton mill in Charlotte, North Carolina. Under the new law John would have to stop working, and Reuben would lose hours from his 60-hour week. A committee of Southern cotton mill owners recruited Dagenhart to sue and paid his legal costs. He argued that the law took away the money his sons earned.

The justices of the Supreme Court ruled 5 votes to 4 on June 3, 1918, in the case Hammer v. Dagenhart, that the law broke the Constitution and could not be used. The five justices in the majority said that Congress's power over trade between the states did not cover how goods were made, and Justice Oliver Wendell Holmes disagreed. Members of Congress passed a second child-labor law in 1919, and the justices threw that one out too.

### Grace Fryer

> **Who:** A painter of glowing watch dials who was poisoned by radium at work and sued the company while she was dying.
>
> **When and where:** Orange, New Jersey. Worked from 1917 to 1920. Sued in 1927. Settled in June 1928.
>
> **Movie:** *Radium Girls* (2018), a drama inspired by the dial painters' case. Its main characters are two invented sisters, not Grace Fryer.

**"Our instructors told us to point [our brushes] with our lips."**

Grace Fryer painted watch dials with glowing paint at the United States Radium Corporation in Orange, New Jersey, from 1917 to 1920. The paint glowed because it contained radium, which gives off radiation, energy that damages the body from the inside. Supervisors taught the women to shape the tip of the brush with their lips, so the radium paint went into their mouths, and they told the women the paint was safe.

**What the radium did.** Radium is in the same chemical family as calcium, so the body takes it into the bones and teeth, and almost all of it stays in the skeleton. Scientists who studied the dial painters found that it stopped the body from making enough new blood cells, killed the bone of the jaw so that the jawbone broke down, and caused bone cancer.

A dentist named Theodor Blum examined Grace Fryer in 1924 and found that her jawbone was wasting away in a way he had never seen before. As the dial painters fell sick and died, company officials played down and disputed the poisoning.

**The lawsuit.** A lawyer named Raymond Berry sued the company in May 1927 for five of the women: Grace Fryer, Katherine Schaub, Quinta Maggia Macdonald, Albina Maggia Larice and Edna Hussman. Reporters called them "the five women doomed to die," and some of them were too sick to travel to court.

The company's officials agreed in June 1928 to pay the women to end the lawsuit, in a deal called a settlement. Each woman received $10,000 (some accounts say $15,000), $600 a year for as long as she lived and payment for her medical bills, which a committee of three doctors had to approve. The company's officials never admitted that the company was to blame.

### Catherine Wolfe Donohue's case, 1938

A supervisor named Miss Murray also taught the dial painters at the Radium Dial Company plant in Ottawa, Illinois, to point their brushes with their lips. Catherine Wolfe Donohue was one of them. "We would first dip the brush into water, then into the powder, and then point the ends of the bristles between our teeth," she said.

**The box of bones.** She came to a hearing on February 10, 1938, with a box of pieces of bone that she said had come from her jaw. When the judge asked her doctor about her chances, she collapsed, and several men carried her from the room. She weighed 71 pounds.

**The ruling.** The hearing officer, the official who ran the hearing, ruled on April 5, 1938, that her illness came from her work at the plant. He awarded her $5,661, paid as $277 a year for life. The company's lawyers appealed, asking for a new ruling. The members of the Illinois Industrial Commission, a state board that decided workers' claims, turned down the appeal on July 6, 1938, and added $730.

Donohue died later that month, at 35. The last appeal in her case ended in October 1938, after her death.

### How many men died digging the Hawks Nest tunnel?

Nobody knows exactly. Almost 5,000 men dug the Hawks Nest tunnel near Gauley Bridge, West Virginia, from 1930 to 1932, most of them Black men from the South, and counts of the dead run from 476 to close to 1,000.

**Who had it dug.** Managers of the Union Carbide company had the tunnel dug to carry water to a power plant, which was built to supply power to Union Carbide's alloy works, where metals were mixed. They hired the Rinehart and Dennis company of Charlottesville, Virginia, to do the digging.

**The dust.** The tunnel went through sandstone made mostly of silica, the hard mineral that sand is made of, and a third of it was dug wider so that the silica could be mined. The men worked with no dust control and nothing to protect their breathing, in poor air underground.

Breathing silica dust causes silicosis. The dust forms scar tissue in the lungs, and the scarred lungs cannot take in enough oxygen. Silicosis cannot be cured, and in bad cases it kills.

**The counts.** Members of a US House of Representatives committee held hearings in 1936 and put the deaths at 476. The scientist Martin Cherniack studied the records in 1986 and found as many as 764. Scientists at the National Institute for Occupational Safety and Health, the federal agency that studies workers' health, said close to 1,000 in 2002.

The workers and their families filed 538 lawsuits. They ended in a settlement of $200,000 in all, and single payments ran from $30 to $1,600.

### Building the skyscrapers, the bridge and the dam

Up to 3,400 workers a day built the Empire State Building in New York, and by the official count five of them died. Lewis Hine photographed the ironworkers high on the open steel frame in 1931. Mohawk ironworkers from Kahnawake, a Mohawk community just south of Montreal in Canada, worked in the building crews.

**The Golden Gate Bridge.** The chief engineer, Joseph Strauss, required workers on the bridge in San Francisco to wear hard hats, and he spent about $130,000 on a safety net under it. The net caught 19 men who fell, and they called themselves the "Halfway to Hell Club." One of them, the ironworker Al Zampa, fell on October 19, 1936, broke four bones in his back and went back to ironwork.

Eleven men died building the bridge. Ten of them died on February 17, 1937, when a falling platform tore through the net.

**Hoover Dam.** The federal Bureau of Reclamation's official count is 96 deaths on the job. It leaves out 42 deaths that were recorded as pneumonia, a disease of the lungs. The true number of deaths at the dam is not known.

Managers at Six Companies, the company that hired the dam workers, had crews drive gasoline trucks inside the tunnels the men dug at the dam site. The trucks' exhaust filled the tunnels with carbon monoxide, a poison gas from engines. When tunnel workers fell very ill or died, company doctors said they had a form of pneumonia. A history of the dam kept by the University of Nevada, Las Vegas library describes this, and so does a book of dam workers' memories by the historians Andrew Dunar and Dennis McBride.

**The lawsuit.** Six workers sued Six Companies in 1933. They said the gas had poisoned them and left them with lasting illness, and each asked for $75,000 plus lost pay. Company officials hired a private detective to look into the men's pasts. More workers came forward and joined the case, and in the end the officials settled with 50 workers and paid them an amount they kept secret.

### The right to organize and the sit-down strikes

Many businesses closed and millions of people lost their jobs during the Great Depression of the 1930s. At its worst, in 1933, about 12.8 million people, almost one worker in four, had no job. Federal officials hired people who were out of work through programs such as the Works Progress Administration and the Civilian Conservation Corps. Under the Wagner Act, which members of Congress passed in 1935, forming a union became a legal right for workers.

**The CIO.** That same year John L. Lewis and other union leaders formed a new group inside the American Federation of Labor, the AFL, a large group of unions of skilled workers, to organize whole factories. The AFL's leaders threw them out, and the group became the Congress of Industrial Organizations, the CIO. Its unions took in every worker in a mass-production plant, such as a car factory or a steel mill.

**Flint.** Autoworkers in Flint, Michigan, sat down inside General Motors' Fisher Body plants on December 30, 1936. In a sit-down strike, workers stop working but stay inside the plant, so the company cannot bring in other workers. They stayed for 44 days, until February 11, 1937.

The Women's Emergency Brigade, led by 23-year-old Genora Johnson, guarded the plants. When police fired tear gas at the men inside one of General Motors' plants, the women broke its windows. "We used our clubs to smash the windows out so the men inside could get some air," Johnson remembered. General Motors' managers agreed to recognize the United Auto Workers.

### The Memorial Day Massacre, 1937

Several hundred people marched toward the Republic Steel plant on Sunday, May 30, 1937. The plant stood on Chicago's far Southeast Side, and the marchers were supporting the steelworkers' strike there. They were white, Black and Latino men, women and children, and about 200 of them were women. There, 264 Chicago police met them.

The police threw tear gas, fired their guns and beat the marchers with clubs. They killed ten people and shot 40, and more than 90 people were wounded in all. The Paramount company filmed it, and its officials at first held back the newsreel.

**What the senators found.** Senators on a committee led by Senator Robert La Follette Jr. looked into the killings. They found that the police had used "excessive force," far more force than was needed, and had made "baseless allegations," claims with nothing true behind them. The senators said the police "did not carry out an honest investigation." No record names any police officer who was ever punished.

**By 1937:** Workers had a legal right to form unions, and the Flint sit-down had made General Motors bargain with the autoworkers, but no federal law yet set a lowest wage or kept children out of factories.

### A. Philip Randolph

> **Who:** A union leader who organized the Pullman porters and won the first contract between a major American company and a union led by Black workers.
>
> **When and where:** Founded the Brotherhood of Sleeping Car Porters in August 1925. Contract signed August 25, 1937. Washington, 1941.
>
> **Movie:** *10,000 Black Men Named George* (2002), a television drama with Andre Braugher as Randolph. Also *A. Philip Randolph: For Jobs and Freedom* (1996), a documentary shown on PBS.

**Passengers called the porters "George," whatever their real names were.**

A. Philip Randolph founded the Brotherhood of Sleeping Car Porters in August 1925. Porters worked on the Pullman Company's sleeping cars on trains, and all of them were Black men. Pullman's managers required them to serve passengers with a smile.

**The name.** After the Civil War, George Pullman, whose company ran the sleeping cars, set out to hire men who had once been enslaved to work as his porters. Passengers called the porters "George," after him. The Chicago History Museum says this carried on a practice from slavery, when an enslaved person was called by the owner's name.

**The contract.** The Pullman Company's officials signed a contract with the union on August 25, 1937, twelve years after it began. It was the first contract between a major American company and a union led by Black workers. The porters' working month had run to about 400 hours, and under the contract it fell sharply. The porters also got $1.25 million in raises.

**Order 8802.** Randolph threatened in 1941 to lead a march on Washington. On June 25, 1941, President Franklin Roosevelt signed Executive Order 8802, an order from the president. It stated there could be "no discrimination in the employment of workers in defense industries or government because of race, creed, color, or national origin."

Under the order, defense companies, which made weapons and supplies for the military, and government offices could not refuse to hire people because of their race, religion or the country their families came from. Randolph directed the March on Washington for Jobs and Freedom in 1963.

### A lowest wage for the whole country, 1938

President Roosevelt signed the Fair Labor Standards Act on June 25, 1938, and it took effect on October 24. The law set the first federal minimum wage at 25 cents an hour, rising to 40 cents by 1945, and a work week of 44 hours, falling to 40 hours by October 1940. It also banned most work by children under 16 in the jobs it covered, but it did not cover farm work.

The justices of the Supreme Court ruled the other way on child labor in 1941. They decided that Congress did have the power to limit child labor, under the 1938 law.

### Women in the war plants

Women took jobs in war plants in large numbers during World War II. They made up 27 percent of the workforce in 1940 and nearly 37 percent by 1945, when about 6.5 million more women were working. Before the war about 1 percent of aircraft workers were women. In 1943 more than 310,000 women built aircraft, about 65 percent of all the workers in that industry.

### Naomi Parker Fraley

> **Who:** A war worker in the machine shop of the Naval Air Station at Alameda, California, and the woman in a 1942 photograph linked to the "We Can Do It!" poster.
>
> **When and where:** Alameda, California, 1942. Died January 20, 2018, at 96.

**She drilled, patched airplane wings and riveted in a Navy machine shop.**

Naomi Parker went to work at the Naval Air Station in Alameda, California, during World War II. She was assigned to its machine shop, where her jobs included drilling, patching airplane wings and riveting. In March 1942 a photographer took her picture at work on a turret lathe, a metal-cutting machine for making many copies of the same part.

**The photograph and the poster.** People later linked her photograph to a poster of a woman worker with the words "We Can Do It!", which became famous in the 1980s. For decades the woman in the photograph was said to be someone else. Then a scholar named James J. Kimble found the original print, and its caption named Naomi Parker. Nobody has proved that the poster's artist used this photograph.

### The bracero program, 1942

US officials started the bracero program, named for the Spanish word for a man who works with his arms, in 1942 to bring Mexican men to work on American farms and railroads during the war. Over 22 years, more than 4.5 million contracts were signed.

**The missing pay.** American employers held back 10 percent of every bracero's pay from 1942 to 1946, and many braceros said the holdbacks went on after that. The money went through American banks to banks in Mexico, for a savings fund the braceros were to receive when they went home. Most braceros never got that money, and the records of where it went do not add up. Mexican officials agreed in 2009 to pay former braceros or their families 38,000 pesos each.

### The strike wave of 1945 and 1946

When the war ended, workers in steel, coal, railroads and car plants struck in greater numbers than ever before. There were 4,750 strikes involving 3.47 million workers in 1945. The Bureau of Labor Statistics, the federal office that counts jobs and workers, recorded 4,985 strikes involving 4.6 million workers in 1946, and no other year in its records has more.

**If you remember one thing:** In these fifty years workers won federal laws for a lowest wage, a 40-hour week, an end to most child labor and the right to form unions.

In 1900: Children worked in mills and mines, no federal law set a lowest wage, and 1,489 coal miners were killed at work.

In 1950: Federal law set a minimum wage and a 40-hour week, banned most work by children under 16, and made forming a union a legal right.

**Next:** After 1950 the share of workers in unions reached its peak and then fell, while new groups of workers organized.

## 1950 to 2000

**Era 9 of 10 · 1950 to 2000 · about 15 minutes**

Union membership reached its peak in 1954, when about one American worker in three belonged to a union, and after that the share fell for the rest of the century. By 1956 more Americans worked in offices, stores and schools than with their hands in factories, mines and building trades. Factory jobs reached their highest number in June 1979 and then fell, and by 2000 about 13 percent of workers belonged to a union.

New groups of workers organized in these years: farmworkers, city garbage collectors, flight attendants and office clerks. The share of women with paid jobs rose from 34 percent in 1950 to 60 percent in 2000.

### Unions at their peak, and the move to the office

In the peak year, 1954, 34.8 percent of Americans who worked for wages or salaries belonged to a union. Leaders of the AFL and the CIO joined their groups into one, the AFL-CIO, on December 5, 1955. It had about 15 million members, and George Meany was its first president.

**Offices and stores.** For the first time, by 1956, more Americans worked in white-collar jobs, in offices, stores and schools, than in blue-collar jobs, working with their hands in factories, mines and building trades.

Women went to work for pay in growing numbers. In 1950, 34 percent of women were in the labor force, which means they had a paid job or were looking for one, and by 2000 the figure was 60 percent. Over the same years, women's share of all workers rose from 30 percent to almost 47 percent.

### The braceros at work

The bracero program went on after the war. Men who wanted contracts went through reception centers at the border, run by officials of the federal agency that handled immigration. One was the Rio Vista farm in El Paso, Texas, and men who went through it remembered "poor food, humiliating medical examinations, and the fumigation."

**The spraying.** Officials had the men strip off their clothes, line up and be sprayed with DDT, a white powder that kills insects. The officials believed that Mexican workers carried insects and germs.

Growers could hire braceros right at the border from 1948, which let them skip the cost of moving the men and avoid government checks. Braceros worked six or seven days a week on farms and railroads in 26 states. Some were paid little and lived in poor housing, and supervisors cursed at some of them and attacked some of them physically. They worked with pesticides, chemicals that kill insects and weeds, and researchers later found these chemicals very harmful to farmworkers.

**The end of the program.** Members of Congress agreed in late 1963 to keep the program going for only one more year. They did not renew it again, so the law behind it, Public Law 78, ran out on December 31, 1964, and the program ended. Labor unions had pushed to end it. By then growers were also using more farm machines, and the public had learned about the braceros' working conditions.

### The Mohawk ironworkers

Ironworkers from the Mohawk communities of Kahnawake, just south of Montreal, and Akwesasne, which lies across the border of the United States and Canada on the St. Lawrence River, worked high steel from the 1920s onward. That means they built the steel frames of bridges and skyscrapers, walking on narrow beams far above the ground. They helped build the Empire State Building, the Chrysler Building and Rockefeller Center in New York, and later the World Trade Center. The 9/11 Memorial and Museum has an exhibit about them called "Skywalkers."

### Cesar Chavez and Dolores Huerta

> **Who:** Organizers who built the farmworkers' union, together with the Filipino American grape pickers led by Larry Itliong, who walked out first.
>
> **When and where:** Delano, California, 1965 to 1975.
>
> **Movie:** *Cesar Chavez* (2014), a drama directed by Diego Luna, with Michael Peña as Chavez. *Dolores* (2017), a documentary about Dolores Huerta directed by Peter Bratt.

**About 1,500 grape pickers, most of them Filipino American, walked out first.**

Cesar Chavez and Dolores Huerta led farmworkers to win the first union contracts in the California grape fields. The pickers who walked out of the vineyards around Delano, California, on September 8, 1965, belonged to the Agricultural Workers Organizing Committee, or AWOC, a union led by Larry Itliong. Eight days later, on September 16, members of Chavez and Huerta's National Farm Workers Association voted to join the strike.

**The march.** Strikers marched about 300 miles from Delano to Sacramento, the state capital, from March 17 to April 11, 1966, and about 10,000 supporters were with them when they arrived. The two unions joined together and became the union now called the United Farm Workers. Chavez went without food for 25 days in February and March of 1968 as a call for nonviolence, and Senator Robert Kennedy was with him when he ended the fast on March 10.

**The boycott.** Across the country, people stopped buying California table grapes, in what was called the grape boycott. Twenty-six grape growers in Delano signed the first union contracts on July 29, 1970. Dolores Huerta negotiated the contracts, and she made up the union's slogan, "Sí, se puede," Spanish for "Yes, it can be done."

The federal labor law of 1935 left out farmworkers. California's lawmakers passed the Agricultural Labor Relations Act in 1975, the first law in the United States to give farmworkers the right to collective bargaining, bargaining as a union with their employers.

**The accounts of 2026.** The New York Times reported in March 2026 that Chavez had sexually abused two girls in the 1970s. The two women, Debra Rojas and Ana Murguia, are daughters of union organizers, and they said the abuse began when they were 12 and 13. Rojas said Chavez raped her in a motel room when she was 15, forcing her into sex.

Dolores Huerta then said publicly that Chavez had pressured her into sex once and had raped her in a car in 1966, and that she became pregnant both times. She said she had kept the secret for 60 years because she believed the truth would hurt the farmworker movement.

Chavez died in 1993, so no court has ever heard these accusations. Leaders of the United Farm Workers canceled the union's events for Cesar Chavez Day. On March 26, 2026, California's lawmakers voted to rename the state holiday Farmworkers Day, and Governor Gavin Newsom signed the change into law.

### Pesticides in the fields

Farmworkers who worked in fields sprayed with pesticides had high rates of birth defects, cancer and burns. Cesar Chavez and Dolores Huerta campaigned to ban DDT on grape and lettuce ranches. In the 1980s, children in several towns of California's San Joaquin Valley had cancer at rates "800% above the norm."

### Fired for marrying or turning 32

Managers at US airlines fired stewardesses who married or who turned 32, and at some airlines 35, into the late 1960s. They also weighed the women and checked that they wore girdles, tight undergarments.

**Dusty Roads.** Barbara "Dusty" Roads flew for American Airlines from 1950. She pressed members of Congress to change the rules and helped found the Association of Professional Flight Attendants, a union. The Civil Rights Act of 1964 banned treating workers unfairly in hiring and firing because they were women or men. Flight attendants brought cases under that law, and in those years airline managers dropped the age and marriage rules.

### Memphis, 1968

Two Memphis garbage collectors, Echol Cole, 36, and Robert Walker, 30, took shelter from the rain on February 1, 1968, inside the compactor of their garbage truck, the part that crushes the garbage. The truck was not working properly, and the compactor crushed both men to death.

Eleven days later, 1,300 Black sanitation workers went on strike. They wanted the city's leaders to recognize their union, which means to accept it and bargain with it, and they wanted the work made safe and pay that was enough to live on. Many of them were paid so little that they were on welfare, government help for people without enough money, and hundreds relied on food stamps to feed their families. The strikers carried signs that read "I AM A MAN."

**The mayor.** The members of the City Council voted to recognize the union on February 22, and Mayor Henry Loeb rejected the vote. He said only the mayor could recognize a union, and he would not. He also kept the worn-out trucks on the streets and would not pay overtime for late-night shifts. The next day, police sprayed Mace, a stinging chemical, and fired tear gas at marchers walking to City Hall.

Violence broke out during a march on March 28, and some people looted downtown shops. Members of a young Black Power group called the Invaders were accused of starting it. Police followed the marchers back to Clayborn Temple, a church, fired tear gas inside and clubbed people lying on the floor.

**Larry Payne.** A Memphis police officer shot and killed Larry Payne, a 16-year-old student. The officer said Payne came at him with a knife. Most people who saw it said Payne came out of a basement with his hands up, and none of them saw a knife. The officer was never charged or disciplined.

Dr. Martin Luther King Jr. came to Memphis to support the strikers. James Earl Ray shot and killed him on the balcony of the Lorraine Motel on the evening of April 4, 1968. City negotiators agreed on April 16 that the City Council would recognize the union and raise wages. The union was AFSCME Local 1733, part of a national union of city and state workers.

### Coal dust and a new safety law

An explosion in the Consol No. 9 mine at Farmington, West Virginia, killed 78 miners on November 20, 1968. Members of Congress then passed the Federal Coal Mine Health and Safety Act of 1969. Under it, federal inspectors had to inspect every underground coal mine four times a year, and they could shut a mine down if it put lives in danger. The law also provided federal payments for miners with black lung.

Black lung is a disease caused by breathing coal dust, which scars the lungs. In the worst form, masses of scar tissue leave the miner "gasping for every breath." More than 76,000 miners have died of black lung since 1968.

**Fewer deaths.** The number of coal miners killed at work fell from 311 in 1968 to 133 in 1980 and 38 in 2000. President Richard Nixon signed the Occupational Safety and Health Act, a federal law on safety at work, on December 29, 1970. That year about 14,000 workers were killed on the job, about 38 a day.

### Office workers organize

Two office workers in Boston, Karen Nussbaum and Ellen Cassedy, founded 9to5 in 1973. Its members were women who did clerical work, such as typing, filing and answering phones. They organized over pay, promotion and harassment on the job, treatment meant to upset, shame or frighten a worker. In an early lawsuit, they won $1.5 million in back pay, the pay the women were owed, from publishing companies in Boston.

### Cashiers and the barcode, 1974

With barcode scanners, cashiers no longer had to key in each price by hand. The scanners also recorded, hour by hour, what sold, and managers later used those records to set workers' schedules. The first sale rung up by scanning a barcode came at a Marsh supermarket in Troy, Ohio, at 8:01 in the morning on June 26, 1974, when the cashier Sharon Buchanan scanned a ten-pack of Juicy Fruit gum.

### The mills close

The managers of Youngstown Sheet and Tube suddenly shut the company's Campbell Works steel mill in Youngstown, Ohio, on September 19, 1977, and 5,000 workers lost their jobs. People in Youngstown remember that day as "Black Monday." Factory jobs in the United States reached their highest number, 19.6 million, in June 1979, and after that the number fell for forty years.

The share of wage and salary workers in unions was 20.1 percent in 1983 and about 13.4 percent by 2000.

### Frank Lumpkin

> **Who:** A Black steelworker who lost his job, his last paycheck and his pension when his Chicago steel mill shut down, and who fought for 17 years to win the money back.
>
> **When and where:** Wisconsin Steel, South Deering, Chicago, from the 1950s. Born 1916. Died March 1, 2010.

**In April 1980, the bank said their last paychecks were worthless.**

Frank Lumpkin spent 17 years fighting to win back the pay and pensions, money paid to workers after they retire, that he and more than 3,000 other steelworkers lost when their mill closed in 1980.

**A working life.** Lumpkin was born in Georgia in 1916 to a family of sharecroppers, who farm land that belongs to someone else and pay the owner with part of the crop. At 6 he hauled stone for an uncle, and at 15 he left school to work on citrus plantations. He also boxed for money as "KO" Lumpkin.

He moved north to Buffalo, New York, in 1940, worked in construction, in an aircraft factory and at Bethlehem Steel, and served in the Merchant Marine, the crews of American cargo ships. In the 1950s he went to work at Wisconsin Steel in the South Deering neighborhood of Chicago, and he stayed about 30 years.

**How the mill closed.** Wisconsin Steel ran out of money in 1980. Its main buyer, International Harvester, had stopped buying its steel, and Harvester's managers then demanded the money they were owed.

Harvester had owned the mill from 1902 until 1977. That year its managers sold the mill to Envirodyne, a company with no experience in steel, and lent Envirodyne the money to buy it. When Harvester's own workers went on strike in late 1979, Harvester's managers bought none of the mill's steel while the strike lasted. That steel had been about 40 percent of what the mill made.

In March 1980 Harvester's managers moved to collect the money Envirodyne still owed for the mill. They also told Chase Manhattan Bank, which had lent Envirodyne money, that they would no longer back the bank's emergency loans to the mill. The *International Directory of Company Histories*, a reference book about companies, describes these steps.

The mill closed without warning in late March 1980, while Envirodyne owned it, and the accounts do not name the person who gave the order. The workers lost their jobs, their health benefits, their back pay and their pensions. In April, officers of Chase Manhattan Bank told them that their final paychecks were worthless.

**Save Our Jobs.** Lumpkin and his wife, Bea Lumpkin, started the Wisconsin Steel Save Our Jobs Committee. Its members were Black, Mexican American and other steelworkers and their families, and they helped families with food, medical care and utility bills. First the members tried to get the mill reopened. Then they fought to recover the lost pay and benefits, and they sued International Harvester and Envirodyne.

Six hundred former workers had died in the seven years since the closing, the committee counted in 1987. The lawyer Thomas Geoghegan won a settlement of $14.5 million from International Harvester in 1988. Over 17 years the committee won about $17 million in all, about a third of the $40 million the workers were owed. Lumpkin also ran to become an Illinois state lawmaker and lost.

### The air traffic controllers, 1981

About 13,000 federal air traffic controllers, the workers who guide airplanes in and out of airports, went on strike on August 3, 1981. Federal law did not allow federal workers to strike. President Ronald Reagan gave them 48 hours to return to work, and on August 5 he fired 11,345 of them. Federal officials also stopped accepting their union as the workers' union. The historian Joseph McCartin, who wrote a book about the strike, argues that the firings showed private employers that they could fight strikes and beat their unions.

### El Monte, 1995

State and federal agents and El Monte police raided a fenced apartment complex in El Monte, near Los Angeles, on August 2, 1995. Inside they found 72 Thai garment workers who had been forced to sew clothes and were not allowed to leave, and they freed them. Suni Manasurangkun and her sons ran the operation. The recruiters who brought the workers from Thailand took their passports when they arrived, and the workers owed about $5,000 for the trip.

**Behind the fence.** A high fence topped with razor wire surrounded the buildings, and an armed guard sat in the courtyard. The workers sewed clothes 84 hours a week, from early morning to midnight, for about $1.60 an hour. One worker, Rotchana Cheunchujit, was paid five to seven cents a garment. The owners made the workers buy food at their own store at high prices, and some workers had not been outside the fence for as long as seven years.

One woman escaped through a second-story window. A letter in pencil with a hand-drawn map reached the authorities, and the raid followed. The clothes carried "Made in the USA" labels and were sold at chain stores including Miller's Outpost, Mervyn's and Montgomery Ward.

**The guilty pleas.** Suni Manasurangkun, three of her sons and three other people pleaded guilty to federal crimes in February 1996, which means they told the court they had broken federal law. Two of her sons fled and were never caught. Officials of the companies that had sold the clothes agreed in 1997 to pay the workers the wages they were owed, to end lawsuits against them. One account puts the total at more than $4.5 million, and another at $4 million.

After the case, and partly because of it, members of Congress passed a federal law in 2000 against human trafficking, the buying, selling and moving of people to force them to work.

**If you remember one thing:** The share of workers in unions peaked in 1954 and fell for the rest of the century, while farmworkers, garbage collectors, flight attendants and office clerks organized.

**One number:** 13.4 percent. That was the share of wage and salary workers in unions in 2000. In 1954 it had been 34.8 percent, more than two and a half times as high.

**Next:** After 2000 some workers found jobs through apps on their phones, and workers at Starbucks and Amazon voted in their first unions.

## 2000 to Today

**Era 10 of 10 · 2000 to Today · about 11 minutes**

Millions of Americans now work for themselves and sell their work to companies, outside most labor laws, including the minimum wage law. About 11.9 million of them were independent contractors in their main job in July 2023, and some find their work through apps on their phones. One worker in ten belonged to a union in 2025, according to the federal Bureau of Labor Statistics. Workers at Starbucks coffee shops and at an Amazon warehouse voted in their first unions in 2021 and 2022.

Workers are still killed on the job. In 2024, 5,070 workers were killed at work, about 14 a day.

### Unions and pay today

Union members were 10.0 percent of wage and salary workers in 2025, 14.7 million people, according to the Bureau of Labor Statistics. They were 32.9 percent of government workers and 5.9 percent of workers at private companies. The share had been 20.1 percent in 1983 and about one worker in three in 1954.

The federal minimum wage has been $7.25 an hour since July 24, 2009, and as of September 2026 members of Congress have not raised it. The first one, in 1938, was 25 cents.

### Working through an app

Some independent contractors find work through apps that send them rides to drive or food to deliver, and the laws on the minimum wage and overtime pay do not cover them. Counting only people for whom it was their main job, independent contractors were 7.4 percent of all workers in 2023.

**Gig work.** Researchers at the Pew Research Center, a research group, counted more widely: anyone who had ever earned money through an online gig platform, an app or website that hands out short jobs one at a time. In their survey of August 2021, 16 percent of American adults had done so at least once, and 9 percent had done so in the past year.

**Proposition 22.** The managers of the app companies treat their drivers as independent contractors. California voters approved Proposition 22, a question put on the ballot, on November 3, 2020, with 58.63 percent of the vote. Under it, the app companies could keep treating drivers as independent contractors, but they had to pay drivers at least 120 percent of the minimum wage for the time they spent on a ride or a delivery, plus pay for each mile.

### Raef Lawson

> **Who:** A food-delivery driver for Grubhub whose court case asked whether an app driver is an employee.
>
> **When and where:** Los Angeles, 2015 and 2016. A federal judge ruled on his case in 2018 and 2023, and approved a settlement in 2026.

**After years in court, a judge awarded him $65.11.**

Raef Lawson was an actor, writer and director in Los Angeles who was trying to make a career. He signed up in August 2015 to deliver food for Grubhub, a company whose app takes food orders from restaurants.

He picked blocks of two to five hours around mealtimes, week by week, and Grubhub paid him for the blocks he worked, 105 hours in his busiest month. It paid nothing toward his gas or his phone, so those costs came out of his own pocket. In 2016 Grubhub's managers classed all 4,000 of its California delivery drivers as independent contractors.

**Let go.** Grubhub's managers ended the company's agreement with him on February 15, 2016, saying he had not worked many of the blocks he signed up for. The judge at his trial also found that he sometimes "gamed" the app, which means he tricked it: he logged on late, and he switched his phone to airplane mode so no new orders came.

**The case.** Lawson sued Grubhub for the minimum wage, for overtime pay, which is extra pay for hours past 40 in a week, and for his costs, saying that he had been its employee. Judge Jacqueline Scott Corley ruled in 2018 that he had been an independent contractor. Three months later, the justices of California's Supreme Court set a new rule: a company must prove that a worker is not an employee.

A federal appeals court, a higher court that checks the rulings of lower courts, sent Lawson's case back to Judge Corley on September 20, 2021. She ruled on March 30, 2023, that under the new test Lawson had been an employee. She wrote that "food delivery is not outside the usual course of" Grubhub's business, and she awarded him $65.11 in unpaid minimum wages for four months of work.

**The settlement.** Grubhub's officials agreed in 2026 to pay $24.75 million to California drivers to end their claims, and the judge approved the deal on July 30, 2026. About 60,000 drivers are in the settlement, and each gets at least $25. Judge Corley called it "my oldest case."

### The pandemic, 2020

About 48.7 million employed people, 35.4 percent of them, worked from home in May 2020 because of the COVID-19 pandemic, according to the Bureau of Labor Statistics. By April 2022 that share had fallen to 7.7 percent, and many office workers kept working from home for part of the week. Workers in grocery stores, warehouses, delivery and health care, called essential workers, kept going to work in person.

### Unions at Starbucks and Amazon

Baristas, the workers who make the coffee drinks, at a Starbucks on Elmwood Avenue in Buffalo, New York, voted 19 to 8 to form a union on December 9, 2021. The Washington Post and ABC News reported that it was the first union at one of the roughly 9,000 US stores that Starbucks owned itself. Workers at hundreds of other stores followed.

Workers at Amazon's JFK8 warehouse on Staten Island, New York, voted 2,654 to 2,131 for the Amazon Labor Union. Officials of the National Labor Relations Board, the federal agency that runs union elections, announced the result on April 1, 2022. It was the first union at an Amazon warehouse in the United States.

### Chris Smalls

> **Who:** An Amazon warehouse worker who was fired and then organized the first union at an Amazon warehouse in the United States.
>
> **When and where:** The JFK8 warehouse, Staten Island, New York, 2020 to 2022.
>
> **Movie:** *Union* (2024), a documentary by Brett Story and Stephen Maing about the union campaign at JFK8. It won a Special Jury Award at the Sundance Film Festival in 2024.

**He built a union from a bus stop across the road.**

Chris Smalls worked as a process assistant at Amazon's JFK8 warehouse on Staten Island. He led a walkout over safety from COVID-19 in March 2020, with workers leaving their jobs together in protest, and Amazon's managers fired him.

Smalls and other workers then started the Amazon Labor Union. At a bus stop across the road from the warehouse they set up a table with food and talked with workers as they came and went, thousands of conversations over many months. The workers won the vote in April 2022.

### Where the new unions stand in 2026

Baristas at 600 Starbucks stores, about 12,000 workers, had joined the union Starbucks Workers United by June 2025, according to the union. They began a national strike on November 13, 2025, and it grew to about 4,500 workers in more than 130 cities. The union's leaders called it the longest strike in the company's history. As of September 2026, no Starbucks store's workers have voted to approve a first contract.

Members of the National Labor Relations Board ordered Amazon on April 2, 2026, to begin talks with the union at JFK8 on a contract for pay and working conditions. They found that Amazon had "illegally and willfully" ignored the union, according to a Teamsters union press release. As of September 2026, no contract has been reported.

### Injuries in the warehouses

Staff members working for Senator Bernie Sanders, who led a US Senate committee on labor, published a report on Amazon warehouses in December 2024. It was a report by his own staff, not by the whole committee, and they interviewed 135 workers for it.

**What they found.** In each of the past seven years, the staff found, Amazon workers had been nearly twice as likely to be injured as other warehouse workers.

In 10- to 12-hour shifts, workers repeat the same movements "hundreds and thousands of times," the report states. A computer tracks how fast each worker goes, and workers who fall behind get penalties from the computer system automatically, which can end in firing.

### Children in the slaughterhouses

Managers at Packers Sanitation Services, a cleaning company based in Wisconsin, put 102 children aged 13 to 17 to work on night shifts, officials of the US Department of Labor reported in February 2023. The children worked at 13 meatpacking plants in 8 states, where animals are killed and cut up for meat, according to reporting by KCUR, a public radio station in Kansas City.

They cleaned back saws, brisket saws and head splitters, machines that cut up animals, using chemicals strong enough to burn skin, and at least three of them were injured. The JBS plant in Grand Island, Nebraska, had 27 of the children, and the Cargill plant in Dodge City, Kansas, had 26.

**The fine.** Packers Sanitation Services paid $1.5 million, the most the law allowed. Jessica Looman of the Labor Department's Wage and Hour Division called the violations "systemic," which means built into the way the company worked, and "a corporate-wide failure."

On farms, federal law still allows children to work at younger ages than in other jobs. Outside school hours, a child under 12 may work on a farm owned or run by a parent, or, with a parent's permission, on a small farm that does not have to pay the minimum wage. Children of 12 and 13 may work with a parent's permission or on a farm where a parent works, and any child 14 or older may do farm jobs outside school hours.

### Heat, floods and mines

Sixty-eight crop workers died of heat from 1992 to 2006, according to a 2008 report by the Centers for Disease Control and Prevention. Their death rate from heat was 0.39 for every 100,000 workers, against 0.02 for all civilian workers, nearly 20 times as high. A 56-year-old tobacco worker in North Carolina died in July 2005 with a body temperature of 108 degrees. He was in the United States on a temporary farmworker visa, and the report does not name him.

Across all jobs, 345 workers died of heat from 2011 to 2019, 43 of them in 2019, according to the Bureau of Labor Statistics. Officials of the Occupational Safety and Health Administration, the federal job-safety agency, proposed a rule on August 30, 2024, to protect workers from heat, a requirement that employers would have to obey by law. The officials held public hearings from June 16 to July 2, 2025. As of September 2026 there is no final federal rule on heat at work.

**Erwin, Tennessee.** Floods from Hurricane Helene reached the Impact Plastics plant in Erwin, Tennessee, on September 27, 2024, and five employees and a contractor who cleaned the offices drowned. One worker who survived and the families of some who died said no one told the workers they could leave until the flood had covered the road and the plant had lost power.

Inspectors from Tennessee's job-safety agency found that the company had "exercised reasonable diligence," which means it had taken reasonable care. They gave the company no citations, the official notices for breaking safety rules.

The local chief prosecutor, District Attorney General Steven Finney, looked into whether the workers had been told they could not leave, or that they would be fired if they left. He found "no evidence" of either and closed the case with no charges in July 2025. The family of Johnny Peterson, one of the men who died, filed a lawsuit.

**Upper Big Branch.** An explosion of gas and coal dust killed 29 miners at the Upper Big Branch mine in West Virginia on April 5, 2010. The mine belonged to Massey Energy. Its chief executive, Don Blankenship, was found guilty in December 2015 of conspiring, plotting with others, to break federal mine safety laws. Judge Irene Berger gave him the longest sentence the law allowed on April 6, 2016, one year in prison and a fine of $250,000. He was not convicted of causing the deaths.

**The count.** Injuries at work killed 5,070 workers in 2024, according to the Bureau of Labor Statistics, one worker every 104 minutes, about 14 a day. Road crashes and other transportation accidents killed 1,937 of them. In 1970 about 38 workers a day had been killed on the job.

### Wage theft and the tomato fields

Some employers do not pay workers all the money the law says they have earned, and this is called wage theft. Researchers at the Economic Policy Institute, a research group that sides with labor unions, studied the ten states with the most people in 2017. They found that 2.4 million workers there were paid less than the minimum wage, and together they lost $8 billion a year. A worker who worked all year lost about $3,300, nearly a quarter of what they had earned.

**The Fair Food Program.** Tomato pickers in Immokalee, Florida, formed the Coalition of Immokalee Workers in 1993, and the coalition's Fair Food Program has run since 2011. Big buyers such as McDonald's and Walmart pay a little extra for each pound of tomatoes and buy only from growers who follow a code of conduct written by the workers. The code sets a lowest pay, requires shade and water and bans harassment. Checkers visit the farms, and workers can call a complaint line.

More and more farmworkers come to the United States on temporary H-2A visas, which allow them to do farm work for a season. About 48,000 H-2A jobs were approved in fiscal year 2005, the government's budget year, and nearly 400,000 in fiscal year 2025, more than eight times as many. More than 90 percent of the visas go to Mexican workers.

**The three questions, answered**

- Which workers were not free to leave their work? Native people forced to work under Spanish rule, indentured servants bound for years, enslaved people, prisoners leased to Southern mines and planters, and the Thai garment workers held behind a fence in El Monte until 1995. Virginia judges sentenced John Punch in 1640 to serve for the rest of his life.
- What happened when workers went on strike? Some won, like the Philadelphia printers in 1786 and the Flint autoworkers in 1937. Many times police, hired guards and soldiers broke the strike, and at Lattimer in 1897, Ludlow in 1914 and Chicago in 1937 they killed strikers, their families and people marching with them.
- What made work less deadly? Laws written after workers died: more than one way out of every Pennsylvania mine after the Avondale fire, safer couplers after thousands of brakemen died, new factory laws in New York after the Triangle fire, and the 1969 coal mine law after Farmington. Deaths on the job fell from about 38 a day in 1970 to about 14 a day in 2024.

**What changed:** Work moved from households, forced labor and bound servants to jobs for wages, and wage workers won a shorter week, a lowest wage and safety laws, though their share in unions has fallen since 1954 to one in ten.

**Five dates to keep**

- July 9, 1640: Virginia judges sentence John Punch to serve his master for life.
- June 2, 1786: Philadelphia's printers begin the earliest proven strike of workers in one trade in the United States.
- March 25, 1911: The Triangle fire kills 146 workers in a New York factory where a stairway door was locked.
- June 25, 1938: President Roosevelt signs the law that sets the first federal minimum wage, 25 cents an hour.
- April 1, 2022: Workers at an Amazon warehouse on Staten Island win the first union at an Amazon warehouse in the country.

**Not known:** No one has ever proved who threw the bomb at Haymarket Square in 1886.

**Where to go:** Hopewell Furnace National Historic Site, in Pennsylvania, is the National Park Service site of the ironworks where more than 100 woodcutters and about 20 colliers worked in the 1830s.

**Next:** Chapter 15, Food and Farming. It asks what Americans ate and how they grew it, and the braceros and farmworkers of this chapter appear there too.
