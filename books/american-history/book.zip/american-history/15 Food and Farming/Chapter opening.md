# Chapter 15: Food and Farming

**Chapter 15 of 37 · Food and Farming · 10 eras · about 75 minutes**

**American food began with crops that Native farmers bred, and since then much of it has been grown on taken land by people who were enslaved or paid little.**

On Cape Cod in November 1620, men from the *Mayflower* found baskets of corn buried in the ground. Nauset farmers had buried the corn to plant the next spring. The Englishmen dug it up and named the spot Cornhill. They wrote that they would "satisfy them for their corn," meaning they would pay the owners later. It was the first corn the Plymouth colonists ate. Native farmers had spent thousands of years turning a wild grass into that corn.

This chapter follows American food from those fields to the drive-in and the lab. Watch two things as you go. The first is whose land and whose work the food came from: Native farmers, enslaved Africans in the rice and cotton fields, families who farmed for a share of the crop, Mexican farmworkers, and today's crop pickers. The second is how far the food travels. When the country began, about nine of every ten working people were farmers. Then came tin cans, pond ice, cold railroad cars, frozen dinners and fast food. In 2022 the country had fewer than 2 million farms for the first time since before the Civil War.

**Three questions this chapter answers**

- How did Native farmers turn a wild grass into corn?
- Who did the hardest farm work, and what did they get for it?
- How did Americans come to eat food grown far away by people they never met?

**Five minutes?** Read "Who got the cotton money?" in 1900 to 1950.

**Can skip:** "Farming began in the East too", "Why turn corn into whiskey?", "The potato blight", "Organic farming rules become law". The chapter still makes sense without them.

## Before 1500

**Era 1 of 10 · Before 1500 · about 4 minutes**

Native farmers turned a wild grass into corn, and by 1500 corn fed whole towns. Farming here was already thousands of years old. People in each region also ate what grew or lived best around them: bison on the Plains, salmon in the Northwest, wild rice around the Great Lakes.

Europeans later carried corn, beans and squash from these fields across the ocean.

### How corn was made

Native farmers made corn out of a wild grass called teosinte. A teosinte seed head holds only a few hard kernels. Farmers began changing it about 9,000 years ago in the Balsas River valley of southern Mexico. Each year they took seed only from the plants they chose and planted it again, so the crop changed a little at a time. After thousands of years of this breeding, the grass had become corn.

Scientists have confirmed the date and the place in two ways. Ancient corn dug from the ground shows it, and so do the genes of corn and teosinte, the tiny instructions inside every living thing that parents pass on to their young.

Corn is so changed from the wild grass that it cannot reseed itself. It grows only where people plant it. Native farmers grew it a little farther north at a time, over thousands of years, until it reached what is now the United States.

### The Three Sisters

Native farmers planted corn, beans and squash together in the same field, and each crop helped the other two grow. The three crops are called the Three Sisters.

The corn grew tall, and the bean vines climbed the corn stalks. Bean roots hold tiny living things called bacteria. These bacteria take nitrogen, a gas in the air, and put it into the soil. Plants need nitrogen to grow, so the beans fed the soil that all three plants shared. The squash spread wide leaves over the ground, and their shade kept water in the soil and blocked the sunlight that weeds needed.

Corn and beans eaten in the same meal also feed people better than either food does alone. Together they give the body a fuller mix of protein, the part of food the body uses to build muscle.

### Farming began in the East too

Native people in the eastern part of North America started farming on their own, long before corn reached them. They took wild plants and bred them into crops. About 5,000 years ago they had tamed a kind of squash.

They also grew six plants for their seeds: sunflower, goosefoot, sumpweed, maygrass, little barley and erect knotweed. Sunflower and sumpweed seeds are rich in oil. The other four have starchy seeds. Maygrass and little barley are grasses whose grain can be ground into flour, and people cooked and ate goosefoot's small seeds.

Scientists call this group of crops the Eastern Agricultural Complex. Eastern North America is one of the places in the world where people started farming on their own, without learning it from anyone else.

### Foods by region

Cahokia was a Native town near where St. Louis is today. Around the year 1100, between about 10,000 and 20,000 people lived there, and corn farming fed them.

People in other regions lived mainly on other foods. On the Great Plains, hunters killed bison. By a widely used estimate, about 30 million bison still lived there in the early 1800s. Along the Northwest coast and its rivers, salmon was the main food. People on the coasts gathered shellfish. In the Northeast, people collected sap from maple trees.

Around the Great Lakes, people harvested manoomin, a wild rice that grows in shallow water, from canoes. In Ojibwe, the word means "the good berry." The Ojibwe are one of the Anishinaabe peoples, a family of related nations that also includes the Odawa and the Potawatomi. In an Anishinaabe prophecy, a teaching about what was to come, the people were led to the place where they would find "the food that grows on water." Manoomin is still a central food of Ojibwe life.

No farmer from before 1500 is known by name. Because corn cannot reseed itself, every generation of Native farmers had to save the seed and plant it again. Seed keepers in Native nations still grow these crops.

## The 1500s

**Era 2 of 10 · The 1500s · about 3 minutes**

European ships began carrying crops and farm animals across the Atlantic in both directions in the 1500s. Corn, potatoes and turkeys went east to Europe, and wheat, cattle and pigs came west. Africans, most of them carried across in chains by slave traders, brought crops of their own. The historian Alfred W. Crosby named this movement the Columbian Exchange, in his 1972 book of that name. Native people here still grew and ate their own foods, and in Florida a Spanish army lived on the corn it took from them.

### What crossed the ocean

Europeans carried American crops and animals home to Europe. These included corn, potatoes, tomatoes, beans, squash, peanuts, peppers, vanilla, turkeys and cacao, the bean that chocolate is made from. Corn and potatoes later became main foods across Europe, Africa and Asia.

Europeans brought wheat, rice, sugarcane, citrus fruit (the family of fruit that includes oranges and lemons), and honeybees to the Americas on their ships. They also brought cattle, pigs, sheep, goats and chickens. Columbus brought horses on his second voyage, in 1493. Spanish colonists founded St. Augustine, in Florida, in 1565, and began a colony in New Mexico in 1598. In both places they planted wheat and citrus and raised cattle.

The word exchange can sound like a friendly trade, but Europeans took American crops home from lands they were invading. Much of what arrived was grown to feed the colonists. Before long, planters were forcing enslaved people to grow sugarcane on plantations.

Enslaved Africans brought their own crops and the skill to grow them, among them okra, watermelon, yams, sorghum, black-eyed peas and African rice.

### De Soto's army and Apalachee corn

The Spanish soldier Hernando de Soto landed near Tampa Bay, in Florida, in May 1539, with an army of more than 600 people. He carried no food supplies except a small herd of pigs. Men who marched with him wrote accounts of the trip, and those accounts say the herd began with about 13 pigs. By 1542 it had grown to about 700. The army rarely killed the pigs for food, and pigs that escaped ran wild across the Southeast.

De Soto's army moved from town to town and took the corn that Native villagers had stored, and the soldiers ate it. Without that corn, the villagers were often at risk of starving. De Soto also seized dozens of Native men, women and children. His soldiers forced them to carry the army's equipment and supplies and to do the work of the camp.

**The captives.** Rodrigo Ranjel, de Soto's secretary, kept a diary of the march. An account written from it states that the Spaniards took the men "to have more slaves and servants." Some of the captives died and others ran away, so the soldiers seized more. The same account records that the soldiers wanted the women "for their lewdness and lust," which means they wanted them for sex. The women were prisoners and could not refuse. The soldiers raped them, forcing them to have sex.

De Soto's army seized Anhaica, the main town of the Apalachee, in October 1539. Tallahassee, Florida, stands there today. The army lived in the town until March 1540 and took its stored food, which was enough to feed 600 men and 220 horses for five months.

Archaeologists, scientists who study the past by digging up what people left behind, have found burned corncobs at the site. The Apalachee fought back with quick raids and ambushes, and they went after the Spaniards' horses.

## The 1600s

**Era 3 of 10 · The 1600s · about 6 minutes**

Native corn kept the first English colonists at Jamestown and Plymouth alive in the 1600s. The colonists bought some of that corn and grew some of it with Native teaching, and they took some by force. In Virginia, planters then grew tobacco in place of food.

### Jamestown: hunger, and corn the English took by force

The colonists at Jamestown, in Virginia, planned to live partly on food they traded from the Powhatan people and partly on supply ships from England. In the autumn of 1609, Powhatan leaders stopped trading food with them, and Powhatan warriors surrounded the fort. The winter of 1609 to 1610 is called the Starving Time. When it began, the colony had about 500 people, and about 240 of them were inside the fort. By spring, about 60 of the people in the fort were still alive.

The colonists ate their horses, dogs and rats, and they ate leather. Some ate the bodies of people who had died. Archaeologists found the bones of a girl whom researchers call Jane. The bones show that colonists ate her body after she died. Scientists at the Smithsonian announced the finding in 2013.

**Percy's raid.** English soldiers also took corn by force and destroyed Native fields. On August 10, 1610, George Percy led English soldiers against the Paspahegh town near Jamestown. They burned the houses, cut down the cornfields and took corn. Percy wrote that they killed 15 or 16 people. Other accounts put the number of villagers killed as high as 75.

The soldiers captured the wife and two children of Wowinchopunck, the Paspahegh weroance, or leader. When Percy hesitated, his men complained. Percy then agreed to kill the children. His soldiers threw the children overboard from a boat and shot them in the head in the water.

That night at Jamestown, Captain Davis told Percy that Lord De La Warr, the colony's governor, wanted the children's mother burned alive. Captain Davis and two soldiers took her into the woods and killed her with a sword. Percy wrote that he did not believe the order really came from the governor.

**Ten years of raids.** Powhatan warriors attacked the English settlements in March 1622. After that, colonial soldiers marched out almost every summer for ten years to attack Powhatan towns and cornfields. At a peace meeting in 1623, colonists poisoned the Powhatans' wine, shot them, and then destroyed their cornfields.

### Why Virginia planters grew tobacco instead of food

Tobacco sold for so much money that many Virginia planters grew it in place of food crops. John Rolfe grew the colony's first successful tobacco crop in 1612, from a sweet kind of tobacco.

Members of Virginia's assembly, the colony's lawmaking body, passed laws again and again to make planters grow food. Under a tobacco law of 1629 and 1630, a family could grow 2,000 tobacco plants for each family member and no more. The lawmakers set the limit partly so that families would still plant food crops.

### Plymouth: corn dug up, then corn planted

The first corn the Plymouth colonists ate was corn they took. In November 1620, men from the *Mayflower* went exploring on Cape Cod. There they found baskets of corn that the local people had buried in the ground. The owners were saving it as seed for the next spring.

The Englishmen dug up about ten bushels of the corn (a bushel holds about 8 gallons) and a bag of beans. They wrote that they planned to "satisfy them for their corn," which meant to pay the owners later. They named the place Cornhill.

The same group of men dug up graves nearby. They opened bundles that held the bones of a man and a small child. They wrote that they "brought sundry of the prettiest things away," meaning they took several of the objects buried with the dead.

The owners of the corn were Nauset people. In the summer of 1621, the colonists met one of them and promised to pay him. They offered to bring the owners as much corn as they had taken. Later in 1621 the colonist Edward Winslow wrote that the owners had been given "full content," meaning they were fully satisfied. His letter does not say what they were given.

The colonists built their town on the land of Patuxet, a Wampanoag town. An epidemic, a disease that spreads quickly through many people, had killed most of the people of Patuxet between 1616 and 1619. One reason the colonists gave for settling there was the "good corn-ground ready to our hands." The Patuxet people had cleared those fields.

The colonists planted about 20 acres of corn in the spring of 1621. The corn did well, and their first harvest, that autumn, fed them through their second winter.

### Squanto (Tisquantum)

> **Who:** A Patuxet man who taught the Plymouth colonists to plant corn, after an English captain had kidnapped him.
>
> **When and where:** Patuxet, where the colonists built Plymouth, in what is now Massachusetts. Kidnapped 1614, home 1619, taught the colonists in the spring of 1621, died 1622.
>
> **Movie:** *Squanto: A Warrior's Tale* (1994), a feature film that mixes his real story with invented events.

**He taught the colonists to bury fish with their corn.**

Squanto, also called Tisquantum, showed the Plymouth colonists how to plant corn in the spring of 1621. He also interpreted between the colonists and the Wampanoag, which means he put each side's words into the other's language.

An English captain named Thomas Hunt kidnapped Squanto in 1614 and took him to Spain to be sold as a slave. Squanto reached England and learned English there. In 1619 he came home with an English expedition and found his town of Patuxet empty. An epidemic had killed most of its people.

The colonist Edward Winslow described the planting in a letter of December 1621. Following "the manner of the Indians," he wrote, "we manured our ground with herrings, or rather shads," two kinds of fish. The colonists buried the fish in the soil with the corn seed to feed the crops, and Squanto taught them to do it.

Scholars have argued for decades about where Squanto learned the method. In 1975 Lynn Ceci, an anthropologist (a scientist who studies how people live), argued in the journal *Science* that burying fish with corn was a European method. She found little evidence that many Native farmers used fish this way, and she argued that Squanto probably learned it during his years among Europeans. Other scholars defended the older account, the one Winslow gave.

**Known:** Squanto showed the colonists how to bury fish with their corn.

**Not known:** Where he learned the method, from Native farmers or among Europeans, is still not settled.

### What the colonists ate

The English colonists learned corn dishes from Native cooks, and Americans went on eating them for centuries. One was hominy, which is dried corn cooked in water. For samp, cooks pounded corn into coarse meal and boiled it into a mush, and the name comes from the Narragansett word *nasàump*. Johnnycakes were flat cakes baked from cornmeal. Along with their corn, the colonists ate beans, and once their hogs had multiplied, they ate pork and drank cider made from apples.

## 1700 to 1750

**Era 4 of 10 · 1700 to 1750 · about 6 minutes**

Planters in the Carolina Lowcountry, the flat, wet land along the coast of South Carolina, became some of the richest people in the colonies by forcing enslaved Africans to grow rice. The enslaved Africans built the rice fields and did the work in them. Planters paid more for captives from West Africa who already knew how to grow rice.

Farther north, farmers in Pennsylvania, New York and New Jersey grew more wheat than they could eat and shipped flour to other places. New Hampshire's town histories say that settlers there planted the first potato patches in North America that lasted.

### Carolina rice and African skill

English settlers first brought a small amount of rice to Charles Town, now Charleston, in 1670. No record shows that anything grew from it. By July 1699, samples of Carolina rice were on sale in London to test whether buyers wanted it. The first crops grew on dry, high ground. By the 1720s, planters had moved their rice into freshwater swamps inland, and they had enslaved workers build dams to hold the water in ponds.

**The rice boom.** Carolina planters shipped out about 269,000 pounds of rice a year from 1698 to 1702. Forty years later, from 1738 to 1742, they shipped out more than 30 million pounds a year, more than a hundred times as much. One kind of Carolina rice later became known as Carolina Gold.

Planters put out advertisements asking for captives from the part of West Africa known as the Rice Coast. That coast included Senegambia, the land along the Senegal and Gambia rivers, and Sierra Leone. Planters paid more for people from there because those people knew how to grow rice.

**African methods.** Records from Carolina fields show African methods at work. Enslaved workers built earth banks around fields beside the tidal rivers so they could flood and drain them. They sowed seed by pressing it into the mud with the heel and toe. They separated the grain from its husks by tossing it in coiled baskets called fanner baskets.

**What is certain, and what is argued.** It is certain that planters paid more for captives from the Rice Coast and that enslaved Africans used African methods in the Carolina fields. Scholars argue about how much the whole rice business owed to that African knowledge. In 2001 the scholar Judith Carney argued that African knowledge was its base, and in 2005 three historians answered that she had made the African share too large.

Most scholars now hold a middle view: planters built the rice business with their money and by force, and they also depended on African skill. Records from the colony also show that in its early years, more captives came from Angola than from any other place, and Angola is not on the Rice Coast.

### Whose land the rice grew on

The Kiawah, Etiwan and Stono people lived along the Ashley, Cooper and Stono rivers. They were still there in 1670, when English colonists settled among them at Charleston Harbor.

English colonists captured Kussoe people who fought back in 1671, and Stono people in 1674, and sold them into slavery in the Caribbean. The Kiawah left the Ashley River in the early 1680s and moved to the island now named for them. By then no nation of the Lowcountry had more than fifty bowmen, and the Stono had sixteen hunters. In the spring of 1684, leaders of eight nations signed away their land claims to the English who ran the colony.

English colonists in Carolina made their biggest profits before 1720 from two kinds of goods they shipped out. One was ship supplies, such as tar made from pine trees. The other was Native people, whom they sold as slaves. In 1770 a colonist named William Bull wrote of the Native nations along the coast that "there remains now, except a few Catawbas, nothing of them but their names, within three hundred miles of our sea coast."

### The rice workers, unnamed in the records

Planters' records list the enslaved rice workers by first name, age and price. They say almost nothing else about them. No single rice grower from these years can be followed through life in the records.

Planters gave each enslaved worker a set task every day. The usual task was to work a quarter of an acre of land. A worker who finished the task had the rest of the day. Workers labored in direct sun, standing in water or mud, among mosquitoes, horseflies, snakes and alligators.

Enslaved Africans dug the banks and canals of the rice fields. Nic Butler, a historian at the Charleston County Public Library, has written that the earth they moved across the Lowcountry is about as much as all the great pyramids of Egypt put together.

More enslaved people died in the Lowcountry than were born there until the 1760s. Many of the dead were children. Planters kept buying new captives to replace them, and by 1708 more Black people than white people lived in South Carolina.

**The slave ships.** Slave traders rarely landed more than 300 enslaved Africans a year at Charles Town in 1710. By 1720 they landed more than 1,000 a year, and by 1770 more than 3,000. More than four of every ten Africans brought to North America in the slave trade came in through Charleston Harbor.

### Eliza Lucas Pinckney

> **Who:** A planter's daughter who ran her family's South Carolina plantations as a teenager and made the colony's first successful indigo dye.
>
> **When and where:** Wappoo plantation, near Charleston, South Carolina. Indigo experiments from 1739, first successful dye in 1744.

**She was about 16 when she took charge of three plantations.**

Eliza Lucas produced South Carolina's first successful dye from indigo, a plant that colors cloth blue, in 1744. Indigo is a farm crop but not a food.

Her father, George Lucas, went back to the island of Antigua, in the Caribbean, in 1739 to serve as its lieutenant governor, the official just below the governor. Eliza was about 16. She took charge of Wappoo plantation and of the 20 enslaved people who worked it. She also oversaw the family's two other plantations, which were much larger.

That same year she began experimenting with indigo seed. Turning the plant into dye was skilled work done by experts. She first worked with an indigo maker from the island of Montserrat. Her best results came with an indigo maker of African descent whom her father hired from the French islands of the Caribbean.

She used her 1744 crop to make seed and gave the seed to other planters. Planters in South Carolina shipped out about 5,000 pounds of indigo in the shipping year 1745 to 1746. By 1748 they shipped out 130,000 pounds. She later married and took the name Pinckney.

### Wheat, potatoes and everyday meals

Pennsylvania, New York and New Jersey were called the breadbasket colonies. Farmers there grew more wheat than their families needed. Merchants shipped the extra wheat as flour out of the ports of Philadelphia and New York.

Settlers known as the Scots-Irish, families of Scottish background who had lived in the north of Ireland, planted potatoes at Londonderry, New Hampshire, in 1719. New Hampshire's histories count their patches as the first lasting potato fields in North America. The potato first grew as a crop in the Andes mountains of South America. People carried it to Europe, and settlers later brought it back across the ocean to North America.

Most colonial families ate corn, pork and bread, and drank cider. Rich families also bought tea, sugar and wine from overseas, and they ate bread made of wheat.

## 1750 to 1800

**Era 5 of 10 · 1750 to 1800 · about 5 minutes**

About nine of every ten working people in the United States were farmers when the country began, by a widely used estimate from the US Department of Agriculture. The first census, a count of the people, was taken in 1790. It counted about 4 million people.

Thomas Jefferson wrote that farmers were God's chosen people, while people he enslaved farmed his land. In 1796 Amelia Simmons became the first American to write a cookbook for American kitchens, and some of its recipes used American cornmeal.

### Matthew Patten

> **Who:** A New Hampshire farmer, carpenter and judge whose diary records what his family grew, caught and ate.
>
> **When and where:** Bedford, New Hampshire, on the Merrimack River. His surviving diary runs from 1754 to 1788.

**In ten days of fishing, he sent 354 fish home.**

Matthew Patten kept a diary that shows how one farm family in New Hampshire fed itself. He headed each little booklet of it "A Day Book continued." His entries for the year 1767 record the family's food through the seasons.

Patten was a joiner, a carpenter who does the finer woodwork in a house. He also farmed, worked as a judge, and surveyed land, which means he measured it and marked its borders.

**What the family ate.** The Pattens grew corn, rye, wheat, peas, potatoes, barley and turnips. They butchered their own hogs, calves and sheep, and they caught shad and salmon in the Merrimack River. They bought tea, sugar, molasses and rum. The family paid and was paid in bushels of grain as often as in money.

**Winter.** Neighbors paid Patten in corn for surveying their land and for writing deeds, the papers that prove who owns a piece of land. In January he took corn and rye to a neighbor's mill to be ground into meal and flour, and on January 30 he butchered the family's hogs.

**Spring.** The family's potatoes had spent the winter buried in a pit. Patten opened it on March 4 and wrote that they were "sound and good." In April and May the family sowed peas and planted potatoes and corn, and "the boys" spread manure from the barn on the field behind it. They also sowed hemp and flax, plants whose fibers are made into rope and cloth.

**Fishing.** In May Patten helped haul a net for shad, a fish the family took from the Merrimack each spring. From May 28 to June 6 he fished at Amoskeag Falls and sent 354 fish home.

The name Amoskeag comes from a Pennacook word that means roughly "good fishing place." Long before Bedford was a town, Pennacook people strung large nets across the river at the falls and caught sturgeon, salmon and a fish called the alewife. Bedford lies in Pennacook country.

**Summer.** In June and July Patten caught salmon and split them with two neighbors. In August he reaped his rye, and later that month he mowed his meadow for hay.

Patten died on August 27, 1795, in one of the town's fields. He had carried dinner out to the men who were mowing.

### Jefferson's farmers and Monticello's rations

Thomas Jefferson believed that family farms made free citizens. He wrote about the idea in his book *Notes on the State of Virginia*, first printed in 1785: "Those who labour in the earth are the chosen people of God, if ever he had a chosen people." For about a hundred years afterward, American leaders wrote land laws meant to put land in the hands of family farmers.

People Jefferson enslaved did the farm work at Monticello, his plantation in Virginia. He enslaved more than 600 people during his adult life. In the years Jefferson had tobacco grown at Monticello, enslaved children picked worms off the tobacco plants.

**The rations.** Each week, Jefferson gave each enslaved worker at Monticello a set amount of food, called a ration: a peck of cornmeal (about 8 quarts), half a pound of pork or pickled beef, and four salted fish. Nursing mothers received extra, and workers got whiskey at harvest. Researchers who studied the Monticello records found that these rations were not enough food for a person to live on. So in their little free time, enslaved people hunted, fished, trapped, kept gardens and raised animals.

Enslaved families also sold chickens and vegetables from their own gardens and flocks to the Jefferson family. Jefferson's granddaughter Anne Cary Randolph wrote down these purchases in the household accounts. Most of the sellers she recorded were enslaved people who worked in the house, many of them members of the Hemings family.

### Why turn corn into whiskey?

Farmers in the backcountry, the land far from the coast beyond the older farms and towns, could not easily haul wagons of corn over the long roads to buyers. So they turned their extra corn into whiskey, which they could carry to market in jugs.

### Amelia Simmons

> **Who:** The author of *American Cookery*, the first cookbook written by an American for American kitchens.
>
> **When and where:** Hartford, Connecticut, 1796.

**On her title page she called herself "an American orphan."**

Amelia Simmons wrote *American Cookery*, the first cookbook written by an American for American kitchens. It was printed in Hartford, Connecticut, in 1796. Beyond those words on her title page, nothing about her life is known.

Her book contains the first known printed recipes that used American cornmeal. Among them were johnnycake, "Indian slapjack" and Indian pudding. Colonists called corn "Indian corn" and cornmeal "Indian meal," so the word Indian in these names meant that the dishes were made with cornmeal.

It also contains the first printed recipe that used pearlash, a salt made from wood ashes, to make dough rise. Bakers used pearlash before baking powder existed. The book includes some of the earliest printed uses of the words "cookey" (cookie) and "slaw" (a salad of shredded cabbage), which came into American English from Dutch settlers in America.

## 1800 to 1850

**Era 6 of 10 · 1800 to 1850 · about 6 minutes**

Sealed in tin cans or kept cold with ice cut from frozen ponds, food could now be sold far from the farm where it grew, to people the grower never met. In the Deep South, planters, the owners of large farms worked by enslaved people, spread cotton fields over land that federal troops had forced Native nations to leave. On the prairie of the Midwest, farmers used a new steel plow to turn thick grassland into fields of wheat and corn.

### Food in cans, and ice from ponds

A Frenchman named Nicolas Appert proved in 1809 that food sealed in a container and then heated would keep without spoiling. The method is called canning.

Americans soon took it up. William Underwood opened a cannery in Boston in 1820 or 1821. In New York, Thomas Kensett canned seafood, fruit and vegetables, and in 1825 he received an American patent for tin cans, a government paper that gave him the sole right to make and sell them for a set number of years.

Other merchants sold ice. Workers cut blocks of ice from frozen ponds in New England in winter, including Walden Pond. Merchants shipped the ice to cities. People used it to keep food, fresh fish and drinks cold. Families kept ice in a box called an icebox, which became a common piece of kitchen furniture.

### Frederic Tudor

> **Who:** A Boston merchant, called the Ice King, who built a business shipping New England pond ice to warm places around the world.
>
> **When and where:** Boston. First cargo of ice to Martinique in 1806. Ice to India in 1833. Died 1864.

**His ship carried 180 tons of pond ice to India.**

Frederic Tudor built a business selling New England pond ice in hot countries far away. His first cargo of ice left Boston in 1806, bound for the Caribbean island of Martinique. A Boston newspaper, the *Boston Gazette*, printed: "No joke. A vessel has cleared at the Custom House for Martinique with a cargo of ice." The ship had permission from the port's officials to sail, and the paper hoped the trip would "not prove a slippery speculation," a speculation being a risky business deal.

Much of the ice melted during the three-week voyage. Tudor sold what was left. He lost about $4,500 on the trip, though some accounts say $4,000. He kept at the business for years, and in 1812 and 1813 he spent time in debtors' prison, a jail for people who could not pay what they owed.

His ship the *Tuscany* sailed from Boston for Calcutta, in India, on May 12, 1833. It carried 180 tons of ice cut the winter before. The ship reached India in September, about four months later. About 100 tons of the ice were still frozen, and about 80 tons had melted on the way.

### Cotton fields on Native farms

Across the Deep South, planters spread cotton so widely that they pushed food crops to the edges of their land. Many planters bought corn and pork from Midwestern farms instead of growing enough food on their own plantations.

**Who did the work.** Enslaved people did the work in the cotton fields. The planters held them as property and forced them to work without pay. They worked in groups called gangs, from sunup to sundown, six days a week.

Solomon Northup, a free Black man who was kidnapped and sold into slavery, was held in Louisiana from 1841 to 1853, nearly ten of those years on Edwin Epps's cotton plantation. He wrote that "an ordinary day's work is two hundred pounds." Each night the cotton was weighed, and pickers who brought in less were whipped, usually fifty strokes. Epps did some of the whipping himself.

**Whose land it was.** The new cotton fields were the farms and hunting grounds of the Cherokee, Muscogee (Creek), Choctaw, Chickasaw and Seminole nations. In 1830 President Andrew Jackson signed the Indian Removal Act. Under it, federal troops forced these nations off their land and moved them west. Chapter 2, Native Nations, tells the removals in full.

**The Trail of Tears.** The Cherokee were one of those nations, and their removal of 1838 and 1839 is called the Trail of Tears. Soldiers under General Winfield Scott forced more than 16,000 Cherokee from their homes and held them in crowded, dirty camps, with too little food and water and no shelter from the weather.

Measles, whooping cough and dysentery, a disease of the gut that causes bloody diarrhea, spread through the camps. More than 4,000 Cherokee died of disease, hunger and cold in the camps and on the march west, and one scholar has estimated that twice as many died.

### Breaking the prairie

Farmers moving onto the prairie of Illinois found thick, sticky sod, the top layer of soil, held together by the tangled roots of grass. Prairie sod stuck to iron plows and stopped them.

John Deere, a blacksmith in Grand Detour, Illinois, made a plow of polished steel in 1837. The sod slid off its smooth blade instead of sticking, so the plow could cut through the prairie. By 1846 Deere was selling nearly a thousand plows a year.

Cyrus McCormick had shown his reaper, a machine that cuts grain, in Virginia in 1831, six years before Deere made his plow. Before it, farmers cut wheat by hand, with tools such as the sickle, a curved blade. A reaper cut grain many times faster than a person with hand tools, so a family could plant far more wheat. Within one generation, farmers had turned the prairie into fields of wheat and corn.

Deere's plows broke land that Native nations had lived on. Early settlers at Grand Detour saw signs of a Ho-Chunk village inside the bend of the river.

**War on the Mississippi.** US soldiers and militia, citizens called up to fight, went to war in 1832 against Sauk and Meskwaki people led by Black Hawk. On August 1 and 2, at Bad Axe on the Mississippi River, Black Hawk's band of perhaps 500 men, women and children tried to cross the river. Soldiers on the army steamboat *Warrior* fired on them.

About 1,300 soldiers and militia under General Henry Atkinson attacked the people still on the east bank. The soldiers shot some of the Sauk and Meskwaki before they could reach the far shore, and others drowned trying to get across. Thomas Ford, a governor of Illinois, later estimated that 150 were killed and as many drowned. Others have disputed his count.

**The treaties.** With two treaties, written agreements between nations, US officials got Native land in northern Illinois and southern Wisconsin in 1832 and 1833, a few years before Deere made his plow. Farmers moved onto that land and plowed it.

Ho-Chunk leaders signed the first treaty with General Winfield Scott and the governor of Illinois in September 1832. They gave up their lands in southern Wisconsin and northern Illinois in return for yearly payments. At a treaty meeting in Chicago in 1833, Potawatomi leaders sold the last of their land in northern Illinois and all of their land in southeastern Wisconsin. In return they got land farther west, in Iowa, and they had to leave Wisconsin by 1838.

### The potato blight

A potato disease called late blight broke out near the ports of Philadelphia and New York in 1843. It is caused by a water mold, a tiny living thing that destroys potato plants. The blight spread through potato fields in the eastern United States. American farmers lost potato crops, but they had other food to eat.

The blight reached Europe by 1845. In Ireland, poor families depended on potatoes and had no other food, and the blight destroyed their crop. About 1 million people died in Ireland's Great Famine, a time of so little food that people starved, from 1845 to 1852.

## 1850 to 1900

**Era 7 of 10 · 1850 to 1900 · about 8 minutes**

Families claimed millions of acres of free farmland under the Homestead Act, land that US officials and soldiers had taken from Native nations. By 1900, growing, packing and shipping food had become a big business, from Texas ranches to Chicago meatpacking plants to the cities of the East. Cowhands drove millions of cattle north from Texas, and meatpackers in Chicago shipped their beef east in cold railroad cars.

Farmers formed groups of their own, starting in 1867, to buy supplies together and to speak up against the rates railroad companies charged them.

### Homestead farms on taken land

The Homestead Act became law on May 20, 1862. Under it, a person could claim 160 acres of public land for free. To keep the land, the person had to live on it and farm it for five years. Women could claim land. After 1868 Black Americans could claim land too. Most Native people could not.

Over the years the law was in force, people filed about 4 million claims. About 1.6 million of them finished the five years and received a land patent, the government paper that made the land theirs. Together they received about 270 million acres, close to one tenth of all the land in the United States.

All of this land had belonged to Native nations. US officials and soldiers had taken it by treaty, by purchase and by war.

**The Dawes Act.** Members of Congress passed the Dawes Act in 1887. Under it, federal officials broke up land that each Native nation held together into separate plots for single families. Officials then sold the land they called surplus, meaning left over, and much of it went to white farmers. Native nations held about 138 million acres in 1887 and about 48 million by 1934. Through the plots and the sales, federal officials had taken about 90 million acres from them, two of every three acres they had held.

**Oklahoma.** Federal officials opened land in Oklahoma to settlers in 1889, two years after the Dawes Act. US officials had taken that land from Native nations, and settlers raced in to claim it.

### Uriah and Mattie Oblinger

> **Who:** A homesteading family whose letters describe the food and work of a Nebraska farm claim.
>
> **When and where:** Fillmore County, Nebraska. Uriah filed his claim in 1872. Mattie and their baby, Ella, arrived in May 1873. The family letters run from 1862 to 1911.

**Uriah built the family's house out of blocks of prairie sod.**

The letters of Uriah and Mattie Oblinger describe what one homestead family in Nebraska grew and ate in the 1870s. The Library of Congress and the Nebraska State Historical Society keep the family's letters, and the Library of Congress collection holds 318 of them, written from 1862 to 1911.

Uriah went ahead from Indiana to Nebraska in the fall of 1872. He filed a claim about eleven miles west of the town of Geneva, in Fillmore County, broke the prairie sod and built a house out of blocks of sod. On December 1 he wrote about the other young families starting out around him: "We will all be poor here together."

The Otoe-Missouria and the Pawnee had signed over most of their land in this part of Nebraska in treaties of 1854 and 1857. Homesteaders began filing claims in the county in 1866.

Mattie and their baby daughter, Ella, joined Uriah in May 1873. On June 16 Mattie wrote that Uriah had planted sod corn, corn set straight into newly plowed prairie sod. She spelled words her own way: "Uriah has 23 acres of sod corn planted it looks real well."

An Iowa settler, L. S. Coffin, described in 1902 how sod corn was planted. A man struck an axe deep into the sod, and a boy or girl dropped three or four kernels into the slot and stamped it shut with one foot.

Mattie's garden had "Squashes and Cucumbers & Mellons & Beans comeing on," and tomato plants too. She bought milk and butter from a neighbor, Mrs. Furgison, and paid twelve cents a pound for the butter. "I like the sod house the best," she wrote, and "every lick we strike is for our selves and not half for some one else."

Over the next years the family lived through blizzards, drought, swarms of grasshoppers and low prices for their crops. In February 1880 Mattie died giving birth, and her newborn son died with her. She was 36. She left three daughters, Ella, Stella and Maggie, and Uriah moved the family to Minnesota that year.

### Sharecropping: growing a crop someone else sold

After the Civil War, most freedpeople, the men, women and children who had been freed from slavery, had no land of their own. Many became sharecroppers, families who farmed someone else's land for a share of the crop. A landowner gave a sharecropping family food, seed, tools and a cabin on credit, which meant the family would pay for them later. This was called the furnish. The family usually worked about twenty acres.

At harvest the landowner sold the crop and took out the cost of the furnish plus interest, an extra charge for paying later. Then the landowner paid the family its share, usually half of the crop's value or less.

**The debt.** The landowner held a lien on the crop, a legal claim to it until the debt was paid, and kept the account books. Most sharecropping families stayed in debt to the landowner year after year. They grew food and cotton but did not control the money from selling it.

### The bison killed, the cattle driven north

About 30 million bison lived on the Great Plains in the early 1800s, and by 1900 fewer than 1,000 were left. Hunters killed them to sell their hides, and the herds also shrank from railroad building, disease and drought. US Army commanders encouraged the killing, because the herds were the food supply of the Plains nations.

The people of the Lakota leader Sitting Bull were starving by 1881, because the bison herds were nearly gone. They surrendered at Fort Buford in July 1881.

Ranchers put cattle on the grasslands where the bison had lived. Between 1866 and 1884, cowhands drove about 5.2 million Texas cattle north to railroad towns. In 1867 Joseph McCoy built a market for cattle at Abilene, Kansas, where the railroad line reached, and herds came up to it along the Chisholm Trail. In Texas, as many as one cowhand in four was Black. Many others were Mexican or Mexican American.

**Fences.** The long drives ended when barbed wire fences and quarantine lines closed the open range, the unfenced grassland where cattle could graze and travel freely. Joseph Glidden received a patent for barbed wire on November 24, 1874. Under a Kansas law of 1885 and 1886, passed to keep out a cattle disease called Texas fever, Texas cattle could not cross the quarantine line into Kansas. Herds could no longer use the trails that crossed such lines.

### Charles Goodnight

> **Who:** A Texas cattleman who invented the chuckwagon, the kitchen on wheels that fed cowhands on cattle drives.
>
> **When and where:** Texas, 1866.

**His chuckwagon's pantry box dropped flat to make a table.**

Charles Goodnight invented the chuckwagon in 1866. A cattle drive crossed open grassland for months, and its crew had to eat every day. Goodnight took a leftover Army wagon and built a hinged pantry box onto it. Part of the box dropped down flat to make a table where the cook could work.

The chuckwagon carried the food for the trail, such as beans, bacon, biscuits and coffee. On a drive, the cook ranked second only to the trail boss, the man in charge of the whole drive. Some characters in the novel *Lonesome Dove* are partly based on Goodnight.

### Beef from the Plains to a city plate

The Union Stock Yards opened in Chicago on December 25, 1865. Their pens, where cattle, hogs and sheep were held until they were sold, became the largest market for farm animals in the world.

Gustavus Swift was a meatpacker, a businessman who ran a plant where animals were killed and cut up into meat for sale. He shipped beef east from Chicago already butchered, instead of shipping live animals.

An engineer named Andrew Chase designed a railroad car for Swift in 1878 that was cooled with ice, and beef packed in it stayed cold all the way to the cities of the East. A steer, one of the male cattle raised for beef, could now be raised in Texas, killed in Chicago and eaten in New York.

### Farmers join together

Oliver Hudson Kelley, a Minnesota farmer and a clerk in the federal Department of Agriculture, founded the Patrons of Husbandry in 1867 (husbandry is an old word for farming). People knew it better as the Grange. It was the first large farmers' group with members across the whole country. Grange members met in their own halls and bought supplies together to get lower prices, and they spoke up together against the rates the railroad companies charged to carry their crops.

**Colleges for farming.** Members of Congress had already passed the Morrill Act in 1862. Under it, federal officials gave each state 30,000 acres of public land for each of the state's members of Congress, land that had been taken from Native nations. State officials sold the land and used the money to start colleges that taught farming and the skills of working with machines. These schools are called land-grant colleges.

**Experiment stations.** Under the Hatch Act of 1887, each state's land-grant college received $15,000 a year at first to run a farm experiment station. The act was named for William Hatch, a member of the US House of Representatives from Missouri who led the House committee on farming. At these stations, which today run in all 50 states, scientists studied soil, seed and farm animals and sent their results to farmers.

## 1900 to 1950

**Era 8 of 10 · 1900 to 1950 · about 16 minutes**

Federal inspectors went to work inside the meatpacking plants in 1906, and in the years that followed federal officials took on many new jobs in how Americans got their food. In the 1930s, officials paid farmers to grow less, bought up extra food and gave it to hungry families. During World War II they limited how much sugar, meat and coffee each person could buy. In 1946 President Harry Truman signed a law that made school lunch a permanent federal program.

On the farms, tractors began to take the place of horses, and new kinds of seed corn and chicken farming began.

### What was in the meat: the 1906 food laws

President Theodore Roosevelt signed two food laws on the same day, June 30, 1906. Under the Pure Food and Drug Act, no one could sell food or medicine from one state to another if it was mislabeled or adulterated, meaning made impure or mixed with something that should not be in it.

Scientists at the Bureau of Chemistry enforced this law at first, and since 1930 the Food and Drug Administration, or FDA, has done that work.

The second law was the Meat Inspection Act. Under it, federal inspectors worked inside the packing plants and checked the meat. Members of Congress passed both laws within a few months after a novel about Chicago's meatpacking plants came out.

### Upton Sinclair

> **Who:** A novelist whose book about the Chicago meatpacking plants came out months before the 1906 food-safety laws.
>
> **When and where:** Chicago, 1904. His novel *The Jungle* came out as a book in February 1906.

**He wrote about the workers, and readers noticed the meat.**

Upton Sinclair wrote *The Jungle* to show how immigrant workers in Chicago's meatpacking plants lived. In 1904 he spent about seven weeks working undercover in the plants. His novel was printed in parts in 1905 and came out as a book in February 1906.

Readers fixed instead on what Sinclair described going into the meat. In the novel, spoiled ham and moldy sausage were dosed with chemicals and ground up again, along with meat that had fallen on the dirty floor. The packers put out poisoned bread for the rats in the storerooms, and then "rats, bread, and meat would go into the hoppers together." The hoppers fed the machines that ground the sausage.

Within months, Roosevelt signed the two food laws of June 30, 1906. Later that year Sinclair wrote about how readers had taken his book: "I aimed at the public's heart, and by accident I hit it in the stomach."

### George Washington Carver

> **Who:** A scientist who taught poor Southern farmers how to rebuild worn-out cotton land and grow their own food.
>
> **When and where:** Born enslaved near Diamond, Missouri, about 1864. Taught at Tuskegee Institute, Alabama, from 1896 until his death in 1943.
>
> **Movie:** *George Washington Carver: An Uncommon Life* (Iowa PBS, 2018), a documentary.

**His most famous booklet listed 105 ways to prepare peanuts.**

George Washington Carver taught Southern farmers to plant crops that rebuilt their soil. Moses and Susan Carver enslaved his mother, Mary, and so they claimed him as their property too.

When he was a few months old, a band of men kidnapped him and his mother from the farm to sell them. A neighbor got the baby back. His mother was not brought back. Moses and Susan Carver raised him and his older brother, Jim.

He was the first Black student at Iowa State, and later he taught there. He took charge of farming studies at Tuskegee Institute in Alabama in October 1896 and stayed until he died in 1943.

Year after year of cotton had worn out the soil on many Southern farms. Carver taught crop rotation, which means changing the crop planted in a field from one year to the next. A farmer planted peanuts, cowpeas (a kind of bean) or sweet potatoes, which built the soil back up, and then went back to cotton, which wore it down.

Carver wrote 44 practical bulletins, small printed booklets, and gave them to farmers for free. He also sent out the Jesup wagon, a wagon pulled by a mule that was used to show farmers new ways of farming. His best-known bulletin came out in 1916 and was reprinted for decades. It was called *How to Grow the Peanut and 105 Ways of Preparing It for Human Consumption*. In his laboratory he made hundreds of test products from peanuts and sweet potatoes.

Many people believe that Carver invented peanut butter. He did not. The Aztecs of Mexico made peanut paste centuries earlier. Marcellus Gilmore Edson received a patent, the sole right to make and sell an invention, for a peanut paste in Canada in 1884, and John Harvey Kellogg received one in 1895.

### Pellagra: a disease from a corn diet

About 3 million Americans got pellagra, a disease caused by a diet missing a vitamin called niacin, between 1900 and 1940. About 100,000 of them died of it. Those hit hardest were poor farmers, sharecroppers (families who farmed someone else's land for a share of the crop) and cotton-mill workers in the South. They lived mostly on cornmeal, molasses and dried pork, with few fresh vegetables and little meat or milk.

Many mill owners paid workers in scrip, a kind of paper money that could be spent only at the company's own store. Those stores sold mostly cornmeal, dried meat and molasses.

A person with pellagra got skin rashes, diarrhea and dementia, which means confusion and loss of memory. The disease could end in death.

**The prison test.** Most scientists of the time thought pellagra was an infection, spread by germs. Joseph Goldberger, a doctor with the US Public Health Service, thought the diet caused it, and he tested the diet on prisoners in 1915, with the agreement of Mississippi's governor, Earl Brewer.

At the Rankin State Prison Farm, Goldberger fed eleven volunteer prisoners the corn-based meals poor Southerners ate, starting on April 19. They got biscuits, mush, grits, gravy, cornbread, sweet potatoes, cane syrup and coffee. In return, the men were promised pardons, meaning they would be let out of prison.

About half of the eleven men got pellagra, five or six depending on the account, and the others showed some signs of it. The men had skin rashes and stomach illness, and the men who got pellagra recovered. Goldberger had shown that he could cause pellagra by keeping fresh food from people.

In 1916 Goldberger injected himself, his wife and other volunteers with blood from pellagra patients, to show that the disease did not spread from person to person.

A scientist in Wisconsin found in 1937 that the missing nutrient was niacin, also called vitamin B3. Federal and state laws passed during World War II required that niacin be added to bread.

### Sugar and pineapple from Hawaii

Sugar plantations made up most of the business of the Hawaiian Islands. The planters brought in contract workers from overseas, bound to work for a set number of years, many of them from Japan and, after 1908, from the Philippines. Around 1899 a Japanese contract worker earned about $13 a month, and his food and the cost of his trip both ways came out of that pay.

James Dole started the Hawaiian Pineapple Company in 1901, and workers at his company canned pineapple in huge amounts for kitchens on the mainland. US officials had taken over the islands three years before, in 1898.

**The takeover.** Hawaii was a kingdom with its own queen until 1893. On January 17 of that year, a group of mostly American businessmen moved to overthrow Queen Liliuokalani. Some of the group's members were sons of partners in the companies that controlled more than half of Hawaii's sugar crop, and the group pushed for the United States to take over the islands.

John L. Stevens, the top US official in Hawaii, had 162 US sailors and Marines brought ashore from the warship USS *Boston*, and the queen gave up her power under protest.

Native Hawaiians signed 21,269 names on petitions in 1897, asking that Hawaii not be joined to the United States. On July 7, 1898, President William McKinley signed the Newlands Resolution, a measure to annex Hawaii, which means to take it over and make it part of the country.

### Tractors, hybrid corn and chickens

Henry Ford's company began selling a cheap tractor called the Fordson in 1917. Even so, American farms in 1920 had 246,000 tractors and about 26 million horses and mules, and animals still did most of the pulling. The International Harvester company brought out the Farmall in 1924. It could also cultivate row crops, meaning it could work the soil between rows of growing plants, the last big farm job that still needed horses.

A farm horse ate crops too. It took about five acres to grow the feed for one horse. When a farmer sold a horse or stopped using it, the farmer could plant those acres with food for people.

Henry A. Wallace founded Pioneer Hi-Bred in 1926. It was the first company that sold hybrid seed corn, seed that comes from crossing two different parent plants.

**By 1930:** Federal inspectors were working inside the meatpacking plants, tractors were starting to replace farm horses, and farmers could buy hybrid seed corn.

### Cecile Steele

> **Who:** A Delaware farmer who began the business of raising chickens for meat after a hatchery sent her 500 chicks by mistake.
>
> **When and where:** Ocean View, Delaware, 1923. She lived from 1900 to 1940.

**She ordered 50 chicks, and the hatchery sent her 500.**

Cecile Long Steele had ordered the chicks in 1923 for her farm in Ocean View, Delaware. She raised all 500 indoors and sold them at 16 weeks old for 62 cents a pound.

She ordered 1,000 chicks on purpose in 1924, and by 1926 she was raising 10,000. By 1928 about 500 farms on the Delmarva Peninsula, the land where Delaware, Maryland and Virginia meet, were raising broilers, young chickens raised for their meat.

Chicken later became the meat Americans eat most, by weight. By the count of the National Chicken Council, a group that speaks for chicken companies, each American ate about 32 pounds of chicken in 1965. Its figures for 2025 put each American at about 103 pounds of chicken, 59 pounds of beef and 49 pounds of pork.

### Dust, pigs and food stamps in the 1930s

Farmers on the southern Great Plains had plowed up the grassland to plant wheat during World War I, when wheat sold for high prices. A drought began in 1931, and the wheat died. The bare, dry soil blew away in dust storms. The storm of April 14, 1935, is called Black Sunday. Crops failed year after year. Farm families lived on vegetables from their gardens, canned food, food handed out by federal officials, and jackrabbits.

No one kept an official count of the people the dust killed. In Kansas alone, dozens of people died of dust pneumonia in 1935. Dust pneumonia happened when dust settled deep in a person's lungs. It stopped the cilia, the tiny hairs that sweep the airways clean, from moving. The person had fever, chest pain, coughing and trouble breathing.

**Paid to grow less.** Under the Agricultural Adjustment Act of May 1933, federal officials paid farmers to grow less, so that crop prices would rise. That year farmers plowed under about 10 million acres of cotton that was already growing, turning the young plants back into the ground. Federal officials bought about 6 million pigs and had them killed. At the same time, hungry people across the country stood in breadlines, long lines for free food.

Judges threw out the farm law in 1936, and members of Congress wrote a new one in 1938. Federal payments to farmers have continued ever since.

Many Americans were angry that federal officials were having food destroyed while people went hungry. Federal officials set up the Federal Surplus Relief Corporation to give extra farm food to families on relief, meaning families getting government help.

**Food stamps.** The first Food Stamp Program began in Rochester, New York, on May 16, 1939, and Mabel McFiggin was the first buyer. People bought orange stamps that paid for food. With them came free blue stamps, which could buy only foods that federal officials listed as surplus, meaning extra.

### Who got the cotton money?

The landowners got most of it. Under the cotton contracts of 1934 and 1935, federal officials paid landowners to take land out of cotton. The sharecroppers who farmed that land, families who farmed someone else's land for a share of the crop, were supposed to get a part of the payment, but under the contracts their share was only about 11 percent.

A landowner could keep the whole payment by evicting the sharecroppers, meaning forcing them off the land, and hiring day laborers, workers paid one day at a time, instead. When planters cut their cotton land by 40 or 50 percent, they cut the number of families working it by the same share.

**The lawyers.** Some lawyers at the Agricultural Adjustment Administration, the federal office that ran the farm payment program, tried to stop the evictions. Led by Jerome Frank, they decided that landowners had to keep the same families on their land. In February 1935 the office's head, Chester Davis, had Secretary of Agriculture Henry Wallace fire them.

**The union.** Seven Black men and eleven white men met at the Sunnyside School in Poinsett County, Arkansas, in July 1934 to fight the evictions. They started a union, a group of workers who join together to demand better pay and treatment, and called it the Southern Tenant Farmers' Union (a tenant farmer works land that someone else owns).

Planters and lawmen answered with force. Sheriff J. D. Dubard of Poinsett County arrested a white organizer, Ward Rodgers, at the end of a union meeting in Marked Tree in January 1935, and Rodgers was held in jail there.

About forty armed planters broke up a union crowd at Birdsong on March 15, 1935, along with lawmen and the planters' riding bosses, the men on horseback who watched over the field workers. Later that month a mob attacked the home of the union's lawyer, Cornelius Tyree Carpenter.

At a union meeting in Gilmore, four armed white men broke in. They ordered the Black members to leave and told them they would be lynched, meaning killed by a mob, if they were caught at another union meeting. Many members were beaten and threatened with guns. The Encyclopedia of Arkansas account of the union does not name the men who did it.

### Ration books and victory gardens

Federal officials rationed food during World War II, which means they limited how much of it each person could buy. Every person got a ration book of stamps, even babies. Sugar was the first food rationed, in May 1942. Coffee followed that November. In March 1943 meat, cheese, fats and canned foods were added. Sugar was also the last food to come off the list, in June 1947.

Federal officials allowed each person 26 pounds of sugar a year, about 8 ounces a week. In 1945 they cut the amount to as little as 4.5 ounces a week. Every month each person got 64 red points for meat and fats and 48 blue points for processed foods, such as canned goods. A shopper had to hand over the right points, along with money, to buy these foods.

**Victory gardens.** Americans planted about 20 million victory gardens, home vegetable gardens grown to help feed the country during the war. By 1943 and 1944, these gardens grew about 40 percent of the country's fresh vegetables, roughly 9 to 10 million tons. Accounts differ on which of the two years was the peak.

Frozen food was already on sale by the war years. Clarence Birdseye's quick-frozen foods first went on sale on March 6, 1930, in 18 stores in Springfield, Massachusetts.

### Adelaide Wisdom Benjamin

> **Who:** A girl whose family grew a victory garden and shopped with ration stamps during World War II.
>
> **When and where:** New Orleans, Louisiana, and El Paso, Texas, 1941 to 1945. She was born in New Orleans in 1932.

**She put 10 cents of her 25-cent allowance into war stamps.**

Adelaide Wisdom grew up in New Orleans. During the war her father tried to join the Army and the Navy but did not meet their requirements. The Marines accepted him. After boot camp he was posted to El Paso, Texas, as a Marine recruiter, and the family moved with him.

At the store, the family could buy sugar, butter and some vegetables only with the right ration stamps. Beef and lamb were hard to find. With so little to serve, the family could not have guests over for meals.

The family grew a victory garden in New Orleans and in El Paso. "We grew mirlitons, and string beans and tomatoes in our backyard," she said in a 2013 oral history for the National WWII Museum (a mirliton is a pale green squash). The crops grew well in New Orleans but not in El Paso. She collected scrap with her brother, such as old coat hangers and bicycle tires, and she put 10 cents of her 25-cent weekly allowance into war savings stamps.

When Germany surrendered in 1945, she bought a chocolate soda, a comic book and bubble gum. She later became a lawyer and practiced law with her husband, Eddie Benjamin, for 55 years.

### Farms taken from Japanese Americans

President Franklin Roosevelt signed Executive Order 9066, an order from the president that has the force of law, on February 19, 1942. In March and April, General John L. DeWitt ordered about 120,000 people whose families came from Japan forced out of their homes on the West Coast. Under his orders, US officials sent both citizens and noncitizens away and locked them up in prison camps behind barbed wire.

Many of these families were farmers. By 1940 Japanese American farmers and their children grew almost 40 percent of California's vegetables. When they were forced out, many had to leave their orchards and fields with crops ready to harvest.

**Farms lost.** The Farm Security Administration was the federal office put in charge of their farms. Its officials handed more than 1,000 of the farms to new farmers in March 1942 alone.

**Farming in the camps.** The prisoners farmed inside the camps too. At Tule Lake, California, they harvested almost 30 crops, among them potatoes, rutabagas and daikon radishes. Most of the field workers there were paid $12 a month, a quarter of what farmworkers outside earned, and camp officials sold more than 2 million pounds of what they grew.

### Braceros in the fields

US officials started the bracero program in 1942 to bring Mexican workers, called braceros, into the country for farm and railroad work. Over 22 years, workers signed more than 4.5 million contracts. Braceros picked much of the country's fruit and vegetables until the program ended in 1964.

US employers also held back 10 percent of each bracero's pay, and many braceros never got that money back. Chapter 14, Work and Workers, tells the story of the missing pay.

### Why school lunch became a law

Many young men called up to serve in World War II failed their physical exams because of malnutrition, not having had enough of the right food. General Lewis Hershey ran the draft, the system that called men into the military. After the war he told members of Congress that malnutrition put the country's safety at risk.

Towns and charities had already run school meal programs for decades, and in the 1930s federal officials gave these programs extra food they had bought from farmers. On June 4, 1946, President Harry Truman signed the National School Lunch Act. The law states that Congress passed it "as a measure of national security," a way to keep the country safe, and to protect the health of the nation's children. Under it, federal money for school lunches became permanent.

**If you remember one thing:** Between 1900 and 1950, federal officials began inspecting Americans' meat, paying farmers to grow less, rationing food and paying for school lunches.

- June 30, 1906: Theodore Roosevelt signs the Pure Food and Drug Act and the Meat Inspection Act.
- May 16, 1939: The first food stamps go on sale in Rochester, New York.
- June 4, 1946: Harry Truman signs the National School Lunch Act.

**Next:** After 1950 farms grew fewer and bigger, and Americans started buying frozen TV dinners and fast-food hamburgers.

## 1950 to 2000

**Era 9 of 10 · 1950 to 2000 · about 10 minutes**

Fewer, bigger farms grew more food on each acre after 1950. Farmers used tractors, hybrid seed, fertilizer and pesticides. Swanson sold 25 million frozen TV dinners in 1955, and fast-food stands served hamburgers in seconds. In the 1980s the owners of about 300,000 farms could not pay their loans, after land prices fell and interest rates rose. Meanwhile some farmers and cooks began to grow food by organic methods, without man-made chemical fertilizers and pesticides, and to serve food from nearby farms.

### Tractors outnumber horses, and farms grow bigger

The 1954 Census of Agriculture, the federal government's count of the country's farms, was the first in which American farms had more tractors than horses and mules. Farms had about 4.6 million tractors that year and about 4 million horses and mules. In 1920 there had been about 25 to 26 million horses and mules.

The number of farms fell too. In 1935 the country had 6.8 million farms, the most it ever had. After that the number kept dropping, toward 2 million. The farms that were left were bigger. Many of them grew only a few kinds of crops and relied on chemical fertilizers and pesticides.

Nearly all the corn in the country grew from hybrid seed by the 1950s. For about a hundred years before that, farmers had grown roughly 25 to 30 bushels of corn on an acre, a bushel being about 8 gallons. By the 1970s farmers were growing more than 100 bushels an acre, more than three times as much.

### Fast food and the TV dinner

Richard and Maurice McDonald opened a drive-in restaurant in San Bernardino, California, in 1940. In 1948 they rebuilt it around what they called the Speedee Service System, with a menu cut down to 15-cent hamburgers, french fries and milkshakes. The carhops, the servers who had carried food out to people's cars, lost their jobs. Workers made the food on a kind of assembly line, where each worker did one job over and over, and customers got their food in seconds.

The Swanson company put a frozen turkey dinner in an aluminum tray on sale in 1953 and called it a TV dinner. It cost about 98 cents. The company sold more than 10 million in 1954 and 25 million the next year. According to company stories, Swanson had too many turkeys left over after Thanksgiving.

**Whose idea it was.** Who thought of the TV dinner is disputed. For decades a salesman named Gerry Thomas said the idea was his. The company's owners were the brothers Gilbert and Clarke Swanson. Their relatives, and a Swanson scientist named Betty Cronin, said the brothers came up with it at the company and that Thomas took the credit. Frozen meals had been sold before either claim: in 1945 the Maxson company made frozen "Strato-Plates" to serve on airplanes.

### Ray Kroc

> **Who:** A milkshake-machine salesman who became the McDonald brothers' franchise agent and then bought them out.
>
> **When and where:** Visited San Bernardino, California, in 1954. Opened his first McDonald's in Des Plaines, Illinois, on April 15, 1955. Bought out the brothers in 1961.
>
> **Movie:** *The Founder* (2016), a drama based on his story and the brothers'.

**He bought out the McDonald brothers for $2.7 million in 1961.**

Ray Kroc sold milkshake machines. In 1954 he went to see the McDonald brothers' stand in San Bernardino. He became the brothers' agent for franchises, deals that let other people open stores under the brothers' name and system in return for fees.

Kroc opened his own McDonald's in Des Plaines, Illinois, on April 15, 1955. In 1961 he bought the brothers out for $2.7 million. The brothers said Kroc had made a handshake promise to keep paying them royalties, a share of the money from every sale, and never kept it. Kroc also opened a McDonald's near their original stand, in competition with it.

### Norman Borlaug

> **Who:** An Iowa-born plant scientist whose wheat helped poor countries grow far more grain, in what was called the Green Revolution.
>
> **When and where:** Mexico from 1944. India and Pakistan in the 1960s. Nobel Peace Prize in 1970.
>
> **Movie:** *The Man Who Tried to Feed the World* (PBS American Experience, 2020), a documentary.

**His short-stemmed wheat came from crossing thousands of kinds.**

Norman Borlaug bred wheat that grew more grain on the same land. Starting in 1944, he worked in Mexico for a program run by the Rockefeller Foundation, a charity started by the Rockefeller family. He crossed thousands of kinds of wheat. The result was a semi-dwarf wheat, with short stems, that resisted plant diseases. By 1956 Mexican farmers grew all the wheat the country needed.

Experts in the 1960s predicted famines, times when there is so little food that people starve, in India and Pakistan. Farmers there planted Borlaug's wheat, and the famines the experts predicted did not happen. Borlaug won the Nobel Peace Prize in 1970, the only farm scientist to have won it.

Many writers credit his work with saving as many as a billion lives, a common estimate rather than a count. The rise in grain harvests in poor countries that followed is called the Green Revolution.

Farmers grew his wheat together with chemical fertilizer and irrigation, water brought to the fields by pipes and ditches, so they came to depend on chemicals they had to buy. Many farmers also stopped planting old kinds of crops, so fewer kinds were grown.

### Pesticides in the fields

Farmers sprayed their crops with pesticides, chemicals that kill insects and weeds. One of them, DDT, which kills insects, was in wide use from the mid-1940s, and it made the shells of eagles' eggs thin. Rachel Carson's book *Silent Spring*, published in September 1962, described what these long-lasting pesticides did to birds, soil, water and people. By 1963 only 417 pairs of bald eagles were nesting in the lower 48 states. Officials at the Environmental Protection Agency banned DDT in 1972.

Farmworkers in steady contact with pesticides had high rates of burns, cancer and children born with birth defects. In the 1980s, children in several towns of California's San Joaquin Valley had cancer at rates "800% above the norm," according to the Walter P. Reuther Library at Wayne State University.

**The farmworkers' union.** Cesar Chavez and Dolores Huerta campaigned to ban DDT on grape and lettuce ranches. With the United Farm Workers, they organized the people who picked the crops. They are known for the grape strike in Delano, California, when grape pickers refused to work until growers met their demands.

In March 2026 the New York Times reported that two women said Chavez had sexually abused them as girls in the 1970s, and Dolores Huerta then said that he had raped her, forcing her into sex. Chavez died in 1993, so no court has heard these accusations. Chapter 14, Work and Workers, tells the strike and these accounts in full.

### Black farmers and their land

Black farmers ran more than 900,000 farms in 1920. Between 1910 and 1997, the amount of farmland Black Americans owned fell by nearly 90 percent.

**Loans held back.** Researchers at the Union of Concerned Scientists, a science group, named two of the causes in a 2023 report. The first was that officials of the US Department of Agriculture, or USDA, had stopped Black farmers from getting the loans and grants that would have kept them on their land. Lloyd Wright, who once ran the department's civil rights office, called it "the last plantation," after the big farms where enslaved people had been forced to work.

**Heirs' property.** The second cause was heirs' property. When a landowner died without a will, a paper that says who gets a person's things after the person dies, the land passed to the landowner's heirs, the family members who inherit it. All the heirs owned the land together. Each owned a share of the whole farm, not a piece of land of their own.

Any one of the heirs could ask a court to force a sale of the whole farm. A land buyer could buy one heir's share and then ask a court to sell the farm at auction, and farms sold that way went for far less than they were worth. USDA officials have called heirs' property "the leading cause of Black involuntary land loss," meaning land lost when the owners did not choose to sell.

**What it cost.** In a study published in 2022, five economists put the value of the land Black farmers lost from 1920 to 1997 at about $326 billion in today's dollars. By 2007 Black farmers ran 32,938 farms, about 1.5 percent of the country's farms.

**The court case.** Black farmers took the USDA to court in a case called *Pigford v. Glickman*. They showed that from 1983 to 1997, USDA officials treated Black farmers worse than white farmers because of their race, and that the officials failed to look into the farmers' complaints.

Members of local county committees made the decisions on USDA farm loans. Black farmers said committee members turned down their loans, or made them wait longer for approval than white farmers. The Congressional Research Service report on the case does not name the committee members.

Judge Paul L. Friedman approved a settlement, an agreement that ends a lawsuit, on April 14, 1999. Under it, 15,645 farmers had their claims approved, out of 22,721 who qualified. Those approved under the part of the settlement called Track A each received $50,000, and USDA officials canceled what they owed on their USDA loans. The payments and debt relief came to about $1.06 billion. A second settlement, of $1.25 billion, was announced on February 18, 2010, for farmers who had missed the first deadline.

### Organic farming rules become law

Organic farmers grow food without man-made chemical fertilizers and pesticides, and they build up their soil with compost, rotted plant and animal matter. J.I. Rodale began a magazine called *Organic Farming and Gardening* in Emmaus, Pennsylvania, in 1942 and spent decades urging farmers and gardeners to farm this way.

Members of Congress passed the Organic Foods Production Act in 1990. It required national rules for what could be sold as organic. The USDA organic seal, a label for food that meets those rules, came into use on October 21, 2002.

### Alice Waters

> **Who:** A cook who built her restaurant around food from nearby farms and started a school garden where children grow and cook their own food.
>
> **When and where:** Chez Panisse restaurant, Berkeley, California, opened in 1971. The Edible Schoolyard, Berkeley, started in 1995.
>
> **Movie:** *Alice Waters and Her Delicious Revolution* (PBS American Masters, 2003), a documentary.

**In her school garden, students grow food, cook it and eat it.**

Alice Waters opened a restaurant called Chez Panisse in Berkeley, California, in 1971. She cooked with food that was fresh, grown nearby, in season and organically grown. Chez Panisse was one of the first restaurants of the style later called California cuisine, cooking built on fresh food from local farms. Waters helped start the farm-to-table idea, which means buying food straight from local farms.

Waters started the Edible Schoolyard at Martin Luther King Jr. Middle School in Berkeley in 1995. Students there grow a garden, cook what they grow and eat it.

### The farm crisis of the 1980s

American farmers sold large amounts of grain to other countries in the 1970s. They planted "fencerow to fencerow," every acre up to the fences. Expecting the good years to last, many farmers borrowed from banks to buy more land and machines.

Then, in the early 1980s, interest on loans, the extra money a borrower pays back on top of a loan, rose high. At the same time, the price of farmland fell. In parts of the Midwest, farmland lost as much as 60 percent of its value between 1981 and the mid-1980s. By 1984 American farmers owed about $215 billion, twice what they had owed in 1978, and many could not earn enough to keep up with their loan payments.

The owners of an estimated 300,000 farms defaulted during the 1980s, meaning they could not pay back their loans. About 300 banks in farm country failed, running out of money and closing.

**Farm Aid.** Willie Nelson, John Mellencamp and Neil Young held a concert called Farm Aid in Champaign, Illinois, on September 22, 1985. About 80,000 people came, and more than $7 million was raised for farm families. Farm Aid concerts still take place.

### Russel and Mary Jane Jordan

> **Who:** An Iowa farm couple who sold their machinery, livestock and household goods at auction to pay their bank, while their daughter filmed it.
>
> **When and where:** Iowa. The family had owned its farm for 125 years. Their bank was in Atlantic, Iowa.
>
> **Movie:** *Troublesome Creek: A Midwestern* (1995), a documentary about the family. It won the Grand Jury Prize at the Sundance Film Festival and was nominated for an Academy Award.

**To pay the bank, they sold everything but the land.**

Russel and Mary Jane Jordan owned a farm in Iowa that had been in their family for 125 years. A company called Norwest, which owned banks in several states, bought their bank in Atlantic, Iowa, and a man from the company's headquarters, Tim Wolf, took over their loans.

**The debt.** In the spring of 1990 the bank's officers called in an old debt of $70,000, which meant they demanded that it be paid. That same spring the Jordans had taken out their yearly loan of $150,000 to pay for the season's farming. To keep the bank from taking the farm, they decided to pay off both, about $220,000 in all.

**The auction.** The Jordans sold all their machinery, their livestock and even their household goods at an auction. They kept only the land. The sale raised about $300,000, more than enough to pay what they owed. Russ and Mary Jane moved to a rented house in Atlantic. Their son Jim took over farming the home place with his own equipment. Later the crop land was rented out to neighbors.

Their daughter, Jeanne Jordan, and the filmmaker Steven Ascher made the film about the family.

## 2000 to Today

**Era 10 of 10 · 2000 to Today · about 8 minutes**

Americans have argued since 2000 over what goes into their food, who picks it and who can get enough of it. Meanwhile the number of farms kept falling. The 2022 Census of Agriculture, the USDA's count of the country's farms, found 1.9 million farms in the United States, 7 percent fewer than in 2017. It was the first count below 2 million since before the Civil War. In 1935 there had been 6.8 million.

### Weight, hunger and food stamps

Researchers at the Centers for Disease Control and Prevention, or CDC, measure obesity, a body weight high enough to raise the risk of illness. By their count, about three American adults in every ten had obesity in 1999 and 2000, and about four in every ten in the years 2021 to 2023.

Doctors link diet to heart disease and to type 2 diabetes, an illness in which the body cannot keep the sugar in the blood at a healthy level.

Some Americans live far from a place to buy fresh food. USDA officials map low-income areas that are far from a supermarket, and people call these areas food deserts. In a city, far means more than 1 mile away. In the country, it means more than 10 miles. An area counts when at least 500 people, or a third of the people who live there, are that far away.

By that measure, about 19 million people, about 6 percent of the population, lived in food deserts in 2019.

USDA economists had counted households that did not always have enough food since 1995. In September 2025, USDA officials under Agriculture Secretary Brooke Rollins announced that they would end the count. They called it "redundant, costly [and] politicized," meaning a repeat of other work, too expensive and slanted by politics. The last report came out on December 30, 2025. It reported that in 2024 about one household in seven did not always have enough food: nearly 48 million people, including more than 14 million children.

President Donald Trump signed the One Big Beautiful Bill Act on July 4, 2025. Under it, federal spending on SNAP, the Supplemental Nutrition Assistance Program once called food stamps, goes down. Economists at the Congressional Budget Office, which works out costs for Congress, figured that the cut will come to $186.7 billion over ten years.

### Farmers' markets

Farmers' markets, where farmers sell their own crops straight to shoppers, grew in number. USDA officials counted 1,755 of them in 1994 and 8,771 in 2019, five times as many. The number grew about 7 percent a year until about 2011, and then it stopped growing much.

### COVID-19 in the meat plants, 2020

The disease COVID-19 spread through the plants that process meat and poultry, birds such as chickens and turkeys. Officials in 23 states reported 16,233 cases of COVID-19 among workers in 239 plants in April and May 2020, and 86 of those workers died. This count comes from a CDC report of July 2020. Of the sick workers whose race was recorded, 87 percent were members of racial or ethnic minority groups.

### Changed seeds and new kinds of meat

Most of the country's corn, soybeans and cotton grows from genetically engineered seed. Scientists made it by changing the seed's DNA, the chemical instructions inside every cell, in a laboratory, so that the plants survive sprays that kill weeds. In 2025 farmers planted it on about 92 percent of the country's corn acres, 96 percent of its soybean acres and 93 percent of its cotton acres, according to USDA economists.

Industry histories name the Flavr Savr tomato, sold in 1994, as the first engineered food sold in stores. Scientists of the National Academies of Sciences, a group of leading American scientists, reviewed about 1,000 studies in 2016. They wrote that they found no convincing proof that eating these foods harms people's health. Many Americans still argued against them. Under federal rules in force since January 2022, foods that contain changed DNA that tests can detect must carry a "bioengineered" label.

**New kinds of meat.** The Impossible Burger, made from plants, came out in 2016. Beyond Meat also makes meat from plants. The public could buy its shares, small parts of the company, for the first time in 2019, and their price rose more on the first day than that of any other company's new shares that year.

USDA officials gave two companies, UPSIDE Foods and GOOD Meat, the first approval in the United States to sell chicken grown from animal cells instead of from a live bird in June 2023. People call it lab-grown meat.

On vertical farms, workers grow vegetables indoors on shelves stacked high. Investors put money into these companies, and the business grew fast. AeroFarms, an early company of this kind, filed for bankruptcy, a court process for a business that cannot pay its debts, in June 2023. The company later reorganized and stayed in business.

### Who picks the food?

Most hired crop workers in the United States were born in other countries, USDA economists report. In recent years about 15 percent of crop-farm jobs have gone to workers on H-2A visas, papers that let a farmworker from another country come for one season of farm work. More than 90 percent of H-2A workers come from Mexico.

The number of H-2A jobs grew more than eight times over from 2005 to 2025. Chapter 14, Work and Workers, gives the numbers.

**Heat and children.** Crop workers in the fields died of heat at nearly 20 times the rate of all American workers from 1992 to 2006, a CDC count found. Federal law also lets children work on farms at younger ages than in other jobs. Chapter 14 tells the death of one of those crop workers, a 56-year-old tobacco picker in North Carolina, and sets out the rules for children on farms.

### Lucas Benitez

> **Who:** A tomato picker who helped start the Coalition of Immokalee Workers and its Fair Food Program.
>
> **When and where:** Born in Guerrero, Mexico. Moved to Immokalee, Florida, at 17. The coalition began in 1993, and the Fair Food Program began in 2011.
>
> **Movie:** *Food Chains* (2014), a documentary about the coalition. Benitez appears in it.

**In one case, he helped free about 700 workers held in slavery.**

Lucas Benitez came to Immokalee, Florida, from the state of Guerrero in Mexico when he was 17. He picked tomatoes in the fields there. In 1993 he helped start the Coalition of Immokalee Workers, a group of farmworkers.

**The orange groves.** In 2000 Benitez looked into slavery in the orange and grapefruit groves around Lake Placid, Florida, north of Immokalee. Two brothers, Ramiro and Juan Ramos, supplied as many as 700 pickers to the growers there. They made the workers pick fruit ten hours a day, six days a week, and threatened them at gunpoint with torture and death if they tried to escape.

The brothers charged each worker $1,000 for the trip to Florida. Each week they took most of the workers' pay, saying it went to that debt and to food and rent, but no worker was ever set free. In April 2001 four of the workers escaped with the coalition's help. A federal court convicted the brothers in 2002, and Ramiro Ramos was later sentenced to 15 years in prison. WGCU, a public radio station in Florida, credits Benitez with helping to free about 700 workers in that one case.

**The Fair Food Program.** The coalition and Florida's tomato growers began the Fair Food Program in 2011. Big buyers such as McDonald's and Walmart pay about a penny more for each pound of tomatoes. The program's managers suspend any farm where workers are forced to work, children are put to work as a regular practice, or workers suffer sexual assault, any sexual touching or attack against a person's will, including rape. Chapter 14 tells the rest of how the program works.

Benitez received the University of Michigan's Wallenberg Medal, an award for people who defend human rights, in October 2023.

### Black farmers in the new century

The 2022 Census of Agriculture counted 46,738 Black farmers on 32,653 farms, according to a USDA report of June 2024. They made up 1.4 percent of all the country's farmers and worked 5.3 million acres. The number of farms run by Black farmers was 8 percent lower than in 2017. In 1920 Black farmers had run more than 900,000.

USDA officials paid about $2 billion on July 31, 2024, to more than 43,000 farmers, ranchers and forest owners who had faced discrimination in USDA farm loans, meaning they had been treated worse because of who they were, such as their race. The NAACP Legal Defense Fund reported the payments that day. The money came from a section of the Inflation Reduction Act, a law that members of Congress passed in 2022.

### The first farmers, still farming

People in Native nations are working to control their own food, which is called food sovereignty. Tribes run bison herds, seed banks that save the seeds of old crops, and programs that bring back traditional foods. Native chefs and seed keepers are rebuilding the ways their nations cooked and ate. Among the Ojibwe of the Great Lakes, manoomin, or wild rice, is harvested by canoe and is still a central food.

### Nephi Craig

> **Who:** A White Mountain Apache and Diné (Navajo) chef who opened a café built around Apache foods.
>
> **When and where:** Café Gozhóó, Whiteriver, on the White Mountain Apache Reservation in Arizona, opened in 2021.
>
> **Movie:** *Gather* (2020), a documentary about Native food sovereignty that features him.

**He cooks Western Apache foods like parched corn and acorn powder.**

Nephi Craig is a chef who cooks the foods of the Western Apache. He opened Café Gozhóó, a café built around Apache foods, in Whiteriver, Arizona, on the White Mountain Apache Reservation, in 2021. Apaches who are recovering from addiction to alcohol or drugs work in its kitchen through a job-training program run by the tribe's Rainbow Treatment Center.

**The food.** Craig's Western Apache seed mix has pine nuts, amaranth (a plant whose tiny seeds are eaten like grain), pumpkin seeds and parched corn. To parch corn, he swirls white corn kernels in a hot pan until they toast. He has also served grilled squash with Apache acorn powder, made from ground acorns.

Craig said in 2026 that he had been sober himself for 15 years. That year he published a book about his life and his cooking, *Our Knives Will Save Us*. He also founded the Native American Culinary Association, a group for Native cooks.

The 2020 documentary *Gather* follows him and others who are bringing back Native foods. Among them are Twila Cassadore, a San Carlos Apache woman who gathers wild foods, and Elsie DuBray, a student scientist from the Cheyenne River Sioux.

**The three questions, answered**

- How did Native farmers turn a wild grass into corn? For thousands of years, starting in southern Mexico about 9,000 years ago, they saved seed only from the teosinte plants they chose, until the grass became corn.
- Who did the hardest farm work, and what did they get for it? Enslaved people worked the rice and cotton fields for no pay, and sharecroppers got half the crop's value or less and stayed in debt. From 1992 to 2006, crop workers died of heat at nearly 20 times the rate of all American workers.
- How did Americans come to eat food grown far away by people they never met? With canning, pond ice and railroad cars cooled with ice, food could be sold far from the farm, and the farms grew fewer, down to 1.9 million in 2022.

**What changed:** Growing food went from the work of nearly every family to the business of fewer, bigger farms, while the hardest field work stayed with people who were enslaved, in debt or far from home.

**Five dates to keep**

- About 9,000 years ago: farmers in southern Mexico begin breeding corn.
- November 1620: the *Mayflower* men dig up Nauset seed corn.
- May 20, 1862: the Homestead Act becomes law.
- June 30, 1906: Roosevelt signs the pure food and meat inspection laws.
- April 14, 1999: a judge approves the *Pigford* settlement.

**Not known:** No farmer from before 1500 is known by name.

**Where to go:** You can read 318 of the Oblinger family's letters online at the Library of Congress, in its Prairie Settlement collection.

**Next:** Chapter 16, Economy. It follows how the country has made its living, through booms and panics.
