# Chapter 9: Science

**Chapter 9 of 37 · Science · 10 eras · about 95 minutes**

**Science in America grew from a few people watching the sky into labs with thousands of workers, and along the way many scientists used people who never agreed to be studied.**

A dead moose reached General John Sullivan in New Hampshire on April 3, 1787, badly rotted. Thomas Jefferson had asked for its skin, skeleton and horns. He wanted to show a French scientist named Buffon that American animals were not small and weak. The antlers could not be saved, so Sullivan sent another animal's antlers and wrote that they "may be fixed on at pleasure." In the book where he argued with Buffon, Jefferson also called Black people inferior to white people. He called that claim "a suspicion only."

This chapter follows American science from the sunrise posts at Cahokia to the James Webb Space Telescope. Most of it is people measuring things: a comet, the speed of light, the carbon dioxide in the air. Watch also for the people who were measured. From the 1830s to the 1970s, scientists and doctors dug skulls out of graves, had enslaved people photographed as "evidence" about race, and injected hospital patients with plutonium. The last eras show what families and Native nations did about it. Watch, too, who gets the credit: more than once it went to someone other than the person who did the work.

**Three questions this chapter answers**

- How did American scientists learn how far away the stars are?
- Why did scientists collect human skulls and brains, and where are those remains now?
- Who did the work but was left out of the credit?

**Five minutes?** Read "How did Henrietta Leavitt measure space?" in 1900 to 1950, then "The shape of DNA, and who got the credit" in 1950 to 2000.

**Can skip:** "Charting the winds at sea", "The physics inside the transistor, 1947", "Heavy elements, made by many countries", "Computers that predict the shapes of proteins". The chapter still makes sense without them.

## Before 1500

**Era 1 of 10 · Before 1500 · about 3 minutes**

The people of Native nations here watched the sky for many generations and learned where the sun rose at each time of year. They studied plants, fire, the weather and the tides as well. Each generation taught what it knew to the next.

They marked what they knew about the sky with posts and with carvings in rock. At Cahokia, people set up circles of wooden posts that marked where the sun rose. At Chaco Canyon, sunlight falls on two carved spirals in set places at certain times of year.

### Woodhenge at Cahokia

The people of Cahokia, in what is now Illinois, tracked the sunrise with circles of upright wooden posts between about the years 900 and 1100. Chapter 8 tells how they built the circles. The place where the sun comes up moves along the horizon over a year, and the posts marked that movement. The circles are known today as Woodhenge. Nations such as the Chickasaw and the Osage descend from the people who lived at Cahokia.

The posts marked the sunrise on the solstices, the longest and the shortest days of the year. They also marked it on the equinoxes, the two days each year when day and night are about the same length.

### How does the Sun Dagger at Chaco Canyon work?

Sunlight slips past three slabs of sandstone and lands on two spirals carved into the rock. The slabs lean against a cliff near the top of Fajada Butte, a steep hill with a flat top in Chaco Canyon, in what is now New Mexico. The canyon was a center for the ancestral Pueblo people from 850 to 1250. Their descendants today include the Hopi, the Pueblo peoples of New Mexico and the Navajo Nation.

**The daggers.** The light falls on the spirals as thin blades, called daggers, and they land in set places at the solstices and the equinoxes. Researchers in a group called the Solstice Project argue that the spirals also mark a cycle of the moon. Over 18.6 years, the points where the moon rises and sets swing out to their widest and back again. Other researchers who study ancient astronomy still debate that claim.

**Worn away.** Anna Sofaer, a volunteer making a record of rock art, recorded the daggers at the summer solstice of 1977. They no longer form the way she saw them. By the summer solstice of 1989, two of the three slabs had shifted. Park officials had limited visits to the butte, but visitors walking there had made the ground wear away faster.

### Knowledge of living things

Native nations built up knowledge of ecology, the ways living things depend on each other and on the land, by watching closely over many generations. Scientists today call it Traditional Ecological Knowledge, or TEK for short. Part of it is knowledge of how fire changes the land and the living things on it.

The Ecological Society of America, a group of scientists who study ecology, has a section for TEK. A botanist, or plant scientist, named Robin Wall Kimmerer helped to found it.

### Robin Wall Kimmerer

> **Who:** A botanist of the Citizen Potawatomi Nation who uses Native knowledge and laboratory science together in her work.
>
> **When and where:** The present day. The State University of New York's College of Environmental Science and Forestry.

**Her 2013 book has been a New York Times bestseller since 2020.**

The book is *Braiding Sweetgrass*, and it has been on the list since February 2020. Kimmerer is a member of the Citizen Potawatomi Nation. In her work she studies plants in two ways together. One is the knowledge that Native nations have built up and taught. The other is the science of the laboratory.

**Sweetgrass at a Mohawk farm.** In a study published in 2005, Kimmerer and a fellow researcher worked to bring back sweetgrass, a plant used to make baskets, at Kanatsiohareke, a Mohawk farm. Members of the Mohawk community chose the spot, because sweetgrass had grown there in the past. The researchers then tested four ways of planting it. The sweetgrass grew best beside a crop called hairy vetch.

She earned a PhD in botany, the highest degree a university gives, at the University of Wisconsin. She teaches at the College of Environmental Science and Forestry, part of the State University of New York, where she founded the Center for Native Peoples and the Environment. In 2022 the MacArthur Foundation named her a MacArthur Fellow.

## The 1500s

**Era 2 of 10 · The 1500s · about 1 minute**

Europeans who crossed the ocean in the 1500s studied this land only on short visits. They collected what they found, described it in writing and published their descriptions in Europe.

### Thomas Hariot's report

Thomas Hariot, an English mathematician, spent a year on Roanoke Island and wrote down the plants, the animals and the foods he found. The island lies among the shallow waters of the Outer Banks, in what is now North Carolina. Hariot went there in 1585 and 1586 with the expedition that Walter Raleigh sent.

He also wrote about the Native nations who lived there, such as the Secotan. They spoke Algonquian languages, a group of languages related to each other.

**The book.** Hariot published *A Briefe and True Report of the New Found Land of Virginia* in 1588. It was the first book in English about North America written by someone who had been there. A publisher named Theodor de Bry printed it again in 1590, with pictures made from drawings by John White.

## The 1600s

**Era 3 of 10 · The 1600s · about 3 minutes**

A few colonists kept careful records of the sky and the weather in the 1600s, and some of them still read the sky as a message from God. English colonists in New England founded Harvard, the first college in their colonies, in 1636, and printed their first almanac three years later. One of them, Increase Mather, measured comets but still wrote that they were warnings from God.

### A college, an almanac and a telescope

Members of the Massachusetts Bay General Court, the colony's lawmakers, voted in 1636 to found a college. It was the first college in the English colonies. John Harvard died in 1638 and left the college his books and half of everything else he owned. On March 13, 1639, the same lawmakers voted to name the college Harvard, after him.

**The almanac.** That same year a sailor named William Pierce worked out an almanac, a yearly booklet with a calendar and tables of the sun and moon. Its title was *An Almanack for New England for the Year 1639*. Stephen Daye printed it at Cambridge, in Massachusetts, on the first printing press in the colonies. It was one of the first two things printed there.

For the next two hundred years, ordinary families learned about astronomy, the study of the sun, the moon, the planets and the stars, from almanacs.

**The telescope.** John Winthrop Jr., a governor of Connecticut, visited London from 1661 to 1663. While he was there, members of the Royal Society, a group of scientists in London, elected him a fellow, or full member. He was one of the first colonists to join. In about 1672 he gave Harvard his telescope, which was 3.5 feet long. It was the college's first scientific instrument.

### The comet of 1680

Thomas Brattle followed the Great Comet of 1680 with a telescope from Boston. He had finished his studies at Harvard in 1676. The comet showed in the sky in November and again in December. Brattle worked out that the two sightings were one comet, which had swung around the sun in between.

**A warning and a measurement.** Increase Mather wrote a book about comets in 1683, called *Kometographia*. In it he listed comets as warnings sent by God. Yet he measured comets with parallax, which means looking at an object from two different places. A near object seems to shift against the stars far more than a distant one. His measurements showed that comets were distant bodies, not vapors, a kind of gas.

That same year Mather founded the Boston Philosophical Society, modeled on the Royal Society in London. People then called the study of nature natural philosophy, so a philosophical society was a group for studying nature. Mather's group met for about three years.

The English scientist Isaac Newton published his book the *Principia* in 1687. In it Newton set out his laws of motion and of gravity, and he wrote about Brattle's New England observations of the comet of 1680.

### Rev. John Campanius Holm

> **Who:** A chaplain in the colony of New Sweden who kept the first known weather record in what is now the United States.
>
> **When and where:** Near what is now Wilmington, Delaware, 1644 and 1645.

**Twice a day, with no instruments, he wrote down the weather.**

John Campanius Holm kept the first known record of the weather in what is now the United States. He wrote it down twice a day through 1644 and 1645. He followed the same plan day after day, and he had no instruments at all.

Holm was a chaplain, a minister who serves people far from home. He served New Sweden, a Swedish colony on the Delaware River, near what is now Wilmington, Delaware.

Officials of the National Oceanic and Atmospheric Administration, the US government's weather and ocean agency, now give the John Campanius Holm Award. It goes to volunteers who take weather readings, up to 25 people each year.

## 1700 to 1750

**Era 4 of 10 · 1700 to 1750 · about 3 minutes**

Colonists who studied nature began to share their work in these years, with each other and with scientists in London. A farmer named John Bartram and Benjamin Franklin of Philadelphia got them started. Bartram traveled through the colonies from 1730 to collect and study American plants. Franklin organized a society in Philadelphia for this kind of work in 1743. From 1747 he ran experiments with electricity and mailed the results to London. Scientists in Britain read those letters, and Franklin became the first American scientist known outside the colonies.

### The American Philosophical Society, 1743

Benjamin Franklin organized the American Philosophical Society in Philadelphia in 1743. It is the oldest learned society in the United States, a group of people who meet to share and discuss what they have found out.

The botanist John Bartram first suggested the idea in 1739. Franklin started the society with a pamphlet, a short printed booklet. It was titled *A Proposal for Promoting Useful Knowledge among the British Plantations in America*, and in that title the word plantations means colonies.

The society grew out of the Junto, a club Franklin had started in 1727 with about twelve friends, most of them tradesmen. Its members met on Friday nights to argue about right and wrong, about government and about nature. Franklin meant the new society to be an American answer to the Royal Society in London.

### Benjamin Franklin

> **Who:** A Philadelphia man whose experiments with electricity made him the first American scientist known in other countries.
>
> **When and where:** Philadelphia, experiments from 1747 to 1751.
>
> **Movie:** *Benjamin Franklin* (2022), a two-part documentary by Ken Burns, shown on PBS. It is about Franklin's life.

**Scientists still say "positive" and "negative" because Franklin chose those words.**

Benjamin Franklin ran experiments with electricity in Philadelphia from 1747 to 1751. He reported his results in letters to Peter Collinson, a member of the Royal Society in London.

Franklin thought of electricity as a single fluid. He called an object positive when it held more of this fluid than normal, and negative when it held less. He argued that electric charge is never made or destroyed. It only moves from one object to another, an idea scientists call the conservation of charge. He also proposed that lightning is electricity.

His letters came out in London in April 1751 as a book, *Experiments and Observations on Electricity*. In 1753 members of the Royal Society gave him the Copley Medal, their highest honor. He was the first person from outside Britain to receive it, and the first American to be known in other countries as a scientist.

### John Bartram

> **Who:** A Quaker farmer who studied plants, built the oldest surviving botanic garden in America, and first suggested the American Philosophical Society.
>
> **When and where:** His farm at Kingsessing, on the Schuylkill River, from 1728. He lived from 1699 to 1777.

**He and his sons gave science more than 200 new American plants.**

Scientists first learned of more than 200 American plants through John Bartram and his sons. Bartram was a farmer and a Quaker, a member of a Christian group also called the Society of Friends.

He bought a farm of 102 acres at Kingsessing, on the Schuylkill River, in 1728. There he built a botanic garden, where plants are grown so they can be studied. It is the oldest botanic garden in America that survives today.

He traveled from 1730 to 1765 to collect plants, from New York as far south as Florida. The idea that became the American Philosophical Society was his, in 1739. King George III named him the King's Botanist for North America in 1765.

Carl Linnaeus, the Swedish botanist who made the system scientists use to name living things, reportedly called Bartram "the greatest natural botanist in the world."

## 1750 to 1800

**Era 5 of 10 · 1750 to 1800 · about 7 minutes**

Scientists in Europe began reading and reprinting American work after 1750. Benjamin Franklin designed the 1752 test that showed lightning is electricity. Men in France ran it first, and Franklin wrote that he then ran it with a kite. In 1769 four men at Norriton timed the planet Venus as it crossed the sun, and members of the Royal Society in London reprinted their results.

Thomas Jefferson used evidence in his book *Notes on the State of Virginia*, and later a moose, to argue with a scientist in France about the size of American animals. In that same book he wrote that Black people were inferior to white people, meaning less able, in body and mind. He called the claim "a suspicion only." Benjamin Banneker, a free Black farmer who taught himself astronomy, sent Jefferson an almanac he had calculated as proof against it.

### Who ran the lightning test first?

Men in France ran Franklin's lightning test before Franklin did. Franklin had published a plan for a test that would show whether lightning is electricity. Thomas-François Dalibard followed the printed plan at Marly-la-Ville on May 10, 1752, with a tall iron rod. He reported the test to the French Academy, a society of scholars, on May 13. The test showed that lightning is electricity.

**The kite.** Franklin wrote that he ran his own test in Philadelphia with a kite. He first described it in print on October 19, 1752, in the *Pennsylvania Gazette*, a newspaper. Nobody recorded the exact day or the exact spot. The date most often given, June 1752, comes from an account Joseph Priestley wrote in 1767.

Few writers have doubted that the kite flight took place, and no record from the day settles the question either way. One who did doubt it, Tom Tucker, argued in a 2004 book called *Bolt of Fate* that Franklin never flew the kite at all.

### Timing Venus, 1769

Four men at Norriton, in Pennsylvania, timed the planet Venus as it passed across the face of the sun on June 3, 1769. An event like this is called a transit of Venus. Astronomers in many parts of the world timed the same transit. They planned to use the times to work out the distance from Earth to the sun.

Members of the American Philosophical Society chose teams to watch from three places. It was the first large, organized science project in the colonies.

**Norriton.** The Norriton team worked at the home of David Rittenhouse, in what is now Montgomery County, Pennsylvania. Rittenhouse built most of the instruments they used. He, William Smith, John Lukens and John Sellers made the timings. Their results filled the first volume of the society's *Transactions*, its printed record of research, which came out in 1771. Members of the Royal Society in London reprinted the results.

### David Rittenhouse

> **Who:** A Pennsylvania instrument maker and astronomer who taught himself both trades. One of the four men who timed Venus at Norriton in 1769.
>
> **When and where:** Norriton, Pennsylvania, in 1769, and Philadelphia. He lived from 1732 to 1796.

**He taught himself to build machines that showed the planets moving.**

David Rittenhouse taught himself to make scientific instruments and to study the stars. He built orreries, machines that show the planets moving around the sun. When an orrery's gears turn, small models of the planets move along their paths.

He followed Franklin as president of the American Philosophical Society in 1791. Later he became the first director of the United States Mint, where the country's coins are made.

### Jefferson, Buffon and the moose

A scientist in France named Buffon taught that animals and people grew "degenerate" in the Americas, by which he meant smaller and weaker. Thomas Jefferson argued against him with evidence in his book *Notes on the State of Virginia*. Jefferson wrote the book to answer a list of questions a French official had sent. He called each chapter a Query, an old word for a question.

**A claim with no evidence.** In the chapter called Query XIV, Jefferson wrote that Black people "are inferior to the whites in the endowments both of body and mind." Inferior means lower or less able, and endowments here means natural abilities. He called the claim "a suspicion only." In reason, he wrote, Black people were "much inferior, as I think one could scarcely be found capable of tracing and comprehending the investigations of Euclid," a mathematician of ancient Greece.

Jefferson himself enslaved more than 600 people during his life.

**The moose.** Jefferson's other evidence against Buffon was a moose. He was then the United States minister in Paris, the country's official representative to the French government. On January 7, 1786, he wrote to John Sullivan of New Hampshire, a former general and governor. He asked for "the skin, the skeleton, and the horns of the Moose."

Sullivan's party of men killed a moose in Vermont. Its body reached Sullivan on April 3, 1787, badly rotted. The skull and antlers could not be saved, so Sullivan sent the antlers of another animal. He wrote that they were "not the horns of this moose but may be fixed on at pleasure," meaning Jefferson could attach them however he liked.

The shipment reached France in about late September 1787. Around October 1, Jefferson gave Buffon the moose's bones and skin, along with the other animal's antlers. Jefferson wrote that the moose "convinced Mr. Buffon. He promised in his next volume to set these things right." Buffon died in April 1788 without printing a correction.

### Benjamin Banneker

> **Who:** A free Black tobacco farmer who taught himself mathematics and astronomy and calculated almanacs for the years 1792 through 1797.
>
> **When and where:** Baltimore County, Maryland, where he was born on November 9, 1731. He died in 1806.

**He sent Thomas Jefferson a handwritten almanac as proof.**

Benjamin Banneker taught himself mathematics and astronomy from books and instruments that he borrowed. He was a free Black tobacco farmer in Baltimore County, Maryland. For six years of printed almanacs, 1792 through 1797, he worked out where the sun, the moon and the planets would be on each day.

He correctly predicted the solar eclipse of April 14, 1789, when the moon passed between the earth and the sun. Better-known almanac makers had calculated it differently.

**The letter.** On August 19, 1791, Banneker sent Jefferson his almanac in manuscript, written by hand, as proof against Jefferson's claim about Black people. In the letter that went with it, he challenged Jefferson about slavery. "However variable we may be in society or religion," he wrote, "however diversified in situation or colour, we are all of the same family."

Jefferson wrote back on August 30, 1791: "no body wishes more than I do to see such proofs as you exhibit (show), that nature has given to our black brethren (brothers), talents equal to those of the other colours of men." Jefferson sent the almanac on to a man named Condorcet in Paris.

**The almanacs sell.** Banneker's first almanac, for 1792, went on sale in December 1791. Goddard & Angell of Baltimore printed it, and it sold in Baltimore, Philadelphia and Alexandria. His Quaker neighbors, Joseph and George Ellicott, had already interested other Quakers in his work, and the abolition societies of Baltimore and Philadelphia, groups that worked to end slavery.

Members of the abolition societies of Pennsylvania and Maryland promoted the almanacs. Several printers published them, and they sold in the United States and in England. The 1792 almanac opened with support from James McHenry, a Maryland politician, who used the word of the time for a Black person: "I consider this Negro as fresh proof that the powers of the mind are disconnected with the colour of the skin."

**Jefferson, later.** Banneker died in 1806. Three years later, on October 8, 1809, Jefferson wrote to Joel Barlow: "we know he had spherical trigonometry enough to make almanacs, but not without the suspicion of aid from Ellicot, who was his neighbor & friend, & never missed an opportunity of puffing him." Spherical trigonometry is the mathematics of angles and distances on a sphere, such as the sky, and puffing meant praising someone too much. Jefferson was hinting that Ellicott had helped with the mathematics. He himself called it a suspicion.

### Jefferson's fossil, 1797

Jefferson presented a paper about a fossil animal named Megalonyx, which means "giant claw," to the American Philosophical Society on March 10, 1797. The paper was printed in 1799. It was the first fossil animal from the United States to get a genus name, the name for a group of closely related kinds of animals or plants.

Caspar Wistar wrote a second paper to go with Jefferson's. With it, Wistar began the study of paleontology, ancient life through fossils, in the United States.

## 1800 to 1850

**Era 6 of 10 · 1800 to 1850 · about 9 minutes**

Americans set up their own places for science between 1800 and 1850. Benjamin Silliman, Yale's professor of chemistry from 1802, founded the country's first lasting science journal, a magazine where scientists publish their research, in 1818. President James K. Polk signed a law in 1846 to set up the Smithsonian Institution in Washington, paid for by an Englishman who never visited the country. Its first head, Joseph Henry, set up a network of volunteers who reported the weather.

In Philadelphia in the same years, a doctor named Samuel George Morton collected hundreds of human skulls. Some of the men who supplied him robbed graves to get them. Morton measured the skulls and used the numbers to rank the races of people. The idea that skull size shows the intelligence or worth of a group of people is false.

### A professor, a fallen stone and a journal

Benjamin Silliman became Yale's professor of chemistry, the study of what things are made of and how they change, in 1802. His job covered natural history too, the study of plants, animals and rocks. He gave his first lectures in 1804.

**The Weston meteorite.** A meteorite, a rock from space, fell at Weston, Connecticut, on December 14, 1807. Silliman and James Kingsley wrote down what was known about the fall. Then they ran chemical tests to learn what the rock was made of. It was the first meteorite fall in the Americas that scientists recorded and studied in this way.

Silliman founded the *American Journal of Science* in 1818. It was the first science journal in the country that lasted, and for decades people called it "Silliman's Journal."

### Who found induction first?

Michael Faraday in London was the first to publish the discovery of electromagnetic induction, the making of an electric current with a magnet. He published it in 1831, and he keeps the credit. Joseph Henry, in Albany, New York, had found the same effect on his own but published later.

**Self-induction.** Henry has the credit for a related discovery, self-induction, which he published in Silliman's journal in July 1832. When the electric current in a coil of wire changes, the coil makes its own push of electricity against that change. Scientists measure the strength of self-induction in a coil with a unit called the henry, named after him.

Henry was a teacher at the Albany Academy, a school in Albany, and his best years of research there ran from 1826 to 1832. He built the strongest electromagnets of his day. An electromagnet is a magnet made by sending electricity through a coil of wire.

### Samuel Morton's skulls

Samuel George Morton, a Philadelphia doctor, collected human skulls and used them to rank the races of people. He lived from 1799 to 1851 and belonged to the Academy of Natural Sciences of Philadelphia, a society of scientists. He prepared a lecture on how skulls differ in 1830 and began to collect them in the early 1830s. When he died in 1851, he owned 867 human skulls.

**Where they came from.** He got the skulls through 138 contacts: scientists, traders, military men and missionaries, people sent by churches to spread their religion. Army surgeons at far-off posts were his most useful suppliers. Some of his collectors robbed graves. About a dozen skulls came from a potter's field in Philadelphia, a burial ground for poor people, where poor Black Philadelphians were buried.

Morton himself got the remains, what was left of the bodies, of at least 14 Philadelphians, Black and white, while he worked as a doctor at the city's almshouse, a public home for poor people. A 2021 report for a University of Pennsylvania project does not name who dug up their bodies, and a Philadelphia news station reported that year that the Philadelphia skulls were likely bought from grave robbers.

A doctor in Havana, José Rodríguez Cisneros, dug up the graves of enslaved Africans in Cuba in 1840 and shipped about 50 of their skulls to Morton. More skulls came from battlefields and from gallows, the frames on which people were hanged. Many of the skulls were those of Native Americans.

**The measuring.** Morton filled each skull with peppercorns, and later with lead shot, which means tiny balls of lead. Then he poured them out and measured how much the skull had held. He believed that a bigger skull meant a more intelligent person. He ranked the races by the average size of their skulls, with white Europeans at the top.

His book *Crania Americana*, Latin for "American skulls," came out in 1839 and made him famous in other countries. The Penn Museum's own account states that Morton is sometimes called the "father of scientific racism." Scientific racism is the use of the look of science to claim that some races are better than others.

**Used to defend slavery.** Two of Morton's followers, the doctor Josiah Nott and George Gliddon, used his work to defend slavery. In 1854 they published a book in Morton's honor called *Types of Mankind*. Nott argued in it that Black people were a separate species, a separate kind of living thing, naturally and forever below white people. His aim was to show that freeing enslaved people would be a disaster for both races. Nott wrote to protect his clients, who were slaveholders.

**Disputed.** Scholars still argue about how carefully Morton measured. Stephen Jay Gould of Harvard wrote in 1978, and again in a 1981 book, that Morton's numbers were biased, meaning his mistakes leaned toward the answer he wanted. In 2011 six scholars led by Jason E. Lewis measured 308 of the 670 skulls Morton had published, and they found his errors small and random. A 2016 paper argued against parts of their work.

**Known:** Morton's main idea, that skull size ranks the intelligence or worth of groups of people, is false, and the argument is only about how carefully he measured.

**The skulls today.** The Penn Museum, at the University of Pennsylvania, holds Morton's skulls. Museum staff took them off a classroom display in 2020. On April 12, 2021, the museum's director, Christopher Woods, apologized for "the unethical possession of human remains in the Morton Collection." Unethical means wrong. He announced a plan to return the remains.

On the order of a Philadelphia court, museum staff buried the skulls of 19 Black Philadelphians from the collection in January 2024. They buried them at Eden Cemetery in Collingdale, Pennsylvania, one of the oldest Black burial grounds near Philadelphia. A group called the Black Philadelphians Descendant Community Group objected. Its members said that the Black community, not the museum, should decide what happened to the remains.

### James Smithson

> **Who:** An English chemist who left his fortune to the United States to found the Smithsonian Institution. He never set foot in the country.
>
> **When and where:** Died in Genoa, Italy, on June 27, 1829. The Smithsonian was founded in Washington on August 10, 1846.

**More than 100,000 gold coins crossed the ocean to found the Smithsonian.**

James Smithson, an English chemist, paid for the Smithsonian Institution, even though he never set foot in the United States. He died in Genoa, Italy, on June 27, 1829.

His will left his money to his nephew, with a condition. If the nephew died without heirs, meaning children or other family to inherit the money, it was to go to the United States. The will said the money was "to found at Washington, under the name of the Smithsonian Institution, an establishment (a place set up for a purpose) for the increase & diffusion (spreading) of knowledge."

**Not known:** why Smithson left his fortune to a country he had never seen. He never explained it.

The nephew died without heirs in 1835. In September 1838, more than 100,000 gold coins called sovereigns reached the mint in Philadelphia, where the country's coins are made. Workers there turned them into American coins worth more than $500,000. Members of Congress then argued for eight years about what to do with the money. President James K. Polk signed a law to set up the Smithsonian on August 10, 1846.

### Joseph Henry

> **Who:** A teacher at the Albany Academy who discovered self-induction and became the first Secretary, or head, of the Smithsonian Institution.
>
> **When and where:** Albany, New York, for his research of 1826 to 1832. Princeton from 1832. Washington from 1846.

**About 150 volunteers sent him the weather from where they lived.**

Joseph Henry, the first Secretary, or head, of the Smithsonian Institution, drew the first weather maps of the whole country. From 1849 he ran the Smithsonian Meteorological Project, a study of the weather. About 150 volunteers wrote down the weather where they lived. They sent their reports by mail, and by telegraph at no charge. A telegraph sent messages along a wire as bursts of electricity.

A decade later, about 600 observers were sending reports. The project ran from 1849 to 1870, and it led to the National Weather Service, the weather agency of the United States government today.

**How he got the job.** Henry discovered self-induction while he taught at the Albany Academy, and he became a professor at Princeton in 1832. On December 3, 1846, he won seven of the twelve votes cast by the Smithsonian's Board of Regents, the group that runs it. He held the job for 32 years, until he died in 1878.

### Charting the winds at sea

Matthew Fontaine Maury made charts, or maps for sailors, of the winds at sea and of the currents, the streams of moving water inside the ocean. He built them from thousands of old ships' logs. A log is the daily record a ship's crew keeps of its position, the wind and the sea.

Maury ran the Navy's Depot of Charts and Instruments, where old logs were stored, from 1842. He went through thousands of them for facts about winds and currents. In 1847 he issued the first Wind and Current Chart of the North Atlantic. He then collected logs from ship captains around the world, all kept in the same format. Captains who used his charts cut their sailing times.

**He joined the Confederacy.** Virginia's leaders took the state out of the United States in April 1861. Maury then resigned from the US Navy and joined the Confederacy, the group of Southern states that broke away from the United States and fought against it in the Civil War. Before the war, Maury had wanted slavery to spread into the American West and also into Cuba and Brazil.

### Maria Mitchell

> **Who:** A librarian and astronomer on Nantucket who found a comet in 1847. She was the first American and the first woman to win the King of Denmark's gold medal for finding a comet.
>
> **When and where:** Nantucket, Massachusetts. She found the comet on October 1, 1847.

**From a Nantucket bank roof, she found a comet nobody had charted.**

Maria Mitchell was sweeping the sky with a small telescope on October 1, 1847, moving it slowly across the stars. She was on the roof of the Pacific National Bank building on Nantucket, an island off Massachusetts, where her father worked. She found a comet, a frozen body that travels around the sun, that no chart of the sky showed. It is known as "Miss Mitchell's Comet."

The King of Denmark offered a gold medal for each new comet found with a telescope. Mitchell won it, the first American and the first woman to receive it. An Italian astronomer named de Vico saw the same comet two days after she did.

**Library by day.** Mitchell had been the first librarian of the Nantucket Atheneum, a library on the island, since 1836. For the 20 years she held that job, she read in the library by day. At night she and her father watched the sky from the roof of the bank, where he was in charge.

She became the first woman elected to the American Academy of Arts and Sciences, a society of scholars, in 1848.

## 1850 to 1900

**Era 7 of 10 · 1850 to 1900 · about 13 minutes**

Louis Agassiz, the most famous scientist in America, used his fame in these years to push a false claim about race. In 1850 he had seven enslaved people in South Carolina photographed, with their clothes taken off, as "evidence" that the races of people were created separately.

Officials of an Army museum in Washington asked Army doctors, from 1868, to send them the skulls of Native Americans, and scientists there measured the skulls to rank the races. Agassiz attacked Charles Darwin's book *On the Origin of Species*, and the botanist Asa Gray defended it.

Other American scientists measured light, energy and the stars with new care. Albert Michelson measured the speed of light in 1879 to within about 0.05 percent of the value used today. Josiah Willard Gibbs of Yale founded the science of energy in chemical changes with a paper published in 1876 and 1878. Williamina Fleming, first hired as a maid, sorted more than 10,000 stars at Harvard's observatory.

### The argument over Darwin's book

Charles Darwin's book *On the Origin of Species* came out in London in November 1859. Darwin argued that species, the different kinds of living things, were not each created separately. He wrote that species change over time, and he called the way they change natural selection.

**How it works.** Some living things have a trait, a feature such as color or size, that helps them survive and have young where they live. They have more young, and the young are likely to have the trait too. In time, the trait spreads through the group.

**Two sides at Harvard.** Copies of the book reached Harvard quickly, and two scientists there took opposite sides. Asa Gray, a botanist, defended Darwin's theory. Gray had arranged for the book to be published in America. Louis Agassiz, who studied animals and was the most famous scientist in America, attacked it. He insisted that every species had been created separately.

The two men argued it out at the American Academy of Arts and Sciences in early 1860, after Agassiz opened his attack there on January 10. Gray kept defending Darwin in essays in the *Atlantic Monthly*, a magazine. He collected them in 1876 in a book called *Darwiniana*. In it he argued that a person could accept science and keep a religious faith at the same time.

### Agassiz and the fifteen photographs

Louis Agassiz used his standing as America's most famous scientist to push a racist idea called polygenism, the false claim that the races of people were created separately. In the winter of 1850, Agassiz hired a photographer named Joseph T. Zealy to photograph enslaved people in South Carolina as "evidence" for it.

On a tour of plantations, the large farms worked by enslaved people, Agassiz looked for people who had been born in Africa. He thought that people born in Africa were racially "pure." He examined them himself. He left instructions with Robert W. Gibbes, a doctor in Columbia, South Carolina, to collect photographs as evidence. Gibbes arranged for Zealy to photograph the people Agassiz had examined.

Zealy made 15 daguerreotypes, an early kind of photograph made on a polished metal plate. The pictures show seven people: Renty Taylor, his daughter Delia, Alfred, Drana, Fassena, Jack and Jem.

**Found again.** Elinor Reichlin found the daguerreotypes at Harvard's Peabody Museum in 1976. They are the earliest known photographs of enslaved people in America.

The accounts of how the people were posed differ. In 1977 Reichlin wrote that each person had been posed naked. News reports in 2025 said that Renty and Delia were posed with no shirts on and photographed from several angles. Both accounts agree that the people were photographed with their clothes off, at least from the waist up. Reichlin's account does not make clear whether Gibbes or Zealy did the posing.

**Who they were.** B. F. Taylor enslaved Renty on his plantation, called Edgehill. Delia was Renty's daughter, born in America to parents from Africa. Jack worked in Taylor's fields as a driver, an enslaved man put in charge of other enslaved workers. F. W. Green of Columbia enslaved Jem. Reichlin's account does not name who enslaved Alfred, Drana and Fassena.

**The lawsuit.** Tamara Lanier, who identifies Renty as her great-great-great-grandfather, sued Harvard over the pictures in 2019. She claimed the images belonged with Renty's family, asked for money in damages, and asked Harvard to admit its part in slavery. In 2022 the judges of the Supreme Judicial Court of Massachusetts, the state's highest court, let her claim for emotional distress, harm to a person's mind and feelings, go forward.

Lanier and Harvard's lawyers settled the case on May 28, 2025. Harvard paid her an amount that was not made public, and Harvard's leaders agreed to give up the images. Lanier's lawyer said that Harvard still had not publicly accepted her family tie to Renty.

Harvard's leaders handed the pictures over in December 2025, from the Peabody Museum to the International African American Museum in Charleston, South Carolina. Harvard's statement said the move would put them "in the appropriate context and increase access to them for all Americans." Museum staff there unveiled them to the public on March 11, 2026.

### Why did Army doctors send skulls to Washington?

Scientists at the US Army Medical Museum in Washington measured the skulls of Native Americans to rank the races. From the 1860s, Army doctors and other collectors sent them the skulls, and the collectors took many of them from graves and battlefields.

**One man's remains.** The museum got the remains of a Dakota man killed in May 1864 near an Army post in rural Minnesota. Militiamen, part-time citizen soldiers who were fighting the Native people there, shot him twice. One bullet shattered his skull. The other went through his mouth or neck.

Soldiers dragged his body to a nearby fort, where settlers beat it. Someone cut off his scalp, the skin and hair of the top of the head, and carried it away to keep. Someone buried the body in a shallow grave. A few months later, his skeleton was dug up again.

He was about 25 to 35 years old, and nobody recorded his name. The historian Samuel Redman, who told this man's story in 2016, does not name the militiamen, the settlers or the person who dug him up. Alfred Muller, an Army doctor with the title of acting assistant surgeon, examined the man's remains and sent them to the Army Medical Museum. They ended up at the Smithsonian.

**The orders.** Officials in the Army's Surgeon General's Office, which ran the Army's doctors, sent out a letter called Circular No. 2 in 1867. In it they asked Army medical officers to collect skulls, along with Native weapons, clothing, tools, food and medicine. From 1868, officials at the Army Medical Museum asked Army doctors in "Indian country," the lands where Native nations lived, to send them Native American skulls.

The museum's scientists did craniometry, which means measuring skulls. Craniometry was part of a false "racial science." People who did it used the measurements to sort humans into races, then ranked the races by how intelligent they believed each one was. George A. Otis, the museum's curator, the person in charge of its collection, collected and measured hundreds of the skulls.

Redman's history of these collections tells how the collectors got the skulls. They dug some out of graves, sometimes months after the burial, and emptied whole cemeteries. Others came from battlefields, from people who had just been killed there. Redman's account does not say who did the killing. Some skulls arrived at the museum without anyone asking for them.

**Mulberry Creek, 1869.** One of the collectors was B. E. Fryer, the Army surgeon at Fort Harker in Kansas. In late January 1869, US soldiers and Kansas settlers attacked a party of Pawnee men at a farm near Mulberry Creek, in Kansas. James Riding In, a Pawnee historian, calls it a massacre. The Pawnee said the soldiers fired first, and Army officers said the Pawnee did.

Two soldiers were wounded. The soldiers and settlers killed eight or nine Pawnee men. One of them was a man whom settlers captured and then killed, and the reason given was that he was "trying to escape." Five men escaped and hid their dead friends' bodies from the soldiers. Three of those five later died of exposure, from cold out in the open.

In all, as many as twelve Pawnee men may have died because of the attack: eight or nine at the farm, the captured man among them, and three more from the cold.

Fryer sent a civilian to cut off the dead men's heads on January 30. Over the next weeks, Fryer or men he sent searched for the hidden bodies. On March 11, 1869, Fryer shipped 26 Native skulls to Washington, and six of them were Pawnee. He wrote to Otis that two of the skulls were damaged because soldiers "shot into the bodies and heads several times after the fight."

Fryer sent Otis the remains of at least 42 people from 1868 to 1872. They were Cheyenne, Wichita, Caddo, Osage, Kansa and people of other nations. Riding In told what Fryer did in a 1992 article, quoting Fryer's letter to Otis.

**Moved to the Smithsonian.** The museum's collection held about 3,000 skulls by about 1900. Army officials moved the Native remains to the Smithsonian's national museum in 1898 and again in 1904. The only ones they kept back were those of interest for the study of surgery. One record counts 2,000 skulls in the transfer.

### Colleges and farm research in every state

The Morrill Act became law on July 2, 1862. Under it, members of Congress gave each state 30,000 acres of public land for each of its senators and representatives. The states sold the land and used the money to start colleges that taught farming and the skills of machines and building. These are called land-grant colleges, and through them students in every state could study science.

**Whose land.** The land had been taken from Native nations. The reporters Robert Lee and Tristan Ahtone counted about 10.7 million acres of it. US officials had taken it from nearly 250 Native nations, bands and communities, in more than 160 land deals backed by violence. For all of it, US officials paid less than $400,000.

Under the Hatch Act of 1887, members of Congress set aside federal money for an agricultural experiment station in every state, a place where scientists run tests to improve farming. Scientists at the stations did research for the public in every state, including places far from the old college towns.

### Maria Mitchell's eclipse trip, 1878

Maria Mitchell led a team of women about 2,000 miles by train to Denver in 1878 to watch a total solar eclipse, when the moon blocks all of the sun's light for a short time. The eclipse took place on July 29, 1878. Her team was made up of students and graduates of Vassar College, a college for women. The women ran the trip themselves, and reporters for newspapers across the country followed it.

Mitchell had become a professor at Vassar in 1865. She was the first American woman to be a professor of astronomy.

### Josiah Willard Gibbs

> **Who:** A Yale physicist whose long paper of 1876 and 1878 founded chemical thermodynamics, the science of energy in chemical changes.
>
> **When and where:** Yale, in New Haven, Connecticut. Professor from 1871.

**Yale paid him nothing for his first nine years as professor.**

Josiah Willard Gibbs founded chemical thermodynamics. With its rules, chemists can work out from the energy in a chemical change whether the change will happen on its own.

He published this work in two parts, in 1876 and 1878. It came out in the *Transactions of the Connecticut Academy*, a journal that was little known, and it was very hard to follow.

**A model in the mail.** Scientists in Europe took notice of Gibbs's work before scientists in America did. In 1873 Gibbs had published shorter papers that described a curved surface in mathematics. In 1874 the Scottish physicist James Clerk Maxwell, a scientist who studied matter and energy, built a model of that surface with his own hands. He shaped it in clay, made copies in plaster and mailed one to Gibbs in New Haven.

**No pay.** Gibbs had earned the first American doctorate in engineering, at Yale in 1863. A doctorate is the highest degree a university gives. He was Yale's professor of mathematical physics from 1871, and for his first nine years in that job he received no pay. He lived on money he had inherited. When leaders of Johns Hopkins University offered him a job in 1880, Yale's leaders began to pay him so that he would stay.

He received the Copley Medal, at that time the top science honor in the world, in 1901.

### Albert Michelson

> **Who:** An immigrant from Prussia, raised in mining towns in the West, who measured the speed of light to within about 0.05 percent of today's value.
>
> **When and where:** Annapolis, Maryland, in 1879. Cleveland, Ohio, in 1887.

**His speed of light was off by only 1 part in 2,000.**

Albert Michelson measured the speed of light at Annapolis, in Maryland, in 1879. He got 299,864 kilometers per second, in air, and some books print his figure as 299,910. His result came within about 0.05 percent of the value scientists use today. That is an error of about 1 part in 2,000.

Michelson was born on December 19, 1852, in Strelno, a town in Prussia, a German kingdom. The town is now Strzelno, in Poland. His parents brought him to the United States in 1855, when he was 2. He grew up in mining towns in California and Nevada, and he graduated from the US Naval Academy at Annapolis.

**No ether.** Michelson and the chemist Edward Morley ran the test now called the Michelson-Morley experiment in Cleveland, Ohio, from April to July 1887. Scientists then thought that light traveled as waves through an unseen substance they called the ether. Michelson and Morley found no trace of the ether. A result like this, where the test finds nothing, is called a null result.

Their null result was an early clue for the theory of relativity, a new account of space, time and light that Albert Einstein put forward in 1905. Michelson became the first American to win a Nobel Prize in science, in 1907.

### Williamina Fleming

> **Who:** An immigrant from Scotland, hired as a maid in the house of the Harvard College Observatory's director, who went on to classify more than 10,000 stars.
>
> **When and where:** Harvard College Observatory, from about 1879.

**She started as a maid in the observatory director's house.**

Williamina Fleming, an immigrant from Scotland, took a job in about 1879 as a maid in the house of Edward Pickering. He was the director of the Harvard College Observatory, a building for studying the sky. In 1881 she moved onto the observatory's staff, and she sorted more than 10,000 stars by type for the Draper Catalogue, a list of stars published in 1890.

She was one of the observatory's "computers." At that time a computer was a person whose job was to do calculations and measurements. Fleming studied photographic plates, glass sheets that hold photographs of the night sky. On a plate from 1888 she spotted the Horsehead Nebula, a cloud of gas and dust in space.

Fleming discovered 59 nebulae and 10 novae, stars that suddenly grow much brighter for a time. She also found more than 310 variable stars, stars whose brightness changes. In 1899 she became Curator of Astronomical Photographs, the person in charge of the observatory's photographs of the sky.

**The Chest of 1900.** Harvard's time capsule of 1900, a box of papers sealed to be opened in the future, holds an entry by Fleming. It records that she earned $1,500 a year, while men in similar jobs earned $2,500. After talking about women's pay with Edward Pickering, the director, she wrote of him: "Does he ever think that I have a home to keep and a family to take care of as well as the men?"

**If you remember one thing:** After 1850 some American scientists measured light and the stars with new care, while Louis Agassiz and the Army's museum scientists used photographs and skulls to rank the races.

- 1850: Agassiz has seven enslaved people in South Carolina photographed as "evidence" for his false claim.
- March 11, 1869: Army surgeon B. E. Fryer ships 26 Native skulls to Washington, six of them Pawnee.
- 1879: Albert Michelson measures the speed of light to within about 0.05 percent.

**Next:** In the next fifty years American astronomers measured how far away the galaxies are, and the men who ran a new office in New York called their work a science of who should have children.

## 1900 to 1950

**Era 8 of 10 · 1900 to 1950 · about 24 minutes**

American scientists measured distances across the universe and ran the first controlled nuclear chain reaction in these fifty years, and some of them used people as research material without asking them. Henrietta Leavitt found a rule for measuring space in 1912, and Edwin Hubble used it to show in 1929 that the galaxies are moving apart. Enrico Fermi's team in Chicago ran the chain reaction on December 2, 1942. Fermi, Albert Einstein and Emilio Segrè all came to American labs from Europe in the 1930s.

The staff of the Eugenics Record Office in New York collected family records from 1910 to 1939 to claim that poverty and behavior are inherited. At the Smithsonian, Aleš Hrdlička collected human brains and bones to rank the races. Doctors working for the Manhattan Project, the secret program that built the atomic bomb, injected 18 hospital patients with plutonium from 1945 to 1947 to learn where it goes in the human body.

### The charge of an electron and the place of a gene

Robert Millikan measured the electric charge of a single electron in experiments with drops of oil, from 1909 to 1913. An electron is one of the tiny particles inside every atom, and it carries electricity. Millikan showed that electric charge comes in exact, equal pieces, and he won the Nobel Prize in Physics in 1923.

The Nobel Prizes were first given in 1901 under the will of Alfred Nobel, a Swedish inventor. Each year they go to people for work in physics, chemistry, medicine, writing and peace, and later also economics.

**The fly room.** Thomas Hunt Morgan found a fruit fly with white eyes in his lab at Columbia University in New York in 1910. People called the lab the "fly room," and after that fly Morgan and his team spent 17 years working there. They proved that genes sit in a line along the chromosomes. A gene is a piece of the instructions, passed from parents to children, that shapes a living thing, and a chromosome is a thread inside a cell that carries genes.

Morgan won the Nobel Prize in Physiology or Medicine in 1933. It was the first Nobel Prize for genetics, the study of how living things pass on their traits.

### Frank Chapman and the first Christmas Bird Count

> **Who:** An ornithologist, a scientist who studies birds, at the American Museum of Natural History. He proposed counting birds at Christmas instead of shooting them.
>
> **When and where:** Across North America, from Toronto to Pacific Grove, California, on December 25, 1900.

**On Christmas Day 1900, 27 people counted birds instead of shooting them.**

Hunters had a Christmas custom called the "side hunt." In a side hunt, they shot at every bird and animal they could reach. Frank M. Chapman proposed that people count the birds instead.

Chapman worked at the American Museum of Natural History in New York. He had founded a bird magazine called *Bird-Lore* and was its editor.

The 27 bird-watchers ran 25 separate counts that day, from Toronto in Canada to Pacific Grove in California. Together they counted about 18,500 birds of 90 species.

The count has run every winter since 1900. It is one of the longest-running records of citizen science, research done by ordinary volunteers, in the world.

### Robert Goddard

> **Who:** A physics teacher at Clark University who built and flew the first rocket that burned liquid fuel. The New York Times mocked his rocket science in an editorial in 1920 and printed a correction in 1969.
>
> **When and where:** Worcester and Auburn, Massachusetts. The first flight was on March 16, 1926.

**His first liquid-fuel rocket flew 2.5 seconds and landed 184 feet away.**

Robert Goddard launched the first rocket that ran on liquid fuel at Auburn, Massachusetts, on March 16, 1926. It rose 41 feet, flew for 2.5 seconds and came down in a farm field 184 feet away.

Goddard grew up in Worcester, Massachusetts, and began teaching physics at Clark University there in 1914. He later ran its physics department, and he became a full professor in 1934. In all he spent 29 years in Clark's physics department.

**The editorial.** The Smithsonian Institution published his paper *A Method of Reaching Extreme Altitudes*, about reaching very great heights, in January 1920. On January 13, 1920, the editors of the New York Times answered it with an editorial, an article giving the newspaper's own opinion. Its title was "A Severe Strain on Credulity." Credulity means a willingness to believe things.

The editors mocked Goddard for thinking that a rocket could push itself forward in a vacuum, a space with no air in it, like outer space. They wrote that he lacked "the knowledge ladled out daily in high schools."

**The correction.** The three Apollo 11 astronauts were on their way to the Moon on July 17, 1969, when the Times editors printed a correction. It read: "...it is now definitely established that a rocket can function in a vacuum as well as in an atmosphere. The Times regrets the error."

### How did Henrietta Leavitt measure space?

Henrietta Swan Leavitt found that a kind of blinking star shows how bright it truly is, and that let astronomers measure how far away stars are. She was one of more than 100 women the Harvard College Observatory hired as "computers" to study photographs of the stars. She was paid 30 cents an hour, five cents more than most of the others. She had been deaf since an illness in her twenties.

**The blinking stars.** Leavitt studied a kind of variable star called a Cepheid, which grows brighter and dimmer over and over, in a steady rhythm. In 1912 she published a paper on 25 Cepheids in the Small Magellanic Cloud, a patch of stars in the southern sky. She showed that the time a Cepheid takes for one blink tells how bright it truly is.

Astronomers compare that true brightness with how bright the star looks from Earth. The dimmer it looks compared with its true brightness, the farther away it is. With Leavitt's rule, Cepheids became markers for measuring distance across the universe. Her rule is called the period-luminosity law: the period is the time of one blink, and luminosity means true brightness.

Leavitt died on December 12, 1921. In 1925 a Swedish mathematician who did not know she had died wrote to begin nominating her for a Nobel Prize.

### Edwin Hubble

> **Who:** An astronomer who showed that there are galaxies far outside our own and that the universe is expanding.
>
> **When and where:** Mount Wilson Observatory, California, from 1923 to 1929.

**On one glass plate, Hubble wrote "VAR!" beside a star in Andromeda.**

Edwin Hubble found a Cepheid star on a photograph of the Andromeda "nebula," a faint cloudy patch in the sky, on the night of October 4 to 5, 1923. He was working with the Hooker telescope at Mount Wilson, which has a main mirror 100 inches across. The photograph was on a glass plate, and Hubble marked the plate "VAR!" for variable star.

Using Leavitt's law, Hubble worked out how far away the star was. His answer was about 900,000 light-years, each one the distance light travels in a year. At that distance Andromeda lay far outside the Milky Way, our own galaxy, so it had to be a separate galaxy, a huge group of billions of stars. He announced the result at a meeting of the American Astronomical Society on January 1, 1925.

**The universe is expanding.** In March 1929 Hubble published his finding that the farther away a galaxy is, the faster it is moving away from us. He used measurements of the galaxies' light made by Milton Humason.

Georges Lemaître, a Belgian scientist, had already worked out and published the expansion of the universe in 1927. His paper appeared in a journal that few people read. In 2018 the members of the International Astronomical Union, the world society of astronomers, renamed Hubble's law the Hubble-Lemaître law.

**By 1930:** Astronomers had shown that Andromeda is a separate galaxy and that the galaxies are moving apart, and a rocket on liquid fuel had flown in a Massachusetts field. In Washington and in New York, other scientists were collecting brains, bones and family records to rank people.

### Aleš Hrdlička's brain collection

Aleš Hrdlička collected human brains and bones for the Smithsonian to try to prove that the races differ in their bodies. From 1903 into the early 1940s he ran the physical anthropology division, the study of human bodies and bones, at the Smithsonian's National Museum of Natural History in Washington. Hrdlička believed that white people were superior to other races. Scientists have since shown his theories about the races' bodies to be false.

**The brain collection.** Hrdlička began what he himself called the "racial brain collection" in 1903. Reporters at the Washington Post looked into his collecting and published what they found in August 2023. They reported that the museum held at least 255 brains, and that Hrdlička or people working at his direction collected most of them.

Collectors took most of the remains without the consent of the dead people or their families. Consent means agreeing to something after being told what it is. Many of these people had died in hospitals, were poor, or had no relatives nearby to claim and bury them. Collectors dug up burial grounds as well.

**Kodiak Island.** In the 1930s Hrdlička and a small team dug up the remains of about 1,000 people from the Uyak site on Kodiak Island, in Alaska, and shipped them to the Smithsonian. The people of Larsen Bay, who are Alutiiq, asked the Smithsonian for their dead in 1987. Museum staff sent the remains back to Larsen Bay in September 1991. It was one of the first returns of Native American remains in the country.

The Post's reporters found that in 2023 the museum held more than 30,700 human remains. More than 19,000 of them, about 62 percent, or three of every five, were collected while Hrdlička led the division.

### The Eugenics Record Office

The staff of the Eugenics Record Office at Cold Spring Harbor, New York, collected family records from 1910 to 1939 and used them to argue that some people should not have children. Eugenics was the claim that a country should decide which of its people may have children, and stop the rest. The men who ran the office presented it as the science of heredity, the passing of traits from parents to children.

**Who paid for it.** The biologist Charles B. Davenport directed a research station at Cold Spring Harbor that belonged to the Carnegie Institution of Washington, a private group that paid for scientific research. In 1910 Davenport persuaded Mary Harriman, the widow of a railroad owner, to give $10,000. She bought an 80-acre farm next to the station and built an office on it. The Eugenics Record Office opened there in 1910, with Harry H. Laughlin in charge.

**Door to door.** Staff at the office ran summer courses that trained field workers, and photographs of the courses survive from 1913 to 1922. The field workers went door to door and filled out forms of questions about families. By 1924 the office's files held 750,000 index cards, along with family trees and reports.

Davenport, Laughlin and their workers traced traits through families, such as blindness and musical ability. They also traced what they called "feeblemindedness," their label for people they judged to be of low intelligence. They treated poverty and behavior as traits that parents pass to their children.

Laughlin used the office's records to push for laws to keep immigrants out and to sterilize people labeled "defective." To sterilize a person is to operate on the body so that the person can never have a child. In a woman, for example, a doctor cut out a piece of each of the two tubes that carry eggs to the womb. It cannot be undone.

**The critics.** Scientists who studied heredity, among them Thomas Hunt Morgan, Raymond Pearl and Herbert Jennings, pointed out flaws in eugenics research. They showed that the eugenicists' experiments were badly designed and that the eugenicists used the new science of genes too simply. They also showed that the work was racist and unfair to poor people. In 1935 leaders of the Carnegie Institution gathered a panel of scientists to judge the office's work, and the panel found that almost none of it had any scientific worth.

**Nazi Germany.** In the 1930s Americans learned what Nazi Germany's leaders were doing with eugenics. Under a German law of July 14, 1933, judges and doctors sat on special courts, each made up of a judge and two doctors. By 1945 the judges and doctors on these courts had forced about 400,000 people to be sterilized.

Doctors usually cut the tubes that carry sperm in men, and tied or cut the tubes that carry eggs to the womb in women. The forced operations killed hundreds of people, most of them women.

Vannevar Bush, the president of the Carnegie Institution, cut off the office's money in 1939, and it closed in December 1939. Its records went to the University of Minnesota in 1948. Staff at Cold Spring Harbor Laboratory now publish this history on the laboratory's archive website, under the heading "Good genes, bad science."

### Albert Einstein

> **Who:** A physicist who moved to America in 1933, the year the Nazis took control of Germany. He became a US citizen in 1940.
>
> **When and where:** Princeton, New Jersey, from October 1933.

**In 1946 Einstein called racism "a disease of white people."**

Albert Einstein arrived in the United States on October 17, 1933, the year the Nazis took control of Germany. He joined the new Institute for Advanced Study in Princeton, New Jersey, as one of its first professors.

He had done his most famous physics, the theory of relativity, in Europe between 1905 and 1915. Relativity explains how space, time and gravity are tied together.

**The letter.** On August 2, 1939, Einstein signed a letter to President Franklin Roosevelt. The physicist Leo Szilard wrote it, with Edward Teller and Eugene Wigner. The letter stated that Germany might build atomic bombs. Historians at the Atomic Heritage Foundation, a group that records the history of the bomb, trace the start of the Manhattan Project back to this letter.

Einstein became a citizen of the United States on October 1, 1940. He kept his Swiss citizenship.

**At Lincoln.** The leaders of Lincoln University, a Black university in Pennsylvania, gave Einstein an honorary degree in May 1946. An honorary degree is one a college gives to honor a person's life and work. At Lincoln he called racism "a disease of white people." He said, "I do not intend to be quiet about it."

### Emilio Segrè

> **Who:** An Italian physicist who lost his job at home in 1938 under Mussolini's laws against Jews, stayed at Berkeley, and won a Nobel Prize.
>
> **When and where:** Berkeley, California, from the summer of 1938.

**Italian officials took his job while he was visiting Berkeley.**

Emilio Segrè was visiting Ernest Lawrence's Radiation Laboratory at the University of California, Berkeley, in the summer of 1938. That year Benito Mussolini, who ruled Italy, put antisemitic racial laws, laws hostile to Jews, into force. Italian officials used those laws to take away Segrè's job as a professor in Palermo, Italy.

Segrè stayed in America. Lawrence gave him a job as a research assistant, at low pay.

Segrè later helped discover the elements technetium and astatine, and plutonium-239, one form of plutonium. With Owen Chamberlain he discovered the antiproton. A proton is a tiny particle with a positive electric charge, found in the center of every atom, and an antiproton matches it but has a negative charge. Segrè and Chamberlain shared the Nobel Prize in Physics in 1959.

**By 1939:** Einstein, Fermi and Segrè had come to American labs from Europe, the Eugenics Record Office had lost its money, and Einstein had signed a letter warning President Roosevelt that Germany might build atomic bombs.

### Splitting the atom, and the big laboratories

Two chemists in Berlin, Otto Hahn and Fritz Strassmann, discovered nuclear fission in December 1938. Fission is the splitting of the center of an atom, called the nucleus, into two pieces, and the split gives off energy. In January 1939 Lise Meitner and her nephew Otto Frisch explained what the chemists' results meant. Meitner was a Jewish refugee, a person who flees their home country to be safe, living in Sweden. In 1944 the Nobel judges gave the prize for the discovery to Hahn alone and left Meitner out.

**Chicago Pile-1.** News of fission reached America in January 1939. On December 2, 1942, Enrico Fermi's team of 49 people ran the first controlled nuclear chain reaction. In a chain reaction, each atom that splits sets off more atoms splitting. Controlled means the team could keep it steady and stop it. The team's reactor, a machine built to run a chain reaction, was called Chicago Pile-1.

The reactor stood under the west stands of Stagg Field, an unused football field at the University of Chicago. The reaction kept itself going for 28 minutes and made about half a watt of power.

Fermi was an Italian physicist. He won the Nobel Prize in 1938 and sailed straight from the ceremony in Stockholm to New York. His wife, Laura, was Jewish, and Mussolini had just put his new laws against Jews into force.

**The big labs.** Chicago Pile-1 belonged to the Manhattan Project. The project's leaders set up three large laboratories: the Metallurgical Laboratory in Chicago, Clinton Laboratories at Oak Ridge in Tennessee, and Los Alamos in New Mexico. They were the start of the national laboratories, the government's big science labs.

**Hiroshima and Nagasaki.** American bomber crews dropped the project's two atomic bombs on the Japanese cities of Hiroshima and Nagasaki in August 1945. Researchers at the Radiation Effects Research Foundation, a research group that Japan and the United States run together, estimate that within two to four months the bombs killed 90,000 to 166,000 people in Hiroshima and 60,000 to 80,000 in Nagasaki. The exact numbers are not known, and a US study in 1946 gave lower counts.

**The lab at Berkeley.** An older lab came before these, the Radiation Laboratory at the University of California, Berkeley. Ernest Lawrence built it around his cyclotrons, machines that speed tiny particles around in a circle and smash them into atoms. From 1931 the lab was housed in a converted campus building, and it became a separate laboratory on July 1, 1936. In 1939 Lawrence won the first Nobel Prize at Berkeley.

Glenn Seaborg, a chemist who found new elements with the Berkeley lab's cyclotrons, redrew the periodic table, the chart of all the chemical elements, before the war ended. He pulled a row of heavy elements out of the main table and set it as its own row at the bottom. That row is called the actinides. With his layout, chemists could predict how elements that nobody had made yet would behave.

After the war, American scientists built their labs on the Berkeley plan of big machines run by big teams.

### Plutonium injected into 18 patients

Doctors working for the Manhattan Project injected 18 hospital patients with plutonium between April 1945 and July 1947. Plutonium is a radioactive metal, one that gives off radiation, which is invisible energy that can damage or kill the cells of the body. Scientists made plutonium during the war and used it in atomic bombs.

Once plutonium is in the blood, it collects in the bones, the liver and the spleen, an organ that cleans the blood. There it keeps giving off radiation that kills cells. When a person breathes it in, it scars the lungs and can cause cancer.

**Why they did it.** The doctors wanted to know where plutonium goes in a human body and how fast the body gets rid of it in urine. Workers on the bomb could take some in by accident, and the doctors wanted a way to judge how much a worker had taken in. Four men led the program: Wright Langham of Los Alamos, Joseph Hamilton of the University of California in San Francisco and Berkeley, Hymer Friedell of Oak Ridge, and Stafford Warren, the head of the project's medical section.

The doctors injected one patient at Oak Ridge, three in Chicago, 11 in Rochester, New York, and three at the University of California hospital in San Francisco. Doctors in the program also injected six people with uranium, five with polonium and at least one with americium, all of them radioactive metals. In all they injected about 30 civilians, people who were not in the armed forces.

**Ebb Cade.** Cade, a 53-year-old Black cement mixer, was hurt in a car accident at Oak Ridge on March 24, 1945. On April 10, 1945, a doctor injected him with 4.7 micrograms, or millionths of a gram, of plutonium.

The doctors later blamed each other for the injection. Dr. Joseph Howland, an Army doctor, said he gave it only after his boss, Hymer Friedell, ordered him to in writing, and that Cade never gave his consent. Friedell said he gave no such order and that another doctor, Dwight Clark, gave the injection. A federal committee set up in 1994 to look into these experiments could not tell which account was right.

Doctors did not set Cade's broken arm and leg until April 15, five days after the injection, when they also took samples of his bone. Someone pulled out 15 of his teeth, and they were tested for plutonium. The committee's report does not name who pulled them. Its members could not find out whether the teeth were pulled mainly because they were decayed or for the test. Cade died of heart failure on April 13, 1953.

**Albert Stevens.** Doctors at the San Francisco hospital told Stevens, a 58-year-old house painter, that he had stomach cancer that would kill him. They injected him with plutonium on May 14, 1945, as part of Joseph Hamilton's program. The federal committee's report does not identify the doctor who gave the injection. When surgeons operated, they found a harmless ulcer, a sore in the stomach, and no cancer.

The doctors told Stevens only about "a new substance." Members of the federal committee later found that he was almost certainly never told it was plutonium. He died of heart failure in 1966, 21 years later.

**Simeon Shaw.** One patient came from Australia. In April 1946 officials of the Red Cross and the US Army arranged for Simeon Shaw, a 4-year-old boy with bone cancer, and his mother to fly on an Army plane to San Francisco. Within days, doctors at the university hospital injected him with a liquid that held plutonium and two other metals, yttrium and cerium, under Joseph Hamilton's direction.

His medical file holds a consent form for an operation. A witness signed it a week after the injection, stating that his mother agreed. The committee found that the form probably covered a bone test done that week, not the injection itself. Surgeons cut out a piece of his bone tumor to see how much of the metals it had taken up. He went home to Australia about a month after the injection, and nobody followed up on him. He died in January 1947.

**Eda Schultz Charlton.** Charlton, 49, entered Strong Memorial Hospital in Rochester on November 2, 1945. Three weeks later doctors in the hospital's research ward, run by Dr. Samuel Bassett, injected her with 4.9 micrograms of plutonium. No doctor had ever found that she was dying of any illness. She lived until 1983.

**Elmer Allen.** Allen was a Black railroad porter from Italy, Texas, a worker who carried passengers' bags on the trains. He was 36, and his doctors believed he had bone cancer. On July 18, 1947, doctors at the University of California hospital injected him with plutonium. The researchers never expected the injection to help him. Soon afterward, a surgeon cut off his left leg at the middle of the thigh. A test of his tumor showed a slow-growing bone cancer called chondrosarcoma.

Two doctors signed a note saying the experiment had been explained to him and that he agreed. The committee's members found it unclear whether he was told the injection was not meant to help him. According to later newspaper reporting, he died in 1991 without ever learning what had been done to him. In 1995 his daughter, Elmerine Whitfield Bell, told the committee: "We contend that my father was not an informed participant in the plutonium experiment."

### Trinity and the people downwind

Manhattan Project scientists exploded the first atomic bomb at a test site called Trinity, in New Mexico, on July 16, 1945. The project's leaders decided not to move the people who lived nearby. According to the National Park Service, they worried that moving people would make them suspicious or cause panic. The nearest ranchers lived 13 miles from the site, and tens of thousands of people lived within 50 miles.

**Secrecy first.** General Leslie Groves, the Army officer in charge of the project, wanted the test kept secret above all. Under his rules, nobody was to be protected unless people had already been badly hurt. When the project doctor James Nolan brought him safety plans, Groves asked him, "What's the matter with you, are you a Hearst propagandist?" William Randolph Hearst owned a chain of newspapers known for stories written to shock and excite readers, and a propagandist spreads one side's story.

The scientists Joseph Hirschfelder and John Magee warned of "the definite danger of dust containing active material." Robert Oppenheimer, the director of the Los Alamos lab, approved a plan to move people only after they had taken in 60 to 100 roentgens of radiation. A roentgen is a unit for measuring radiation. Nobody was moved.

**The fallout.** Fallout is radioactive dust that falls back to the ground after a nuclear explosion. The fallout from Trinity spread over an area about 250 miles long and 200 miles wide. It fell heaviest on Chupadera Mesa, a flat-topped highland 30 miles away, and it fell across Lincoln, Socorro, Otero and Sierra counties. People there ate vegetables and drank water that had fallout in them.

The Ratliff family, who lived near a place called Hot Canyon, took in about 47 roentgens in two weeks. The allowed amount was 1.4, so they took in more than 30 times the limit. Nobody warned them.

After the test, Groves put out a statement to the press. It said that an ammunition dump had exploded and that nobody had been hurt.

Stafford Warren, the project's chief medical officer, reported to Groves in writing on July 21, 1945. He wrote that the dust "was potentially a very serious hazard over a band almost 30 miles wide extending almost 90 miles northeast of the site." He advised that future tests take place in an area "with a radius of at least 150 miles without population," meaning with nobody living within 150 miles.

**Not known:** how many people the Trinity fallout made sick or killed, because no government official ever counted them. The National Park Service states that the exposure is "linked to cancer, stillbirth, and birth defects." A stillbirth is a baby born dead, and a birth defect is a problem in a baby's body that begins before it is born.

### The physics inside the transistor, 1947

Chapter 8 tells how John Bardeen and Walter Brattain built the first transistor, a small solid part that can make an electrical signal stronger, at Bell Labs, the research laboratory of the telephone company AT&T, on December 16, 1947. The physics that led to it started with a design that failed.

William Shockley, the head of their group, designed an amplifier, a device to make a signal stronger, out of a solid crystal in April 1945. It did not work. A year later Bardeen suggested a reason: electrons sitting on the surface of the crystal might be blocking the electric push from outside, so that it could not reach into the crystal.

Bardeen and Brattain set out to study those surface electrons, and that work led them to the transistor. Bardeen explained how the electrons behave at the surface using quantum mechanics, the branch of physics that describes very tiny particles. Shockley then designed a second kind, the junction transistor, and the three men shared the Nobel Prize in Physics in 1956.

### Barbara McClintock

> **Who:** A scientist who studied the chromosomes of corn and discovered that genes can move from one place to another.
>
> **When and where:** Cold Spring Harbor, New York. Her key experiments began in 1944.

**In corn, she found genes that move from place to place.**

Barbara McClintock discovered that some genes move from one place to another on the chromosomes, which is called transposition. She found it in maize, which is corn, in experiments she began in 1944. She called the moving pieces "controlling elements."

McClintock earned a PhD at Cornell University in 1927 and studied the chromosomes of corn under the microscope. She came to Cold Spring Harbor in 1941 or 1942. The Eugenics Record Office there had closed in December 1939.

She first described the moving genes in 1948. In 1950 she published a paper about mutable loci, places on a chromosome that can change, called *The Origin and Behavior of Mutable Loci in Maize*. She presented the work at a meeting of scientists at Cold Spring Harbor in 1951.

**Slow to catch on.** Other scientists respected her as an expert on chromosomes, but for decades few of them took up her idea of moving genes. In the 1960s and 1970s, molecular biologists, who study the molecules inside cells, reached the same finding.

**If you remember one thing:** Between 1900 and 1950 American scientists learned to measure the universe and to split atoms, and doctors working on the bomb injected 18 hospital patients with plutonium to see where it went in their bodies.

- In 1900: Volunteers counted birds on Christmas Day, and nobody had yet measured the distance to another galaxy.
- In 1950: Astronomers had measured the distance to Andromeda and found the galaxies moving apart, and the government ran big national laboratories that began with the atomic bomb.

**Next:** After 1950, a doctor cut cells from a woman's tumor without asking her, and a reporter and the families brought the hidden radiation experiments into the open.

## 1950 to 2000

**Era 9 of 10 · 1950 to 2000 · about 18 minutes**

A doctor cut cells from Henrietta Lacks's tumor in 1951 without asking her, and for the rest of the century Americans kept learning what scientists had done to people who never agreed. The reporter Eileen Welsome made the plutonium injections public in 1993. Members of a federal committee then found nearly 4,000 radiation experiments on people, and in 1995 President Bill Clinton apologized. Under laws passed in 1989 and 1990, museum staff had to begin returning the Native American dead that scientists had collected.

In the same fifty years, James Watson and Francis Crick worked out the shape of DNA from Rosalind Franklin's X-ray pictures. By about 1970 most geologists, the scientists who study the Earth's rocks, agreed that the continents move. Charles David Keeling's measurements on Mauna Loa showed the carbon dioxide in the air rising every year.

### Henrietta Lacks and the HeLa cells

A doctor at Johns Hopkins Hospital cut cells from the tumor of Henrietta Lacks in 1951 without her knowledge or consent. Nobody told her, and nobody asked her permission. Her cells became the first human cells that kept living and dividing in a lab with no end.

Henrietta Lacks was a Black woman, born on August 1, 1920. She and her husband moved to Baltimore, Maryland, in 1941, and they had five young children. In 1951 she went to Johns Hopkins Hospital because she was bleeding from her vagina.

Dr. Howard Jones was a gynecologist, a doctor who treats the parts of a woman's body that carry and deliver babies. He found a malignant, or cancerous, tumor on her cervix, the narrow lower end of the womb. Doctors treated her cancer with radium, a radioactive metal, which was the usual treatment at the time.

**The cells.** During the treatment she was asleep under anesthesia, a medicine that puts a patient into a deep sleep so they feel no pain. While she was asleep, Dr. Lawrence Wharton Jr. cut samples from her tumor and from healthy tissue of her cervix. They went to the laboratory of George Gey, a cell biologist at Johns Hopkins.

Most human cells died in a lab dish. Hers kept dividing, about once every 20 to 24 hours. Scientists named the cells HeLa, from the first two letters of her first and last names. Henrietta Lacks died at Johns Hopkins on October 4, 1951. She was 31.

Scientists used HeLa cells to study the polio vaccine, the shot that protects people from polio, and leukemia, a cancer of the blood. They also used them to study the AIDS virus, cancer, and the effects of zero gravity in space. Her family did not learn that her cells were being used in research until the 1970s.

### The shape of DNA, and who got the credit

James Watson and Francis Crick worked out the shape of DNA in 1953, using Rosalind Franklin's X-ray pictures without her knowledge. DNA is the molecule inside cells that carries genes, and a molecule is a group of atoms joined together. Watson was a 24-year-old American, and Crick was British. They worked at Cambridge University in England. At Caltech in California, Linus Pauling and his team were racing for the same answer.

Watson and Crick published the structure in the journal *Nature* on April 25, 1953. DNA is a double helix: two long strands wound around each other in a spiral.

**Franklin's picture.** They depended on the work of Rosalind Franklin at King's College London. Franklin took pictures of DNA with X-rays, a kind of invisible light that passes through many things. In early 1953 Maurice Wilkins, who worked at King's College, showed Watson her picture called "Photo 51." He did it without her knowledge. Accounts differ on whether this was in late January or in February.

**What the picture showed.** Photo 51 showed a pattern shaped like an X. To Franklin, the X meant that the strands of DNA wind in a helix, a spiral. When Watson saw the picture, he concluded the same thing, and he also took from it measurements of the molecule. He and Crick relied on Photo 51 to work out their model of DNA's shape.

Her data reached Watson and Crick a second way, in a report for the Medical Research Council, a British government group that paid for research. Max Perutz passed it to them. Franklin's own paper came out in the same issue of *Nature*. She died in 1958, at 37. In 1962 the Nobel Prize went to Watson, Crick and Wilkins. Nobel rules do not allow a prize to go to a person who has died.

**What Watson said.** Watson later became the chancellor, one of the top leaders, of Cold Spring Harbor Laboratory in New York, the place where the Eugenics Record Office had run from 1910 to 1939. While he held that post, he made racist statements about the intelligence of people in Africa.

The *Sunday Times Magazine* of London quoted him in 2007. He said he was "inherently gloomy about the prospect of Africa" because "all our social policies are based on the fact that their intelligence is the same as ours." In the same sentence he went on: "where all the testing says not really."

The laboratory's trustees, the people who govern it, acted at once in 2007. They removed him from all his management jobs there and ended his post as chancellor.

In a PBS film shown on January 2, 2019, *American Masters: Decoding Watson*, he was asked whether his views had changed. He said, "No, not at all." On January 11, 2019, the laboratory's leaders called his views "unsubstantiated (not backed by proof) and reckless" and "reprehensible (deserving strong blame), unsupported by science." They took away his honorary titles.

### How did geologists learn that the continents move?

Maps of the ocean floor recorded the evidence, and by about 1970 most geologists agreed that the continents move. The idea is called plate tectonics. The Earth's outer shell is broken into huge pieces, called plates, that slowly shift.

Marie Tharp and Bruce Heezen published a map of the floor of the Atlantic Ocean, the *Physiographic Diagram of the Atlantic Ocean*, in 1957. Harry Hess published a paper called "History of Ocean Basins" in 1962. In it he proposed seafloor spreading, the idea that new ocean floor forms along the undersea mountain ranges and spreads outward. Tharp and Heezen published a painted map of the ocean floor of the whole world in 1977.

### Marie Tharp

> **Who:** A geologist and mapmaker who mapped the ocean floor and found the rift valley along the Mid-Atlantic Ridge. Women were kept off the research ships, so she drew her maps on land.
>
> **When and where:** Lamont Geological Observatory, Columbia University, from 1948.

**Her work partner first called her discovery "girl talk."**

Marie Tharp found a valley running down the middle of the Mid-Atlantic Ridge, a long chain of mountains under the Atlantic Ocean, in 1952 and 1953. It was a rift valley, a valley that forms where the Earth's crust, its rocky outer layer, is pulling apart. Her work partner, Bruce Heezen, at first dismissed her finding as "girl talk."

**Drawn on land.** Tharp began work at Columbia University's Lamont Geological Observatory in 1948. According to Smithsonian Magazine, Navy rules kept her off the research ships that Maurice Ewing and her other colleagues hired. She first sailed on one in 1968.

She made her maps from soundings, measurements of how deep the water is, taken on the ships. Tharp turned the depth numbers into drawings of the shape of the sea floor. The rift valley she found became part of the evidence that the sea floor spreads apart. Staff at the Library of Congress later named her one of the great mapmakers of the 20th century.

### Measuring the air on Mauna Loa

Charles David Keeling of the Scripps Institution of Oceanography began measuring the carbon dioxide in the air on Mauna Loa, a volcano in Hawaii, in March 1958. Carbon dioxide is one of the gases in the air. It is a greenhouse gas, a gas that takes in heat and gives it off again. The amount in the air is rising mostly because people burn coal, oil and other fossil fuels for energy.

**The Keeling Curve.** His first reading was 313 parts per million, meaning 313 molecules of carbon dioxide in every million molecules of air. The average in the early part of that year was about 315. The measurements have run without a break since 1958, and the line they make on a graph is called the Keeling Curve. It rises in a saw-tooth pattern, with small ups and downs inside a steady climb.

The curve had passed 430 parts per million by 2026, more than a third above Keeling's first reading. Climate scientists use the Keeling Curve as the base measurement for their work.

### What was the hiss in the Bell Labs antenna?

The hiss was the leftover glow of the Big Bang, the hot beginning of the universe. Arno Penzias and Robert Wilson picked it up in 1964 and 1965 at Bell Labs, the research laboratory of the telephone company AT&T, in Holmdel, New Jersey, with a large antenna shaped like a horn. An antenna is a device that picks up radio waves.

The hiss was made of microwaves, a kind of radio wave, and they could not get rid of it. They even cleared out pigeons that had nested in the antenna, along with their droppings.

Physicists at Princeton identified the hiss as the cosmic microwave background, the cooled light left over from the early universe. Penzias and Wilson won the Nobel Prize in 1978.

### Darleane Hoffman

> **Who:** A nuclear chemist who found plutonium in nature and whose group did chemistry on single atoms of the heaviest elements.
>
> **When and where:** Los Alamos, New Mexico, and from 1984 Berkeley, California. She reported the plutonium find in 1971.

**She found plutonium in rock from a California mine.**

Darleane Hoffman showed in 1971 that plutonium-244, one form of plutonium, occurs in nature. Scientists had believed that all plutonium was made by people. Hoffman was a leader of a chemistry division at Los Alamos National Laboratory, and she found tiny traces of plutonium-244 in rock from the Mountain Pass mine in California.

**One atom at a time.** In 1984 she moved to Lawrence Berkeley National Laboratory and the University of California, Berkeley. Her group did chemistry on single atoms of the heaviest elements. The periodic table arranges the elements in patterns, and elements in the same column behave alike. Her group tested those patterns one atom at a time, to find where the heaviest elements stop following them. She died in 2025, at 98.

**By 1970:** Scientists knew the shape of DNA, most geologists agreed that the continents move, and the Keeling Curve had been climbing on Mauna Loa for twelve years. The first Apollo crew had landed on the Moon in 1969.

### What the Moon rocks and the space probes taught

Six Apollo crews landed on the Moon between 1969 and 1972. They brought back 382 kilograms, or 842 pounds, of Moon rock and soil, in 2,200 samples. Scientists at NASA's Johnson Space Center, part of the government's space agency, keep the samples and are still opening and studying them. Scientists used the rocks to work out the history of the Moon and the ages of surfaces across the solar system.

**The Viking tests.** Viking 1 and Viking 2 became the first spacecraft to land on Mars and work there, in 1976. Each carried tests for life in the Martian soil, and the results did not agree. One test, called Labeled Release, gave a result that looked like life. Another found no organic matter, the carbon-based material that living things are made of.

**Disputed:** Most scientists now think chemicals in the soil called perchlorates caused the Labeled Release result. Gilbert Levin, who led that test, argued to the end of his life that it had found life. Nobody has settled the question.

**The Voyagers.** The two Voyager probes were launched in 1977. Their pictures showed volcanoes on Io, a moon of Jupiter, and a cracked shell of ice on Europa, another moon of Jupiter. Other pictures showed the thick air around Titan, a moon of Saturn. The Voyager flights reached Uranus in 1986 and Neptune in 1989. Both probes are now in interstellar space, the space between the stars.

**Cosmos.** Carl Sagan's television series *Cosmos* began on PBS, the public television network, in the fall of 1980. In 2020 Charles Apple of *The Spokesman-Review*, a newspaper in Washington state, wrote that it was the most-watched PBS series until Ken Burns's *The Civil War* in 1990. The news site Space Daily reported that about 500 million people around the world have seen it.

### Linda Morabito

> **Who:** A navigation engineer at NASA's Jet Propulsion Laboratory who found the first active volcano ever seen beyond Earth.
>
> **When and where:** Jet Propulsion Laboratory, Pasadena, California, on March 9, 1979.
>
> **Movie:** *The Farthest* (2017), a documentary about the Voyager missions, in which Morabito tells the story of her discovery.

**A faint cloud at the edge of Io was an erupting volcano.**

Linda Morabito found the first active volcano ever seen beyond Earth on March 9, 1979. It was on Io, a moon of Jupiter. An active volcano is one that is erupting, throwing out gas and melted rock.

Morabito was a navigation engineer for the Voyager 1 probe, a person who works out where a spacecraft is and where it is heading. She was processing a routine navigation picture of Io when she noticed a faint plume, a cloud shooting up from the surface, at the edge of the moon. It was 270 kilometers high, about 170 miles. The plume came from an erupting volcano. Morabito later wrote her own history of the discovery.

### Richard Feynman

> **Who:** A physicist who rebuilt the theory of light and matter, drew the diagrams that physicists still use, and explained hard ideas simply.
>
> **When and where:** Los Alamos during World War II. Later Caltech, in Pasadena, California. He died in 1988.
>
> **Movie:** *The Fantastic Mr Feynman* (2013), a BBC documentary with interviews with Feynman, his family and his colleagues.

**He dropped a piece of rubber into ice water on television.**

Richard Feynman sat on the commission, a group of experts, that looked into why the space shuttle Challenger broke apart in 1986. On February 11, 1986, at a hearing shown on television, he dropped a piece of O-ring rubber into ice water. An O-ring is a rubber ring that seals a joint. The cold rubber lost its spring. In about one minute he showed how launching in cold weather had caused the failure.

**Challenger.** The shuttle broke apart soon after launch, and all seven people aboard died. Hot gas had leaked through a joint in one of its booster rockets. The air at launch was 36 degrees Fahrenheit, 15 degrees colder than at any earlier shuttle launch. The seven who died were Francis R. Scobee, Michael J. Smith, Ellison S. Onizuka, Judith A. Resnik, Ronald E. McNair, Christa McAuliffe and Gregory B. Jarvis.

**The physicist.** Feynman shared the Nobel Prize in Physics in 1965 for his work on how light and electrically charged matter act on each other. Physicists everywhere still use the simple drawings he invented to show how particles act on each other, called Feynman diagrams. During World War II he worked at Los Alamos. Later he became known for explaining hard ideas plainly, in his lectures at Caltech and in his 1985 book *Surely You're Joking*. He died in 1988.

### The national labs, a late Nobel and the genome

During the Cold War, the long rivalry between the United States and the Soviet Union after World War II, government money paid for big machines and big teams at the national laboratories. The main labs were Lawrence Berkeley, Lawrence Livermore, Argonne, Los Alamos and Oak Ridge. Scientists at these labs and in the Soviet Union raced each other to make new elements.

**Inside the proton.** Murray Gell-Mann proposed in 1964 that protons and neutrons, the particles in the center of every atom, are built from smaller particles, which he named quarks. For years nobody could find a quark.

A team from MIT and SLAC, a laboratory in California with a machine two miles long that speeds up electrons, found the first signs of quarks in 1968. They fired electrons at protons and found hard little pieces inside them. Gell-Mann won the Nobel Prize in 1969, and three leaders of the team shared one in 1990.

**A late Nobel.** Barbara McClintock, who had found genes that move in corn, won the Nobel Prize in Physiology or Medicine in October 1983. The prize came 39 years after she began the experiments, and she was the first woman to win that prize without sharing it.

**The genome.** Officials of the National Institutes of Health and the Department of Energy launched the Human Genome Project on October 1, 1990. A genome is the complete set of DNA in a living thing. The project's goal was to read all the DNA in a human genome, in order. Its planners gave it 15 years and about $3 billion.

### Two laws to return the dead

Under two laws passed in 1989 and 1990, museum staff had to begin returning the Native American dead they held. Scientists had collected many of those remains, among them the skulls Army doctors sent to Washington from 1868 and the remains of about 1,000 people that Aleš Hrdlička's team dug out of burial grounds in Alaska in the 1930s. Native nations campaigned for both laws.

The National Museum of the American Indian Act became law on November 28, 1989. It requires Smithsonian staff to list the Native human remains the Smithsonian holds and to return them when asked.

The Native American Graves Protection and Repatriation Act became law on November 16, 1990. People call it NAGPRA, and repatriation means sending something back to where it came from. Under NAGPRA, staff at museums and government agencies that take federal money must list the Native American human remains and sacred objects they hold. They must return them to descendants and to Native nations.

### The radiation experiments made public

The reporter Eileen Welsome made the plutonium injections public in November 1993. Her three-part series in the *Albuquerque Tribune*, called "The Plutonium Experiment," began on November 15, 1993, and it named the patients who had been injected. She won the Pulitzer Prize for National Reporting, a top award for American journalism, in 1994.

Energy Secretary Hazel O'Leary opened her department's records in 1993. President Bill Clinton set up the Advisory Committee on Human Radiation Experiments on January 15, 1994, to investigate.

**What the committee found.** The committee's members reported in 1995. They found "nearly 4,000 human radiation experiments sponsored by the federal government between 1944 and 1974." They also found "several hundred intentional releases of radiation into the environment for research purposes," meaning radiation let out into the air, land or water on purpose.

They found "little evidence of rules or practices of consent except in research with healthy subjects." In the 1940s and 1950s it was routine for doctors to use patients in research without the patients knowing. About the plutonium injections, the committee's members wrote: "In no case was there any expectation that these patient-subjects would benefit medically from the injections."

**The Fernald School.** Some of these experiments were done on children. The Fernald School was a state school in Massachusetts for children with disabilities, and researchers from MIT worked there with the school's senior staff. In 1946 they gave radioactive iron to 17 boys who lived at the school. From 1950 to 1953 they gave radioactive calcium to 57 boys, in a special breakfast.

The boys belonged to the school's "science club," whose members got extra milk and trips. One MIT researcher, Robert S. Harris, wrote that three boys who objected could be "induced to change their minds." A 1949 letter from the school's head to parents described a special diet and blood tests and did not mention radiation.

Doctors at Massachusetts General Hospital in Boston injected 11 patients with uranium from 1953 to 1957.

**The prisons.** Two doctors aimed X-rays at the testicles of 131 prisoners in Oregon and Washington from 1963 to 1973. The testicles are the organs that make sperm. The doctors wanted to learn how radiation affects the making of sperm, and the men could get no health benefit from it. Carl Heller did this to 67 men at the Oregon State Prison, and his former student C. Alvin Paulsen ran the study in Washington.

The men had to agree to a vasectomy at the end, an operation that cuts the tubes that carry sperm so a man can no longer father children. In Heller's study most men also had small pieces cut out of their testicles for testing five or more times, and were paid $25 each time.

**Vanderbilt.** Researchers at Vanderbilt University and the Tennessee state health department studied nutrition in pregnancy from 1946 to 1949. The women were poor patients at a clinic for pregnant women. Paul Hahn led the part of the study in which researchers gave about 819 of them a drink with a dose of radioactive iron at their second visit to the clinic.

Emma Craft and other women from the study sued Vanderbilt in federal court in 1994. They said the researchers called the drink a "cocktail" or a "vitamin drink" and never told them it was radioactive, and that no one gave them a chance to say no. The women had been pregnant when they drank it, and the children they had been carrying joined them in the lawsuit.

The women also said that Vanderbilt researchers ran a follow-up study in the 1960s and found "a disproportionately high incidence of cancer" in the children, meaning more cancer than expected. They said nobody told them they had been exposed or what the study found. Vanderbilt officials denied doing wrong. University officials settled the case in 1998 by paying the women $10 million.

**The apology.** At the White House on October 3, 1995, Clinton said that the United States "offers a sincere apology to those of our citizens who were subjected to these experiments, to their families, and to their communities."

O'Leary announced in November 1996 that the families of 12 people injected in the 1940s would get $4.8 million in all. Eleven had been injected with plutonium and one with uranium, and each family was to receive $400,000. Eleven of the 12 had died. One woman was still alive, living in upstate New York.

**If you remember one thing:** Between 1950 and 2000 Americans learned how DNA is built and that the continents move, and a reporter, the families and Native nations brought the hidden experiments and the collected dead into the open.

**One number:** Members of the federal committee counted nearly 4,000 radiation experiments on people paid for by the government from 1944 to 1974. That is about one new experiment every three days for thirty years.

**Next:** After 2000, scientists finished reading the human genome, and the Lacks family, Native nations and the Trinity downwinders won agreements, apologies and payments.

## 2000 to Today

**Era 10 of 10 · 2000 to Today · about 10 minutes**

The biggest experiments after 2000 had thousands of scientists on them. About 3,000 people worked on ATLAS, one of the two experiments that found the Higgs boson in 2012. Scientists finished reading nearly all of the human genome in 2003 and read all of it in 2022, and they detected gravitational waves for the first time in 2015.

Some of the people who were used for science, and their families, have won apologies, rules and payments. The Lacks family reached an agreement in 2013 on how scientists may use the genome of Henrietta Lacks's cells. The head of the Smithsonian apologized in 2023 for how people collecting for it had taken human remains, many of them dug from graves and most taken without consent. People who lived downwind of the Trinity test became able to claim federal payments in July 2025.

### The genome, finished twice

Scientists announced a working draft of the human genome in June 2000. The International Human Genome Sequencing Consortium, the teams of scientists doing the work, announced in April 2003 that the genome was essentially complete. They had read about 92 percent of it, with fewer than 400 gaps left. They timed the announcement to the 50th anniversary of the 1953 paper on the shape of DNA.

Another group of scientists, the Telomere-to-Telomere consortium, published the first complete human genome with no gaps on March 31, 2022.

**The cost.** The National Human Genome Research Institute, the government's genome research agency, has published what the work cost. Reading one person's genome to a high-quality draft cost about $14 million in 2006. By late 2015 it cost less than $1,500.

James Watson, who with Francis Crick had worked out the shape of DNA in 1953, died in November 2025, at 97.

### The Higgs boson, and the collider that members of Congress cancelled

Scientists at CERN, the European physics laboratory in Geneva, Switzerland, announced on July 4, 2012, that they had found the Higgs boson. The Higgs boson is a particle tied to how other particles get their mass, the amount of matter in an object. Two experiments found it, called ATLAS and CMS. Both used the Large Hadron Collider, a machine that smashes tiny particles together at very high speed.

According to the US Department of Energy, about 1,700 American scientists worked on these experiments through two American labs, Fermilab and Brookhaven.

**The American collider.** American physicists had begun building a collider of their own, the Superconducting Super Collider, near Waxahachie, Texas. It was planned as a ring 54 miles around. Members of Congress cancelled it in October 1993, after $2 billion had been spent and more than 14 miles of tunnel had been dug. The Large Hadron Collider, the machine the Higgs experiments used, was built in Europe instead.

### Monica Dunford

> **Who:** An American physicist who worked on the ATLAS experiment at CERN. She was one of six physicists a film crew followed through the search for the Higgs boson.
>
> **When and where:** CERN, in Geneva, Switzerland, up to the Higgs announcement on July 4, 2012.
>
> **Movie:** *Particle Fever* (2013), a documentary directed by Mark Levinson and produced by the physicist David Kaplan. It follows six physicists, Dunford among them, from the start-up of the Large Hadron Collider to the announcement of the Higgs boson on July 4, 2012.

**She was one of about 3,000 people on a single experiment.**

Monica Dunford is an American experimental physicist, a scientist who runs experiments and measurements. At the time of the Higgs search she was a postdoc on the ATLAS experiment at CERN, doing research for a few years after her PhD before taking a permanent job. About 3,000 people worked on ATLAS.

**First beam.** Dunford tested electronics for the ATLAS detector and crawled under the floor to lay cable, as she later told the story. She was in the ATLAS control room on the day the collider first sent a beam of particles into the detector. "When beam arrived at the detector there were no lights," she said. Physicists hunched over their computers, looking for the beam's data, until someone found it and put it up on a monitor at the front of the room.

### Jennifer Doudna

> **Who:** A biochemist at the University of California, Berkeley, who with Emmanuelle Charpentier made CRISPR-Cas9 into a tool for cutting DNA at a chosen spot.
>
> **When and where:** UC Berkeley. The key paper came out on June 28, 2012.
>
> **Movie:** *Human Nature* (2019), a documentary about CRISPR, in which Doudna is one of the main people interviewed.

**She and Charpentier made a tool that cuts DNA where scientists choose.**

Jennifer Doudna and Emmanuelle Charpentier published a paper about CRISPR-Cas9 in the journal *Science* on June 28, 2012. CRISPR-Cas9 is a tool that scientists can program to cut DNA at a spot they choose. Cutting DNA at a chosen spot lets scientists change genes.

Doudna is a biochemist, a scientist who studies the chemistry inside living things, at the University of California, Berkeley. She and Charpentier won the Nobel Prize in Chemistry in 2020. It was the first science Nobel Prize shared by two women with nobody else.

### Rainer Weiss

> **Who:** An MIT physicist, who came to America as a child refugee from Nazi Germany, and who worked out the idea for the detectors that first picked up gravitational waves.
>
> **When and where:** MIT, and the LIGO detectors at Hanford, Washington, and Livingston, Louisiana. The detection came on September 14, 2015.

**His idea from 1972 caught the ripples from two black holes crashing.**

The two LIGO detectors picked up gravitational waves for the first time on September 14, 2015. Gravitational waves are ripples in space and time. These came from two black holes that crashed into each other 1.3 billion light-years away. A black hole is a place in space where gravity is so strong that not even light can get out. Rainer Weiss had worked out the idea for the detectors in 1972.

**A child refugee.** Weiss was born in Berlin in 1932. His family fled the Nazis through Prague and reached New York in January 1939. He became a professor at MIT, the Massachusetts Institute of Technology.

His kind of detector is called a laser interferometer. It uses laser beams to measure very small changes in distance. The LIGO detectors were paid for by the National Science Foundation, the government agency that pays for science research. LIGO scientists announced the discovery on February 11, 2016, a century after Einstein predicted the waves. Weiss shared the Nobel Prize in Physics with Barry Barish and Kip Thorne in 2017.

### The Webb telescope

The James Webb Space Telescope was launched on December 25, 2021. NASA staff released the telescope's first science images on July 11 and 12, 2022. Scientists using the telescope have found galaxies from the first few hundred million years of the universe, earlier than any galaxies found before.

Scientists using the telescope made the first clear detection, in 2022, of carbon dioxide in the air of an exoplanet, a planet that circles a star other than our Sun. The planet is called WASP-39b.

### Computers that predict the shapes of proteins

Scientists at DeepMind, a British lab, showed in 2020 that their program AlphaFold2 could predict the shape of a protein well enough for practical use. A protein is a molecule that does work inside living cells, and its shape sets what it can do. AlphaFold2 is an example of artificial intelligence, or AI, computer software that learns patterns from huge amounts of data.

According to the European Molecular Biology Laboratory, free public databases held more than 200 million predicted protein shapes by 2026. Staff at the science journal *Nature* surveyed more than 1,600 researchers around the world in 2023. Reporting the results, Richard Van Noorden and Jeffrey Perkel wrote that AI tools were becoming more common in science. Many of the researchers expected AI tools to become a central part of their work soon.

The 2024 Nobel Prize in Chemistry was split in two. Half went to David Baker, an American at the University of Washington, for using computers to design new proteins. The other half went to Demis Hassabis and John Jumper of DeepMind in Britain.

### Heavy elements, made by many countries

Scientists from several countries now work together to make the heaviest elements. Teams from Dubna in Russia and from Lawrence Livermore and Oak Ridge in the United States have worked on the same experiments. Scientists on joint panels of two international science groups, IUPAC and IUPAP, judge who made each new element.

**The seventh row.** IUPAC officials announced on December 30, 2015, that they recognized four new elements, numbers 113, 115, 117 and 118. With those four, the seventh row of the periodic table was full. A team from Dubna and Livermore got the credit for three of them. One of those, tennessine, was named for Tennessee, the home of the Oak Ridge lab, whose scientists shared the credit for it.

Scientists at Berkeley made livermorium, element 116, in 2024 by firing a beam of titanium at a target. With that result, the Berkeley team prepared to try for element 120. The physicists are looking for what they call the "island of stability," a group of superheavy elements that they predict would last longer before breaking apart.

### The Lacks family and the HeLa genome

European researchers published the genome of the HeLa cells in March 2013 without the consent of Henrietta Lacks's family. Francis Collins, the director of the National Institutes of Health, met with members of the Lacks family three times between April and July 2013.

**The agreement.** NIH officials announced the NIH-Lacks Family Agreement on August 7, 2013. Under it, scientists must apply to NIH to use the full genome data of HeLa cells. A working group that includes members of the Lacks family reviews the requests.

**The lawsuit.** The Lacks estate, the property Henrietta Lacks left behind, managed for her heirs, sued Thermo Fisher Scientific in 2021. The company sold about a dozen products made with HeLa cells. The lawyers Ben Crump and Chris Seeger represented the estate. The lawsuit stated that the company "made staggering profits by using the HeLa cell line." It added that this happened "all while Ms. Lacks' Estate and family haven't seen a dime."

According to news reports in STAT and Smithsonian Magazine, the two sides announced a settlement on August 1, 2023. That day would have been Henrietta Lacks's 103rd birthday. They kept the terms of the settlement secret.

### Apologies, and the dead still held

Lonnie G. Bunch III, the Secretary, or head, of the Smithsonian, apologized in August 2023 for how people collecting for the Smithsonian had taken many of its human remains. He spoke after the Washington Post published its investigation of Aleš Hrdlička's collecting. The Penn Museum's director had apologized for the Morton skulls two years earlier.

**Still held.** Reporters at ProPublica, a news organization, counted the Native American remains still held, using federal NAGPRA reports. As of January 6, 2025, staff at about 650 museums, universities and agencies had reported holding more than 210,000 Native American remains. They had not yet made 90,831 of them, or 42 percent, available for return. That is more than two of every five.

The Ohio History Connection had the most remains not yet made available for return, about 8,000. The Illinois State Museum had about 5,800 and Harvard University about 5,400. The Smithsonian is not on that list, because it reports under the 1989 law instead of NAGPRA.

A second count, made in September 2024 and reported by Retrospect Journal, agrees closely. It found that 126,299 of 216,804 remains had been returned, which leaves about 90,500 not returned.

**The 2024 rule.** A revised NAGPRA rule took effect on January 12, 2024, after Interior Department officials announced it on December 6, 2023. Under the rule, staff at museums and federal agencies must ask direct descendants, Native nations or Native Hawaiian organizations for their free, prior and informed consent. That means a yes given freely and beforehand, by people who have been told everything about the request. Staff need it before they display human remains or sacred and cultural objects, let others see them, or do research on them.

To follow the new rule, staff at the Field Museum in Chicago covered display cases in two of its halls in January 2024. A statement from the museum said that the cases held cultural items that "could be subject to" the new rules, and that they would stay covered while staff reviewed what was known about the items.

### Payment for the Trinity downwinders, 2025

Downwinders are people who lived where the wind carried fallout from nuclear bomb tests. Members of Congress passed the Radiation Exposure Compensation Act, a law to pay people for harm, in 1990. The law included people who lived downwind of the Nevada Test Site, where nuclear bombs were tested from 1951 to 1957. It did not include the Trinity downwinders in New Mexico.

**The campaign.** Tina Cordova of the Tularosa Basin Downwinders Consortium led the campaign to add them. In July 2025, 80 years after the Trinity test, President Donald Trump signed a budget bill that added New Mexico's downwinders to the law. The bill also added uranium workers who entered the industry after 1971.

Each person who qualifies can receive $100,000 in one payment. According to KUNM, a New Mexico public radio station, New Mexicans can apply until December 31, 2027.

**The three questions, answered**

- How did American scientists learn how far away the stars are? Henrietta Leavitt showed in 1912 that the blink of a Cepheid star tells how bright it truly is, and so how far away it is. Edwin Hubble used her rule in 1923 to place Andromeda far outside our own galaxy.
- Why did scientists collect human skulls and brains, and where are those remains now? Samuel Morton, the Army's museum scientists and Aleš Hrdlička measured them to rank the races, an idea that is false. Morton's skulls are at the Penn Museum, whose staff buried 19 of them in 2024, and the Smithsonian still held at least 255 of the brains in 2023. Many Native American remains have been returned since the laws of 1989 and 1990, but in January 2025 museums still had 90,831 not yet made available for return.
- Who did the work but was left out of the credit? Lise Meitner explained fission, and Rosalind Franklin's X-ray pictures showed the shape of DNA. The Nobel Prizes went to Otto Hahn alone in 1944 and to Watson, Crick and Wilkins in 1962.

**What changed:** American science grew from a few colonists watching comets to experiments with thousands of workers, and the people scientists had used without asking, and their families, began to win apologies and payments.

**Five dates to keep**

- June 3, 1769: four men at Norriton time Venus crossing the sun.
- 1839: Samuel Morton's *Crania Americana* ranks the races by skull size.
- 1912: Henrietta Leavitt publishes her rule for measuring space.
- April 25, 1953: Watson and Crick publish the shape of DNA.
- November 16, 1990: NAGPRA becomes law.

**Not known:** how many people the fallout from the 1945 Trinity test made sick or killed, because no government official ever counted them.

**Where to go:** The International African American Museum in Charleston, South Carolina, where the 1850 photographs of Renty, Delia and five others went on public view on March 11, 2026.

**Next:** Chapter 10, Energy. It asks what powered American life, from muscle and wood to the atom and the sun.
