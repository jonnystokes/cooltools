# Chapter 22: War and the Military

**Chapter 22 of 37 · War and the Military · 10 eras · about 130 minutes**

**Until World War II, sickness killed more American soldiers than weapons did. In almost every war, at home and abroad, soldiers also killed people who could not fight back.**

A small photograph on glass, of three young children, was the only thing Sergeant Amos Humiston had on him when he was killed at Gettysburg on July 1, 1863. The 1850 to 1900 era tells how that picture reached his wife. In his war, about five soldiers died of disease for every three who were killed in battle like him.

This chapter follows, in order, the wars fought on this land and then the wars American soldiers fought overseas, from a town on the Missouri River destroyed about 1325 to the war with Iran that began in 2026. As you read, keep three things in view: what killed the soldiers, who was made to go, and what happened to soldiers who killed people who could not fight back. For most of this history, the flu killed more soldiers than bullets did, and so did typhoid and dysentery, infections spread by dirty water and food. In the Civil War a drafted man, one ordered into the army by law, could pay $300 and go home. The men who burned towns and shot prisoners were rarely punished, though a few people stood in their way, like the helicopter pilot Hugh Thompson at My Lai.

**Three questions this chapter answers**

- What killed most American soldiers before World War II?
- Who was made to fight, and who could get out of it?
- Were soldiers who killed people who could not fight back ever punished?

**Five minutes?** Read "The Mexican War, 1846 to 1848" in 1800 to 1850 and "Who had to fight in the Civil War?" in 1850 to 1900.

**Can skip:** "Louisbourg, 1745", "The forts that were destroyed, 1568 and 1586", "The Bonus Army, 1932". The chapter still makes sense without them.

## Before 1500

**Era 1 of 10 · Before 1500 · about 4 minutes**

People fought wars in North America long before Europeans came, and everything known about those wars comes from what the fighters left in the ground. No one north of Mexico wrote them down. Archaeologists, scientists who dig up and study what people left behind, have found skeletons with wounds, houses burned where they stood, and ditches and walls built around towns.

From that evidence they can tell that a town was attacked, about when it happened, and what a weapon did to a bone. No fighter's name survives from these wars, and no word that any of them said, including their reasons for fighting.

**On the Great Plains.** Signs of violence there go back to about 250 B.C. Fighting grew more common after about the year 1250. From then on attackers often burned villages, and skeletons regularly show cut marks from scalping and from bodies being cut apart. Scalping means cutting the skin and hair off the top of a person's head.

### Walls, ditches and stone weapons

Farming villages along the Missouri River, in what are now North and South Dakota, often had a ditch dug around them and a palisade, a fence of tall logs set upright in the ground. Some of these villages held up to 1,000 people.

**Cahokia.** The largest town north of Mexico stood near present-day St. Louis. Between about 1050 and 1150, perhaps 15,000 to 20,000 people lived in its center. Its people began a wall of upright logs about two miles long around the middle of the town about 1100. They rebuilt it three times over about 200 years, so four walls stood there one after another.

Staff at Cahokia Mounds State Historic Site estimate about 20,000 logs for each wall. Towers called bastions stuck out from the wall at even distances. Archers could stand in them and shoot arrows at attackers.

Archaeologists disagree about what the Cahokia wall was for. Some point out that bastions are built for fighting, and that some stretches of the wall went up in a hurry and cut right through neighborhoods where people lived. Others, in lesson pages from the University of Illinois, think it may have marked off the town's powerful families from ordinary townspeople, or insiders from outsiders.

**What the bones show.** Wounds show which weapons people used. At Norris Farms, in central Illinois, archaeologists studied a cemetery of 264 people from a village of about the year 1300. At least 43 of them, about 16 in every 100, had died by violence. Counting only the adults, at least one death in three came from fighting.

Arrows had hit some of them. Others had been struck from the front, the side and the back with heavy weapons such as stone axes. The bones do not show who the attackers were.

### How many died at Crow Creek?

At Crow Creek, on the Missouri River in South Dakota, archaeologists found the bones of at least 486 men, women and children killed in a single attack. The town there belonged to ancestors of the Arikara Nation. Archaeologists from the University of South Dakota dug into the ditch around the town in 1978. They dated the bones by measuring the carbon left in them, a method called radiocarbon dating, and found that the attack happened about 1325.

**Nearly the whole town.** Douglas Bamforth, an archaeologist at the University of Colorado, calls the 486 dead nearly the whole town. P. Willey, the scientist who studied the bones, thinks they were about 60 in every 100 of the people who lived there. Bamforth thinks the killings came from a fight over food. The likely reason, he says, was too many people in the area for the food they could get, at a time when the weather was getting worse.

Many of the people at Crow Creek had been scalped, had their heads cut off, or had their bodies cut apart. Scalping leaves cut marks on the skull, and cracked skulls were common.

The bones also show that these people were badly underfed before they were killed. Animals had chewed many of the bones, so the bodies lay in the open for some time before anyone buried them in the ditch.

The bones do not show who the attackers were. Fewer young women lie in the grave than a whole town would have had. Willey thinks the most likely reason is that the attackers carried young women away as captives.

## The 1500s

**Era 2 of 10 · The 1500s · about 9 minutes**

Small Spanish armies marched into the homelands of Native nations in the 1500s, and the reports their leaders wrote are the first written record of war in what is now the United States. The soldiers brought horses and trained attack dogs, and they fought with swords and lances. Their reports tell only the Spanish side.

**Forts and prisoners.** Native people destroyed every fort one Spanish captain built inland, all of them by 1568. Spanish soldiers and French colonists also fought each other on the coast of Florida. There the Spanish commander had his men kill about 245 French prisoners who had already surrendered.

### De Soto's march, 1539 to 1543

Hernando de Soto landed near Tampa Bay, in Florida, in May 1539, with about 600 men, 220 horses, packs of dogs and a herd of pigs. For the next three years his army crossed the Southeast. De Soto took hostages to force the towns to let his army pass. He held the leader of the Coosa towns hostage to get through those towns, and his men ate the food the Coosa had stored.

The National Park Service's page on de Soto states what his men did to towns that did not cooperate. They threw people to the dogs, setting trained attack dogs on captives to bite and tear them, often to death. They burned people alive. They raped Native people, which means they forced them to have sex. They cut off people's noses and hands, and they enslaved men and women to carry the army's loads.

### How the battle at Mabila began

De Soto's army reached Mabila, a town with a palisade around it, in October 1540. The battle there began on October 18, when a Spanish officer decided that a Mabila man had not shown him enough respect. The argument ended with the officer cutting off the man's arm. An article at HistoryNet, a history magazine website, names the officer as Captain Baltasar de Gallegos. Mabila's leader was a man the Spanish called Tascalusa.

The battle lasted about nine hours. At the end de Soto's soldiers burned the town while people were still inside it. The army's own record-keeper wrote, "We killed them all either with fire or the sword."

The counts of the dead do not agree. The National Park Service's page lists more than 200 Spanish dead and about 2,000 people of Mabila. A University of Alabama news report states about 20 Spanish killed and 250 wounded, with thousands of Mabila dead. Searchers from the University of Alabama have looked for the town, and no one has ever found where Mabila stood.

### The end of the march, 1542 and 1543

De Soto died of a fever on May 21, 1542. His men sank his body in the Mississippi River and hid his death, so the nations they had been fighting would not learn that he could die. In June 1543 the rest of the army went down the Mississippi in seven boats. Only 311 of the Spanish reached the Gulf of Mexico. They took enslaved Native people with them, and no one recorded how many.

### The Tiguex towns, 1540 to 1541

Far to the west, in the winter of 1540 to 1541, the Spanish commander Coronado and his army fought the Tiguex towns on the Rio Grande in New Mexico. The Tiguex were Pueblo people, who lived in towns of houses several stories tall. They spoke the Tiwa language and lived in twelve or more towns near present-day Albuquerque. Tiwa is still spoken today at the pueblos of Isleta, Sandia, Taos and Picuris.

**Corn and cloaks.** Coronado's soldiers took over the town of Coofor and made its people leave. The army's horses and mules ate the corn stalks the Tiguex needed to burn for heat in winter. Then Coronado demanded about 300 or more pieces of cloth from the towns, and his men did not give the towns time to decide. People had to take off their own cloaks and hand them over. Soldiers took better cloaks off any Tiguex man they saw wearing one.

**A complaint to Coronado.** Then a Spanish soldier went into a Tiguex house and raped the wife of the man who lived there, or tried to. Pedro de Castañeda, a soldier on the expedition who later wrote its history, says so. The husband and the town's leaders complained to Coronado.

The husband could not pick out the soldier in a line of men, but he knew the soldier's horse. The owner of the horse denied it, and the husband got no justice. Castañeda knew the soldier's name and chose not to write it down.

The next day Tiguex men killed a Native man who guarded the army's horses and drove off many of the horses. Coronado sent Don García López de Cárdenas to surround the town where the soldier had raped the woman, or tried to. After a day and a night, Cárdenas's men and their Native allies from Mexico smoked the defenders out of the cellars.

The defenders made the sign of the cross to ask for peace. Two Spanish soldiers on the roof made the sign back. The men put down their weapons, and the Spanish promised them they would not be punished.

**The stakes.** Coronado had ordered Cárdenas not to take anyone alive and to make an example of them to frighten the other towns. Cárdenas ordered 200 stakes set up to burn the prisoners alive. Castañeda wrote that when the prisoners saw the Spanish tying men to the stakes and starting to burn them, about 100 men in a tent fought back. Spanish foot soldiers and horsemen killed them.

Castañeda gives no exact count of the people burned. A history from the New Mexico Office of the State Historian names the town as Arenal, across the river from Coofor, and states that the Spanish killed dozens of captives there. At his trial, Cárdenas told a different story. He said some soldiers had speared men in a tent without his order.

The fighting went on for about three months. The Tiguex shut themselves inside their houses and shot arrows from the roofs and through slots in the walls. The Spanish charged on horseback and set fires to force people out. By the count on a National Park Service page, the Spanish killed hundreds of Tiguex, and the Tiguex killed a smaller number of Spanish and Mexican soldiers. The Spanish burned villages and enslaved Tiguex women and children.

**Cárdenas on trial.** Spanish officials later put Cárdenas on trial. A royal prosecutor, the lawyer who brought the case for the king, charged him with killings, with rapes committed by his men, with setting dogs on Native people, and with taking food and clothing. The judges of the Council of the Indies, the king's council for Spain's colonies, found him guilty in 1549 and said so again in 1551.

They first ordered him to serve 30 months as a soldier at Oran, in North Africa, and to pay 800 ducats, which were Spanish coins. He asked for a lighter punishment and got one: 12 months as a soldier in Spain, a fine of 200 ducats, and 10 years banned from the Americas.

### Why the inlet is called Matanzas

An inlet south of St. Augustine, in Florida, has been called Matanzas, the Spanish word for "slaughters," since 1565. There Spanish soldiers killed about 245 French prisoners who had surrendered.

**Fort Caroline.** About 200 French colonists built Fort Caroline near present-day Jacksonville in 1564. They were Huguenots, French members of the Protestant churches, which had broken away from the Catholic Church, the church led by the pope in Rome. The land belonged to the Timucua, who had lived in northern Florida for at least 1,000 years. King Philip II of Spain claimed Florida, and he was Catholic.

The Spanish founded St. Augustine, farther south, on September 8, 1565. Twelve days later their commander, Pedro Menéndez de Avilés, marched 500 soldiers overland and attacked Fort Caroline at dawn. His men killed most of the settlers they found. In his own letter to the king, Menéndez counted 132 men at the fort whose throats his soldiers cut, and 10 more killed the next day. He spared about 50 women and children and sent them by ship to Havana, in Cuba.

**At the inlet.** A hurricane had already wrecked the French ships. About 127 French survivors came ashore at the inlet with no food and no weapons, and they surrendered to Menéndez. He told them to give up their Protestant faith. They refused, and his soldiers killed 111 of them.

Menéndez spared 16 men. A few said they were Catholic. Some were sailors from Brittany who had been forced onto the ships. Four were craftsmen the Spanish settlers at St. Augustine needed. Menéndez wrote to King Philip on October 15, 1565, "I had their hands tied behind them and put them to the knife."

A second group of French survivors came to the same inlet with their commander, Jean Ribault. They surrendered and refused the same demand, and Menéndez's men killed 134 of them. In his letter Menéndez gave his reason: the French "spread the Lutheran sect," meaning Protestant teaching, in land the king of Spain claimed.

The Florida Museum of Natural History dates the first killing to September 29, 1565. It dates the second to October 11, and the National Park Service dates it to October 12.

### The forts that were destroyed, 1568 and 1586

Captain Juan Pardo built a chain of small Spanish forts inland between 1566 and 1568. He built Fort San Juan in January 1567 at the Native town of Joara, in the upper Catawba Valley of North Carolina, and thirty soldiers held it. In all, Pardo left about 120 men in forts across the Carolinas and east Tennessee.

The soldiers demanded more food than the towns around them could give, and they attacked the people they lived among. By May 1568, Native people had attacked every one of the forts, destroyed them all and killed nearly every soldier. Archaeologists have found Fort San Juan. It is the Berry site in Burke County, North Carolina.

**Drake at St. Augustine.** English sailors under Francis Drake burned St. Augustine in 1586. Drake was a privateer, a sea captain allowed by his government to attack Spanish ships and towns. He arrived with 21 ships between May 28 and 30, 1586, and the town had about 150 soldiers. His men burned the town and its wooden fort and took about 2,000 pounds in money from the treasury.

## The 1600s

**Era 3 of 10 · The 1600s · about 10 minutes**

English colonists fought their first wars on this coast against the nations whose land they had settled on: the Powhatan in Virginia, the Pequot in Connecticut, and Metacom's Wampanoag and their allies in New England. In every one of these wars, Native allies fought beside the colonists. Mohegan and Narragansett fighters, for example, joined the English against the Pequot in 1637.

**The militia.** The English colonies had no army. They had a militia instead, made up of ordinary men, mostly farmers, who left their work to fight when their leaders called them and went home when the fighting ended.

The lawmakers of Massachusetts Bay, meeting as the General Court, ordered every healthy man between 16 and 60 to join the militia on December 13, 1636. Ministers and judges did not have to. The lawmakers organized the men into three regiments, large units of soldiers. Leaders of today's Army National Guard date its beginning to that order.

Colonial soldiers struck at towns and food. They attacked the Pequot town at Mystic before dawn in 1637. In Virginia, from 1622 on, they burned Powhatan corn in the fields and seized the corn people had stored.

### The Powhatan wars in Virginia, 1622 to 1646

The English colony in Virginia stood on the land of the Powhatan, a group of nations led by one head chief. In 1622 the Powhatan leader Opechancanough judged that the English would keep taking more Powhatan land unless they were stopped.

**The attack of 1622.** Opechancanough sent fighters to the English plantations, or large farms, along the James River in one planned attack on March 22, 1622. The men came to houses and fields as if to trade or share a meal, then attacked. They killed as many as 347 colonists, out of about 1,200 in the colony.

A Powhatan man who worked for a settler named Richard Pace warned him, and Pace warned Jamestown in time. The English accounts of the warning do not give the Powhatan man's name.

**The poisoned toast.** Opechancanough agreed to meet English leaders on the Pamunkey River in May 1623 to make peace. Captain William Tucker led the English party of about 12 men. The English offered poisoned drinks to toast the agreement. When the Powhatan leaders fell sick, the English shot them, and some of the English cut off scalps.

The English accounts of the dead do not agree. A settler named Robert Bennett wrote to his brother on June 9, 1623, that "some tooe (two) hundred" were thought to have been poisoned, and that the English killed about 50 more. Governor Francis Wyatt and his council answered in 1624 that no one had been poisoned at a feast and that only nine were shot. Their own report says the men took poison along, to be used if nothing else worked. Neither account names the poison.

**Burning the corn.** The English also went after the Powhatan food supply, from 1622 on. In their own words, they waited "till their corne was ripe," then raided through the fall and winter to "surprize their corne," meaning to seize it. They agreed to pauses in the fighting so both sides could plant, then attacked again after the harvest. In July 1624, English soldiers burned fields with enough corn, by their own count, to feed 4,000 men for a year. The war lasted until 1632.

Opechancanough attacked again on April 18, 1644, and killed about 400 colonists. Virginia's governor, Sir William Berkeley, led soldiers who captured him in 1646 and took him to Jamestown. Within two weeks, one of his English guards shot him dead in his cell. Encyclopedia Virginia's history of Opechancanough does not name the guard.

### The Pequot War, 1636 to 1638

The Pequot War grew out of two killings of English traders. Pequot men killed the trader John Stone and his crew on the Connecticut River in 1634. Manisses men from Block Island, a different nation from the Pequot, killed the trader John Oldham in July 1636.

**Endecott's raid.** John Endecott of Massachusetts Bay led 90 soldiers to Block Island in August 1636 and burned the villages there. Then his men sailed to Pequot land and burned a Pequot village too. Pequot fighters attacked Wethersfield, Connecticut, on April 23, 1637, killed nine men and women, and took two girls captive.

**Mystic.** Captain John Mason of Connecticut and Captain John Underhill of Massachusetts Bay reached the Pequot town at Mystic before dawn on May 26, 1637. Mohegan and Narragansett fighters came with them. The English set fire to the palisade and the houses inside it, and they shot the people who tried to get out.

Historians at the Mashantucket Pequot Museum count more than 400 Pequot killed in one hour, and other counts go as high as 700. Most of the Pequot fighting men were away with their sachem, or leader, Sassacus, so most of the dead were old men, women and children. The English lost two dead and twenty wounded.

The English fought the surviving Pequot in a swamp near present-day Fairfield, Connecticut, in July 1637, for about a day and a night. Sassacus escaped west, and Mohawk fighters killed him later that month. The Pequot museum's history of the war states that some captive Pequot women were killed after the English argued over who would get them, and it does not name who killed them. The English sold other captives into slavery in New England and the Caribbean.

**Captives for sale.** John Winthrop, the governor of Massachusetts Bay, wrote in his journal on July 13, 1637, that the colony's leaders had sent 15 Pequot boys and 2 women away as slaves. A ship captain, William Peirce, carried them. Massachusetts leaders held a day of thanksgiving on October 12, 1637, for defeating the Pequot and bringing the soldiers home safe. In February 1638 Peirce came back on the ship *Desire* with cotton, tobacco and enslaved Africans.

**The Treaty of Hartford.** Leaders of the Connecticut colony at Hartford and Mohegan and Narragansett leaders signed the Treaty of Hartford, a written agreement, in 1638. Under it they divided the surviving Pequot between the Mohegan and the Narragansett. The signers barred the Pequot from their homeland and forbade them ever to call themselves Pequot again.

Pequot survivors held together. By 1651, Robin Cassacinamon had led some of them back to 500 acres of their land. In 1666, leaders of the Connecticut colony set aside a reservation, land kept for a Native nation to live on, for the Pequot at Mashantucket. The Mashantucket Pequot Tribal Nation is in Connecticut today.

### King Philip's War, 1675 to 1676

King Philip's War was fought in New England in 1675 and 1676. The English called the Wampanoag sachem Metacom by the name King Philip.

A National Park Service article calls it one of the deadliest wars in American history, when the number killed is compared with how many people lived in New England. One estimate, published by HistoryNet, counts about 9,000 people killed out of about 80,000 in New England, about one person in nine. About two out of every three of the dead were Native people, and many of them died of starvation.

**A death and a trial.** John Sassamon, a Christian Native man, was found dead under the ice of a pond in January 1675. Days before, by the accounts of the time, he had warned Plymouth's governor, Josiah Winslow, that Metacom's men were planning an attack.

English judges at Plymouth tried three Wampanoag men for his murder on June 1, 1675, before an all-English jury. Six Native men sat with the jury to advise it. Plymouth's officials hanged two of them, Tobias and Mattashunannamo, on June 8. They held back the third, Wampapaquan, for a month and then shot him to death. The fighting began that June at the English town of Swansea.

**The swamp fort.** When the war began, Metacom sent the old men, women and children of the Wampanoag across Narragansett Bay to live with the Narragansett. The Narragansett stayed out of the fighting. In October 1675 their leaders promised Massachusetts Bay in a treaty that they would not join Metacom. The leaders in Boston then demanded that the Narragansett hand over the Wampanoag who had fled to them, as hostages. The Narragansett refused.

Leaders of the English colonies feared the two nations would join together. About 1,000 English soldiers attacked a fortified Narragansett winter village in a frozen swamp in Rhode Island on December 19, 1675. About 1,000 Narragansett men, women and children were living there. Governor Winslow of Plymouth and two majors, from Massachusetts and Connecticut, led the soldiers of their colonies.

The soldiers took the fort and burned every house in it. The National Park Service counts 300 Narragansett men and almost 400 women and children killed. James Oliver, an English officer, wrote that the English lost about 68 dead and 150 wounded.

After the attack, the Narragansett joined Metacom, and Native fighters struck back across New England. By one count, they attacked 52 of the 90 English towns and burned 17 of them to the ground. Narragansett fighters came to Providence in late March 1676. Roger Williams of Providence tried to bargain with them, and they turned him down and burned the town.

A Native man fighting with the colonists shot Metacom dead at Mount Hope on August 12, 1676. The colonists put his head on display at Plymouth. They sold his wife and his nine-year-old son into slavery.

### What happened on Deer Island?

Massachusetts Bay's leaders held Christian Native people, who were allies of the English, on Deer Island in Boston Harbor through the winter of 1675, and many of them starved. The leaders moved them there that autumn because they did not trust them. The first were Nipmuc people from the town that is now South Natick. Between 500 and 1,100 people were held there, most of them women and children, with little shelter and too little food.

The colonists let the survivors go in May 1676. The two counts of the dead do not agree. Mass Humanities, a history group, states that about half of some 900 people held there died of hunger and cold. A National Park Service page states that very few survived, so by its account most of them died.

Some people were smuggled off the island and sold as slaves in the West Indies, the islands of the Caribbean, or in Tangier, in North Africa. The National Park Service page gives no number and does not name the men who sold them. Massachusetts colonists also put about 45 Native people to death in public on Boston Common.

**Sold for life.** Governor Josiah Winslow of Plymouth and Governor John Leverett of Massachusetts Bay signed papers that allowed Native men, women and children to be sold into slavery for life. A colonial record notes one sale: "that day wee sold Capt Davenport 47 Indians young & old for 80 pd," meaning 80 pounds for 47 people. Ships carried captives to Barbados, Bermuda, Jamaica, the Azores, Spain, and Tangier.

Descendants of captives sent from Rhode Island to Bermuda have since reconnected with Native nations in New England and Canada.

### The Beaver Wars and the Pueblo Revolt

Other wars of the 1600s had no English colonists in them. Chapter 2, Native Nations, tells these two from the side of the nations who fought them. In the Beaver Wars, fighters from the Haudenosaunee nations, also called the Iroquois, raided villages of the Wendat, also called the Huron, for years, to control the trade in furs. French and Dutch traders armed their Native trading partners with guns, and the guns made the raids deadlier.

The raids broke the Wendat apart between 1642 and 1649. Haudenosaunee fighters destroyed the Wendat homeland, Wendake, in 1649 and 1650. They killed many Wendat and adopted many others into Haudenosaunee nations. About 500 Wendat moved east to the Quebec City region.

**The Pueblo Revolt.** People from the Pueblo towns of the Rio Grande rose together against Spanish rule in New Mexico on August 10, 1680. They surrounded Santa Fe, took it, and drove the Spanish out. They killed 401 settlers and 21 Franciscan friars, who were Catholic priests, and let most other Spanish people leave. The Pueblos governed themselves for 12 years. Diego de Vargas began the Spanish return in 1692, and armed resistance went on for years after.

## 1700 to 1750

**Era 4 of 10 · 1700 to 1750 · about 8 minutes**

Both wars that reached North America in these years began in Europe, one over who would become king of Spain and one over who would rule Austria. Colonial militia and Native fighters did most of the fighting here, and the Native fighters had their own reasons. Here the two wars are called Queen Anne's War, from 1702 to 1713, and King George's War, from 1744 to 1748.

**The Haudenosaunee stay out.** The leaders of the Haudenosaunee Confederacy, an alliance of Native nations with the biggest fighting force in the northeast, chose to stay out of these wars.

At Montreal on August 4, 1701, about 1,300 representatives from more than 30 Native nations made peace with New France, the French colony in Canada. There the Haudenosaunee leaders promised to take neither side between France and Britain. They worked to keep that promise for about fifty years, and French and British commanders both had to plan around it.

**The winter raid.** In the north, the common act of war was the winter raid. Fighters came at a sleeping town before dawn, killed some of the people and took others captive. Then they marched the captives hundreds of miles to Canada on foot. A captive might be adopted into a Native nation, sold back to family for money, or killed on the trail for not keeping up.

### Deerfield, February 29, 1704

About 250 fighters attacked Deerfield, a town in western Massachusetts, before dawn on February 29, 1704. Their commander was Jean-Baptiste Hertel de Rouville, a French lieutenant, or junior officer, born in Canada. He led 47 French Canadian soldiers and about 200 fighters from the Abenaki, the Wendat and the Kanien'kehaka, as the Mohawk people call themselves. The historians of Deerfield's museum write that these nations fought to keep English settlers out of their homelands.

About 300 people lived in Deerfield, and more than half were killed or taken captive. Deerfield's history museum, the Pocumtuck Valley Memorial Association, which keeps the town's old records, lists 48 killed and 111 captured. A Library of Congress history page lists 57 killed and 112 captured.

In the house of the town's minister, John Williams, the attackers killed his six-week-old daughter Jerusha and his six-year-old son John. They also killed Parthena, a Black woman Williams had bought and held as a slave. Her husband Frank, also enslaved by Williams, was taken captive.

**The march north.** The attackers drove the captives across the frozen Deerfield River and marched them 300 miles to New France in the middle of winter. Each captive belonged to the man who had taken them, and those men killed captives who could not keep up. Williams wrote that on one day they killed two women "so faint they could not travel."

Mary Brooks, a young woman, told Williams that her falls on the ice had caused a miscarriage, which means she had lost the baby she was carrying. She said she was too weak to walk far and knew they would kill her. They killed her that day. Williams did not record the names of the men who killed them. Of the more than 100 captives, only about half ever came back to New England.

### John Williams

> **Who:** Deerfield's minister, captured with five of his children in the 1704 raid. He came home and wrote the best-known captivity story of colonial America.
>
> **When and where:** Born in Roxbury, Massachusetts, December 16, 1664. Minister at Deerfield from 1686. Captured February 29, 1704. Back in New England late in 1706. Died 1729.

**The raiders took him, his wife and five of their children.**

Soon after the march began, at the Green River in what is now Greenfield, Massachusetts, his wife, Eunice Mather Williams, fell while crossing and went under the icy water. She walked on a short way. At the foot of a mountain, the man who had taken her captive killed her with one blow of a hatchet. Williams did not record his name.

Williams and four of his children came home. His daughter Eunice, who was seven when the raiders took her, did not. He returned late in 1706 and preached about his captivity in Boston on December 5 that year, and in 1707 he went back to his church in Deerfield.

His book about the raid and the march, *The Redeemed Captive Returning to Zion*, was printed in seven editions before 1795.

### Eunice Kanenstenhawi Williams

> **Who:** John Williams's daughter, taken from Deerfield at seven. She became a member of the Kanien'kehaka nation at Kahnawake and chose to stay there all her life.
>
> **When and where:** Born in Deerfield, September 17, 1696. Taken February 29, 1704. Died at Kahnawake, near Montreal, in 1785, aged 89.

**Carried off at seven, she refused every offer to bring her home.**

Eunice Williams was seven when the attackers carried her out of Deerfield. At Kahnawake, a Kanien'kehaka town near Montreal, a family adopted her in a formal ceremony. She was first named A'ongote, "she was taken and placed." Later she was named Kanenstenhawi, "she brings in the corn," and was accepted as a full member of the nation. She was also baptized a Catholic, in the Christian ceremony with water that makes a person a member of a church, and given the name Marguerite.

Her father and English officials tried again and again to bring her back. She refused. At 16 she married François-Xavier Arosen, a man of her town. They had at least three children: two daughters, Catherine and Marie, born in 1736 and 1739, and a son, John. The Pocumtuck Valley Memorial Association's history says John seems to have died at Lake George, in New York.

She visited her Williams brothers and sisters in New England four times, in 1740, 1741, 1743 and 1761. At her brother Stephen's house in Longmeadow, Massachusetts, she slept outside in the orchard instead of inside the English house. Each time, she went home to Kahnawake. New Englanders called her the "unredeemed captive," the one they never bought back.

### Why the Tuscarora went to war, 1711 to 1713

The Tuscarora of North Carolina had three complaints, as the historians Elizabeth A. Fenn, Peter H. Wood and others name them in the account NCpedia publishes. They objected to the way white traders dealt with them and to the enslaving of Native people. Most of all, they objected to settlers taking their land. English settlers had founded the town of New Bern near the Tuscarora in 1710.

The Tuscarora began a series of planned attacks on the settlers on September 22, 1711. Soldiers from South Carolina, fighting with Native allies, defeated them by March 1713. By then about 1,400 Tuscarora were dead, and the winners had captured and enslaved about 1,000.

About 1,500 surviving Tuscarora walked north. In 1722 they became the sixth nation of the Haudenosaunee Confederacy.

### The Yamasee War, 1715 to 1717

The Yamasee War in South Carolina began over debt and the slave trade in Native people. Yamasee towns stood along the Savannah River and around Port Royal. Traders from Charleston let the Yamasee take goods and pay later, hoping to take Yamasee land when the debts could not be paid. By 1715, paying off the debt would have taken at least two years of work from every Yamasee man.

The traders also enslaved Native people and whipped them, and settlers were moving onto Yamasee land. The Yamasee themselves had raided Apalachee towns in Florida and sold the people they captured to Carolina merchants as slaves.

**Pocotaligo.** Thomas Nairne, the colony's agent for dealing with Native nations, met Yamasee leaders at Pocotaligo Town on April 14, 1715, with two other colonists, William Bray and Samuel Warner. They hoped to stop the fighting before it started. The next morning, Good Friday, Yamasee men killed Bray and Warner. They held Nairne for several days and tortured him to death by sticking burning splinters of wood into his skin.

Across the South, Creek, Choctaw, Apalachee and other men killed the traders who worked among them. By June 1715, about nine in every ten of those traders were dead.

The first Yamasee attacks, on plantations near Port Royal, killed about 100 colonists. Over the whole war, about 400 settlers were killed, and colonists had to leave half the farmland in the colony. The South Carolina Encyclopedia and NCpedia give no count of the Yamasee dead or the other Native dead.

**Craven's war.** South Carolina's governor, Charles Craven, called up every white man and armed some enslaved Black men as well. About 300 families who owned plantations escaped by ship. Craven's forces beat the Yamasee at Port Royal and at the Salkehatchie River and drove them south of the Savannah River. By the spring of 1716, most Yamasee had moved to Spanish Florida.

Carolina officials talked the Lower Cherokee into fighting the Creek in 1716. That began a war between the Cherokee and the Creek that lasted about forty years. Carolina officials ended their own war by 1718.

### Louisbourg, 1745

King George's War began in this part of the world in 1744, after a group of English scalp hunters, men who hunted Native people for their scalps, killed or wounded several Penobscot people. In 1745 New England soldiers laid siege to Louisbourg, a French fortress on Cape Breton Island, in what is now Canada, surrounding it to cut it off until it gave up.

Massachusetts leaders raised an army of their own colonists to take the fortress. The soldiers sailed from Boston on March 24, 1745, and nearly 2,000 of them landed near Louisbourg on April 30. Colonel William Pepperrell commanded them. Commodore Peter Warren, a British navy commander, waited offshore with a group of warships. Up to about 4,300 New Englanders served there over the whole siege, but only about half that many at any one time.

The acting French governor, Louis Du Pont Duchambon, asked on June 15 what conditions he would get if he surrendered. He and his soldiers surrendered the fortress on June 17, 1745.

**The winter after.** Far more New Englanders died holding Louisbourg than died taking it. During the siege, French fire killed about 100, and 30 died of illness. Then the soldiers spent the winter in wrecked, dirty buildings, and sickness spread. The counts of the dead do not agree. A HistoryNet account counts 561 burials between late November and mid-February. The Dictionary of Canadian Biography gives 1,200 to 2,000 deaths over the winter and spring.

British officials gave Louisbourg back to France in 1748 in the Treaty of Aix-la-Chapelle, the agreement that ended the war. In return, French officials gave back Madras, a city in India they had taken from Britain.

## 1750 to 1800

**Era 5 of 10 · 1750 to 1800 · about 16 minutes**

Soldiers from the colonies, and then from the new United States, were at war for most of the forty years after 1754. In the Revolution, sickness killed more of them than enemy weapons did.

The French and Indian War began that year. In the treaty that ended it, in 1763, French officials signed over Canada and all French land east of the Mississippi River to Britain. The Revolution lasted from 1775 to 1783 and ended with the thirteen colonies independent. From 1785 to 1795, US soldiers fought a group of Native nations north of the Ohio River.

**Counting the dead.** Historians at the American Battlefield Trust estimate that about 6,800 Americans were killed in battle in the Revolution. At least 17,000 more died of disease, about two and a half for every one killed in battle, and 8,000 to 12,000 of those were prisoners of war. The Defense Department's official list shows 4,435 American battle deaths, and its own note says its records from before World War I are often incomplete.

### The French and Indian War, 1754 to 1763

British and colonial soldiers fought French soldiers and the Native nations allied with France in the French and Indian War. French soldiers forced a young Virginia colonel, George Washington, to surrender at Fort Necessity, in western Pennsylvania, in 1754.

**Braddock's defeat.** The next summer, the British general Edward Braddock marched about 1,450 men toward Fort Duquesne, the French fort where Pittsburgh stands now. About 900 French and Canadian soldiers and Ottawa, Shawnee, Lenape and Mingo fighters caught his column, a long line of marching soldiers, near the Monongahela River on July 9, 1755.

The Native fighters shot from the woods on both sides of the road. They and the French killed 456 of Braddock's men and wounded 422. The French side lost 23 killed. Braddock was badly wounded, and he died on the night of July 13.

**Fort William Henry.** The French general Montcalm surrounded the British at Fort William Henry, on Lake George in New York, with about 8,000 men, nearly 2,000 of them Native fighters. The British commander, Lieutenant Colonel George Munro, surrendered on August 9, 1757. Under the terms, his men could march away with their muskets but no ammunition.

The next day, Native fighters allied with Montcalm killed and scalped sick and wounded men left in the fort. Then they attacked the column of British soldiers, and the women and children with it, on the road.

The counts of the dead run from several dozen up to about 185 men, women and children. Early reports said 1,500, but a HistoryNet account finds it unlikely that more than 200 were killed. Montcalm got 500 captives released, and the Native fighters kept about 200 more.

British soldiers took Quebec on September 13, 1759, after a battle outside the city that lasted about twenty minutes. The British general James Wolfe was shot and died on the field. Montcalm was hit by a musket ball below the ribs and died the next morning.

### Did the blankets from Fort Pitt spread smallpox?

Officers at Fort Pitt, the British fort at present-day Pittsburgh, gave two Lenape men blankets from the fort's smallpox hospital in June 1763, meaning to give them the disease. No one can tell whether the blankets caused the smallpox that spread among the Ohio nations that year and the next. Smallpox spreads from person to person, mostly through the air people breathe, and it killed about one in three people who caught it. It was already in the area that spring.

**The siege.** In 1763, the year the war with France ended, Native nations of the Ohio country went to war against the British in what is called Pontiac's War. Shawnee, Lenape, Mingo and Seneca fighters surrounded Fort Pitt on June 22, 1763. Guyasuta was one of their leaders. Captain Simeon Ecuyer commanded the fort, with the trader and militia captain William Trent.

That spring the fort's officers had set up a hospital for soldiers sick with smallpox. On June 24, two Lenape men, one named Turtleheart, came to the fort to warn the soldiers to leave. Trent wrote in his journal, "we gave them two Blankets and an Handkerchief out of the Small Pox Hospital. I hope it will have the desired effect."

**Amherst's letters.** Two weeks later, the British commander in North America, General Jeffery Amherst, suggested the same thing in a letter to Colonel Henry Bouquet. "Could it not be contrived (arranged) to Send the Small Pox among those Disaffected (unfriendly) Tribes of Indians?" he wrote on July 8. Bouquet answered that he would try to spread it "by means of Blankets."

On July 16 Amherst told him to try it, and to try "Every other method that can serve to Extirpate (wipe out completely) this Execreble (hateful) Race." Amherst also told Bouquet to take no Native prisoners.

### The Revolution, from Lexington to Yorktown

The Revolution was fought between British soldiers and colonists who wanted independence. The shooting started at Lexington, Massachusetts, at about 5 in the morning on April 19, 1775. British soldiers killed eight militiamen on the town green and wounded ten. The fighting went on all day along 16 miles of road back to Boston, and by night 73 British soldiers and 49 militiamen were dead.

**Bunker Hill.** British soldiers attacked the colonists' earth walls on Breed's Hill on June 17, 1775, in the battle named for nearby Bunker Hill. They charged three times in two hours. On the third charge they climbed the walls and fought with bayonets, the long blades fixed to the ends of their muskets. The colonists had run out of ammunition and fell back. British casualties, meaning the killed and wounded together, came to 1,054, and the colonists lost about 450.

That June, the delegates, or representatives, from the thirteen colonies who met as the Continental Congress chose Washington to command a new Continental Army. About 231,000 men served in it during the war, but never more than 48,000 at one time. About 7,000 of them were Black.

**Who had to serve.** Under the rules of the time, the delegates in Congress had no power to draft anyone, which means to order a person into the army by law. So in 1778 they asked each state to draft men from its militia for one year in the Continental Army. Officials in some states drafted more men than others, and the army stayed short of men. A drafted man could pay someone else to go in his place.

Lawmakers in the colonies and the states wrote laws that kept enslaved men out of the militia. That ban covered the militia, not the Continental Army, where about 7,000 Black men served.

Pennsylvania lawmakers made Quakers, whose religion forbids fighting, pay a fine if they would not join the volunteer militia companies called Associations. The fine matched the value of the time a man would have spent drilling, practicing marching and handling weapons with his company. Officials took property from Quakers who refused to pay.

**Saratoga and Yorktown.** The British general John Burgoyne surrendered his army of 5,895 British and German soldiers at Saratoga, New York, on October 17, 1777. When the news reached France that December, the French foreign minister decided to make an alliance with the United States.

Four years later, Washington and the French general Rochambeau led about 17,000 American and French soldiers to Yorktown, Virginia. They surrounded the British general Charles Cornwallis there, while a French fleet held the sea behind him. About 8,000 British soldiers surrendered on October 19, 1781. It was the last big land battle of the war. When the news reached London, the British prime minister, Lord North, said, "Oh God. It is all over." The peace talks that followed ended with the Treaty of Paris in 1783.

### Smallpox and Valley Forge

Washington ordered his whole army inoculated against smallpox on February 6, 1777. To inoculate a soldier, a doctor cut open a sore on a person sick with smallpox, then pushed the same blade under the healthy soldier's skin. The soldier then had a milder case of smallpox and could never catch it again.

**Valley Forge.** More than 12,000 soldiers, with about 400 women and children, marched into winter camp at Valley Forge, Pennsylvania, on December 19, 1777. They built about 1,500 log huts, each 14 feet by 16 feet. Four days later, Washington wrote to Congress that 2,898 of his men were "unfit for duty, because they are barefoot and otherwise naked."

Nearly 2,000 people in the camp had died by June 1778. Most died of the flu, of typhus, a fever spread by body lice, or of typhoid or dysentery, which spread through dirty water and food. Dysentery is an infection of the gut that causes bloody diarrhea, and a person can lose so much water that they die. Two out of three of those deaths came in March, April and May.

### The prison ships of New York

The British held New York City from 1776 to the end of the war. Their officers kept captured American soldiers and sailors in prisons in the city and on ships in the harbor.

The British admiral in command at New York was Richard Howe. The ship called the *Jersey* held about 1,200 prisoners. The British officers who ran the ships gave the prisoners too little food and left the sick without care. By the National Park Service's account, smallpox, hunger and that neglect killed thousands.

One survivor wrote that the ship's biscuits were eaten through by weevils, which are small beetles. The bread was sour and often moldy, and the meat was rotten with age. Every morning, he wrote, a boat from each of the hospital ships carried the dead ashore, where the bodies "were all tumbled together into a hole dug for the purpose."

**The Sugar House and the Provost.** On land, the British held more than 4,500 Americans in the Sugar House, a sugar warehouse five stories tall. Another prison, the Provost, was run by Captain William Cunningham. His prisoners were packed so tightly that at night they could turn over only if they all turned at once.

Leaders of the Congress asked Washington to protest to Howe in January 1777. Washington wrote to Howe about prisoners the British had sent back from New York. He said their "miserable emaciated Countenances," meaning faces so thin from hunger that the bones showed, proved what they said.

The counts of the dead do not agree. A National Park Service page gives more than 11,500 dead on the ships and in the prisons around New York. Historians at the American Battlefield Trust estimate 8,000 to 12,000 deaths among all American prisoners in the whole war.

### Gnadenhutten, March 8, 1782

Gnadenhutten was a town of Lenape and Mohican Christians in the Tuscarawas Valley, in what is now Ohio. They belonged to the Moravian church, and they refused to fight for either side in the Revolution. In February 1782, more than 150 of them went back to their old towns to gather the corn they had left in the fields.

About 160 Pennsylvania militiamen marched there under David Williamson, the officer they had chosen to command them. They blamed the Moravian Lenape for raids on Pennsylvania settlements, which the Lenape denied. The militiamen promised to take the people to Fort Pitt for safety and collected their weapons. Then they held a vote on whether to kill them. Only 16 or 18 of the militiamen voted against it.

**The killings.** The prisoners spent the night praying and singing hymns, with the men in one building and the women and children in another. On the morning of March 8, 1782, the militiamen tied them up. Taking turns, they struck each person on the head with a heavy hammer called a mallet, and then they scalped them.

They killed 96 people. Eric Sterner, writing in the *Journal of the American Revolution*, counts 62 adults and 34 children. Another count gives 28 men, 29 women and 39 children.

A militiaman named Obadiah Holmes Jr., who opposed the killing, said another militiaman, Nathan Rollins, killed 19 people himself. Two boys lived, and one of them survived being scalped. The militiamen burned the buildings with the bodies inside, burned the other Moravian towns, and carried off goods that needed 80 horses to move.

People talked of bringing the killers to court, but no one charged any of the militiamen with a crime. Later the Moravian missionary John Heckewelder, a man sent to spread his religion, gathered the bones and buried them at the town.

### George Washington

> **Who:** A Virginia officer in the French and Indian War who went on to command the Continental Army for the whole of the Revolution.
>
> **When and where:** Fort Necessity, 1754. The Monongahela, July 9, 1755. Commander in chief from June 1775. Resigned at Annapolis, Maryland, December 23, 1783.
>
> **Movie:** *Washington* (History channel, 2020), a documentary series in three parts, with acted scenes.

**Four bullets went through his coat at the Monongahela.**

As a young officer, George Washington was on the losing side twice in two years. At Fort Necessity in 1754 he surrendered to the French, and he promised that he and his men would go back to Virginia and stay out of the region for a year.

A year later he rode with Braddock as a volunteer aide, a helper to the general. After the battle at the Monongahela he wrote to his brother, "I had 4 Bullets through my Coat, and two Horses shot under" him.

The delegates of the Continental Congress chose him to command their army in June 1775, and he held the command until the war ended. On December 23, 1783, he handed his commission, the paper that made him commander, back to Congress at Annapolis. The next day he left for his home at Mount Vernon.

### Joseph Plumb Martin

> **Who:** A Connecticut teenager who joined the army at 15, served as a private and then a sergeant, and later wrote down what it was like.
>
> **When and where:** Born in Becket, Massachusetts, November 21, 1760. Joined the army in June 1776 and was still serving at Yorktown in 1781. Died in Prospect, Maine, May 2, 1850, aged 89.

**He made his shoes from raw cowhide on the march to Valley Forge.**

Joseph Plumb Martin was 15 when he joined the Connecticut troops in June 1776. He fought on Long Island that August, and later at White Plains, Germantown and Monmouth. At Valley Forge he went out with groups of soldiers searching the countryside for food for the army.

On the march into the camp he made himself shoes from a piece of raw cowhide. His other choice, he wrote, was to go barefoot, as hundreds of other men did, "till they might be tracked by their blood upon the rough frozen ground." A National Park Service article points out that his words do not make clear whether he saw the bleeding feet himself or repeated a story people told after the war.

At Yorktown he was a sergeant in the sappers and miners, soldiers who dug the trenches that let the American and French armies surround Cornwallis. He took part in the attack on Redoubt No. 10, a small British fort of earth.

After the war he farmed in Prospect, Maine, married Lucy Clewley, and raised five children. He lost a fight over his land with Henry Knox, a former general. By 1818, when officials approved him for a pension, a payment of $96 a year for his service, he owned almost nothing. In 1830, at 70, he published his memoir, the story of his own life. It was printed again in 1962 as *Private Yankee Doodle*.

### Deborah Sampson

> **Who:** A Massachusetts woman who joined the army as a man named Robert Shurtleff, fought in the light infantry, was wounded, and later won a soldier's pension.
>
> **When and where:** Born in Plympton, Massachusetts, December 17, 1760. Enlisted May 1782. Discharged October 1783. Died 1827.

**She enlisted as Robert Shurtleff and served 17 months as a man.**

At 10, Deborah Sampson was bound out as an indentured servant to a farmer's family in Middleborough, which meant she owed the family a set number of years of unpaid work. In May 1782, at 21, she joined the 4th Massachusetts Regiment as a man, under the name Robert Shurtleff. She served 17 months near West Point, New York, in a light infantry company, a unit of lightly armed foot soldiers.

She was wounded in combat. The Paul Revere House museum says it was in a fight with a raiding party of Loyalists, colonists who fought for the British king. The National Women's History Museum describes a sword cut to her forehead and a musket ball in her left thigh. The historian Alfred F. Young found accounts that put the wound in her shoulder or her chest.

**The musket ball story.** The story that she cut a musket ball out of her own thigh, so no army surgeon would find out she was a woman, comes from a book Herman Mann printed about her in 1797. The New England Historical Society calls Mann's book "a poor history," because he added a great deal that he imagined.

**Known:** Sampson was wounded in combat.

**Not known:** how, where on her body, or when. The accounts differ on all three.

A doctor treating her for a fever in Philadelphia found out she was a woman. General Henry Knox gave her an honorable discharge in October 1783, a record that she had served well. In 1785 she married Benjamin Gannett of Sharon, Massachusetts, and they had three children.

Paul Revere visited her at Sharon in 1804 and wrote to her congressman to support her claim for a soldier's pension. She went on the federal pension list in 1805. In 1806 she wrote to Revere asking to borrow ten dollars. She died in 1827. Ten years later, members of Congress voted to pay her husband, who had outlived her, for her service. He died before the money reached him.

### St. Clair and Fallen Timbers, 1791 to 1794

Several Native nations north of the Ohio River joined in a confederacy, an alliance of nations, and fought US soldiers from 1785 to 1795. General Arthur St. Clair led about 2,000 men north from the Ohio River in 1791. They were a mix of militia, volunteers signed up for six months, and regular soldiers.

On the way, volunteers whose six months were up went home. About 60 militiamen ran off. St. Clair sent 300 regular soldiers back to guard his food supplies, and about 1,400 men were left on November 3.

**The Wabash.** The next day, on the Wabash River, more than 1,000 fighters under the Miami leader Little Turtle attacked St. Clair's camp. More than 900 of the army's soldiers, and the women and children traveling with them, were killed or wounded. That count comes from a US Army history article, and other counts split the dead and wounded differently. Most were left where they fell.

Members of Congress held their first special investigation ever into what went wrong, and they cleared St. Clair. President Washington then put General Anthony Wayne in charge of a new force called the Legion of the United States. Its soldiers drilled over and over until they could march and fight together.

Wayne's soldiers beat the Native confederacy at Fallen Timbers, in what is now Ohio, on August 20, 1794, in less than an hour and a half. US Army historians trace today's regular army back to the Legion.

**If you remember one thing:** In the Revolution, disease killed about two and a half American soldiers for every one killed in battle, and thousands of those who died of it were prisoners.

- 1763: Officers at Fort Pitt hand two Lenape men blankets from the smallpox hospital.
- 1777 to 1778: Nearly 2,000 people die of disease in the winter camp at Valley Forge.
- March 8, 1782: Pennsylvania militiamen kill 96 Christian Lenape and Mohican people at Gnadenhutten, and no one is charged.

**Next:** The new country's army fought Britain once more, then Mexico, and Native nations again and again on their own land.

## 1800 to 1850

**Era 6 of 10 · 1800 to 1850 · about 13 minutes**

US soldiers went to war with Britain and with Mexico between 1800 and 1850, and they fought Native nations again and again on the nations' own land, from the Creek in Alabama to the Sauk in Illinois and the Seminole in Florida.

The army's officers now trained at a school of their own. President Thomas Jefferson signed the law that set up the US Military Academy at West Point, New York, on March 16, 1802. US soldiers fought the British from 1812 to 1815 and Mexico from 1846 to 1848, and they marched into Mexico City in September 1847.

**Disease again.** In the war with Mexico and in the Second Seminole War, disease killed most of the soldiers who died. For the war with Mexico, Defense Department records list 1,733 American soldiers killed in battle and 11,550 dead of other causes. About seven of every eight American dead died of something other than enemy fire.

### Why Madison asked for war in 1812

President James Madison asked Congress for war with Britain on June 1, 1812, and listed three complaints. The first was impressment: British navy officers stopped American ships, took off sailors they said were British, and forced them to serve on British warships. The second was British orders that blocked trade by countries outside the war, including the United States. The third was that British officials encouraged Native nations to attack American settlers in the West.

The members of the House voted for war 79 to 49, and the senators voted 19 to 13, the closest votes on any declaration of war in US history. Madison signed the declaration on June 18, 1812.

**Washington burns.** British soldiers beat the American defenders at Bladensburg, Maryland, on August 24, 1814, and marched into Washington. Their commanders, Major General Robert Ross and Rear Admiral George Cockburn, had their men set fire to the Capitol, the President's House and the Treasury. Madison and many people in the city had already fled.

**Fort McHenry.** Three weeks later, British warships fired between 1,500 and 1,800 shells at Fort McHenry, which stood between the British navy and the city of Baltimore. The shelling lasted 25 hours, starting at 6 in the morning on September 13. The shells killed four men in the fort and wounded 24. Major George Armistead and his men held the fort, and the British ships sailed away.

Francis Scott Key watched the attack from an American ship in the harbor. He had gone to the British fleet to get a prisoner released, and the British would not let him go back to Baltimore until the battle was over. He wrote the verses that became "The Star-Spangled Banner."

**New Orleans.** American and British diplomats, officials sent to make the peace, signed a treaty to end the war at Ghent on December 24, 1814. The news did not reach New Orleans until March.

Before it came, on January 8, 1815, British soldiers under Edward Pakenham attacked General Andrew Jackson's lines outside the city. Jackson's force included frontiersmen from Tennessee and Kentucky, free Black soldiers, Choctaw fighters, and Louisiana militia, part-time citizen soldiers. Jean Lafitte's privateers, ship crews allowed by a government to attack enemy ships, fought with them too.

Of 3,000 British soldiers in the main attack, about 2,000 were killed, wounded or captured in less than 30 minutes. Pakenham rode forward to rally them, was hit by American fire, and died of his wounds. Counts of the British dead run from 285 to about 700. Jackson's side lost 13 killed.

For the whole war, Defense Department records list 2,260 Americans killed in battle and 4,505 wounded. They list no count of soldiers who died of disease.

### The Creek War, 1813 to 1814

While US soldiers fought the British, a second war began in the South, on the land of the Creek, or Muskogee, people, in what is now Alabama and Georgia. It started as a war among the Creek themselves, between Creek towns friendly to the United States and a group from the Upper Towns called the Red Sticks.

Mississippi militia ambushed Red Sticks at Burnt Corn Creek on July 27, 1813, as the Red Sticks came home with ammunition from the Spanish at Pensacola. A month later, on August 30, Red Sticks attacked Fort Mims, a stockade, or fort with a wall of upright logs, north of Mobile. They killed 250 Creek and American settlers there. Tennessee's governor then sent Andrew Jackson with Tennessee militia into Creek country.

**Horseshoe Bend.** Jackson's army of about 3,300 men attacked the Red Sticks' walled town of Tohopeka, at Horseshoe Bend on the Tallapoosa River, on March 27, 1814. The army included Tennessee militia, US soldiers, and Cherokee and Lower Creek allies. About 1,000 Red Sticks under Chief Menawa held the town.

Jackson's army killed more than 800 of them. Soldiers counted 557 bodies on the battlefield, and soldiers led by a man named Coffee shot an estimated 300 more in the river as they tried to swim away. Jackson's side lost 49 killed and 154 wounded. Cherokee and Lower Creek fighters took about 350 Upper Creek women and children prisoner.

Menawa was wounded seven times. He lay among the dead until dark and escaped in a canoe. Later in 1814, in the Treaty of Fort Jackson, US officials made Creek leaders give up land. An Encyclopedia of Alabama article states more than 21 million acres, and a National Park Service page states 23 million.

### The Arikara towns and the Bad Axe, 1823 and 1832

The Arikara, whose towns stood on the Missouri River in present-day South Dakota, fought US soldiers in 1823. Arikara men attacked a party of fur traders led by William Ashley below their towns on June 2, 1823, and killed twelve or thirteen of Ashley's men. Colonel Henry Leavenworth came in August with about 230 soldiers of the 6th Infantry, an army unit of foot soldiers. Fur trappers and about 750 Lakota and Yankton allies came with him.

They attacked the towns with cannon. After a peace was signed, the Arikara left their towns at night. As the soldiers marched away on August 15, two men of the Missouri Fur Company set the empty towns on fire. No reliable count of the Arikara dead survives.

**Black Hawk.** The Sauk leader Black Hawk led about 1,000 Sauk, Meskwaki and Kickapoo people back across the Mississippi River into Illinois in April 1832. US officials said the Sauk and Meskwaki had signed the land away in an 1804 treaty, and Black Hawk rejected that treaty. About 7,000 US soldiers and militiamen went out against his band. Abraham Lincoln served as a militiaman in this war.

**The Bad Axe.** By August the band, perhaps 500 men, women and children, was trying to cross back over the Mississippi near the Bad Axe River, in present-day Wisconsin. Soldiers aboard an army steamboat, the *Warrior*, under Captain Throckmorton, fired on them on August 1. The next day about 1,300 soldiers and militiamen under Brigadier General Henry Atkinson attacked the people still on the east bank.

A Wisconsin Historical Society marker put up in 1955 states that the people were "driven into the water by their pursuers." There, it states, "warriors, old people, women and children" were "shot down or drowned as they tried to escape." Illinois governor Thomas Ford later estimated 150 killed, as many drowned, and 50 taken prisoner.

About 70 people reached the far bank, where Dakota fighters, allies of the United States, captured or killed them. Neither the marker nor Ford's account names the men who fired on the people in the water.

### The Second Seminole War, 1835 to 1842

US soldiers fought for seven years to force the Seminole out of Florida and west to Indian Territory, now Oklahoma. The Seminole had taken in people who escaped slavery in Georgia, South Carolina and Florida, and that turned slaveholders and army officers against them.

**Dade's column.** About 180 Seminole fighters led by Micanopy, Alligator and Jumper attacked Major Francis Dade's column of soldiers on December 28, 1835, on the road from Fort Brooke to Fort King. They killed almost all the soldiers in the column. A Florida Department of State history page states that one soldier survived, and other accounts count two or three.

**Osceola.** General Thomas Jesup ordered soldiers to seize the Seminole leader Osceola near St. Augustine in October 1837, while Osceola was meeting them under a white flag of truce, the sign that both sides agree not to fight while they talk. A National Park Service history describes a "public outcry" against Jesup's "dishonorable ploy," meaning a trick that broke the rules of honor. Soldiers then took Osceola and 237 of his people to Fort Moultrie in South Carolina. He died there as a prisoner on January 30, 1838.

More than 1,500 US soldiers had died in the war by 1842, most of them of disease, and US officials had spent more than $20 million on it. The National Park Service gives no count of the Seminole dead for the whole war. Its page gives one rate instead: for every four Seminole people the soldiers forced out of Florida, they killed one.

### The Mexican War, 1846 to 1848

Texas became part of the United States in 1845, and Mexican officials claimed the strip of land between the Nueces River and the Rio Grande. President James K. Polk sent soldiers under General Zachary Taylor into that strip in 1846. An article in the Colorado Encyclopedia states that Polk "goaded" Mexico into war this way, meaning he pushed Mexico into starting the fighting.

Mexican soldiers under Brigadier General Anastasio Torrejón surrounded a US patrol of cavalry, soldiers on horseback, under Captain Seth Thornton on April 25, 1846. The patrol surrendered. Mexican officials said Thornton's men were the invaders.

Polk told Congress that Mexico had "shed American blood upon the American soil." House members voted for war 174 to 14 and senators 40 to 2, and Polk signed the declaration on May 13, 1846. Ulysses S. Grant, a young officer who fought in the war, later wrote that he regarded it "as one of the most unjust ever waged by a stronger against a weaker nation."

**Veracruz.** US soldiers won at Monterrey in September 1846 and at Buena Vista in February 1847. General Winfield Scott's guns fired more than 6,700 shells into the Mexican port city of Veracruz over four days in March 1847, and the city's defenders surrendered on March 29. One count, in a HistoryNet article, states about 100 Mexican civilians, 80 Mexican soldiers and 13 Americans dead there. Other counts run higher. Scott's soldiers then fought their way inland and took Mexico City in September 1847.

**Civilians.** American soldiers also killed Mexican civilians. Early in 1847, near Saltillo, Mexican ranchers dragged an Arkansas private, Samuel Colquitt, to death. Arkansas volunteers from Captain C. C. Danley's company and another company then found the civilians they believed were guilty and shot between 17 and 30 of them.

General Taylor was furious. He threatened to send the two companies back to the Rio Grande to do hard labor, and he did not, because the Mexican general Santa Anna's army arrived. No one counted all the Mexican civilians killed in the war.

**The surgeons.** Army surgeons had to cut off an arm or leg shattered in battle, an operation called amputation. In the spring of 1847 they used anesthetics in battle for the first time, drugs that put the patient to sleep so the patient feels no pain. Most of the men who died, though, died of dysentery, the gut infection that causes bloody diarrhea, or of yellow fever and malaria, fevers spread by mosquitoes.

**The treaty.** Mexican officials signed the Treaty of Guadalupe Hidalgo on February 2, 1848. Under it they gave up 55 percent of Mexico's land, more than 525,000 square miles, to the United States, and US officials agreed to pay the Mexican government $15 million. That land became California, Nevada, Utah, Arizona, New Mexico and much of Colorado. In the 1840s, Comanche, Apache and Ute people controlled much of Mexico's northern lands, including part of this land.

About 78,700 Americans served in the war and 13,283 died, about one in six. By an estimate quoted on Smarthistory, an education website, about 25,000 Mexican soldiers died.

### John Riley

> **Who:** An Irish-born US Army sergeant who crossed to the Mexican side before the war began and led a unit of deserters, the San Patricios, against the US Army.
>
> **When and where:** Company K, 5th US Infantry. Crossed the Rio Grande in the spring of 1846. Captured at Churubusco, near Mexico City, August 20, 1847.
>
> **Movie:** *One Man's Hero* (1999), a feature film about him, with Tom Berenger as Riley. It is a drama, not a documentary.

**Army officers hanged fifty of his men and branded his face.**

John Riley had trained West Point cadets to fire cannon. In the spring of 1846, before members of Congress declared war, he crossed the Rio Grande and joined the Mexican army, which made him a deserter, a soldier who leaves his army without permission. He organized other deserters into the San Patricio Battalion, a unit of a few hundred soldiers named in Spanish for Saint Patrick. Many of the men were Irish immigrants, and many were Catholic.

A National Park Service page lists their reasons. American officers treated Catholic soldiers with "anti-Catholic bigotry and brutal discipline," bigotry meaning hatred of people for who they are or what they believe. A Smithsonian article states that officers quite often forced Catholic soldiers to attend Protestant services.

Some men were against the war. Mexican officials offered land to foreigners who joined them. Some San Patricios were escaped slaves and free Black men, who saw Mexico, where slavery was against the law, as freer than the United States.

The San Patricios fought at Monterrey, Buena Vista, Cerro Gordo and Churubusco. At Churubusco on August 20, 1847, US soldiers captured between 75 and 80 of them. Army officers tried 72 as deserters in two mass courts-martial, or military trials, held 3 and 6 days after the capture. The men had no lawyers, and no one wrote down what was said.

**The hangings.** Army officers hanged fifty of them, at San Angel on September 10 and at Mixcoac on September 13, 1847. On September 13, Colonel William Harney hanged 30 of them within sight of Chapultepec Castle as the US flag went up over it. He left their bodies on the gallows to rot.

**The whip and the iron.** Riley had deserted before the war was declared, so the court could not sentence him to death. Instead the officers of the court ordered him whipped with fifty lashes, blows from a whip on his bare back that cut the skin. They also ordered him branded. A metal letter D, for deserter, was heated red-hot and pressed into the skin of his face near the eye, and it burned a scar in the shape of the letter that he carried for life.

Some accounts say it was done to both cheeks. One says the first D went on upside down and a second D was burned on the right way up. The Texas State Historical Association and *American Heritage* accounts do not name the men who held the whip and the iron.

Riley stayed in the Mexican army after the war. Records of where he went stop a few years later, and the date of his death is not known.

**If you remember one thing:** The army fought its way to Mexico City and the country took more than half of Mexico's land, and disease killed most of the Americans who died on the way.

**One number:** 7 of every 8. That many of the American soldiers who died in the war with Mexico died of something other than enemy fire: 11,550 of disease and other causes, against 1,733 killed in battle.

**Next:** More American soldiers died in the Civil War than in any other war the country has fought, and sickness killed more of them than bullets did.

## 1850 to 1900

**Era 7 of 10 · 1850 to 1900 · about 21 minutes**

More American soldiers died in the Civil War, from 1861 to 1865, than in any other war the United States has fought. The Union was the United States government and the states that stayed loyal to it. The Confederacy was made up of Southern slave states whose leaders broke away.

**How many died.** Between 650,000 and 850,000 soldiers died in the Civil War. The historian J. David Hacker worked out that range in 2011 from census records, the government's counts of everyone in the country, from 1850 to 1880. His best estimate, about 750,000, is nearly twice the 405,399 Americans who died in World War II.

The long-used count was lower, about 620,000. The armies' own records count fewer still, because they are incomplete. The Union officer in charge of the draft, for example, counted only 133,821 Confederate dead in his final report.

**What killed them.** Disease killed more soldiers than bullets did. Union records list 140,414 Union soldiers killed in battle and 224,097 dead of disease and other causes. That is close to the rate an American Battlefield Trust article gives for the war: five deaths from disease for every three in battle.

Measles spread through the new army camps in 1861. In August that year Lee wrote, "The soldiers everywhere are sick." Army doctors recorded 79,462 cases of typhoid, an infection from bacteria in food or water that contains human waste. It causes high fever and stomach pain, and it can kill.

US soldiers fought the nations of the Plains and the West from the end of the Civil War until 1890. American sailors beat a Spanish fleet in Manila Bay, in the Philippines, in 1898, and American soldiers fought Spain in Cuba. A new war began in the Philippines in February 1899, between US soldiers and Filipino fighters led by Emilio Aguinaldo.

### The Civil War battles, 1861 to 1865

Confederate gunners opened fire on Fort Sumter, in the harbor at Charleston, South Carolina, at 4:30 in the morning on April 12, 1861. Over 34 hours they fired more than 4,000 shots and shells. Major Robert Anderson and the Union soldiers who held the fort surrendered it the next afternoon.

**Antietam.** The two armies had about 23,000 casualties, soldiers killed, wounded or missing, in twelve hours of fighting at Antietam Creek in Maryland, on September 17, 1862. More soldiers were lost at Antietam than on any other single day of the war.

**Gettysburg.** The Union army under George Meade and the Confederate army under Robert E. Lee had 51,112 casualties between them at Gettysburg, Pennsylvania, from July 1 to 3, 1863. About 7,000 of those men were killed. On the last day, Lee sent about 12,500 men to attack the Union soldiers on Cemetery Ridge, in the attack called Pickett's Charge. Close to 60 percent of them were killed, wounded or captured.

Ulysses S. Grant's army surrounded the river town of Vicksburg, Mississippi, for 46 days, in a siege that cut the town off until it gave up. On July 4, 1863, about 29,000 Confederate soldiers at Vicksburg marched out, stacked their rifles and surrendered to him.

### Who had to fight in the Civil War?

Officials on both sides drafted soldiers when too few men volunteered, and both drafts let richer men out. Members of the Confederate Congress passed their draft law first, on April 16, 1862. Under it, officials could draft any white man aged 18 to 35. On October 11, 1862, they passed the Twenty-Slave Law, under which any man who held twenty or more enslaved people did not have to serve. Drafted soldiers called it "a rich man's war."

**The Union draft.** Members of the US Congress passed the Enrollment Act on March 3, 1863. Army officers called provost marshals ran the draft. They drafted men in each district where too few had volunteered to fill the number of soldiers the army asked for. A drafted man could hire a substitute to go in his place, or pay a $300 fee and go home. In 1863, $300 could take the average person a whole year to earn.

Substitutes were often 18- or 19-year-olds too young to be drafted, or immigrants who were not yet citizens. People called it "a rich man's war and a poor man's fight." More than 20 percent of the men drafted did not report. Some fled west and some hid.

**The New York riots.** The draft began in New York City on Saturday, July 11, 1863. A rich man could pay his way out, and many New Yorkers were angry that poor men had to go instead. Many poor white workers, most of them Irish, also feared that if slavery ended, Black people would move to New York and take their jobs.

From Monday, July 13, to Thursday, July 16, mobs looted stores, burned a draft office, and attacked police and soldiers. Their main target was the city's Black people. The rioters lynched at least a dozen Black men, which means they killed them without any trial.

On Clarkson Street on July 13, a gang led by an Irish bricklayer, John Nicholson, beat a Black man named William Jones, who drove a cart for a living, hanged him and set his body on fire. The mobs burned homes and businesses. Rioters set fire to the Colored Orphan Asylum ("Colored" was a word used then for Black people), a home for Black children without parents, on Fifth Avenue with more than 200 children inside. All of the children got out.

The official count of the dead was 119, and the New-York Historical Society notes that many historians think more died. Union soldiers came from Gettysburg to stop the riots. Afterward many Black families moved to Brooklyn and New Jersey, and the number of Black people living in New York City fell by 20 percent.

### Why did surgeons cut off so many arms and legs?

Soldiers on both sides fired the minié ball, a soft lead bullet shaped like a cone, and it often flattened when it hit a body. It splintered bone, tore muscle, and drove dirt and bits of cloth into the wound. A surgeon could not mend an arm or leg smashed that way, so he cut it off. Three of every four operations in the war were amputations, close to 60,000 in all.

**The operation.** The surgeon first put the soldier to sleep with chloroform or ether. He tied a tight band called a tourniquet around the arm or leg to slow the bleeding, then cut through the skin with a knife called a scalpel and through the muscle with a long knife. Then he sawed through the bone. Last, he tied off the blood vessels and bandaged the stump.

Soldiers whose limbs were cut off within two days of the wound lived more often than those operated on later. Infection, loss of blood and poor food killed many of the men operated on later.

### Amos Humiston

> **Who:** A sergeant in the 154th New York Infantry, killed at Gettysburg. He was identified only because of a photograph of his three children found in his hand.
>
> **When and where:** Born in Owego, New York, April 26, 1830. Killed at Gettysburg, Pennsylvania, July 1, 1863. Identified in November 1863.

**A photograph of three children was all he had on him.**

Amos Humiston had made harnesses for horses and had sailed on a whaling ship from 1850 to 1854. He married Philinda Smith on July 4, 1854, and they had three children, Franklin, Alice and Frederick. He joined the army in July 1862 and was a sergeant by January 1863.

He was killed on the first day at Gettysburg. The records do not say what wound killed him. His body was found near the corner of Stratton and York Streets in the town. He had nothing on him to show who he was except a small photograph on glass, called an ambrotype, of three young children. He was buried as an unknown soldier.

**"Whose Father Was He?"** A doctor named John Francis Bourns had hundreds of copies of the photograph made. On October 19, 1863, editors at the *Philadelphia Inquirer* printed the story under that headline. In November, Philinda Humiston saw a copy and knew her children. Without the photograph, his grave in the Soldiers' National Cemetery would read "Unknown," like the graves of 979 other soldiers there.

In October 1866, his three children were among the first thirty children at a home for soldiers' orphans that opened in Gettysburg. A monument to Humiston went up on North Stratton Street in 1993. It is the only monument on the battlefield to a single enlisted soldier, meaning a soldier who was not an officer.

### The prison camps

**Why the camps filled.** Union and Confederate commanders traded captured soldiers under an agreement made in July 1862. In December 1862, Confederate President Jefferson Davis announced that captured Black soldiers and their white officers would not be traded. President Abraham Lincoln stopped the trades in the summer of 1863 because the Confederates would not include Black soldiers.

By August 1863, large trades had ended, and the prison camps filled up. By the end of the war, about 400,000 men had been held in more than 150 prisons.

**Andersonville.** Confederate officers opened a prison camp at Andersonville, Georgia, early in 1864. It was a walled pen of 26.5 acres, built for 10,000 men, and in August 1864 it held more than 33,000. One stream was the only water for most of them. About 19 feet inside the wall ran a line called the deadline, and guards had orders to shoot any prisoner who crossed it.

More than 45,000 Union soldiers were held there in 14 months. Almost 13,000 of them, more than one in four, died there under the Confederate officers who ran the camp, of disease, hunger, filth, crowding, and exposure to heat and cold.

A court of army officers found the camp's commander, Captain Henry Wirz, guilty of war crimes, acts that break the laws of war. The court sentenced him to death, and Union army officers hanged him in Washington on November 10, 1865. He was the only person put to death for war crimes in the Civil War.

**The Union camps.** Between 26,000 and 31,000 Confederate soldiers died in Union prison camps. At Elmira, New York, the barracks had no protection from the winter cold. Close to 3,000 Confederate prisoners died there, about one in four of the men held. An American Battlefield Trust article blames Colonel William Hoffman, the Union officer in charge of all prisoners.

At Camp Douglas, in Chicago, people from the US Sanitary Commission, a group that checked on the health of soldiers and their camps, reported standing water, filthy toilet trenches and "rotten bones." The camp's commanders cut the prisoners' food to make money for themselves. At Point Lookout, Maryland, more than 4,000 prisoners died.

### Fort Pillow, April 12, 1864

Black men who joined the Union army served in regiments, large army units, called the US Colored Troops. The Confederate general Nathan Bedford Forrest attacked Fort Pillow in Tennessee with about 1,500 men on April 12, 1864. The fort held 262 Black artillery soldiers, who fired the big guns, and 295 white Tennessee cavalrymen. Forrest's men took the fort and kept shooting soldiers who had surrendered. A witness told congressional investigators, "They killed all the men after they surrendered, until orders were given to stop."

Private George Shaw, a Black soldier, testified that a Confederate shot him after he surrendered, told him "You are fighting against your master," and threw him into the river. Shaw lived. He saw Confederate soldiers shoot three teenage boys who had escaped slavery in the forehead while the boys begged for their lives.

Forrest's men killed 182 of the Black soldiers that day or wounded them so badly that they died later, about 70 percent of them. A sign in the museum at the fort lists all 182 by name. About 20 percent of the white soldiers were killed. Forrest's men also killed some Black civilians, and no one knows how many. After Fort Pillow, Black soldiers went into battle shouting "Remember Fort Pillow."

### Christian Fleetwood

> **Who:** A Black man born free in Baltimore, who carried his regiment's flag through the attack at New Market Heights and received the Medal of Honor.
>
> **When and where:** Born in Baltimore, Maryland, July 21, 1840. Enlisted in the 4th US Colored Infantry, August 1863. New Market Heights, outside Richmond, Virginia, September 29, 1864. Died September 28, 1914.

**Two flag bearers fell, and he picked up the flag.**

Christian Fleetwood's parents were free. He graduated from the Ashmun Institute in Oxford, Pennsylvania, in 1860, and helped start the *Lyceum Observer*, an early Black newspaper in the South. When he enlisted in August 1863, his officers made him sergeant major, the regiment's top sergeant, because he was so well educated.

His regiment charged at New Market Heights on September 29, 1864. Two soldiers carrying the flag were shot down. Fleetwood picked it up and carried it forward under fire. In his diary that day he wrote that the regiment "got used up" and that he "saved colors," meaning the regiment's flag.

He was one of 14 soldiers of the Colored Troops who received the Medal of Honor, an award for bravery in battle, for that day. Every officer in his regiment asked Secretary of War Edwin Stanton to make Fleetwood an officer. Stanton refused.

After the war Fleetwood worked as a clerk in the War Department in Washington. He also organized a battalion of the District of Columbia National Guard and served as its major.

### Ulysses S. Grant and Robert E. Lee

> **Who:** The two commanding generals at the end of the Civil War. Lee led the Confederate Army of Northern Virginia from June 1862. Grant led all the Union armies from March 1864.
>
> **When and where:** Lee was born at Stratford Hall, Virginia, on January 19, 1807, and died in Lexington, Virginia, on October 12, 1870. Grant was born in Point Pleasant, Ohio, on April 27, 1822, and died on July 23, 1885. They met at Appomattox Court House, Virginia, on April 9, 1865.
>
> **Movie:** *Grant* (History channel, 2020), a documentary in three parts about Grant, with acted scenes.

**Wesley Norris said Lee had salt water poured into his cuts.**

Both men trained at West Point, where Lee finished second in the class of 1829 and Grant 21st of 39 in 1843, and both fought in the Mexican War. In 1854 Grant quit the army so he would not be thrown out, after heavy drinking at remote army posts in the West.

**Wesley Norris.** From 1857 Lee was in charge of 189 enslaved people on the estates of his dead father-in-law. Three of them ran away in 1859. They almost reached the Pennsylvania line, but at Westminster, Maryland, they were caught and jailed, and Lee was told. No surviving record names the men who caught them.

One of the three, Wesley Norris, gave his account in 1866. A county constable named Dick Williams, he said, whipped him and his cousin fifty times each and whipped his sister twenty times while Lee watched. Then, Norris said, Lee ordered the overseer to wash their backs with brine, very salty water, poured into the cuts.

**Harpers Ferry.** In October 1859, the year of the escape, Lee led the 90 US Marines who ended John Brown's raid at Harpers Ferry, Virginia. Brown and 18 of his men had seized the US Armory and Arsenal there, where the government made and stored guns, to fight a war against slavery.

Lee resigned from the US Army on April 20, 1861, after Virginia's leaders voted to leave the Union. On December 29, 1862, he signed the paper freeing the people enslaved on his father-in-law's estates, because the will required it. At Gettysburg on July 3, 1863, he ordered Pickett's Charge.

Grant took Fort Donelson in February 1862, after telling the fort's commander he would accept "no terms except an unconditional and immediate surrender." He took Vicksburg on July 4, 1863. In March 1864 he became a lieutenant general and the commander of every Union army.

**Appomattox.** Lee surrendered to Grant in Wilmer McLean's parlor at Appomattox Court House on April 9, 1865. Under Grant's terms, Lee's soldiers could go home once they signed a promise not to fight the United States again. The officers kept their side arms, the small weapons they carried, and their own horses and belongings. About 28,000 Confederate soldiers signed. Grant finished writing his memoirs a few days before he died of cancer in 1885.

**By 1865:** Lee had surrendered at Appomattox, and somewhere between 650,000 and 850,000 soldiers of the two armies were dead.

### Bear River, Sand Creek and the Marias, 1863 to 1870

During and after the Civil War, US soldiers attacked Native camps in the West where families were living through the winter.

**Bear River.** Colonel Patrick Edward Connor led the 3rd California Volunteer Infantry against a Northwestern Shoshone winter camp on the Bear River, near present-day Preston, Idaho, on January 29, 1863. He had announced that he did not mean to take prisoners. The soldiers attacked in the early morning and began firing without a word.

People jumped into the freezing river. A woman named Anzee Chee hid under the riverbank with other women, and she drowned her own crying baby so the soldiers would not find them. Yeager Timbimboo, a 12-year-old boy, lived by lying still among the dead.

Soldiers killed an estimated 250 to 500 Shoshone, and Connor was promoted to brigadier general for the attack. An article in Smithsonian magazine states that the attack "is often described as" the deadliest killing of Native people by US soldiers, with a death toll believed to be higher than at Sand Creek or Wounded Knee.

**Sand Creek.** Colonel John Chivington led about 675 Colorado volunteer soldiers against the Cheyenne and Arapaho camp of Black Kettle at Sand Creek, in Colorado, on November 29, 1864. Black Kettle's camp flew a US flag and a white flag. The soldiers killed about 230 people by the National Park Service's count, most of them women, children and old people. Soldiers cut off scalps and other parts of the bodies.

Captain Silas Soule and Lieutenant Joseph Cramer would not let their men fire. Soule put the number of dead at three hundred. He also wrote that it was "hard to see little children on their knees have their brains beat out by men professing to be civilized."

After Soule and Cramer sent their letters, army officers held an investigation and members of Congress held two more. Members of Congress's Joint Committee on the Conduct of the War wrote that Chivington "deliberately planned and executed a foul and dastardly (cowardly) massacre," a killing of many people who could not defend themselves.

Chivington left the army and was never tried, and no officer or soldier was punished. About two months after Soule testified against Chivington, on April 23, 1865, someone shot Soule dead on a street in Denver. No one was ever brought to justice for his murder.

**The Marias.** General Philip Sheridan sent Major Eugene Baker of the 2nd Cavalry against Mountain Chief's band of Piikani, or Piegan Blackfeet, in Montana in January 1870. "Tell Baker to strike them hard," Sheridan ordered.

At daybreak on January 23, Baker found a camp on the Marias River. His scout, Joe Kipp, told him it was the peaceful band of Heavy Runner. By one account, Baker answered, "That makes no difference, one band or another of them. They are all Piegans and we will attack them." He ordered a sergeant to shoot Kipp if Kipp warned the camp.

Heavy Runner came out of his lodge waving his paper of safe passage, and the soldiers shot him first. They knocked down lodges, the band's tent homes, with people inside them, set them on fire, and burned the band's winter food.

Army officers counted 173 dead. A later estimate, reported by HISTORY, is that the soldiers killed 37 men, 90 women and 50 children, which makes 177. Other counts run to more than 200. Baker took about 140 women and children prisoner. When he found smallpox among them, he left them with no food or shelter. Neither Baker nor his men were ever punished.

### The army in the West, 1866 to 1890

From 1866 to 1890, US soldiers fought the nations of the Plains and the West. US officials wanted the nations on reservations, land set aside for them, and soldiers attacked the bands that would not go.

**The Buffalo Soldiers.** Members of Congress created six regiments of Black soldiers in 1866, later merged into four: the 9th and 10th Cavalry and the 24th and 25th Infantry. They became known as the Buffalo Soldiers, and army commanders posted them west of the Mississippi River. Counts of how many of them received the Medal of Honor in the wars against the Plains nations run from 17 to 23.

**Little Bighorn.** An army expedition under George Armstrong Custer reported gold in the Black Hills in 1874. An 1868 treaty had promised the hills to the Lakota, and US officials ignored it. In December 1875 they ordered the winter camps off the reservation to come onto it by January 31, 1876, and then sent the army after the camps that stayed out.

Lakota and Cheyenne fighters killed Custer, the commander of the 7th Cavalry, beside the Little Bighorn River in Montana on June 25 and 26, 1876. They killed every man in the five companies, or groups of soldiers, under his own command. In all, 268 US soldiers and scouts died in the two days.

**The Nez Perce.** General Oliver O. Howard ordered Chief Joseph's band of Nez Perce to leave their homeland in the Wallowa country of northeast Oregon in 1877 and move to the reservation. Fighting began that June. About 750 Nez Perce people, about 200 of them fighters, fled from US soldiers from June to October. They covered about 1,170 miles and fought the soldiers again and again as they went. They surrendered at Bear Paw, in Montana, on October 5, 1877, 40 miles from Canada.

**Wounded Knee.** Soldiers of the 7th Cavalry under Colonel James Forsyth surrounded a Lakota camp at Wounded Knee Creek in South Dakota on December 29, 1890, and began taking away the Lakota's guns. The soldiers had four Hotchkiss guns, small cannon on wheels that fired exploding shells one after another, on a bluff above the camp.

A rifle belonging to Black Coyote, a deaf man, went off. Some accounts say he fired it, and others say it went off when a soldier grabbed it. Soldiers of the 7th Cavalry then killed between 250 and 300 Lakota, and almost half of the dead were women and children.

At least 25 soldiers died, and an article in Smithsonian magazine states that other soldiers' bullets likely hit many of them. Twenty soldiers of the 7th Cavalry received the Medal of Honor for that day.

### Cathay Williams

> **Who:** A woman born into slavery who enlisted in the army as William Cathay and served two years with a Black infantry regiment in the West.
>
> **When and where:** Born in Independence, Missouri. Enlisted at St. Louis, November 1866. 38th US Infantry, in Kansas and New Mexico. Discharged October 14, 1868. Applied for a pension in 1891 and was refused.

**Her papers said William Cathay, age 22, 5 feet 9 inches.**

Cathay Williams was born enslaved. During the Civil War, Union soldiers of the 8th Indiana Infantry freed her and took her as "contraband," the army's word for enslaved people who came under Union control. She worked for the regiment, washing clothes and cooking, and followed it to the battle of Pea Ridge in Arkansas and to the Shenandoah Valley in Virginia.

She enlisted at St. Louis as William Cathay in November 1866. She was sent to the 38th Infantry, one of the new Black regiments. She caught smallpox soon after she enlisted and recovered. Over two years she marched about 1,000 miles with her company, from Fort Riley in Kansas to Fort Bayard in New Mexico.

An army doctor at her post found out she was a woman in 1868. She was discharged on October 14 with a certificate of disability, a paper saying she was not fit to serve. In 1876 she told a St. Louis newspaper, "I played sick... The post surgeon found out I was a woman."

She asked for a pension, the regular payment a former soldier can get, as a disabled veteran in 1891. She had spent eighteen months in a hospital in Trinidad, Colorado, and had lost some of her toes. Officials at the Pension Bureau turned her down, even though her discharge papers recorded illness. The date of her death is not known.

### 1898, Cuba and the Philippines

From 1898 on, American soldiers fought most of their wars overseas. The US Navy ship *Maine* blew up in the harbor at Havana, Cuba, on February 15, 1898, and 266 of the 354 men aboard died. People still argue over the cause. Later in 1898, a court of navy officers blamed a mine. In 1976, a study led by Admiral Hyman Rickover found that a fire in a coal bin most likely set off the explosives stored next to it.

**San Juan Hill.** The Black soldiers of the 10th Cavalry fought at Las Guasimas, Cuba, on June 24, 1898, and again in the attack on San Juan and Kettle Hills on July 1. About one in five of them became casualties in that attack. The fighting with Spain stopped on August 13, 1898.

Typhoid killed more American soldiers in 1898 than Spanish soldiers did. Defense Department records list 385 Americans killed in battle in the war with Spain and 2,061 dead of other causes, most of them of typhoid. In the army's camps in the United States there were 20,738 cases of typhoid and 1,590 deaths.

**The Philippines.** Private William Walter Grayson of the 1st Nebraska Volunteer Infantry was standing guard in Manila on February 4, 1899. He fired the shot counted as the first of a new war, between US soldiers and Aguinaldo's fighters. US soldiers captured Aguinaldo in 1901, and President Theodore Roosevelt declared the war over on July 4, 1902, though fighting went on in places.

Historians at the State Department count more than 4,200 American and more than 20,000 Filipino fighters dead. They count as many as 200,000 Filipino civilians dead of violence, hunger and disease. Other estimates of the civilian dead run much higher, up to 1,000,000, and historians disagree about them. The State Department's history does not say how many of the civilians American soldiers killed.

**If you remember one thing:** More American soldiers died in the Civil War than in any other war, and after it US soldiers spent twenty-five years fighting the nations of the West.

**In 1861:** Americans were fighting each other in a war at home in which between 650,000 and 850,000 soldiers died, most of them of disease.

**In 1900:** American soldiers were fighting across the Pacific, in the Philippines, where as many as 200,000 Filipino civilians died by the State Department's count, and more by other counts.

**Next:** In the next fifty years more than 20 million Americans served in two world wars, and most of them were drafted.

## 1900 to 1950

**Era 8 of 10 · 1900 to 1950 · about 23 minutes**

Most of the Americans who fought in the two world wars were drafted. World War II was the first American war in which more of them died in battle than of disease, accidents and infections.

**Who they fought.** Members of Congress declared war on Germany in April 1917. German submarines had sunk American ships, and German officials had tried to draw Mexico into an alliance against the United States. American soldiers then fought on the side of the Allies, the countries already at war with Germany, among them Britain. In World War II the United States fought Japan, Germany and Italy, after Japanese pilots attacked Pearl Harbor in December 1941 and Germany and Italy declared war four days later.

**The two wars.** About 4.7 million Americans served in World War I, from 1917 to 1918, and 116,516 died, more of them of disease and accidents than in battle. More than 16 million served in World War II and 405,399 died, in counts that run from 1941 to 1946. These are the Defense Department's counts.

**The draft.** In World War I, 2.8 million men were drafted, which means they were ordered into the armed forces by law, and 2 million volunteered. In World War II about 10 million of the 16 million who served were drafted.

Military leaders kept Black service members in separate units until after President Harry Truman ordered equal treatment in 1948, and nearly every unit was mixed by about 1953. In 1945, American airmen dropped the first two atomic bombs used in war, on two cities in Japan. An atomic bomb gets its huge power from the tiny centers of atoms. One bomb could kill tens of thousands of people, and unlike other bombs it also gave off radiation, invisible energy that sickened and killed people for weeks afterward.

### What was the water cure?

The water cure was a torture American soldiers used on Filipino prisoners during the war in the Philippines. Soldiers held a man down and poured water into his mouth and nose until his stomach swelled. Then they pressed or stood on his stomach to force the water out, and started again.

**Igbaras.** Soldiers did this to Tobeniano Ealdama, the mayor of the town of Igbaras, on the island of Panay, on November 27, 1900. Captain Edwin Glenn, an army lawyer, oversaw it. Ealdama said later, "My stomach and throat pained me, and also the nose where they passed the salt water through." That night Glenn ordered the town's 400 to 500 houses burned.

A sergeant who had been there, Charles Riley, told a Senate committee about it on April 14, 1902. Army officers tried Glenn and found him guilty. His punishment was a $50 fine and one month in which he was not allowed to do his job. He retired in 1919 as a brigadier general.

**Samar.** Filipino fighters killed 48 of the 74 men in an American company at Balangiga, on the island of Samar, in late 1901. Brigadier General Jacob Smith then ordered Marine Major Littleton Waller to turn the island into a "howling wilderness." Smith told him, "The more you kill and burn, the better it will please me." Smith said he thought Filipino boys of ten were old enough to fight.

Waller had eleven Filipino guides and carriers shot without a trial. At his court-martial, a trial run by military officers, the officers voted 11 to 2 to find him not guilty. At Smith's own court-martial in 1902, officers reprimanded him, which means they scolded him officially. President Theodore Roosevelt then ordered Smith to retire from the army at once. The historian Paul Kramer writes, "The scale of abuses in the Philippines remains unknowable."

### The draft of 1917 and the men who refused

Members of Congress passed the Selective Service Act, the law for the World War I draft, on May 18, 1917. Men had to register on three days in 1917 and 1918, and by the end about 24 million men had filled out draft cards, about 23 percent of everyone living in the country in 1918.

Some drafted men refused to fight because their religion forbade it, and they were called conscientious objectors.

**The Hutterite brothers.** Three brothers, David, Joseph and Michael Hofer, and Joseph's brother-in-law Jacob Wipf were drafted in 1918. They were Hutterites, members of a Christian community in South Dakota that does not fight in wars. They refused to put on uniforms or obey military orders. Officers at a court-martial at Camp Lewis sentenced them to 20 years in prison.

**Alcatraz.** Soldiers took the four men, chained in pairs, to the military prison on Alcatraz Island on July 25, 1918. Guards put them in cold, wet cells in the basement. At first they got half a glass of water a day and no food.

Guards chained them standing to the cell bars with their hands crossed and pulled up high, so only their toes touched the floor. This was called high cuffing, and it strained their arms and shoulders until they swelled. After five days their arms were too swollen to put on their jackets. Duane Stoltzfus, a historian at Goshen College, writes that guards were reported to have beaten them with knotted whips as well.

Guards moved the four in chains to Fort Leavenworth, in Kansas, on November 19, 1918, after the fighting in Europe had stopped. Joseph Hofer died there on November 29, and Michael Hofer on December 2. Officials had Joseph's body dressed in the army uniform he had refused to wear.

The prison doctor listed pneumonia, a sickness that fills the lungs with fluid, during the flu outbreak in the prison. The Hutterite church's record states that they died "as a result of cruel mistreatment by the United States military." On December 6, 1918, Secretary of War Newton Baker ordered an end to chaining prisoners to cell bars.

### Houston, 1917

Army leaders sent 654 Black soldiers of the 3rd Battalion, 24th Infantry, to guard the building of Camp Logan outside Houston, Texas, in July 1917. People in Houston insulted them with racial slurs every day.

Houston police arrested a Black soldier on August 23, 1917, after he questioned the arrest of a Black woman. When Corporal Charles Baltimore asked about it, police beat him, shot at him and held him. A false report that he had been killed spread through the camp.

About 150 soldiers took rifles and marched into the city. About 20 people died. Townspeople, police officers and National Guardsmen were among them, and so were soldiers of the 24th whom other soldiers of the 24th shot by accident. The Department of Veterans Affairs history of that night does not say who shot each of the others.

**The trials.** Army officers charged 118 soldiers with disobeying orders, mutiny (refusing orders as a group), trying to kill and murder. The officers found only eight not guilty. At sunrise on December 11, 1917, they hanged the first 13 men sentenced to death. They did it in secret, within a day of the sentence, and did not tell the War Department.

After protests, War Department officials ordered that every death sentence be reviewed first. At later trials, officers sentenced 16 more men to death, and President Woodrow Wilson changed ten of those sentences to prison terms. In all, army officers hanged 19 soldiers. Most of the others got life in prison. Only Black soldiers were sentenced to death.

The Secretary of the Army canceled all the convictions in 2023 and changed the men's records to honorable discharges, which show that a soldier left the army in good standing. The Army's reviewers found that the soldiers "were wrongly treated because of their race and were not given fair trials."

### The Meuse-Argonne, the flu and the Choctaw code talkers, 1918

More than a million American soldiers fought in the Meuse-Argonne, in northern France, from September 26 to November 11, 1918. By the National Archives' count, 26,277 of them were killed and 95,768 were wounded. An Air Force Times report on the battle's 100th anniversary called it "America's deadliest battle ever."

**The flu.** Influenza, the flu, spread through the army camps and troopships in 1918. Most of the soldiers it killed in army hospitals died of the pneumonia that followed it, and some died within hours. A sailor on one troopship to France remembered 15 burials at sea in one day.

Eric Durr, writing on the Army's website, counts about 45,000 soldiers dead of flu and pneumonia by the end of 1918. That is more than the 26,277 killed in the Meuse-Argonne. A narrower count, of soldiers admitted to army hospitals for flu, is 24,664 deaths.

**The Choctaw code talkers.** German soldiers were listening in on American telephone lines. On October 26, 1918, officers of the 142nd Infantry had Choctaw soldiers send orders over the phone in the Choctaw language, and the Germans could not understand them. The soldiers made up code words. Artillery, the big guns, was "big gun," and a machine gun was "little gun shoot fast."

Nineteen Choctaw soldiers are honored today as these code talkers. Their work was kept quiet until the late 1980s. Some of them had signed their enlistment cards as "natural born citizens." In 1901 members of Congress had changed the law to make the Choctaw citizens of the United States, along with four other nations in Indian Territory, now Oklahoma: the Cherokee, Chickasaw, Seminole and Creek. Many other Native people did not become citizens until a law of 1924.

### Henry Gunther

> **Who:** A drafted bank clerk from Baltimore, whom General John Pershing's army listed as the last American soldier killed in World War I.
>
> **When and where:** Born in Baltimore, Maryland, in June 1895. Company A, 313th Infantry, 79th Division. Killed near Chaumont-devant-Damvillers, France, at 10:59 a.m. on November 11, 1918.

**He charged a German machine gun one minute before the fighting stopped.**

Henry Gunther kept the accounts at the National Bank of Baltimore when he was drafted in September 1917, and he was engaged to be married. By the time his regiment reached France in July 1918 he was a supply sergeant. Then army censors, who read soldiers' mail, opened a letter he had written to a friend. He complained about life in the trenches and told his friend not to join. He lost his rank and became a private again.

German and Allied leaders signed the armistice, the agreement to stop fighting, early on November 11, 1918. It would take effect at 11 a.m., and a runner brought word of it to Gunther's unit. At 10:59 Gunther charged a German machine gun with his bayonet locked onto his rifle. The German soldiers fired, and a bullet hit him in the left temple, the side of his head. He died there. The records do not say why he charged.

Army officials later gave him back his sergeant's rank and awarded him the Distinguished Service Cross, an army medal for bravery in battle. His body came home in 1923, and he is buried in Most Holy Redeemer Cemetery in Baltimore.

**By 1919:** The fighting in Europe was over, and 116,516 of the Americans who served had died, about 45,000 of them of flu and pneumonia.

### The Bonus Army, 1932

Members of Congress voted World War I veterans a bonus, an extra payment for their war service, in 1924, but set the payment date for 1945. In 1932, during the Great Depression, thousands of veterans came to Washington and camped there to ask for the money early. Counts of the veterans run from about 10,000 to more than 20,000. Counting their wives and children, a count in George Mason University's *Histories of the National Mall* reaches about 43,000 people.

Police clearing the camps on July 28, 1932, shot two veterans, William Hushka and Eric Carlson, and both died. Hushka was a butcher from Lithuania who had sold his shop to join the army and became a citizen while he served. He was buried at Arlington National Cemetery.

**Tanks and tear gas.** The same day, President Herbert Hoover ordered the army to clear the camps. General Douglas MacArthur, the army's chief of staff, sent soldiers with six tanks, and they drove the veterans out with tear gas and bayonets.

A National Park Service history states that the soldiers used torches to set the camps on fire, and accounts differ on who set the fires in the main camp, at Anacostia. Members of Congress voted to pay the bonus in 1936, over President Franklin Roosevelt's veto, his refusal to sign the law.

### The draft of 1940 and the objectors

President Franklin Roosevelt signed the Selective Training and Service Act on September 16, 1940, the first draft in the country's history in a time of peace. Every man aged 21 to 45 had to register. By 1945, 50 million men aged 18 to 45 had registered and 10 million had been drafted.

About 43,000 men registered as conscientious objectors. To be accepted as one, a man usually had to belong to a church that taught peace, such as the Quakers, the Mennonites or the Church of the Brethren. Of the 43,000, about 25,000 served in the armed forces without weapons, most of them as medics, and about 12,000 did unpaid work in Civilian Public Service camps. About 6,000 refused to cooperate with the draft at all and went to prison, and more than 4,400 of those were Jehovah's Witnesses.

### World War II, 1941 to 1945

Japanese Navy pilots attacked the US Navy base at Pearl Harbor, Hawaii, on December 7, 1941. They killed 2,403 Americans, counting the missing: 2,008 sailors, 109 Marines, 218 soldiers and 68 civilians. A Japanese bomb of 1,760 pounds hit the forward deck of the USS *Arizona* and set off an explosion. Of her crew, 1,177 died. More than 900 of them are still inside the sunken ship.

**A mess attendant.** Doris Miller was a mess attendant, a sailor who cooked and served food, on the USS *West Virginia* that morning. It was one of the few jobs Navy leaders let Black sailors do. Miller carried his dying captain. Then he fired a machine gun he had never been trained to use. Admiral Chester Nimitz gave him the Navy Cross, a navy medal for bravery in battle, in May 1942.

The crew of a Japanese submarine torpedoed his ship, the *Liscome Bay*, on November 24, 1943. The torpedo set off the bombs stored below deck, and the ship sank in about 23 minutes. About three of every four men aboard died, Miller among them. His body was never found.

**Bataan.** Major General Edward King Jr. surrendered about 75,000 American and Filipino soldiers on the Bataan Peninsula, in the Philippines, on April 9, 1942. Japanese soldiers marched them about 65 miles. The guards starved and beat the prisoners and stabbed with bayonets men who were too weak to walk.

By a Department of Veterans Affairs estimate, Japanese soldiers killed 650 American and 16,500 Filipino soldiers during and after the march, and other counts run higher. After the war, an American military court tried the Japanese commander, Lieutenant General Homma Masaharu. The court sentenced him to death, and American soldiers shot him on April 3, 1946.

**D-Day and Iwo Jima.** Soldiers of the Allies, the countries fighting Germany, landed in Normandy in France on June 6, 1944, called D-Day. Researchers at the National D-Day Memorial Foundation have found the names of 4,436 Allied soldiers, sailors and airmen killed that day. Of them, 2,519 were American, and the rest came from Britain, Canada and Norway.

On the Pacific island of Iwo Jima, from February 19 to March 26, 1945, 6,821 Americans were killed and 19,217 were wounded. Of about 21,000 Japanese defenders, 216 were captured. The rest were killed.

More than 350,000 American women served in uniform, in new women's branches of the Army, Navy and Marines.

### Soldiers in separate units

Black soldiers, sailors and airmen served in separate units. Black pilots trained at Tuskegee, and the 332nd Fighter Group, made up of these pilots, guarded American bombers flying over Europe.

**The bomber story.** Reporters began to write in March 1945 that the group never lost a bomber. That story is false. Daniel Haulman, an Air Force historian, counted the bombers lost: enemy planes shot down 27 bombers that the 332nd was guarding. The other fighter groups in the same air force lost 46 each, on average.

**Port Chicago.** Two ships being loaded with ammunition blew up at the Port Chicago Navy base in California on July 17, 1944. The explosion killed 320 men, and 202 of them were Black sailors. Navy officers had given the dangerous loading work to Black sailors without enough training or equipment.

Afterward, 258 sailors refused to go back to loading under the same conditions. Navy officers convicted fifty of them of mutiny. Thurgood Marshall, a lawyer for the NAACP, a group that works for Black Americans' rights, worked to get a higher court to look at their case again. In 2024, Navy Secretary Carlos Del Toro cleared the names of all the men who were punished.

**Japanese Americans.** After Japan's attack, Army leaders would not let Japanese Americans join the army. President Franklin Roosevelt signed Executive Order 9066, an order from the president that officials had to follow, on February 19, 1942.

Under it, federal officials forced more than 120,000 people of Japanese descent from their homes and locked them in camps behind fences and guard towers. Two thirds of them were American citizens. None of them was charged with a crime.

Army leaders dropped the ban on joining in 1943. From the camps, 1,208 people volunteered, fewer than 6 of every 100 who could. In Hawaii, where officials did not lock up Japanese Americans in large numbers, more than 10,000 volunteered. About 14,000 men served in the 442nd Regimental Combat Team, an army unit of Japanese American soldiers. They received 9,486 Purple Hearts, the medal for being wounded or killed in battle, and 21 Medals of Honor, the country's highest award for bravery in battle.

More than 375 Navajo Marines sent messages in a code built from the Navajo language. In it, a fighter plane was a "hummingbird" and a submarine was an "iron fish." Japanese code breakers never broke it. At Iwo Jima six Navajo code talkers sent more than 800 messages without an error. Military officials kept the code secret until 1968.

**Truman's order.** President Truman signed Executive Order 9981 on July 26, 1948. It required "equality of treatment and opportunity for all persons in the armed services without regard to race, color, religion or national origin." According to a National Park Service history, the labor leader A. Philip Randolph, who had threatened a protest march, pushed Truman to sign it. Military leaders were slow to obey it, and nearly every unit was mixed by about 1953.

### Benjamin O. Davis Jr.

> **Who:** Commander of the Black fighter pilots trained at Tuskegee, and the first Black general in the Air Force.
>
> **When and where:** Born in Washington, DC, December 18, 1912. West Point, 1932 to 1936. Commanded the 99th Fighter Squadron and the 332nd Fighter Group in Italy. Died July 4, 2002.

**For four years his West Point classmates spoke to him only on duty.**

Benjamin O. Davis Jr.'s father, Benjamin O. Davis Sr., was one of only two Black officers in the Army. The son entered West Point in 1932. For four years his white classmates spoke to him only when their duties required it. He never had a roommate, and he ate his meals in silence. He finished 35th of 276 in the class of 1936.

The Army had no Black flying units, so Army leaders made him an infantry officer, an officer of foot soldiers. When Army leaders opened pilot training for Black men at Tuskegee, he trained there and earned his pilot's wings in March 1942. He led the 99th Fighter Squadron and then the 332nd Fighter Group in combat.

Years later, Davis told the historian Alan Gropman that he himself doubted the claim that the group never lost a bomber. In 1998 President Bill Clinton made him a four-star general.

### Daniel Inouye

> **Who:** A Japanese American soldier from Hawaii who lost his right arm in Italy, and later a US senator.
>
> **When and where:** Born in Honolulu, September 7, 1924. 442nd Regimental Combat Team. Wounded near San Terenzo, Italy, April 21, 1945. Died December 17, 2012.

**With his left hand he pulled a live grenade from his right.**

Daniel Inouye wanted to become a surgeon. When he first tried to join the army, he was turned away under the rule that barred Japanese Americans. He enlisted in 1943, after Army leaders dropped the ban.

He led an attack up a ridge in Italy against three German machine guns on April 21, 1945. A bullet hit him in the stomach, and he kept going. Then, in his own words, a German "rifle grenade smashed into my right elbow and exploded. I looked at my dangling arm and saw my grenade still clenched in a fist that suddenly didn't belong to me anymore."

He pulled the live grenade out of his right hand with his left and threw it at the last machine gun. Then he was shot in the leg and passed out.

Surgeons at a field hospital cut off his right arm on May 1. Doctors had already given him so much morphine, a painkiller, that they could give him nothing to put him to sleep for the operation. He was given other people's blood 17 times. He left the army in 1947 as a captain and represented Hawaii in the US Senate for 50 years. On June 21, 2000, President Clinton gave him the Medal of Honor, with 19 other Japanese American veterans.

### Chester Nez

> **Who:** A Navajo Marine, one of the first 29 code talkers, who fought on four Pacific islands.
>
> **When and where:** Born in Chi Chil Tah, New Mexico, 1921. Guadalcanal, Bougainville, Guam and Peleliu, 1942 to 1944. Died in Albuquerque, June 4, 2014.

**Punished at school for speaking Navajo, he built a code in it.**

At his boarding school at Fort Defiance, school staff punished students, often by hitting them, for speaking Navajo. Marine recruiters came to the reservation in April 1942, and Chester Nez joined. He and 28 other Navajo Marines built the code at Camp Elliott in California.

He went into combat on Guadalcanal in November 1942, then on Bougainville. On Guam, in July and August 1944, he was wounded in the foot. He fought again on Peleliu in September 1944.

At home after the war he had nightmares and memories of combat that kept coming back, what doctors now call post-traumatic stress disorder. A Navajo healing ceremony for warriors, the Enemy Way, helped him. He finished high school, studied art at the University of Kansas on the G.I. Bill, a law under which federal officials paid for veterans' schooling, and worked 25 years for the Veterans Administration. He was the last of the first 29 when he died at 93.

**By March 1945:** Allied soldiers had been fighting in France since D-Day, and Marines were fighting on Iwo Jima.

### Tokyo, March 1945

Major General Curtis LeMay commanded the American B-29 bombers attacking Japan, and in early 1945 he changed their method. Instead of dropping ordinary bombs from high up in daylight, the planes flew low at night and dropped bombs made to start fires. Many were filled with napalm, gasoline thickened into a jelly, which sticks to whatever it lands on, including skin, and keeps burning.

B-29 crews in 279 planes dropped more than 1,665 tons of these bombs on Tokyo's neighborhoods of wooden houses on the night of March 9 to 10, 1945. The fires joined into one huge fire, called a firestorm, that used up the oxygen in the air. People suffocated or burned to death. Sixteen square miles of the city burned, and more than a million people lost their homes.

Historians at the National WWII Museum estimate 110,000 dead, and other estimates start at 80,000. That is close to the 116,516 Americans who died in all of World War I. Most of the dead were civilians. LeMay and his commander, General Hap Arnold, called the raid a success. American bomber crews firebombed many more Japanese cities after Tokyo.

### The atomic bombs, August 1945

Scientists and engineers of the Manhattan Project, the secret program to build the bomb, built the first atomic bombs at a cost of about $1.9 billion.

**The order.** General Thomas Handy, the acting Army chief of staff, gave the order on July 25, 1945, at the direction of the Secretary of War, Henry Stimson, and the Army chief of staff, George Marshall. He told General Carl Spaatz to have the 509th Composite Group, a bomber unit, drop the first bomb on a Japanese city as soon as the weather allowed. President Harry Truman approved.

The crew of the bomber *Enola Gay*, piloted by Colonel Paul Tibbets, dropped a bomb made with uranium, a heavy metal, on Hiroshima at 8:16 a.m. on August 6, 1945. On August 9, Major Charles Sweeney's crew dropped a bomb made with plutonium, a different heavy metal, on Nagasaki. Japan's leaders surrendered on August 14.

Scientists at the Radiation Effects Research Foundation, run by Japan and the United States together, estimate that 90,000 to 166,000 people in Hiroshima and 60,000 to 80,000 in Nagasaki died within four months. The exact numbers are not known. A US study in 1946, the Strategic Bombing Survey, gave lower counts: 70,000 to 80,000 dead in Hiroshima and more than 35,000 in Nagasaki.

Most of the dead were killed by burns from the flash of heat and by injuries from the blast. The same US study found that 15 to 20 percent died of radiation sickness.

**Radiation sickness.** The bombs gave off invisible energy called radiation, which killed the cells that make blood and line the gut. People with radiation sickness ran fevers within two days. After about two weeks their hair fell out, and they bled from the gums and nose and under the skin. Deaths from radiation began about a week after the bombs and were highest three to four weeks later.

### Coming home: the G.I. Bill and Isaac Woodard

President Franklin Roosevelt signed the G.I. Bill on June 22, 1944. Under it, federal officials paid for veterans' schooling and promised banks that the Veterans Administration would repay a veteran's home loan if the veteran could not. By 1956, 7.8 million of the 16 million World War II veterans, about one in two, had used it for school or job training. From 1944 to 1952, Veterans Administration officials made that promise on nearly 2.4 million home loans.

**Who got the loans.** Local white bank officers and real estate agents decided who got the loans. Reporters at *Ebony* magazine found in 1947 that of 3,229 of these home loans in 13 Mississippi cities, only two went to Black veterans.

**Isaac Woodard.** Police in South Carolina beat a Black veteran blind on the day he left the Army. Sergeant Isaac Woodard, of Winnsboro, South Carolina, left the Army on February 12, 1946, after four years of service. On the bus home from Camp Gordon, Georgia, he argued with the driver after asking for a rest stop. At Batesburg, South Carolina, the driver had police take him off the bus.

Woodard said that Police Chief Lynwood Shull and Officer Elliot Long beat him with blackjacks, which are short clubs, and tried to gouge out his eyes. Shull later said, "I hit him across the front of the head." A local judge fined Woodard $50. Doctors at the veterans' hospital in Aiken found bleeding in both eyeballs. He was blind for the rest of his life.

Federal officials charged Shull with violating Woodard's civil rights. In November 1946, an all-white jury found Shull not guilty after thirty minutes. Chapter 25, Rights and Movements, tells how his case reached President Truman.

**If you remember one thing:** World War II was the first American war in which more soldiers died in battle than of disease, and most of the men who fought it had been drafted.

**Left open:** The draft of 1940 was the first ever in a time of peace. Would young men still be drafted after the world wars were over? The next era answers it.

**Next:** American forces went to war in Korea in 1950 and in Vietnam in 1965.

## 1950 to 2000

**Era 9 of 10 · 1950 to 2000 · about 14 minutes**

American forces fought two long wars in Asia between 1950 and 2000, in Korea and in Vietnam. Drafted men fought in Vietnam until the draft ended in 1973, and after that everyone who joined the armed forces had volunteered.

**The dead.** By the Defense Department's counts, 36,574 Americans died in Korea, from 1950 to 1953, and 58,220 died in Vietnam. Many more people died in those wars: at least 2.5 million in the Korean War, most of them Koreans, and by Vietnam's own count about 3 million fighters and civilians in the Vietnam War.

About 697,000 American troops went to war against Iraq in 1991. The fighting lasted from January 17 to February 28, and 383 Americans died.

### Korea, 1950 to 1953

North Korean troops invaded South Korea on June 25, 1950, and American troops went to fight for the South. About 120,000 Chinese soldiers surrounded about 30,000 American and allied troops at the Chosin Reservoir in North Korea in November 1950. The temperature fell to 20 degrees below zero. The fighting at Chosin ended on December 13. Of about 8,000 Marines in the fighting, 836 were killed, and the survivors called themselves "The Frozen Chosen."

**No Gun Ri.** American soldiers of the 7th Cavalry Regiment fired on South Korean refugees, people fleeing from danger, in the last week of July 1950. The refugees had gathered at and under a railroad bridge near the village of No Gun Ri. Survivors say about 400 people died, and Korean officials have confirmed at least 163 dead or missing.

Army officers who reviewed the shooting said in January 2001 that they could not count the dead and found no order to shoot. That month President Bill Clinton said that "things were done which should not have been done." He expressed regret and did not apologize.

The historian Sahr Conway-Lanz found a letter in 2006 from the US ambassador, John Muccio, dated July 25, 1950. It said that refugees who kept coming toward American lines after warning shots "will be shot." The Army's report did not include the letter.

By the Korean War Legacy Foundation's count, 38 percent of the Americans taken prisoner in Korea died in captivity, more than one in three. The fighting stopped with an armistice signed on July 27, 1953. At least 2.5 million people died in the war, most of them Korean soldiers and civilians. No single official count exists.

### The hydrogen bomb tests, 1952 and 1954

Radioactive dust from American bomb tests after World War II sickened people who were not at war: Marshall Islanders, American service members and Japanese fishermen. American scientists and military officers tested nuclear weapons, the atomic bombs and the stronger bombs that came after them, in the Marshall Islands, in the Pacific, on the land of the Marshallese people.

**The first hydrogen bomb.** American scientists set off the first hydrogen bomb, a far more powerful kind of nuclear weapon, on Elugelab Island in Enewetak Atoll, a ring of small coral islands around a lagoon, on November 1, 1952. It was more than 450 times as powerful as the bomb dropped on Nagasaki. It destroyed the island and left an underwater crater 6,240 feet wide.

**Castle Bravo.** The test called Castle Bravo, at Bikini Atoll on March 1, 1954, was 1,000 times as powerful as the bomb dropped on Hiroshima, and two and a half times as powerful as its planners expected. A cloud 100 miles wide dropped fallout on Marshall Islanders, American service members, and the crew of a Japanese fishing boat. Fallout is radioactive dust and ash that falls back to the ground after a nuclear blast. It burns the skin it lands on and damages the body from inside when it is breathed in or swallowed.

The military had made no plans to move the people living nearby. On Rongelap, about 110 miles away, the fallout looked like snow, and children played in it. About three days after the blast, American crews took more than 230 people off Rongelap, Rongerik and Utirik, among them 28 American service members. The fallout left Rongelap unsafe to live on.

Twenty-three Japanese fishermen became sick, and one died. The physicist Theodore Taylor said later, "obviously we didn't irradiate (expose to radiation) the natives on purpose. Obviously, we didn't know what the hell we were doing."

**What followed.** American officials made the exposed Marshall Islanders the subjects of a secret medical study called Project 4.1. They told the people working on it not to discuss its purpose, "due to possible adverse public reaction," meaning for fear of how the public would react. The United States later gave the exposed people medical care. A screening from 1993 to 1997 found 57 cases of thyroid cancer, a cancer of a gland in the neck, among Marshallese people born before 1954.

### The war in Vietnam, and who had to go

Marines landed at Da Nang, South Vietnam, on March 8, 1965. By April 1969, about 543,000 American troops were in Vietnam. The deadliest year was 1968, when 16,899 Americans died there. The last American combat troops left on March 29, 1973. The war ended on April 30, 1975, when North Vietnamese troops and their allies in the South took Saigon, the capital of South Vietnam.

**Who had to go.** Counts of the men drafted during the Vietnam years run from about 1.8 million to 2.2 million. Full-time college students could get a student deferment, which put off their draft call while they stayed in school. Until 1969, local draft boards, the officials who chose which men in an area were drafted, called the oldest eligible men first.

**The lottery.** Selective Service officials, who ran the draft for the whole country, held a lottery instead on December 1, 1969. They put 366 birthdays in blue plastic capsules and drew them one at a time. The first date drawn was September 14, so men born on that day were called first. For 1970, the draft reached number 195.

Many men refused to go. Officials accused 209,517 men of breaking the draft law, and fewer than 9,000 were convicted. Some men fled to Canada. In 1972 more men were recognized as conscientious objectors than were drafted. The last draft call came on December 7, 1972, and the law allowing the draft ran out on June 30, 1973. Since July 1980, young men have had to register for the draft again, but no one has been drafted.

**The pardon.** Jimmy Carter pardoned, or officially forgave, the men who had broken the draft law between 1964 and 1973 on January 21, 1977, his first full day as president. His pardon left out crimes that involved force or violence, and it did not cover men who had deserted the armed forces after joining.

### Ron Kovic

> **Who:** A Marine from Long Island, paralyzed by a bullet in Vietnam, who came home and spoke against the war.
>
> **When and where:** Born July 4, 1946. Grew up in Massapequa, New York. Wounded in Vietnam on January 20, 1968.
>
> **Movie:** *Born on the Fourth of July* (1989), directed by Oliver Stone and based on Kovic's memoir. Kovic helped write the screenplay.

**The second bullet went through his shoulder and into his spine.**

Ron Kovic joined the Marines and then volunteered for a second tour in Vietnam, a second stretch of service there. On January 20, 1968, he was shot in the right foot. Then a second bullet went through his right shoulder. It collapsed one lung and cut into his spinal cord, the bundle of nerves inside the backbone that carries messages between the brain and the body.

From the middle of his chest down, he could no longer move. In the hospital at Da Nang, doctors told him he would never walk again.

He spent months at the Veterans Administration hospital in the Bronx, New York. *New Mobility* magazine describes the hospital as short of staff, with out-of-date equipment and conditions that were sometimes abusive. Patients called it "the Bronx Zoo."

He gave his first speech against the war in 1969. In 1972, at a protest at President Richard Nixon's campaign office in Los Angeles, he was thrown out of his wheelchair and arrested. The *New Mobility* account does not name who threw him. His book *Born on the Fourth of July* came out in 1976.

### Muhammad Ali

> **Who:** The heavyweight boxing champion, who refused to be drafted and won his case in the Supreme Court.
>
> **When and where:** Refused induction in Houston, Texas, April 28, 1967. Supreme Court decision, June 28, 1971.

**When an officer called his name, he would not step forward.**

Muhammad Ali was a minister of the Nation of Islam, a Muslim religious group. He asked his draft board to list him as a conscientious objector. The board said no, and so did the appeal board.

He went to the army's induction center in Houston, where new soldiers were sworn in, on April 28, 1967. When the officer called him, he stayed where he was. The officer warned him that refusing was a crime that could bring five years in prison and a $10,000 fine. Boxing officials took away his heavyweight title that day.

He was found guilty in a federal court of refusing the draft on June 20, 1967, and sentenced to five years in prison and a $10,000 fine. His lawyers appealed, and he did not box again for more than three years. On June 28, 1971, all eight justices who heard the case overturned his conviction. They ruled that the appeal board had never given a reason for turning down his claim.

### My Lai, March 16, 1968

American soldiers of Charlie Company, 1st Battalion, 20th Infantry, under Captain Ernest Medina, killed the unarmed people of My Lai, a village in South Vietnam, on March 16, 1968. The counts of the dead differ. The Army's own investigation, led by Lieutenant General William Peers, found at least 175 killed and possibly more than 400. Another Army count gives 347. A memorial in the village lists 504 names, from babies of one year old to a person of 82.

**What the soldiers did.** The Peers report describes it. Soldiers of the 1st Platoon herded 60 to 70 villagers into an irrigation ditch and shot them. In another part of the village, soldiers of the 2nd Platoon made 10 to 20 women and children squat in a circle, fired grenades into them, and then shot the wounded with rifles.

Soldiers raped women and girls, forcing them into sex by violence or threat. The investigators found that one platoon leader watched several rapes that day and did nothing to stop them. Soldiers also burned homes, killed farm animals and destroyed crops.

**The cover-up.** Officers at every level of the division took steps that kept the killings secret, and the story did not become public until late 1969. The Peers investigation named 30 men who knew about the killings. Fourteen of them were charged with crimes. Only one was convicted.

**Calley.** Lieutenant William Calley was tried at a court-martial. On March 29, 1971, a panel of six army officers found him guilty of murdering 22 people. Two days later, the same officers sentenced him to life in prison. Three days after the guilty verdict, President Richard Nixon ordered him held under house arrest, kept under guard in his own quarters.

Lieutenant General Albert Connor, the commander who reviewed the case, cut the life sentence to 20 years in August 1971. Secretary of the Army Howard Callaway cut it to 10 in April 1974. Calley was freed early on parole, under rules he had to follow, in November 1974. No one was convicted of rape.

### Hugh Thompson Jr.

> **Who:** An Army helicopter pilot who landed between American soldiers and Vietnamese villagers at My Lai to stop the killing.
>
> **When and where:** Born in Atlanta, Georgia, April 15, 1943. My Lai, South Vietnam, March 16, 1968. Died in Pineville, Louisiana, January 6, 2006.

**He set his helicopter down between the soldiers and the villagers.**

Hugh Thompson Jr. flew a small scout helicopter with two crewmen, Glenn Andreotta and Lawrence Colburn. Over My Lai that morning, he dropped green smoke next to wounded villagers as a signal that they needed help. When he came back, they were dead. He watched Captain Medina shoot a wounded young woman, and when he saw an irrigation ditch full of bodies he radioed, "There's something wrong here."

He landed, and Lieutenant Calley told him to mind his own business. Then Thompson saw soldiers chasing about ten villagers, some of them children, toward a shelter. He set his helicopter down between the soldiers and the villagers. He told Colburn and Andreotta to fire their machine guns at the soldiers if the soldiers shot at him or the villagers.

He got 11 people out of the shelter, and two other helicopter pilots flew them to safety. Andreotta climbed into a ditch of about 100 bodies and pulled out a living boy, Do Ba. Thompson flew the boy to a hospital and reported the killings. Medina then told his men to stop.

Andreotta was killed in combat three weeks later. In 1969 Mendel Rivers, the congressman who led the House Armed Services Committee, said Thompson was the one soldier at My Lai who should be punished, for threatening American soldiers. Thompson got death threats.

In March 1998, Army leaders gave all three men the Soldier's Medal, Andreotta after his death. It is the Army's highest award for bravery outside combat with an enemy. That year Thompson and Colburn went back to My Lai and met survivors.

### What the Vietnam War cost

Vietnamese officials published their first count of the war's dead on April 3, 1995. They said 1.1 million fighters of North Vietnam and of the Viet Cong, the communist fighters in South Vietnam who fought on the North's side, had died over 21 years, and nearly 2 million civilians in the North and the South. Between 200,000 and 250,000 South Vietnamese soldiers died, by the US military's estimate.

**Operation Homecoming.** American aircrews flew 591 American prisoners of war home from North Vietnam from February to April 1973. Many had been held in Hoa Lo prison in Hanoi, which the prisoners called the "Hanoi Hilton." The historian Andrew Lipps, quoted in a Defense Department news story, writes of the "mental and physical torture" they went through.

**Agent Orange.** American forces sprayed plant-killing chemicals over South Vietnam. One of them, Agent Orange, was tainted with a poison called dioxin. Today officials of the Department of Veterans Affairs treat a list of illnesses in veterans who were exposed to Agent Orange as caused by it, so the veterans do not have to prove it. The list includes several cancers, such as bladder cancer, lung cancer and prostate cancer, and also Parkinson's disease, type 2 diabetes and heart disease.

The Vietnam Veterans Memorial in Washington, designed by Maya Lin, opened in 1982. It lists 58,281 names. The count is higher than the Defense Department's 58,220 because the two lists count some deaths differently.

### Women and gay service members

Under a law signed on June 12, 1948, women could serve as permanent members of the armed forces. Under the same law, women could make up no more than 2 percent of the forces and could not serve in combat units. Members of Congress removed the cap in 1967. In July 1976, 119 women entered the Military Academy at West Point, and 62 of them graduated in 1980.

Under a 1993 law called "Don't Ask, Don't Tell," gay, lesbian and bisexual service members could serve only if they kept it secret. Military officials put more than 13,000 of them out of the armed forces under it before it ended in 2011.

### The Gulf War, 1991

About 100,000 Iraqi soldiers invaded Kuwait on August 2, 1990. American and allied pilots began bombing Iraq on January 17, 1991. The ground attack began on February 24 and lasted 100 hours, and President George H. W. Bush declared a cease-fire on February 28. About 697,000 American troops went to the region, and 383 died, 148 of them in battle.

No official US count of the Iraqi dead exists. In 2003, Carl Conetta of the Project on Defense Alternatives, a research group, estimated that American and allied forces killed 20,000 to 26,000 Iraqi soldiers and about 3,500 Iraqi civilians.

**Gulf War illness.** At least one in four of the American troops came home sick. In 2008 scientists on a committee advising the Department of Veterans Affairs found that 175,000 to 210,000 Gulf War veterans had an illness. Its signs were memory problems, headaches, pain all over the body, and stomach trouble. Doctors had found no treatment that worked, and few of the sick veterans had gotten better.

The committee's scientists linked the illness to pills the soldiers took to protect them from nerve gas, and to pesticides, the chemicals used to kill insects. Other scientists, on panels of the Institute of Medicine, weighed the evidence differently.

**If you remember one thing:** Drafted men fought in Vietnam, and after the draft ended in 1973 everyone who served had volunteered.

- July 1950: Soldiers of the 7th Cavalry fire on refugees under a railroad bridge at No Gun Ri.
- March 16, 1968: American soldiers kill the people of My Lai. Only Lieutenant William Calley is convicted, and he goes free on parole in 1974.
- June 30, 1973: The law allowing the draft runs out.

**Next:** Every American who fought in the wars after September 11, 2001, had volunteered.

## 2000 to Today

**Era 10 of 10 · 2000 to Today · about 11 minutes**

Every American who fought in the wars after the attacks of September 11, 2001, had volunteered. American forces fought in Afghanistan for almost 20 years and in Iraq for almost 9.

**Who served.** Researchers at the Pew Research Center found in 2011 that in the ten years after 9/11 about one American in 200 was on active duty, serving full-time in the military, at any one time. At the height of World War II it had been nearly one in 11.

**The dead.** A 2020 report to Congress, using Defense Department records up to July 2020, lists more than 2,400 American service members dead in the Afghanistan war and about 4,500 in the Iraq war. More than 53,000 were wounded in action in the two wars together.

Far more people in those countries died. Researchers in the Costs of War project at Brown University study the wars after 9/11 in Iraq, Afghanistan, Syria, Yemen and Pakistan. They estimate that more than 940,000 people in those countries were killed in the fighting itself from 2001 to 2023, and more than 432,000 of them were civilians. They estimate that 3.6 to 3.8 million more died because of what the fighting destroyed: the ways people earned a living, hospitals and health care, roads and water systems, and the land.

Counts of the Iraqi civilian dead differ widely. A 2006 survey published in the medical journal *The Lancet* estimated about 600,000 violent deaths, and US and Iraqi officials disputed it. Chapter 23, America and the World, explains why the counts are so far apart.

### Afghanistan and Iraq, 2001 to 2021

American bombing of Afghanistan began on October 7, 2001, less than a month after the September 11 attacks. The invasion of Iraq began on March 20, 2003. The last line of American military vehicles, carrying about 500 troops, left Iraq for Kuwait on December 18, 2011.

**Leaving Afghanistan.** American officials signed a deal with the Taliban in February 2020 and agreed to take American troops out of Afghanistan. The Taliban were the armed group American forces had fought there since 2001. President Joe Biden announced in April 2021 that the last of them would be out by September. Taliban fighters took Kabul, Afghanistan's capital, on August 15, 2021, and several thousand more American troops came to the airport to fly American embassy staff and some Afghans out.

**Abbey Gate.** A bomber from ISIS-K, a terror group in Afghanistan that was also fighting the Taliban, set off explosives he was wearing in a crowd at Abbey Gate, an entrance to the Kabul airport, on August 26. He killed 13 American service members: 11 Marines, a Navy medic and an Army soldier. Another 45 were wounded. US Justice Department officials said in 2025 that about 160 Afghan civilians were killed, and other reports say about 170.

**The drone strike.** Three days after the Abbey Gate bombing, on August 29, 2021, American forces fired a missile from a drone, an aircraft with no pilot aboard, at a car in Kabul. Officers believed it carried an ISIS-K bomb. The driver was Zemari Ahmadi, a 43-year-old aid worker, and the car was at his family's home. The missile killed ten civilians, seven of them children. The next night, at 11:59 p.m. on August 30, the last American plane left Kabul.

General Mark Milley first called it a "righteous strike." On September 17, 2021, General Frank McKenzie, the head of the military's Central Command, called it "a tragic mistake." On December 13, 2021, Defense Secretary Lloyd Austin decided that no one would be punished.

### Abu Ghraib, 2003 and 2004

American military police guarding prisoners at Abu Ghraib prison near Baghdad committed what an Army report calls "sadistic (taking pleasure in hurting people), blatant (done openly), and wanton (done for no reason) criminal abuses" of them, from October to December 2003. Army Major General Antonio Taguba investigated and wrote that report in 2004.

**What the guards did.** The report lists guards punching, slapping and kicking prisoners, jumping on their bare feet, keeping them naked for days, and forcing them into sexual poses to photograph them. Guards poured the liquid from broken glow sticks on prisoners.

Guards used dogs without muzzles to frighten prisoners, and in at least one case a dog bit a prisoner and badly hurt him. Guards also threatened prisoners with a loaded pistol, and attached wires to one prisoner to make him think he would be tortured with electricity.

The CBS program *60 Minutes II* broadcast the guards' photographs on April 28, 2004. Army officers at courts-martial convicted Specialist Charles Graner, who was sentenced to 10 years in prison, Private First Class Lynndie England, sentenced to 3 years, and other low-ranking soldiers.

### Haditha and Kandahar, 2005 and 2012

A roadside bomb killed Lance Corporal Miguel Terrazas, a 20-year-old Marine, in the Iraqi town of Haditha on November 19, 2005. Marines of Staff Sergeant Frank Wuterich's squad then shot five unarmed Iraqi men who had been ordered out of a car. Wuterich told his men to "shoot first and ask questions later." They broke into nearby houses with grenades and rifle fire. In about 45 minutes they killed 24 Iraqi men, women and children, among them an old man in a wheelchair. No weapons were found.

Military prosecutors charged eight Marines. They dropped the charges against six, and one was found not guilty at a court-martial. Wuterich pleaded guilty to one charge of neglecting his duty in January 2012. The judge sentenced him to 90 days, a pay cut and demotion to private, but under his plea deal, an agreement to admit a crime in return for a lighter punishment, he served no time in prison.

**Kandahar.** Army Staff Sergeant Robert Bales left his base in Kandahar, Afghanistan, on the night of March 11, 2012, and went into two villages, Alkozai and Najiban. He killed 16 unarmed Afghan civilians and wounded six more. Seventeen of the 22 people he shot were women or children, and eleven of the dead came from one family. Bales pleaded guilty, and on August 23, 2013, he was sentenced to life in prison.

### Pat Tillman

> **Who:** A professional football player who left the Arizona Cardinals to join the Army Rangers, and was killed by soldiers of his own platoon.
>
> **When and where:** Enlisted 2002. 75th Ranger Regiment. Killed in eastern Afghanistan, April 22, 2004. A committee of the House of Representatives held a hearing on his death on April 24, 2007.

**He called out "Cease fire" and his own name until he stopped.**

Pat Tillman walked away from a $3.6 million contract with the Arizona Cardinals after September 11, 2001. In 2002 he and his brother Kevin joined the Army together. Pat became a Ranger, a soldier of a specially trained Army unit, in the 75th Ranger Regiment, and served tours in Iraq and Afghanistan.

Soldiers in a truck from Pat's own platoon fired on the hillside where his group was on April 22, 2004, after what Kevin Tillman called "a small harassing ambush." The soldier beside him said later that they yelled "Cease fire. Friendlies." Tillman threw a smoke grenade, and the shooting stopped.

When the shooting started again, Tillman was hit. He called out "Cease fire" and his own name over and over until he stopped. Three bullets struck his forehead, so close together that Army medical examiners judged he was shot with an M-16 rifle from about 10 yards. An Afghan soldier with them was killed too.

**The first account.** His family was told that enemy fighters had killed him. In the words of Congressman Henry Waxman, who led the hearing, "the military told the world" the same thing. Army commanders awarded him the Silver Star, a medal for bravery in battle, with a written account of a battle with the enemy.

Kevin Tillman told Congress that Pat's uniform, equipment and notebook were destroyed, and his testimony does not name who destroyed them. On May 29, 2004, five weeks after the shooting, an Army general announced that Tillman had "probably" been killed by his own side. Kevin Tillman called the Army's first account "utter fiction."

### Wounds that do not show, and veterans at home

Military doctors diagnosed 535,544 service members with a traumatic brain injury, damage to the brain from a blow or a blast, from 2000 through 2025, according to a Defense Department count published in June 2026. About 83 percent were mild, most of them concussions, injuries in which a blow shakes the brain, and many happened in training or daily life, not in combat.

**Veteran suicides.** A total of 6,398 veterans killed themselves in 2023, an average of 17.5 a day, according to a report the Department of Veterans Affairs released in early 2026. That is nearly as many as the about 6,900 service members who died in the Afghanistan and Iraq wars together. Sixty-one percent of them had not received care from the department in the last year of their lives. The country had about 18 million veterans in 2023, about 6 of every 100 adults, the Pew Research Center found.

### Tammy Duckworth

> **Who:** An Army helicopter pilot who lost both legs when her Black Hawk helicopter was hit in Iraq, and later a US senator.
>
> **When and where:** Born in Bangkok, Thailand. Illinois Army National Guard. Wounded in Iraq, November 12, 2004.

**"The explosion vaporized my right leg," she wrote.**

Tammy Duckworth became an Army officer in 1992 and learned to fly helicopters. In 2004 she went to Iraq as a Black Hawk pilot with the Illinois Army National Guard, a part-time state army force that can be sent to war.

A rocket-propelled grenade, a small rocket fired from a tube carried on a fighter's shoulder, hit the front of her helicopter on November 12, 2004. In her memoir she wrote, "The explosion vaporized my right leg. It blew my left leg up into the bottom of the instrument panel." It also tore through her right arm.

Dan Milberg, the other pilot aboard, landed the damaged helicopter. Matt Backues, another member of the crew, dragged her, unconscious, across the desert. She lost both legs and part of the use of her right arm, and she recovered at Walter Reed Army Medical Center.

She was an assistant secretary of Veterans Affairs from 2009 to 2011. Illinois voters elected her to the US House in 2012 and to the Senate in 2016. In 2018 she became the first senator to give birth while in office.

### Who may serve

"Don't Ask, Don't Tell" ended on September 20, 2011, and gay, lesbian and bisexual service members could serve openly. Defense Secretary Ashton Carter opened every combat job to women on December 3, 2015. About 220,000 jobs, roughly one in ten, had been closed to them.

**Transgender service members.** The justices of the Supreme Court let President Donald Trump's ban on transgender service members take effect on May 6, 2025, while lawsuits went on. On June 1, 2026, judges of a federal appeals court in Washington ruled 2 to 1 that the ban likely broke the Constitution, and they blocked the discharge of the service members who had sued.

A few weeks later a judge of a lower court extended that protection to all transgender troops then serving, about 4,240 people by the count of the Gender Justice League, a group that works for transgender people's rights. New people were still not allowed to join. On August 28, 2026, Justice Department lawyers asked the Supreme Court to lift the lower court's order.

### The Wounded Knee medals and the Defense Department's name

Twenty soldiers of the 7th Cavalry received the Medal of Honor for Wounded Knee in 1890, where soldiers of the regiment killed between 250 and 300 Lakota people, almost half of them women and children. Defense Secretary Lloyd Austin ordered a review of those medals in 2024. In September 2025, Defense Secretary Pete Hegseth announced that the soldiers would keep them. A bill called the Remove the Stain Act, which would take the medals back, had not passed as of September 2026.

**The department's name.** President Trump signed an order on September 5, 2025, letting officials call the Defense Department the "Department of War." Members of Congress set its legal name. Members of the House voted 216 to 212 on July 22, 2026, to change the legal name, but as of late September 2026 the change had not become law.

### 2025 and 2026: boats, Venezuela and Iran

US military crews began firing on boats in the Caribbean Sea and the eastern Pacific on September 2, 2025. President Trump's officials said the boats were carrying drugs. By September 19, 2026, the Associated Press counted at least 231 people killed in 69 strikes. In at least one case, the Associated Press reported, military officials gave no evidence that the boat carried drugs.

Lawyers for the American Civil Liberties Union are suing for the families of two men from Trinidad, Chad Joseph and Rishi Samaroo, who were killed in a strike on October 14, 2025. The group says they were fishermen and farm workers.

**Maduro.** Soldiers of the Army's Delta Force and officers of the CIA, the American spy agency, captured Venezuela's president, Nicolás Maduro, and his wife, Cilia Flores, in the capital, Caracas, on January 3, 2026. They flew the two to a Navy ship, the USS *Iwo Jima*, and then took them to New York. The next day federal officials made public the charges against them, crimes tied to smuggling drugs. On January 5, in a federal court in New York, both said they were not guilty.

By the Council on Foreign Relations' account, American forces killed 32 Cuban officers in the attack. Members of Congress had not voted to approve the raid beforehand.

**Iran.** American and Israeli forces began bombing Iran on February 28, 2026, and Iranian forces fired back at American troops. By the Pentagon's public count on September 22, 2026, 19 American service members had died and more than 820 had been wounded. Five officials told the *Washington Post* that at least 22 service members had died in the Middle East since the war began, not all of them in the fighting. Chapter 23 gives a count of the people killed in Iran. The war was still going on in late September 2026.

**The three questions, answered**

- What killed most American soldiers before World War II? Disease. In the war with Mexico seven of every eight American dead died of something other than enemy fire, and in World War I flu and pneumonia killed more soldiers than the war's deadliest battle did.
- Who was made to fight, and who could get out of it? Drafts filled the armies of the Civil War, both world wars and Vietnam. In 1863 a drafted man could pay $300 and go home, and in the Vietnam years college students could put off the draft. Since 1973 everyone who serves has volunteered.
- Were soldiers who killed people who could not fight back ever punished? Rarely. No one was charged for killing 96 Christian Lenape and Mohican people at Gnadenhutten in 1782, and no one was tried for Sand Creek. Lieutenant William Calley, the only man convicted for My Lai, went free on parole in 1974.

**What changed:** The fighters changed from militia farmers, who went home when the fighting ended, to millions of drafted men in the world wars, to a small army of volunteers, about one American in 200.

**Five dates to keep**

- May 26, 1637: English soldiers burn the Pequot town at Mystic.
- April 19, 1775: The shooting starts at Lexington.
- July 1 to 3, 1863: The battle of Gettysburg.
- August 6, 1945: An American bomber crew drops an atomic bomb on Hiroshima.
- June 30, 1973: The law allowing the draft runs out.

**Not known:** Nobody knows how many Filipino civilians died in the war of 1899 to 1902, where the counts run from 200,000 to 1,000,000, or how many of them American soldiers killed.

**Where to go:** The Amos Humiston monument stands on North Stratton Street in Gettysburg, Pennsylvania, the only one on the battlefield to a single enlisted soldier.

**Next:** Chapter 23, America and the World. It asks how the country dealt with other nations, from treaties and alliances to the islands it came to rule.
