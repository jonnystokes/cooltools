**Part 5: Power, Law, and War**

# Chapter 20: Government, Law, and Politics

**Chapter 20 of 37 · Government, Law, and Politics · 10 eras · about 140 minutes**

**The rules of American government were written by people, and in every era people with power rewrote them, most often to decide who could vote and who could not.**

One copy of a report survives in the National Archives of the United Kingdom. John Pory wrote it in 1619. It records six days, July 30 to August 4, when twenty-two elected men sat in the church at Jamestown, Virginia, the only building on the island big enough to hold them all. They were the first elected lawmakers in English North America. They made rules about tobacco, gambling and land. No record says who voted for them.

This chapter follows the rules from that church to the Capitol on January 6, 2021. Watch three things as you read. Who may vote: the answer changes in nearly every era, and the people who changed it usually wrote down why. What judges may do: in 1803 the justices of the Supreme Court first cancelled a law, and they have been cancelling and allowing laws ever since. What happens to people in power who break the law: a governor in 1614, a cabinet secretary in 1929, a president in 1974.

The chapter also follows the laws about schools, which say where children must go and what they may be taught. From 1790 on, it tracks the laws on who may come to live in the country and who may become a citizen.

**Three questions this chapter answers**

- Who decided who could vote, and how did the answer change?
- When did judges first cancel a law, and what have they done with that power since?
- What happens when people in power break the law?

**Five minutes?** Read "The Zenger trial, 1735" in 1700 to 1750, then the John Peter Zenger and Andrew Hamilton stories after it.

**Can skip:** "Land for colleges, 1862", "The food laws of 1906", "New kinds of schools, 1991 to 1996", "Immigration law after 2001". The chapter still makes sense without them.

## Before 1500

**Era 1 of 10 · Before 1500 · about 5 minutes**

Long before Europeans arrived, the Native nations here governed themselves, and they did it in different ways. Most of this era is about the Haudenosaunee, five nations in the Northeast that joined in a league and lived under one law, because their own full telling of that law survives. Two short spans at the end cover the Pueblo towns along the Rio Grande, where each town ran its own affairs, and Cahokia, a city of thousands on the Mississippi River led by chiefs.

### How five nations at war made one law

The Haudenosaunee are a league of Native nations whose homelands lie mainly in what is now New York State and the Great Lakes region. Their name means "people who build a house." Five nations joined first: the Mohawk, the Oneida, the Onondaga, the Cayuga and the Seneca. The Tuscarora joined in 1722, which made six. Each nation stayed a separate nation inside the league.

The law that joined them is called the Great Law of Peace. In the Haudenosaunee account, the five nations were once at war with each other. A man called the Peacemaker wanted to spread peace among them. He came to the house of an Onondaga leader named Hayo'wetha, often written Hiawatha. When the nations made peace, they pulled up a white pine tree and threw their weapons into the hole. Then they planted the tree again on top of the weapons and named it the Tree of Peace.

The Haudenosaunee kept the Great Law in memory and passed it on by speaking it. A full telling takes several days. They also wove belts of purple and white shell beads, called wampum. The patterns in the belts recorded the laws of the league, the stories told at ceremonies, and important dealings with other nations. The belts were presented at meetings of the Grand Council, the league's lawmaking body. The Haudenosaunee used wampum to keep these records, and never as money.

**Known:** The league was in place before Europeans arrived.

**Disputed:** When it began. The dates people give run from about 1142 to the 1400s or 1500s.

### The Grand Council and the clan mothers

The league's lawmaking body is the Grand Council, and it has fifty seats. Each seat belongs to a leader called a *hoyaneh*. The Onondaga hold fourteen seats, the Cayuga ten, the Mohawk nine, the Oneida nine and the Seneca eight. Council members are not paid, and they serve for life.

The Haudenosaunee count the Onondaga Nation as the league's capital. They say the council fire burns there, as the Peacemaker promised, and they call the Onondaga the "Keepers of the Central Fire." The Mohawk, in the east, are the "Keepers of the Eastern Door," and the Seneca, in the west, are the "Keepers of the Western Door."

**How a law passes.** Before the council members pass a law, every member must agree to it. This way of deciding is called consensus. Under it, no law passes while even one member is against it.

Women hold power in this government through the clan mothers. A clan is a large group of related families. The members of a clan choose a clan mother together, and she serves for life. The clan mothers choose the council members. A clan mother can also remove any *hoyaneh* who does not serve the good of his nation.

**Did the Constitution borrow from this law?** In 1988 members of both houses of Congress voted for a resolution, a written statement that lawmakers vote on, which said yes. Representative Morris Udall put it forward. Its title states that it was meant "to acknowledge the contribution of the Iroquois Confederacy of Nations to the development of the U.S. Constitution." Iroquois is the more common English name for the Haudenosaunee, and a confederacy is a league of nations or states. The Constitution is the written plan for how the national government of the United States works.

Scholars disagree about how much the men who wrote the Constitution took from the Great Law. Bruce Johansen and Donald Grinde argue that the founders admired Native governments and borrowed ideas from them. Elisabeth Tooker, an anthropologist, a scientist who studies how peoples live, argued the other side. She wrote that the founders took their models from European ideas and that the evidence of borrowing from the league is very thin.

### The Pueblo towns

Groups of Spanish explorers began coming up the Rio Grande in 1540. They found farming peoples living in settled towns, which the Spanish called pueblos, the Spanish word for towns. The people of each town governed themselves. Each town had its own leaders, customs and language. No one leader or council ruled all the pueblos.

At Zuni, a council of priests held power over the town. One group of them, the bow priests, handled dealings with outsiders.

### Cahokia, a city led by chiefs

Cahokia stood near the Mississippi River, east of where St. Louis is now. The city covered more than 4,000 acres, and its largest years came between about 1050 and 1150. Archaeologists, the scientists who dig up what people left behind, disagree widely about how many people lived there then. Their estimates run from 10,000 to 20,000, and some go higher.

Cahokia was a chiefdom, a society led by chiefs and by officials of high rank. The people built large mounds of earth with flat tops. Buildings for religious leaders and for other officials stood on top of the mounds. Other mounds held the graves of people of high rank.

## The 1500s

**Era 2 of 10 · The 1500s · about 2 minutes**

The first governors of Florida and of New Mexico served the king of Spain. Pedro Menéndez de Avilés held his office in Florida by a contract with the king, who lived across the ocean in Spain. Juan de Oñate held his office in New Mexico by a contract with the viceroy, the official who ruled in the king's name from Mexico City. Menéndez used a Timucua council house as his first fort. Oñate made a Tewa town his first capital.

### A governor for Florida, 1565

Pedro Menéndez de Avilés founded St. Augustine, in Florida, on September 8, 1565. King Philip II of Spain had ordered the voyage. Menéndez held the title of *adelantado*, a Spanish office that a man received by signing a contract with the king. He soon became Florida's first governor. St. Augustine is the oldest European settlement in the mainland United States where people have lived without a break since its founding.

Menéndez made his first settlement in the town led by Seloy, a chief of the Timucua people. About 800 colonists came with him, among them 26 women and an unknown number of Africans whom the Spanish held as slaves. Timucua council houses were usually round, built of thatch, and big enough to hold up to a thousand people. Seloy offered Menéndez his council house to use as a fort, and the Spanish used it as their first fort in Florida.

Officials of the king of Spain set rules in 1573 for laying out new towns. The rules belong to a body of royal orders known as the Laws of the Indies. They required a town's streets to form a grid around a central square, or plaza. The main government buildings and the church were to face the plaza. St. Augustine's grid of streets was laid out in 1603, thirty-eight years after the town was founded.

### A governor for New Mexico, 1598

Juan de Oñate made a contract with the viceroy in Mexico City. He promised to settle New Mexico and govern it. In return he got loans, supplies and soldiers. He left the town of Santa Bárbara early in 1598 with 600 Spanish settlers and Native allies from Tlaxcala, in Mexico.

On the Rio Grande he set up his first capital at Ohkay Owingeh, a town of Tewa-speaking people. The Spanish named the town San Juan de los Caballeros in 1598. A year later Oñate moved his capital across the river to a place called San Gabriel. The people of Ohkay Owingeh still live in their town.

Oñate went to the pueblos one by one in the autumn of 1598. Through translators, he made the people of each pueblo swear loyalty to the king of Spain. He also placed a missionary, a priest sent to bring people into his religion, in each one. Oñate governed New Mexico until 1608. The next era tells what the king's judges later found he had done there.

## The 1600s

**Era 3 of 10 · The 1600s · about 10 minutes**

Spanish judges in Mexico City put a former governor of New Mexico on trial in 1614. The English built Jamestown, in Virginia, in 1607, and twelve years later twenty-two elected men met there as the first elected assembly in English North America. The next year, forty-one men aboard the *Mayflower* signed an agreement to make laws for themselves and obey them.

The colonists' own lawmakers decided who could vote, and they changed the rules many times. In 1662 Virginia's lawmakers passed a law that made every child born to an enslaved woman a slave as well. In Massachusetts, lawmakers made towns keep a school.

### What the judges found Oñate guilty of, 1614

Royal judges in Mexico City tried Juan de Oñate, the former governor of New Mexico, in 1614. Officials of the king of Spain had brought 30 charges against him. The judges found him guilty of 12 and not guilty of 18. They ordered him out of New Mexico for life and barred him from Mexico City for four years, or five, since accounts differ. They also fined him 6,000 ducats in the money of Castile, in Spain.

**The charges.** One of the twelve was using too much force against Acoma Pueblo. He was found guilty of it because of the sentences he gave the Acoma people after the fighting there in 1599. He was also found guilty of hanging two Native men without just cause, of the murders of two of his own captains, of ordering his captains to kill two soldiers who had run away from the army, and of lying to the viceroys and the king about how rich the land was.

**What happened at Acoma.** Oñate's nephew Juan de Zaldívar came to Acoma in December 1598 with about thirty soldiers. He took some of them up the mesa, the flat-topped hill where the town stands, to demand food. In the Acoma people's own account, the soldiers raped an Acoma woman. Rape means forcing a person into sex. The Acoma killed Zaldívar and eleven to fourteen of his men. Accounts differ on the number.

Oñate sent Juan's brother, Vicente de Zaldívar, to Acoma in January 1599 with about seventy soldiers. Over two or three days of fighting, those soldiers killed Acoma men, women and children, and they burned much of the town. No one counted the dead at the time.

**Known:** The soldiers killed hundreds of people. The Pueblo nations' own leaders use the figure of about 800.

**Disputed:** The count. Estimates run from about 300 to about 1,500, and PBS reports that about 200 people of Acoma survived out of nearly 2,000. Those figures come from different sources and do not fit together.

**The sentences.** Afterward Oñate sentenced the Acoma men over twenty-five to have one foot cut off, and to be forced to work as slaves of the Spanish for twenty years. Younger men and boys from twelve up, and women and girls over twelve, got the same twenty years of forced work. He handed the old people to the Plains Apache as slaves.

**The children.** He took the children under twelve from their families and gave them to the friars, the Catholic religious brothers with his colony. On Oñate's order, about 70 of the girls were sent to convents in Mexico, houses where nuns live. The National Park Service's account states that almost certainly none of the girls ever came home.

**The Hopi men.** Oñate also sentenced two Hopi men captured in the fighting to have their right hands cut off. Then he had them released to carry word of the punishment to their own people.

**The feet.** The sentences are in the written record. Whether the feet were cut off is disputed. In the Acoma people's own account, Oñate had the right feet of 24 captive men cut off. The historians Marc Simmons and John Kessell doubt that it was done, and Kessell points out that no record describes a one-footed Acoma man.

### The first General Assembly, 1619

The leaders of the Virginia Company of London, the business that ran the colony, put out a paper called the Great Charter in 1618. A charter is a written grant of rights and powers. Sir Thomas Smythe and Sir Edwin Sandys wrote it. It allowed the governor to "summon a General Assembly to legislate as appropriate." That meant the governor could call a meeting of men to make laws.

In the summer of 1619 Governor George Yeardley used that power. The colony had eleven settlements, and two elected men came from each one to speak and vote for it. They were called burgesses. A burgess was an elected member of the assembly. The twenty-two burgesses met in the Jamestown church with Yeardley and his council, the six men who advised him, from July 30 to August 4, 1619.

In six days the members set rules for how they would do business and protected colonists' claims to their land. They also made the Church of England the colony's official church. They passed laws about tobacco, gambling, behavior and dealings with Native nations.

**Whose land it was.** Jamestown stood on land that belonged to the Paspahegh. They were one of twenty-eight to thirty-two groups, each with its own chief, that paid tribute, goods given to a more powerful ruler, to Powhatan. He was the chief over all the other chiefs of Tsenacomoco. The anthropologist Helen C. Rountree estimates that about 15,000 people lived in Tsenacomoco, across about 6,000 square miles. The English built Jamestown on Paspahegh land in 1607 and stayed there without asking the Paspahegh's permission.

**The assembly outlives the company.** The king's officials took away the Virginia Company's charter in 1624. Virginia became a royal colony in 1625, with a governor and council chosen by the king. No one in England had given the assembly permission to go on meeting, but the burgesses kept meeting.

Whether the assembly had any legal right to meet stayed unclear until 1627. That year the king asked the General Assembly to help make rules for the tobacco trade. By asking, he treated the assembly as a lawful body, though no written order said it could meet.

### John Pory

> **Who:** The colony's secretary, who served as Speaker of the first elected assembly in English North America and wrote the record of what it did.
>
> **When and where:** Jamestown, Virginia, July 30 to August 4, 1619.

**Pory, the colony's secretary, ran the 1619 assembly and wrote its record.**

John Pory wrote the record of the first meeting of Virginia's General Assembly. He called his report "The Proceedings of the First General Assembly, July 30, 1619." One copy of it survives, in the National Archives of the United Kingdom. Any copies kept in Virginia, Brent Tarter wrote on the Library of Virginia's blog in 2019, would have been destroyed in one of the British raids on Richmond during the American Revolution, along with most of the colony's records.

Pory knew how a lawmaking body ran its business. He had sat in the English Parliament, the group of lawmakers who made England's laws. The leaders of the Virginia Company made him secretary of the colony on December 2, 1618. He sailed from England in January 1619 with the governor, George Yeardley, and reached Jamestown on April 18.

That summer Yeardley made him Speaker of the assembly, the officer who runs its meetings. Pory was not one of the elected burgesses. He ran the meetings because the governor appointed him. He left Virginia in the early summer of 1622, after Christopher Davidson was made secretary in his place.

### Why forty-one men signed a paper off Cape Cod, 1620

The *Mayflower* anchored off Cape Cod, in what is now Massachusetts, in November 1620. The passengers had permission, called a patent, to settle near the Hudson River. That land lay inside the Virginia Company's territory. Off Cape Cod they were outside it, so no one had given them the right to govern themselves there.

Forty-one men signed an agreement on November 11, 1620, to keep order until a new patent came. It is known as the Mayflower Compact. The signers agreed to "covenant & combine our selves together into a Civill body politick." That meant they promised to form a government together. They also promised to make and obey "just & equall lawes." The women and children did not sign. Most of the servants did not sign either. The original paper has been lost.

The passengers founded Plymouth Colony. They settled at Patuxet, where a Wampanoag community had lived until "a sickness had killed most of them." Plymouth remained a separate colony from Massachusetts Bay until 1691.

### Who could vote

The colonies' lawmakers decided who could vote. In Virginia they went back and forth for more than fifty years over one question: whether every free man could vote, or only a man who owned land or headed a household. The rules came from an old English idea that only people who owned property should have a say in running a place. No record says who voted for the first burgesses in 1619.

The members of the General Assembly let all freemen vote in 1646. A freeman was a man who was neither enslaved nor bound as a servant. They allowed only heads of households to vote in 1655, and they opened the vote to all freemen again in 1656. In 1670 they limited the vote to men who owned land or headed a household.

That limit lasted, except for one year. In 1676, during a revolt called Bacon's Rebellion, all freemen could vote again. The Assembly's members put the limit back in 1677, after the revolt fell apart. In 1684 men who rented land for their whole lives could vote as well.

The members passed a law in 1699 that barred women and anyone under twenty-one from voting. Women voting went against English custom, and no one knows whether any Virginia woman had tried to vote before then.

Candidates in Virginia gave voters food and drink before and after an election. People called it treating. Virginia's lawmakers limited treating during the week of an election, so candidates had other people do the treating for them.

**Massachusetts: church members only.** In Massachusetts Bay, the officers of the colony's company sat together as its lawmaking group, called the General Court. In May 1631 they ruled that only church members could become freemen, the men who could vote. Women could not vote at all.

To join a church, a person had to stand before the church members, tell how they had come to their faith, and be accepted. Most men in the colony could not pass that test. Under a new charter from the king in 1691, men who owned property could vote whether or not they belonged to a church.

### A Virginia law on the children of enslaved women, 1662

The members of Virginia's General Assembly passed a law about the children of enslaved women in December 1662. It states that "all children borne in this country shalbe held bond or free only according to the condition of the mother." Bond meant held in slavery. Under English law, whether a child was born free or bound depended on the father. Under the new Virginia law, a child born to an enslaved woman was enslaved, whoever the father was. Enslavers gained every such child as a worker they owned.

### A town made to keep a school

The lawmakers of Massachusetts Bay put the duty of teaching children on each household in 1642. Parents and masters had to try to teach their children and apprentices, young people bound to a master to learn a trade, to "read the English tongue," or have someone else teach them. They also had to teach them the colony's capital laws, the laws whose penalty was death.

If a household failed, the town's selectmen, its elected leaders, could fine it. They could also take the children away and place them with another master.

In 1647 the lawmakers passed a second law. Its opening words state that "that old deluder, Satan" wants to keep people from knowing the Scriptures, the Bible. A deluder is someone who tricks people. Once a town had fifty households, the people of the town had to appoint someone to teach reading and writing. The parents or the town paid that teacher. A town of one hundred families also had to set up a grammar school to prepare boys for the university.

Under the 1647 law, the penalty fell on the town rather than on the parents. If the people of a town went more than a year without doing what the law required, the town had to pay five pounds to the nearest school until they did it.

## 1700 to 1750

**Era 4 of 10 · 1700 to 1750 · about 7 minutes**

A New York jury set a printer free in 1735 though the governor wanted him in prison. In the same years, the men elected to the colonial assemblies held the power to propose every law and to decide how public money was spent, which gave them control over the pay of the governors the king appointed. The men of Virginia's assembly used their power another way. They took the vote away from every free Black man, every free man of mixed Black and white family, and every Native man in the colony.

### Why the governors could not control their own pay

After 1680 the members of the colonial assemblies had the power to propose all of a colony's laws. In a royal colony, the king chose the governor and his council, and the colonists elected the assembly. By 1763 nine of the thirteen colonies that later rebelled had royal governors.

The members of each colonial assembly decided how public money was spent, and they checked the spending. That gave them control over the salaries of the governor and of the colony's judges.

Officials in London tried to make the assemblies set fixed yearly salaries. They also wanted a fixed civil list, a set list of paid government posts. That list would have given each governor jobs to hand out to his supporters. The assembly members turned down every one of these attempts.

### Virginia's burgesses take away the vote, 1723

The burgesses of Virginia's General Assembly passed a law in May 1723 about enslaved people accused of crimes punished by death. It also set punishments for plots and revolts, and rules to control Black and Native people, enslaved or free.

One clause of it states that "no free negro, mullatto, or indian whatsoever, shall hereafter have any vote at the election of burgesses, or any other election whatsoever." Negro was a word used then for a Black person. Mulatto was a word used then for a person with both Black and white parents or ancestors. With that clause, the burgesses took the vote from every free Black man, every free man of mixed Black and white family, and every Native man in the colony.

A lawyer in London objected. Richard West advised the Board of Trade, the group of officials in London who oversaw the colonies. On January 10, 1724, he wrote: "I cannot see why one Freeman should be used worse than another meerly upon account of his complexion." Complexion meant skin color.

William Gooch, Virginia's lieutenant governor, an officer of the king one rank below the governor, defended the law. On May 18, 1736, he wrote that free Black people had been suspected of helping a planned revolt of enslaved people before the 1723 session. He said the law was meant "to make the free-Negros sensible that a distinction ought to be made between their offspring and the Descendants of an Englishman." Sensible here meant aware. The ban was still in force when Gooch defended it in 1736.

That same year, 1736, Virginia's lawmakers set a land test for voters. A man had to have owned 100 acres of unfarmed land, or 25 acres with a house on it, for at least a year.

### The Zenger trial, 1735

A jury in New York refused in 1735 to find the printer John Peter Zenger guilty of seditious libel. Libel means printed words that harm someone's good name. Seditious libel was the crime of publishing written blame of any public official, of the law, or of anything the law set up. Under that law, it made no difference whether the printed words were true.

The judge told the jury to decide only one question: whether Zenger had printed the newspaper. The jury decided more than that and found him not guilty.

**What the verdict did not change.** The jurors set Zenger free, but the law stayed the same. The case set no rule that later judges had to follow. In New York, the truth of the printed words did not become a defense, a reason that can keep a person from being found guilty, in a libel case until April 6, 1805, seventy years later.

That day the state's lawmakers passed a law allowing truth as a defense when the words were printed "with good motive and for justifiable ends." In 1821 New York's leaders wrote the same rule into the state's second constitution.

### John Peter Zenger

> **Who:** A New York printer jailed for more than eight months for printing attacks on the governor, then found not guilty by a jury.
>
> **When and where:** New York City, November 1734 to August 1735.

**Eight months in jail, and the paper missed only one issue.**

John Peter Zenger sat in jail from November 17, 1734, to August 5, 1735, for printing a newspaper that attacked the governor of New York. The trouble began in 1733. The chief judge, Lewis Morris, wrote a dissent, a judge's written disagreement with the other judges, against Governor William Cosby in a court case. Cosby removed Morris from office. Morris's allies answered by starting a newspaper, the *New-York Weekly Journal*, and Zenger printed it. The first issue came out on November 5, 1733.

Until then the only paper in the colony had been the *New York Gazette*, which printed the governor's side. In the *Journal*, writers accused Cosby's government of tyranny, meaning cruel and unfair rule, with articles, jokes and mocking verses, issue after issue. Cosby offered a reward of fifty pounds to anyone who found out who wrote them. He also ordered copies of the paper burned in public by the hangman.

In January 1734 Chief Justice James De Lancey asked a grand jury to charge Zenger with a crime. A grand jury is a group of citizens who decide whether there is enough proof to charge a person with a crime. The grand jury refused. In October a second grand jury refused too. Its members said no one could tell who had written the pieces.

On November 17, 1734, the sheriff arrested Zenger and took him to the Old City Jail. De Lancey and another judge named Philipse, both allies of Cosby, had signed the order for his arrest. His bail, the money he had to pay to get out of jail until his trial, was £400. That was more money than he had, so he stayed in jail. His wife Anna and his apprentices kept printing the paper. Only one issue was missed.

On April 16, 1735, his lawyers, James Alexander and William Smith, argued that the court itself had not been set up lawfully. De Lancey struck both of their names off the list of lawyers allowed to practice. Zenger was left with no lawyer.

The trial took place on August 4, 1735, on the second floor of City Hall. Andrew Hamilton, a lawyer from Philadelphia, defended Zenger. Hamilton tried to show that what Zenger printed was true. De Lancey stopped him: "The law is clear that you cannot justify a libel." Hamilton then spoke to the jury. He told them they had "the right beyond all dispute to determine both the law and the fact." The jury found Zenger not guilty. He was let out of jail the next day.

### Andrew Hamilton

> **Who:** The Philadelphia lawyer who defended Zenger without pay and told the jury it could judge the law as well as the facts.
>
> **When and where:** New York City, August 4, 1735. Philadelphia before and after.

**He took the case for nothing and told the jury to judge the law.**

Andrew Hamilton defended John Peter Zenger for free. He was a lawyer in Philadelphia, and the members of the Pennsylvania Assembly elected him their Speaker. He traveled to New York for the trial and worked on the case with another lawyer, John Chambers.

The judge would not let Hamilton prove that Zenger's words were true. So Hamilton built his defense on the power of the jury. He told the jurors that the case was "not of small or private concern." He called it "the cause of liberty." He argued that the law gave people "a right to liberty of both exposing and opposing arbitrary power," meaning power used without limits, "by speaking and writing truth." The jury found Zenger not guilty.

The phrase "Philadelphia lawyer" entered American speech because of this case. Dictionaries define it as a very clever lawyer, skilled at the fine points of the law.

Back in Pennsylvania, Hamilton led the planning of the Pennsylvania State House and pushed to get it finished. The building is now called Independence Hall.

## 1750 to 1800

**Era 5 of 10 · 1750 to 1800 · about 15 minutes**

Fifty-six men signed the Declaration of Independence, and in the next fifteen years the leaders of the new country wrote down how it would be governed. They wrote a plan of government, a constitution to replace that plan, and a list of rights added to the constitution. The men who wrote the Constitution put clauses in it that protected slavery. They set no national rule on who could vote, so each state's lawmakers decided.

In the 1790s the country's leaders split into the first two political parties. In 1798 President John Adams signed a law that made it a crime to publish false and scandalous writing against the government. Federal judges sent people who criticized him to jail under it.

### The Declaration of Independence, 1776

The delegates to the Continental Congress voted for independence from Britain on July 2, 1776. The Continental Congress was the meeting of delegates from the thirteen colonies. Two days later, on July 4, they approved the Declaration of Independence, which gave their reasons.

Five men made up the committee that wrote the first version: Thomas Jefferson, John Adams, Benjamin Franklin, Robert R. Livingston and Roger Sherman. Jefferson did most of the writing. The delegates began signing the finished copy on August 2, 1776. In the end 56 men signed it. Livingston, who helped write it, never signed.

### Who could vote in the new states

Leaders in many of the new states wrote state constitutions, each with its own rules for who could vote. The constitutions written in ten states between 1776 and 1790 stated that voters had to be "male" or "freemen." The election laws of five states contained no rule about sex.

New Jersey's constitution of 1776 gave the vote to "all inhabitants of this colony of full age, who are worth fifty pounds." That meant every adult living there who owned fifty pounds' worth of property could vote. It said nothing about sex or race. So unmarried women and free Black people who owned enough property could vote. Fifty pounds was about the price of three horses or eight cows in 1806.

Married women found it much harder to meet the property test, because under the law of the time a wife's property was usually in her husband's hands.

New Jersey's lawmakers passed an election law in 1790 that said a voter must vote in the town where "he or she" lived. In 1797 they passed a law that did the same for the whole state. It also dropped the words "clear estate," an old legal phrase meaning owning property outright, from the property rule. What wives and widows held was often not theirs outright, so with those words gone, it was easier for them to qualify.

Then in 1798 the lawmakers passed a law that let only white male taxpayers vote for town officers. Property owners of any race or sex still voted for county, state and national offices. The next era tells how that ended.

### The Articles of Confederation

Before the Constitution, the country's plan of government was the Articles of Confederation. The members of Congress approved it on November 15, 1777. It took effect on March 1, 1781, when Maryland's leaders approved it, the last of the thirteen states to do so.

Under the Articles, each state had one vote in Congress, whatever its size. Congress had no power to tax. It could not make rules for trade between the states. Any change to the Articles needed every state to agree.

### The Constitutional Convention, 1787

Delegates from the states met in Philadelphia in 1787 to write a new plan of government. The meeting was called for May 14, but too few delegates had arrived to begin until May 25. About 55 delegates took part. No delegates came from Rhode Island. The delegates worked until September 17, 1787, and 39 of them signed the finished Constitution.

The delegates settled how to share seats in Congress with a deal called the Connecticut Compromise. Every state got two senators, and the number of seats each state got in the House of Representatives depended on its population.

**Three-fifths.** The delegates also had to decide whether enslaved people counted as part of a state's population. They agreed to count each enslaved person as three-fifths of a free person when working out a state's seats in the House. This rule is in Article I, Section 2. Under it, the states with the most enslaved people got extra seats in the House.

Article II states that each state has as many electors, the people who pick the president, as it has senators and representatives. So those states also got extra votes for president. Under the law, the enslaved people being counted were property, with no rights at all, so none of them could vote.

### Slavery and voting in the Constitution

Two other clauses of the Constitution dealt with slavery. Article I, Section 9 stated that Congress could not ban "the Migration or Importation of such Persons as any of the States now existing shall think proper to admit" before 1808. That meant members of Congress could not stop the shipping of enslaved Africans into the country for twenty years. Article V stated that no amendment could change that clause before 1808.

Article IV, Section 2 stated that a person "held to Service or Labour in one State" who escaped into another state "shall be delivered up on Claim of the Party to whom such Service or Labour may be due." That meant a person who escaped slavery into a free state still had to be handed back to the enslaver.

The Constitution set no national rule for who could vote. Article I, Section 2 stated that the voters for the House in each state must meet the same rules as the voters for the largest house of that state's own lawmaking body. So each state's lawmakers decided who could vote.

### Ratification

The Constitution would take effect once nine states ratified it. To ratify means to approve formally. Under Article VII, a meeting of delegates in each state, called a convention, voted on it. From October 1787 to May 1788, Alexander Hamilton, James Madison and John Jay wrote 85 essays to persuade New Yorkers to vote for it. They signed them with a made-up name, Publius. The essays came out mainly in two New York newspapers, and they are known as *The Federalist*.

On June 21, 1788, New Hampshire's delegates made it the ninth state to ratify. The new government began on March 4, 1789. Delegates in North Carolina and Rhode Island approved the Constitution only after the first president took office. Rhode Island's lawmakers turned down eleven attempts to ratify it between September 1787 and January 1790. When Rhode Island's delegates finally voted on May 29, 1790, they approved it 34 to 32.

### George Washington

> **Who:** The first president, elected twice with every electoral vote, who chose to leave office after two terms.
>
> **When and where:** Federal Hall, New York, April 30, 1789. Philadelphia, September 19, 1796.

**Washington stopped after two terms, a limit presidents kept for about 150 years.**

George Washington is the only person ever elected president with every electoral vote. It happened twice, in 1789 and in 1792. The electoral votes are the votes cast by electors, the people each state chooses to pick the president. The votes for the first election were counted on April 6, 1789, more than a month late. Members of the new Congress could not reach New York in time because of a cold, snowy winter. Washington had all 69 votes.

On April 30, 1789, Washington swore the oath of office, the promise each new president makes, on the second-floor balcony of Federal Hall in New York. Robert R. Livingston, a New York judge whose title was chancellor, read him the oath while a crowd watched from the street. Then Washington went inside and read his first speech as president, called the first inaugural address, to both houses of Congress.

Nothing in the Constitution limited how many times a president could be elected. In 1796 Washington decided to stop after two terms. He announced it in a written message to the country, printed on September 19, 1796, in a Philadelphia newspaper. It is called his Farewell Address, though he never read it aloud.

James Madison had written a first version in 1792. Alexander Hamilton did most of the writing in 1796, and Washington made changes to it himself. In it he told the country of "the resolution I have formed, to decline being considered among the number of those out of whom a choice is to be made." That meant he would not run again.

In the same address he warned "against the baneful effects of the spirit of party." Baneful means harmful. He also wrote that it was "our true policy to steer clear of permanent alliances with any portion of the foreign world."

For about 150 years the two-term limit stayed a habit, not a law. Franklin Roosevelt broke it when he won a third term in 1940 and a fourth in 1944. The Twenty-second Amendment of 1951 made the limit law. Era 9 tells how.

**The people he owned.** Washington was an enslaver. He owned 123 people at his plantation, Mount Vernon. He also managed 153 more who belonged to the estate of his wife Martha's first husband, the property that man had left when he died. Under the law, Washington could not sell or free those 153.

In his will, dated July 9, 1799, he freed his valet, or personal servant, William Lee at once. He ordered the other 122 people he owned to be freed after Martha died. Martha Washington freed them on January 1, 1801. The other 153 people went back to her first husband's estate. Martha's grandchildren, who inherited that estate, divided them among themselves, and in dividing them they split up families.

The custom of reading the Farewell Address aloud in Congress began on February 22, 1862, during the Civil War, after a thousand people in Philadelphia asked Congress to mark Washington's birthday. Since 1896 a senator has read it aloud in the Senate every year. It runs 7,641 words.

### James Madison

> **Who:** A delegate to the Constitutional Convention who first argued against a bill of rights, then wrote one and steered it through Congress.
>
> **When and where:** Philadelphia and New York, 1787 to 1791. Born March 16, 1751. Died June 28, 1836.

**Madison wrote the Bill of Rights after arguing that none was needed.**

James Madison introduced the amendments that became the Bill of Rights. An amendment is a change or addition to the Constitution. Madison had been the loudest voice against adding a list of rights. He had argued that the Constitution already limited the government's powers. Then delegates in several states agreed to ratify only if the first Congress would consider the amendments they proposed. After that, Madison changed his position.

On June 8, 1789, Madison stood up in the House of Representatives and proposed his list. He told the House, "I think we should obtain the confidence of our fellow citizens, in proportion as we fortify the rights of the people against the encroachments of the government." To fortify means to make stronger. Encroachments means steps that go beyond what is allowed.

Madison wanted each change written into the body of the Constitution, in the place where it belonged. In August 1789 the House members followed Roger Sherman's plan instead. They voted to add the changes at the end, as separate amendments. That is why the Bill of Rights sits at the back of the Constitution.

The House members passed 17 amendments. The senators cut and combined them into 12. Members of Congress proposed those 12 amendments on September 25, 1789, and President Washington sent them to the states on October 2. By December 15, 1791, lawmakers in three-quarters of the states had ratified ten of them. Those ten are the Bill of Rights.

At the Constitutional Convention, Madison had backed the rule counting each enslaved person as three-fifths of a free person. In essay No. 54 of *The Federalist*, he defended it. He said enslaved people had a "mixed status as property and persons." He said many times that slavery went against the principles of a republic, a country governed by elected representatives. He never put forward a workable plan to end it.

Madison enslaved people all through these years. About 100 enslaved people worked at his plantation, Montpelier, at any one time, and nearly 300 over the life of the plantation. When he was short of money, he sold sixteen of them to his cousin William Taylor, who owned a sugar plantation and a cotton plantation in Louisiana. He freed no one in his will. He asked his wife, Dolley, not to sell the people he left her without their consent unless they misbehaved. She sold some of them and kept others enslaved.

### Who could become a citizen, 1790

The first federal law on who could become a citizen allowed only a "free white person." Members of Congress passed it in 1790 and called it the Naturalization Act. Naturalization is the legal process by which a person born in another country becomes a citizen.

The person had to be of good character, had to have lived in the United States for two years and in the state for one, and had to swear an oath to support the Constitution. Part of that racial limit stayed in federal law until 1952.

### The Fugitive Slave Act, 1793

In 1793 the members of Congress passed a law about "persons escaping from the service of their masters." President George Washington signed it on February 12, 1793. Under the law, an enslaver, "his agent or attorney" could "seize or arrest" a person in any state. He could take that person before a single federal judge, or a county, city or town magistrate. A magistrate is a local judge. If the enslaver swore to his claim, spoken or in writing, the judge could give him a certificate to take the person away.

The law provided no jury for the seized person. It stated nothing about letting that person give evidence. Anyone who blocked the seizure, rescued the person, or hid the person after being told of the claim had to pay the enslaver $500.

### The first two parties

In the 1790s the country's leaders split into the first two political parties. A political party is a group of people who work together to win elections and run the government their way.

Alexander Hamilton and John Adams led the Federalists. They wanted a strong national government and an economy built on trade, manufacturing and banking, and they leaned toward Britain. Thomas Jefferson and James Madison led the Democratic-Republicans. They wanted more of the government's power left with the states, opposed a national bank, supported farming and leaned toward France. Washington warned against parties in his Farewell Address of 1796.

### The Sedition Act, 1798

In 1798 members of Congress passed four laws, and President John Adams signed them. Three of them dealt with people from other countries. The fourth, signed on July 14, 1798, was the Sedition Act. Sedition means words or acts that stir people up against the government. Under it, a person committed a crime by writing or publishing "any false, scandalous and malicious writing" against the government. The punishment was a fine of up to $2,000 and up to two years in prison. The law ran out on March 3, 1801.

The only newspaper editors put on trial under the Sedition Act worked for Democratic-Republican papers.

**Disputed:** The number found guilty. Historians have long counted 17 people charged and 10 found guilty, and a later study found 16 more people charged. The National Constitution Center counts more than two dozen found guilty, most of them publishers who opposed the government.

One of the people found guilty was Matthew Lyon, a Democratic-Republican congressman from Vermont who had been born in Ireland. In a letter, he wrote that he saw the public good "swallowed up in a continual grasp for power, in an unbounded thirst for ridiculous pomp, foolish adulation, or selfish avarice." Pomp means showy display. Adulation means too much praise. Avarice means greed. He had also read aloud at campaign meetings a letter by the poet Joel Barlow that blamed Adams and the Senate for trouble with France.

A federal grand jury in Vermont charged Lyon on October 5, 1798. A deputy marshal, a federal law officer, arrested him the next day. On October 9 he stood trial at Rutland before Justice William Paterson of the Supreme Court. Lyon defended himself.

Paterson told the jury that its job had "nothing whatever to do with the constitutionality or unconstitutionality of the sedition law." Constitutionality means whether a law is allowed by the Constitution. The jury found Lyon guilty within an hour. Paterson sentenced him to four months in prison, a $1,000 fine and $60.96 in court costs.

Lyon was held in the jail at Vergennes. While he was there, the voters of his district elected him to Congress again. He was released on February 9, 1799.

Justice Samuel Chase sentenced another writer, James Callender, to nine months in prison and a $400 fine. After Jefferson became president, he pardoned Callender. To pardon means to officially forgive a crime. In 1804 the members of the House voted to impeach Chase, partly for how he ran Callender's trial. To impeach means to charge an official with wrongdoing in office, so that the Senate puts him on trial. The senators found him not guilty.

**If you remember one thing:** Between 1776 and 1791 the country's leaders wrote down how it would be governed, protected slavery in the plan, and left the vote to each state.

- 1787: Thirty-nine delegates signed the Constitution in Philadelphia.
- 1791: Ten amendments, the Bill of Rights, became part of it.
- 1798: Under the Sedition Act, a jury found a congressman guilty of writing against the president, and his voters re-elected him from jail.

**Next:** In 1803 the justices of the Supreme Court claimed a power the Constitution does not name: cancelling a law.

## 1800 to 1850

**Era 6 of 10 · 1800 to 1850 · about 11 minutes**

The Supreme Court's justices struck down part of a law passed by Congress for the first time in 1803. From then on, American judges claimed the power to cancel laws that break the Constitution. In the same years, lawmakers in several states dropped the rule that a white man had to own property to vote. Lawmakers in some of those states took the vote away from Black men.

The first national party convention met in 1831. President Andrew Jackson handed out government jobs to his supporters. He also signed a law that let him make treaties to push Native nations out of the East and send them west. By the end of his presidency, his officials had removed about 50,000 Native people from their homelands in the East.

### John Marshall

> **Who:** The Chief Justice who wrote that judges may refuse to follow a law that breaks the Constitution.
>
> **When and where:** Washington, D.C., 1801 to 1835. *Marbury v. Madison* decided in February 1803.

**A judge's job, he wrote, is "to say what the law is."**

John Marshall wrote the ruling in which the Supreme Court's justices first claimed the power to strike down a law passed by Congress. He was the Chief Justice, the head of the Supreme Court. President John Adams named Marshall for that post on January 20, 1801, and Marshall took his seat on February 4.

He held the seat for 34 years, until he died in Philadelphia on July 6, 1835. In that time he heard more than a thousand cases and wrote more than five hundred opinions. An opinion is a judge's written explanation of a ruling.

In 1801, in his last days in office, Adams appointed William Marbury a justice of the peace, a local judge, for Washington, D.C. The paper that gave Marbury the job, called a commission, was never delivered to him. The new Secretary of State, James Madison, refused to hand it over. The Secretary of State is the president's chief adviser on dealings with other countries. Marbury asked the Supreme Court for an order forcing Madison to deliver it.

In February 1803 Marshall and the other justices decided the case, called *Marbury v. Madison*. They said they could not give Marbury the order he asked for. A section of the Judiciary Act of 1789 said the Supreme Court could give such orders. The justices decided that the section went beyond what the Constitution allowed, so they refused to follow it. It was the first time the justices had declared a law passed by Congress and signed by the president unconstitutional, meaning that it broke the Constitution.

Marshall wrote: "It is emphatically the province and duty of the judicial department to say what the law is." The judicial department means the courts. Province here means proper job. A law that goes against the Constitution is void, which means it has no force, he wrote. And when the two conflict in a case, judges must follow the Constitution. This power is called judicial review. The justices did not declare another act of Congress unconstitutional until the *Dred Scott* case of 1857.

### The Louisiana Purchase, 1803

**The deal.** Two American officials, Robert Livingston and James Monroe, signed a treaty, a written agreement between countries, with France on April 30, 1803. Under it the United States bought 828,000 square miles of land west of the Mississippi River. The price was $15 million, about 4 cents an acre. President Jefferson had sent Monroe to buy only New Orleans and the land to its east called West Florida, and to spend no more than $10 million.

**The question it raised.** President Thomas Jefferson usually read the Constitution strictly, which means he held that the government could do only what the document said it could. He wondered whether the Constitution allowed the government to take on new land at all.

In a letter in 1803 to Wilson Cary Nicholas, Jefferson wrote: "Our peculiar security is in possession of a written Constitution. Let us not make it a blank paper by construction." Peculiar here meant special. By construction he meant by stretching the meaning of its words. He wrote that he would rather ask the nation for more power than take it. He went ahead with the purchase anyway.

French officials sold France's claim to the land. Thousands of Native people, in dozens of nations, lived on it. They were not part of the sale. Article VI of the treaty states that the United States would carry out the treaties Spain had made with "the tribes and nations of Indians" there.

### Ending the import of enslaved people, 1808

Under the Constitution, the members of Congress could not ban the shipping of enslaved Africans into the country before 1808. On March 2, 1807, President Jefferson signed a law that banned it from the first day allowed. The ban took effect on January 1, 1808. From then on, bringing enslaved people across the ocean into the United States was against federal law.

### Who gained the vote and who lost it

Between 1807 and 1838, the lawmakers of several states rewrote their rules on voting. They let white men without property vote. In the same laws and constitutions, they shut out Black men. New Jersey's lawmakers also ended voting by women.

**New Jersey.** New Jersey's lawmakers passed an election law in 1807 that let all white male taxpayers vote and shut out everyone else. Women and free Black people in New Jersey who met the property test had voted since 1776. The new law ended that. The law's words gave its aim as a "uniform practice" across the state, meaning the same rules everywhere.

**New York.** The delegates who rewrote New York's constitution in 1821 dropped the property test for white men. In the same document, they required a Black man to own property worth $250, free of debt, before he could vote. In 1825 only 298 of the nearly 6,000 free Black adults in New York met that test.

**North Carolina and Pennsylvania.** North Carolina's free Black men lost the vote in 1835. The delegates to the state's constitutional convention, a meeting of men chosen to rewrite the state constitution, took it away from them. Pennsylvania's convention delegates did the same in January 1838. They added the word "white" before "freemen," the men allowed to vote, in the section on who could vote.

Robert Purvis wrote a protest called the *Appeal of Forty Thousand Citizens, Threatened with Disfranchisement*. To disfranchise means to take away the vote. He read it aloud on March 14, 1838, at the First African Presbyterian Church in Philadelphia. Pennsylvania's voters approved the new constitution on October 9, 1838, by 113,971 votes to 112,759. Black men in Pennsylvania could not vote again until the Fifteenth Amendment in 1870. That change to the Constitution barred the states from denying a man the vote because of his race.

### The first national party convention, 1831

Men who opposed the Freemasons, a secret society, formed the Anti-Masonic Party. In September 1831 the party's members met in Baltimore to choose their candidate for president. It was the first national nominating convention held by any party. A nominating convention is a meeting where a party's members choose its candidates.

The Anti-Masons were also the first party to give voters a platform, a written list of what the party stood for. The delegates chose William Wirt. In the 1832 election he won only Vermont and its seven electoral votes.

### Andrew Jackson

> **Who:** The president who signed the law to remove Native nations from the East, used the veto to fight the national bank, and gave government jobs to his supporters.
>
> **When and where:** Washington, D.C., 1829 to 1837.

**He signed the removal law, and his officials forced about 50,000 people west.**

Andrew Jackson was the seventh president, from 1829 to 1837. On May 28, 1830, he signed the Indian Removal Act. The act allowed the president to make treaties with Native nations living east of the Mississippi River. Under those treaties the nations had to give up their eastern land and move west. The senators passed it 28 to 19. The members of the House passed it by five votes, 102 to 97, on May 26, 1830, by the count of the House's own historians.

**What the law did.** By the end of Jackson's presidency, his officials had made nearly 70 removal treaties. Federal officials removed about 50,000 Native people from the East to Indian Territory, land west of the Mississippi River that the government set aside for them. The Choctaw, starting in 1831, were the first of the southeastern nations to be forced out. The forced removal of the Muscogee, or Creek, began in 1836. Forcing the Seminole from their land took the government almost twenty years and $15 million.

White settlers got about 25 million acres of the nations' eastern land, which federal officials opened to them.

**The Trail of Tears.** In 1838, a year after Jackson left office, United States Army troops and state militia, part-time soldiers called up by a state, forced more than 16,000 Cherokee people out of their homelands. The soldiers held the Cherokee in camps and then sent them west. The journey is called the Trail of Tears. The National Archives puts the Cherokee dead at about 4,000. The National Park Service counts more than a thousand who died on the way and perhaps several thousand more who died from its effects.

**The ruling Georgia ignored.** Georgia's lawmakers had also passed a law about white people living on Cherokee land. It required any white person living in Cherokee territory after March 1, 1831, to get a license from Georgia's governor and to swear an oath to support Georgia's constitution and laws. Samuel Worcester, a Christian missionary, a man sent to spread his religion, lived on Cherokee land without that license. He was found guilty in a Georgia court and sentenced to four years of hard labor, forced heavy work, in the state prison.

In 1832 the justices of the Supreme Court decided *Worcester v. Georgia*. Chief Justice John Marshall wrote that Georgia's law was "void, and the judgment a nullity," meaning it had no force. Georgia's officials did not carry out the ruling. In April 1832 Jackson wrote to John Coffee that the Court's decision "has fell still born." Stillborn means born dead.

Many schoolbooks quote Jackson saying, "John Marshall has made his decision, now let him enforce it." No record from his own time shows that he said it. The sentence first appears in a history book by Horace Greeley printed in 1864, about twenty years after Jackson died.

**The veto.** On July 10, 1832, Jackson vetoed a bill to renew the charter of the Second Bank of the United States, a national bank. The charter was the paper that gave the Bank the right to operate. A veto is a president's refusal to sign a bill into law. His veto message called the Bank "dangerous to the liberties of the people."

He was the first president to make a veto the center of a major fight over the economy. He made the veto a part of his campaign in 1832 and won a second term.

Jackson then moved the government's money out of the Bank. On March 28, 1834, the senators voted to censure him for it. To censure is to scold someone officially. It is the only time the Senate has censured a president. In January 1837, after Jackson's party won a majority, the senators voted to expunge the censure, which means to strike it from the record.

Jackson also filled government jobs with his own supporters. He called this rotation in office. He argued that government work could be made "so plain and simple" that the jobs could pass around among men who deserved them. Senator William L. Marcy of New York gave the practice its nickname when he said "to the victor belong the spoils of the enemy." Spoils are the goods an army takes from the side it beats. The practice became known as the spoils system.

### The fight over the school tax, 1834 and 1835

In 1834 Pennsylvania's lawmakers passed the Free Public School Act, a law for a statewide system of common schools paid for by taxes. A common school was a free public school open to the children of the town.

Many voters did not want to pay the tax. In 1835 petitions, written requests signed by thousands of them, reached the state's lawmakers, asking them to repeal, or cancel, the law. No one in the state Senate spoke against repeal, and few members of the House did.

Thaddeus Stevens, a member of the Pennsylvania House, spoke against repeal on April 11, 1835. He said: "Many complain of the school tax, not so much on account of its amount, as because it is for the benefit of others and not themselves." He pointed out that a man "cheerfully pays the tax which is necessary to support and punish convicts." The same man, Stevens said, "loudly complains of that which goes to prevent his fellow being from becoming a criminal."

After his speech, the lawmakers dropped the repeal, and the schools stayed. Stevens later called the speech the "crowning utility" of his life, the most useful thing he ever did.

## 1850 to 1900

**Era 7 of 10 · 1850 to 1900 · about 21 minutes**

Black men in Louisiana registered to vote in 1897 numbered 130,344. In 1900 they numbered 5,320. This era tells how both numbers came to be.

Members of Congress passed three amendments to the Constitution between 1865 and 1870, and lawmakers in enough states approved them. Under them, slavery ended, people born in the country became citizens, and no state could deny a citizen the vote because of race. The justices later ruled that the citizenship rule did not cover Native people born into their own nations. In the 1870s and 1880s Black men in many Southern states voted and held office.

Starting in 1890, the delegates who rewrote Southern state constitutions added rules meant to stop Black men from voting. The justices of the Supreme Court ruled that those rules were allowed. They also ruled that laws requiring Black and white people to be kept apart were allowed. In the same years, lawmakers in Washington passed the first laws to shut out immigrants by nationality, and to fill some government jobs by exam. Lawmakers in more and more states required children to go to school.

### Laws that made children go to school

In 1852 the lawmakers of Massachusetts passed the first state law that required children to go to school. Children from 8 to 14 had to attend. The school committee in each town or city had to look into every case of a child who did not. A family that broke the law could be fined up to $20. By 1900, thirty-two states had a law like it. Mississippi's lawmakers were the last to pass one, in 1918. These laws worked alongside laws against child labor.

### Dred Scott v. Sandford, 1857

Dred Scott, an enslaved man, went to court to win his freedom. He argued that he had become free by living in a territory where slavery was banned. The justices of the Supreme Court decided his case, *Dred Scott v. Sandford*, on March 6, 1857, by a vote of 7 to 2.

Chief Justice Roger B. Taney wrote the ruling. He wrote that a Black person whose ancestors were brought to the country and sold as slaves was not a citizen under the Constitution. So Scott had no right to sue in a federal court. Taney also wrote that Black people "had no rights which the white man was bound to respect."

Taney's ruling also said that Congress had no power to ban slavery in the federal territories, the lands that were not yet states. With that, the justices struck down the Missouri Compromise, a law of 1820 that had banned slavery in the northern part of the Louisiana Purchase lands. That made *Dred Scott* only the second time the justices had struck down a law passed by Congress. The first was *Marbury v. Madison* in 1803.

### Secession, 1860

The delegates of a South Carolina convention signed an ordinance of secession, a law declaring that their state was leaving the United States, in Charleston on December 20, 1860. Four days later the delegates approved a statement of their reasons. In it they wrote of "an increasing hostility on the part of the non-slaveholding States to the institution of slavery." They also wrote that the Northern states had joined to elect a man "whose opinions and purposes are hostile to slavery." The man they meant was Abraham Lincoln.

### Abraham Lincoln

> **Who:** The president who suspended a basic legal right during the Civil War, was told by the Chief Justice that he had no power to do it, and kept doing it.
>
> **When and where:** Washington and Baltimore, April to July 1861.
>
> **Movie:** *Lincoln* (2012), a film about the fight in January 1865 to get the House of Representatives to pass the Thirteenth Amendment. The film is about the amendment, not about habeas corpus.

**Lincoln kept holding people without a judge, against the Chief Justice's ruling.**

In the first months of the Civil War, President Abraham Lincoln suspended the writ of habeas corpus. A writ is a written order from a court. Habeas corpus is a person's right to be brought before a judge, who decides whether the government may go on holding that person. When it is suspended, the government can hold a person without taking them before a judge at all. The Constitution allows the writ to be suspended "in Cases of Rebellion or Invasion." It does not say who may suspend it.

Lincoln wrote to General Winfield Scott on April 25, 1861. Governor Hicks of Maryland had called the state's lawmakers to a special meeting, and they looked likely to vote to leave the United States. Lincoln told Scott to stop any effort to arm Maryland's people against the federal government. He approved "the most prompt, and efficient means." Those means included "the bombardment of their cities" and, "in the extremest necessity," suspending the writ.

On April 27 he gave Scott the power to suspend it anywhere along the routes the army's troops used between Philadelphia and Washington. No federal official had suspended the writ since the War of 1812.

**The arrest.** At two in the morning on May 25, 1861, federal soldiers entered the country house of John Merryman, a planter, or owner of a large farm, in Baltimore County, and woke him from his bed. They took him to Fort McHenry. General George Cadwalader held him there. The charge was that Merryman was an officer in a company of men who supported secession and had federal weapons.

On May 26 Chief Justice Roger Taney, who also served as a judge in Maryland, ordered Cadwalader to bring Merryman to court. Cadwalader refused in a letter. He wrote that Lincoln had given officers the power to suspend the writ. A deputy marshal, an officer of the federal courts, carried Taney's next order to the gate of the fort, and a guard would not let him in.

On May 28, with a crowd gathered outside, Taney ruled in Baltimore that the president had no power to suspend the writ, under the Constitution or any law. He said Merryman must be freed at once. Taney issued no order to make that happen. He was 84 years old. He was also the judge who had written *Dred Scott*, so almost no one at the time saw him as neutral.

On July 4, 1861, Lincoln explained himself to Congress. He said the power to suspend the writ had "purposely been exercised but very sparingly." Then he asked, "are all the laws, but one, to go unexecuted, and the government itself go to pieces, lest that one be violated?" Unexecuted means not carried out, and lest means for fear that. He argued that the men who wrote the Constitution could not have meant that "the danger should run its course, until Congress could be called together."

Lincoln's officials went on arresting people and suspending the writ without a vote of Congress. On September 24, 1862, Lincoln suspended it across the whole country for anyone who resisted the draft, the law that made men serve in the army. In March 1863 the members of Congress passed a law that let the president suspend the writ for the rest of the war. With that law, members of Congress settled the dispute. No court settled it.

**The amendment.** Nearly four years after Merryman's arrest, Lincoln put his name on a change to the Constitution. On January 31, 1865, the members of the House passed that change, the Thirteenth Amendment, which ended slavery, by 119 votes to 56. Lincoln signed the resolution, the paper sending the amendment to the states, the next day, though a president does not have to sign an amendment. Enough states had ratified it, or approved it, by December 6, 1865.

### Land for colleges, 1862

Senator Justin Morrill of Vermont put forward the bill that became the Morrill Act on July 2, 1862. Under it, each state received 30,000 acres of federal land for each of its senators and representatives in Congress. The land was to pay for colleges that taught "agriculture and the mechanic arts," meaning farming and the skills of building and machines. More than 10 million acres of the land given out under the act had been taken from Native nations by United States officials, through treaties, agreements and seizure.

Colleges paid for by these land gifts are called land-grant colleges. A second Morrill Act, in 1890, set a rule for each state. The state had to set up separate land-grant colleges for Black students, or show that its colleges did not turn students away because of race.

### The Fourteenth and Fifteenth Amendments

Members of Congress approved the Fourteenth Amendment on June 13, 1866, and it became part of the Constitution on July 9, 1868. It states that "all persons born or naturalized in the United States" are citizens. Naturalized means made a citizen by a legal process. It also states that no state may "deny to any person within its jurisdiction the equal protection of the laws." Within its jurisdiction means inside the area where its laws apply. Equal protection means a state has to apply its laws the same way to everyone.

**Who it left out.** John Elk, a Native man who lived in Omaha, Nebraska, tried to register to vote in 1880. The registrar refused him because he was Native, and Elk sued. The justices ruled against him 7 to 2 in *Elk v. Wilkins* in 1884. They held that Native people born into their own nations were no more citizens by birth than the children of foreign diplomats, officials who represent other countries. Under a law of 1924, which Era 8 describes, American Indians became citizens.

Members of Congress passed the Fifteenth Amendment on February 26, 1869, and it was ratified on February 3, 1870. It states that the right of citizens to vote "shall not be denied or abridged by the United States or by any State on account of race, color, or previous condition of servitude." Abridged means cut back. Previous condition of servitude means having once been enslaved. The amendment names race, color and past slavery. It says nothing about sex, so states could still keep women from voting.

### New constitutions in the South

Reconstruction was the rebuilding of the Southern states' governments after the Civil War. Members of Congress passed laws for it called the Reconstruction Acts. Under those acts, a convention met in Charleston on January 14, 1868, to write a new constitution for South Carolina. Black men in South Carolina had voted for the first time in the election of its delegates. Three out of every five delegates were Black.

Article X of the constitution they wrote required a system of free public schools, "free and open to all the children and youths of the State, without regard to race or color." Schools were to be open at least six months a year. Once there were enough schools, children would have to attend for at least twenty-four months. For decades, state officials did not carry out Article X.

### The Tweed Ring and Tammany Hall

In the 1860s and 1870s, William M. Tweed held several offices in New York City and New York State at once. He was a state senator from 1867 to 1871 and chaired the state Senate's finance committee. From 1868 he was the Grand Sachem, or head, of Tammany Hall. Tammany Hall was a political machine of the Democratic Party. A political machine is a party organization that wins votes by handing out jobs and favors. Through Tammany Hall, Tweed had great power in the Democratic Party.

**How the ring stole.** Tweed and the men around him, called the Tweed Ring, stole money from the city in several ways. They sent the city bills for more than the work cost. Through printing and supply companies they controlled, Tweed's men billed the city too much for supplies. They ran up the cost of public buildings far past their budgets.

A new county courthouse was expected to cost half a million dollars. It ended up costing the city's taxpayers about $13 million. Modern estimates of what the ring stole in all run from $30 million to $200 million, by the count of the reference guide EBSCO Research Starters.

**How it ended.** The cartoonist Thomas Nast attacked Tweed in the magazine *Harper's Weekly* from 1869. In July 1871 editors at *The New York Times* printed evidence from inside the city's accounts, after people who knew about the thefts passed it to the paper.

In late 1873 a court found Tweed guilty and sentenced him to twelve years in prison and a fine of $12,750. He appealed, which means he asked a higher court to look at the case again, and the higher court cut his sentence to one year. He died of pneumonia in the Ludlow Street jail on April 12, 1878.

### Minor v. Happersett: citizens without the vote

In October 1872 Virginia Minor, a citizen of Missouri, tried to register to vote in St. Louis. The registrar, the official who signed up voters, was Reese Happersett. He refused her because she was not a "male citizen." Minor sued. She argued that the Fourteenth Amendment made voting a right of every citizen.

The justices of the Supreme Court ruled against her, and none of them disagreed. They decided the case in their session that began in October 1874. The Chief Justice read the ruling. It states that "the Constitution of the United States does not confer the right of suffrage upon any one." Suffrage means the right to vote. Under the ruling, each state could keep the vote for men only.

### The first laws against immigrants by nationality

The Page Act of 1875 was the first federal law to limit immigration. It barred Chinese laborers brought over under contract. In practice, officials used it to keep out most Chinese women too.

On May 6, 1882, President Chester A. Arthur signed the Chinese Exclusion Act. Under it, no Chinese laborer could come into the country for ten years. This was the first federal law to shut out a whole group of people because of their nationality. Members of Congress later renewed the act and widened it, and they did not repeal it until 1943.

Federal officials also took over the work of admitting immigrants. Officials of New York State had run the landing station at Castle Garden from 1855 to 1890. In 1892 the federal station at Ellis Island opened.

### The election of 1876 and the end of Reconstruction

The presidential election of 1876 was between Rutherford B. Hayes, a Republican, and Samuel J. Tilden, a Democrat. The electoral votes of Florida, Louisiana, South Carolina and Oregon were in dispute. On January 18, 1877, Senator George Edmunds of Vermont proposed an Electoral Commission to settle the count. It had fifteen members: five representatives, five senators and five Supreme Court justices. Members of Congress passed the bill.

The commission's members voted 8 to 7, along party lines, to give every disputed electoral vote to Hayes. Hayes became president. On April 24, 1877, on his orders, federal troops left the Louisiana state house. It was the last state house in the South that federal troops had guarded.

The Equal Justice Initiative, in its calendar *A History of Racial Injustice*, marks that withdrawal as the end of Reconstruction. Its calendar says the withdrawal opened the way for white supremacist rule to come back in the South with nothing to hold it back. White supremacy is the belief that white people should rule over everyone else.

### Joseph Hayne Rainey

> **Who:** A man born to enslaved parents, forced to work on Confederate defenses, who became the first Black member of the US House and the first to preside over it.
>
> **When and where:** Georgetown, South Carolina, and Washington, D.C. Born June 21, 1832. Sworn in December 12, 1870. Died August 2, 1887.

**Rainey became the first Black member of the House in 1870.**

Joseph Hayne Rainey was the first African American to serve in the House of Representatives. He was born in Georgetown, South Carolina, to enslaved parents. His father, Edward L. Rainey, worked as a barber and used his earnings to buy the family's freedom in the early 1840s.

The Confederacy was the group of Southern states that broke away from the United States and fought it in the Civil War. During the war, the Confederate army forced Rainey to work on the defenses of Charleston. He also worked as a steward, a ship's servant, on a Confederate ship that slipped through the blockade, the line of United States warships that tried to keep ships out of Southern ports.

In 1862 he and his wife escaped to Bermuda. There he ran a barbershop and she ran a dress shop. They came home in 1866.

Rainey won election to a full term in Congress on October 19, 1870, with 63 percent of the vote. On November 8 he won a special election for the rest of the current term, with 86 percent. He was sworn in on December 12, 1870.

**The Klan law.** On April 1, 1871, he spoke for the Ku Klux Klan Act. The Ku Klux Klan was a vigilante group, people who act outside the law, that attacked Black Americans and their white allies in the South. Klansmen whipped men, women and children, and they burned Black schools and churches. In July 1870 Klansmen killed six people, among them a schoolteacher, at Cross Plains, Alabama. Members of Congress gathered testimony that Klansmen in Alabama alone committed more than 100 murders between 1868 and 1871.

Under the Ku Klux Klan Act, it became a federal crime to deny anyone the rights the Constitution protects. President Ulysses S. Grant signed it on April 20, 1871. Rainey said the Constitution owed "protection to the humblest citizen, without regard to rank."

Rainey also supported the Civil Rights Act of 1875. He pressed for equal schooling, and he said "mixed schools," schools for Black and white children together, would "annihilate" prejudice. Annihilate means wipe out.

On April 29, 1874, he led a meeting of the House from the Speaker's chair, the seat of the House's leader. He was the first African American to do so.

On January 25, 1877, Rainey spoke against the Electoral Commission. He warned it could lead to "the election of a President by one man rather than by a majority of the people of the United States." Members of Congress passed the bill anyway.

Rainey lost his seat in 1878, by 62 percent to 38, and left the House on March 3, 1879, after more than eight years. No Black member of Congress served longer than he had until the 1950s. He was the first of fourteen Black representatives who served during Reconstruction. After Reconstruction ended, the number of Black members of Congress fell to zero and stayed near zero for decades.

### The Pendleton Act, 1883

Since Andrew Jackson's time, presidents had handed out government jobs to their supporters. Then Charles Guiteau, a man who had wanted a government job and had not gotten one, killed President James A. Garfield. Chester A. Arthur became president after Garfield. Arthur had come up through New York machine politics.

On January 16, 1883, Arthur signed the Pendleton Act. Under it, some federal jobs went to people who passed a competitive exam, not to people who had worked for the winning party. At first the exam rules covered only about 10 percent of the government's 132,000 workers. The other 90 percent were not covered.

### Taking away the vote in Mississippi and Louisiana

The Fifteenth Amendment barred states from denying the vote because of race. In 1890 the delegates who wrote Mississippi's new constitution set out to stop Black men from voting without naming race. Senator J. Z. George led the convention. Its committee on voting included its one Black delegate, Isaiah Montgomery. The committee members agreed that their task was to take away Black men's votes.

**The rules.** The delegates added a poll tax, a tax of $2 a year that a man had to pay before he could vote. They required two years of living in the state and one in the county. A voter had to swear he had not committed certain crimes, crimes the committee believed Black men were more likely to commit.

State officials printed the ballots, and only a man who could read could use them. A man who could not read could be read a section of the constitution. If he could explain it, he could vote. The registrar alone decided whether he had explained it well enough. The delegates put the new constitution into effect themselves, without a vote of the people.

**What the justices said.** In 1898 the justices of the Supreme Court heard *Williams v. Mississippi*. Williams was a Black man found guilty of murder. Jurors in Mississippi were chosen from the lists of voters. He argued that the voting rules in the 1890 constitution kept Black men off those lists, and so off his jury.

On April 25, 1898, the justices ruled against him, and no justice disagreed. Justice Joseph McKenna wrote that the rules "do not on their face discriminate between the races, and it has not been shown that their actual administration was evil." He went on: "only that evil was possible under them." McKenna meant that the rules did not name any race, and no one had proved that officials used them unfairly, only that they could.

**How long they lasted.** Mississippi's poll tax lasted until 1964 in federal elections and until 1966 in state elections. Its reading test lasted until the Voting Rights Act of 1965. Era 9 describes how each one ended.

**Louisiana.** Louisiana's delegates wrote a new constitution in 1898 and also put it into effect without a vote of the people. Their rules for voters were a poll tax of $1 a year, with receipts for two past years, a reading test given by parish registrars, a test of owning $300 in property, and a grandfather clause. The registrars were the officials who signed up voters in each parish, Louisiana's name for a county. The reading test had no fixed standard.

Under the grandfather clause, a man who failed the tests could still register if his father or grandfather had voted in 1867, a year when formerly enslaved men could not vote in Louisiana. Thomas Semmes chaired the convention's committee on the courts. He said: "We met here to establish the supremacy of the white race, and the white race constitutes the Democratic Party of this State."

**The count.** By the count of the Louisiana encyclopedia *64 Parishes*, 130,344 Black voters were registered in 1897. In 1898 there were 12,902. In 1900 there were 5,320, and in 1922 there were 598.

### Plessy v. Ferguson, 1896

A Louisiana law required railroads to give Black and white passengers separate cars, or cars split by a partition. A person who broke the law could be fined $25 or jailed for 20 days. On May 18, 1896, the justices of the Supreme Court ruled 7 to 1 in *Plessy v. Ferguson* that the law was allowed.

Justice Henry Billings Brown wrote the ruling. He called it a "fallacy," a mistake in reasoning, to believe that "the enforced separation of the two races stamps the colored race with a badge of inferiority." A badge of inferiority means a mark that one group is lower than another.

Justice John Marshall Harlan was the only justice who dissented, or disagreed. He wrote: "Our constitution is color-blind, and neither knows nor tolerates classes among citizens."

### Born here, a citizen: Wong Kim Ark, 1898

Wong Kim Ark was born in San Francisco in 1873 to parents who had come from China. In August 1895 he came home from a trip to China on the ship *Coptic*. Officials refused to let him land, under the Chinese exclusion laws. On October 2, 1895, a writ of habeas corpus was filed on his behalf.

The justices of the Supreme Court ruled 6 to 2 on March 28, 1898, that he was a citizen under the Fourteenth Amendment, because he was born in the United States, whatever his parents' nationality.

### Cumming v. Richmond County, 1899

In June 1897 the members of the school board of Richmond County, Georgia, closed Ware High School, the county's high school for Black students. The board members said they could not afford a high school for 60 Black students while 300 Black children had no primary schooling. They kept paying for the high schools for white students.

J. W. Cumming, James S. Harper and John C. Ladeveze, Black taxpayers, sued. They asked the court to stop the board from spending public money on the white high schools until there was an equal school for their children. They also asked it to stop taxing them for schools their children could not attend.

The justices of the Supreme Court turned them down on December 18, 1899. The justices found no violation of the Fourteenth Amendment and treated the closing as a question of money, not of race.

Justice John Marshall Harlan wrote the ruling. Three years earlier he had been the one dissenter in *Plessy*. Here he wrote that "if it appeared that the board's refusal to maintain such a school was in fact an abuse of its discretion and in hostility to the colored population because of their race, different questions might have arisen." Discretion means the power to decide.

**If you remember one thing:** The three amendments of 1865 to 1870 made Black men citizens and voters, and by 1900 the delegates of the Southern states and the justices of the Supreme Court had taken most of that vote back.

In 1870: The Fifteenth Amendment barred every state from denying a man the vote because of race, and Joseph Rainey of South Carolina sat in the House.

In 1900: Louisiana had 5,320 Black voters on its rolls, down from 130,344 three years earlier, and the justices had allowed Mississippi's voting rules and Louisiana's separate railroad cars.

**Next:** Between 1913 and 1920, four amendments changed who paid, who chose the senators, who could drink and who could vote.

## 1900 to 1950

**Era 8 of 10 · 1900 to 1950 · about 23 minutes**

Four amendments, changes to the Constitution, went in between 1913 and 1920. Under them, Congress could tax incomes, voters chose their senators, alcohol was banned, and no state could deny women the vote. A fifth amendment ended the ban on alcohol in 1933.

President Franklin Roosevelt was elected four times. The justices of the Supreme Court struck down parts of his New Deal, the set of laws he backed in the 1930s, and then he tried to add more justices to the Court. The justices ruled that a Virginia law was allowed, and under it doctors sterilized about 8,300 people, operating on them so that they could never have children. The justices also held that the Army's orders forcing people of Japanese descent from their homes during World War II were justified. About 122,000 people were forced into camps under those orders.

In big cities, the leaders of party organizations called political machines still traded jobs and favors for votes. One of them explained how, and this era opens with him.

### George Washington Plunkitt

> **Who:** A New York machine politician who explained to a reporter, from a shoeshine stand at the New York County Court House, how he made his money and kept his votes.
>
> **When and where:** The Fifteenth Assembly District, New York City. His talks were printed in 1905. He died in 1924.

**"I seen my opportunities and I took 'em."**

George Washington Plunkitt was a district leader for Tammany Hall, the Democratic Party's political machine in New York City. A district leader was the party's boss in one part of the city. Plunkitt led Tammany's work in the Fifteenth Assembly District. He also served as a state senator and as a member of the state assembly, one of the two groups of lawmakers in New York State. He grew up poor. By the time he died in 1924, he was rich.

A newspaperman named William L. Riordon wrote down Plunkitt's talks and published them in 1905 as *Plunkitt of Tammany Hall*. The title page states that Plunkitt gave the talks "from His Rostrum." A rostrum is a speaker's stand, and his was the shoeshine stand at the New York County Court House. The book is not a word-for-word record. Riordon gathered and shaped what Plunkitt said.

Plunkitt split graft into two kinds. Graft is money a person gets by using a public office. Dishonest graft, he said, meant blackmailing gamblers and squeezing money out of illegal businesses. To blackmail people is to make them pay money by threatening to tell their secrets.

Honest graft meant learning where city officials planned to build something, buying the land first and then selling it to the city at a profit. "I ain't no looter," he said. "The looter hogs it. I never hogged." His summary of himself is cut into his gravestone: "I seen my opportunities and I took 'em."

He also described the everyday work of a machine. When a building burned at night, Plunkitt and his captains, the party workers under him, came to the fire and found the families shelter and clothes on the spot. He knew employers across the city and got people jobs. His men found families in trouble before the charity groups did. He said he did it because those people remembered him on election day.

### The food laws of 1906

President Theodore Roosevelt signed two laws on the same day, June 30, 1906. The Pure Food and Drug Act banned selling food, drink or drugs across state lines if they were mislabeled or made impure. Harvey Wiley and the officials of his Bureau of Chemistry enforced it. In 1930 that office was renamed the Food and Drug Administration. The Meat Inspection Act required federal inspectors in meatpacking plants, set rules for cleanliness and banned false labels. The laws followed Upton Sinclair's book *The Jungle*, published in February 1906, and years of work by Wiley's team.

### Two amendments in 1913

**The income tax.** Members of Congress put a 2 percent tax on incomes over $4,000 into a tariff bill in 1894. A tariff is a tax on goods brought in from other countries. The Supreme Court's justices struck the income tax down, 5 to 4.

Members of Congress passed the Sixteenth Amendment on July 2, 1909. According to the National Archives, the conservatives who proposed it expected it never to be ratified. An amendment is ratified, or approved, when lawmakers or special meetings in three-quarters of the states have voted for it. The Sixteenth Amendment was ratified on February 3, 1913. Under it, Congress may tax incomes "without apportionment among the several States." That meant the money did not have to be divided among the states by population.

**Senators chosen by voters.** The Seventeenth Amendment was ratified on April 8, 1913, when Connecticut's lawmakers voted for it and completed the three-quarters needed. Before it, the lawmakers of each state chose that state's senators. After it, the voters chose them. Augustus Bacon of Georgia was the first senator elected by the voters under the new amendment, on July 15, 1913.

### The grandfather clause struck down, 1915

Under a 1910 amendment to Oklahoma's constitution, Black men had to pass a reading test to vote, and white men were excused from it. The amendment excused anyone who could vote "on January 1st, 1866, or at any time prior thereto." It also excused any "lineal descendant" of such a person, meaning a child or grandchild. Almost no Black man could vote before 1866, so nearly all white men were excused and Black men had to take the test. A rule like this is called a grandfather clause, because it excused a man whose grandfather could vote.

Federal prosecutors, the government lawyers who bring criminal charges for the United States, charged two Oklahoma election officers, Frank Guinn and J. J. Beal, with keeping Black citizens from voting under this rule. The justices of the Supreme Court ruled against the 1866 clause in *Guinn v. United States* on June 21, 1915.

They held that it was void, meaning it had no force, because it broke the Fifteenth Amendment. That amendment bars the United States and every state from denying a citizen the vote "on account of race, color, or previous condition of servitude." Chief Justice Edward White wrote the opinion.

### Prohibition and repeal

Members of Congress passed the Eighteenth Amendment on December 18, 1917, and lawmakers in the states ratified it on January 16, 1919. It banned "the manufacture, sale, or transportation of intoxicating liquors," meaning alcoholic drinks. The ban began one year after ratification, in January 1920.

Fourteen years later, members of Congress voted to end the ban. They passed the Twenty-first Amendment on February 20, 1933. Its first section reads: "The eighteenth article of amendment to the Constitution of the United States is hereby repealed." To repeal a law is to cancel it. Members of Congress sent this amendment to special conventions, meetings held in each state to decide on it, and not to the state lawmakers. It was ratified on December 5, 1933. No other amendment repeals another, and no other was sent to state conventions.

### The Nineteenth Amendment, 1920

Members of the House passed the Nineteenth Amendment on May 21, 1919, and senators passed it on June 4, 1919. On August 18, 1920, Tennessee's lawmakers ratified it. Their vote made Tennessee the thirty-sixth state to ratify, which was enough. Secretary of State Bainbridge Colby certified it, or officially declared it part of the Constitution, on August 26, 1920.

Its words are: "The right of citizens of the United States to vote shall not be denied or abridged by the United States or by any State on account of sex." Abridged means cut down. After it, no state could keep the vote for men only, as the justices had allowed in *Minor v. Happersett*.

**By 1920:** Four amendments in seven years had given Congress the income tax, given voters the choice of their senators, banned alcohol, and barred every state from keeping the vote from women. The rules that kept Black men from voting in the South still stood, except the grandfather clause.

### Quotas, and citizenship for Native people, 1921 and 1924

In 1921 members of Congress passed the Emergency Quota Act, the first law with a set limit on how many immigrants could come. A quota is a fixed share. Under the act, the yearly limit for each nationality was 3 percent of the people born in that country who were living in the United States in 1910.

In 1924 members of Congress passed the Immigration Act, which set a lower limit. It was 2 percent of the people born in each country who were living in the United States in 1890, as the census of that year counted them. A census is a count of all the people in the country. Under the 1924 act, fewer immigrants could come from Southern and Eastern Europe than before, and nearly all immigrants from Asia were barred. The total was capped at about 165,000 a year.

**Citizens, but not voters.** President Calvin Coolidge signed the Indian Citizenship Act on June 2, 1924. Under it, American Indians became citizens. Since 1884, under the justices' ruling in *Elk v. Wilkins*, Native people born into their own nations had not been citizens by birth. Even as citizens, they were not on the lists of voters in every state, because each state's lawmakers wrote their own rules about who could vote.

An Arizona law barred people "under guardianship" from voting. In 1928 the judges of the Arizona Supreme Court held that Native people on reservations were wards of the federal government, people under its guardianship. So, the judges held, the law kept them from voting. New Mexico's constitution shut out "Indians not taxed."

In 1948 judges in both states ended these bans. On July 15 the judges of the Arizona Supreme Court overturned their own 1928 ruling in *Harrison v. Laveen*. Justice Levi Udall wrote that ruling. In August a federal court in New Mexico ruled in *Trujillo v. Garley* that the "Indians not taxed" rule broke the Constitution. In Utah, Native people could not vote until 1957, later than in any other state.

### The anti-lynching bill, 1922

Lynching is murder by a mob, carried out without any trial. Members of Congress introduced bills to make lynching a federal crime, one the national government could charge. George Henry White, then the only Black member of Congress, introduced one on January 20, 1900. Leonidas Dyer, a Republican representative from Missouri, introduced another on April 8, 1918. Members of the House passed Dyer's bill on January 26, 1922. Senators opposed to it blocked it in the Senate, and it never became law. No federal anti-lynching law passed in this era.

### Teapot Dome

In the Teapot Dome case, a member of the president's cabinet leased Navy oil land to two oil men who gave him money. The cabinet is the group of officials who head the big government departments. Albert B. Fall was Secretary of the Interior under President Warren G. Harding. Fall persuaded Harding to move the Navy's oil reserves, land kept for the Navy's future oil, to the Interior Department, and the Secretary of the Navy carried out the transfer.

**The leases and the money.** Fall then leased, or rented out, the Teapot Dome reserve in Wyoming to Harry F. Sinclair's Mammoth Oil company. He leased the Elk Hills reserve in California to Edward Doheny's Pan-American Petroleum. Doheny gave Fall a $100,000 "loan" with no interest. Sinclair gave him about $300,000 in cash and government bonds, papers the government promises to pay back with interest.

**The investigation.** In October 1923 the senators on the Public Lands Committee opened an investigation. Senator Thomas J. Walsh of Montana led it for about two years, and he found Doheny's $100,000. In 1927 the justices of the Supreme Court ruled that the oil men had gotten the leases corruptly, meaning by dishonest deals.

On October 25, 1929, a jury found Fall guilty of taking a bribe from Doheny. A bribe is money given to an official in return for a favor. A judge sentenced Fall to one year in prison and a $100,000 fine. He was the first person found guilty of a crime he committed while serving in a president's cabinet.

Doheny was found not guilty of paying the same bribe. Sinclair went to jail for several months, for contempt of Congress, the crime of refusing to obey Congress or one of its committees, and for having the jury in his case followed.

### School law: who decides, and who pays

**Who decides where a child goes to school.** Oregon's Compulsory Education Act of 1922 required parents to send children aged 8 to 16 to the public school in their district. Compulsory means required. The Society of the Sisters of the Holy Names of Jesus and Mary, which ran Catholic schools, sued Oregon's governor, Pierce, over the law. A second case was brought for Hill Military Academy.

The justices of the Supreme Court struck the law down in *Pierce v. Society of Sisters* on June 1, 1925. Justice James McReynolds wrote that it interfered with the liberty of parents to direct their children's education. He wrote: "The child is not the mere creature of the state." He meant that a child does not belong to the government, and that the people who raise a child have the right to guide the child's future.

Under that ruling, state lawmakers may require a child to be educated, but they may not require every child to attend a government school. Private schools and church schools are legal because of it. Homeschooling depends on the same ruling, but it became legal only later, state by state, in the 1980s and early 1990s.

**Who decides what a teacher may teach.** Tennessee's governor, Austin Peay, signed the Butler Act on March 21, 1925. It made it unlawful to teach in the state's public schools "any theory that denies the story of Divine Creation of man as taught in the Bible, and to teach instead that man has descended from a lower order of animals." That meant a teacher could not teach evolution, the scientific idea that living things, people included, developed over a very long time from earlier forms.

Civic leaders in Dayton, Tennessee, heard that the American Civil Liberties Union would pay for a court challenge to the law. They set up a test case, a trial arranged on purpose so that a court would rule on the law. They asked John T. Scopes, a football coach and science teacher, whether biology could be taught without evolution. He said it could not, because the state's own approved textbook included it.

His trial opened in Dayton on July 10, 1925, before Judge John T. Raulston. On July 21 the jury found him guilty, and he was fined $100, the smallest fine the law allowed.

In January 1927 the judges of the Tennessee Supreme Court threw out his conviction. The state constitution required a jury, not a judge, to set any fine over $50, and Raulston had set the fine himself. So the judges never ruled on the Butler Act itself. It stayed in force until 1967.

**Who pays.** Between 1920 and 1950, more and more of the money for public schools came from the states, and less from local school districts. In the school year 1919-20, local money made up 83.2 percent of the money for public schools. By 1949-50 the local share had fallen to 57.3 percent. Nearly all the rest came from the state, and less than 3 percent from the federal government. Small districts were merged, and their number fell by almost a third between 1937-38 and 1949-50.

### Buck v. Bell, 1927

Virginia's lawmakers passed a law in 1924 that allowed state officials to sterilize people they judged "feeble-minded" and likely to have "socially inadequate offspring." Sterilization is an operation that makes a person unable ever to have children. "Feeble-minded" was a label officials put on people they judged to be slow to learn. Offspring means children. Aubrey Strode wrote the law and then defended it in court.

Carrie Buck was born on July 2, 1906, in Charlottesville. She was raised by foster parents, the Dobbs family. In 1923 she became pregnant. By her own account, as Encyclopedia Virginia reports it, Clarence Garland, the foster parents' nephew, raped her. Rape means forcing a person into sex. Her foster parents believed the pregnancy showed promiscuity, meaning sex with many partners, and so showed that she was "feebleminded." On January 23, 1924, they asked a court to have her committed to a state institution, meaning sent there to live by a court's order.

**The ruling.** Her case went to a trial court under Judge Bennett T. Gordon on November 18, 1924, then to Virginia's Supreme Court of Appeals on November 12, 1925, and then to the Supreme Court. On May 2, 1927, the justices ruled 8 to 1 that Virginia's law was allowed. Justice Oliver Wendell Holmes wrote the opinion. It includes the sentence "Three generations of imbeciles are enough." Imbecile was another insulting label for a person judged slow to learn. Justice Pierce Butler dissented, meaning he disagreed with the ruling, without writing an opinion.

**The operation.** She had been sent to the Virginia State Colony for Epileptics and Feebleminded, a state home for people who had seizures or were judged slow to learn. Dr. Albert Priddy ran it. He picked her for the operation, and on September 10, 1924, the colony's board approved it. Carrie Buck did not agree to it. Near the end of her life she said she "kicked against it," and she told the historian Paul Lombardo, "They done me wrong. They done us all wrong."

On October 19, 1927, Dr. John H. Bell performed the operation on Carrie Buck. It is called a salpingectomy. He cut her fallopian tubes, the tubes that carry eggs to the womb, so that she could never become pregnant again.

**The 8,300.** Between 1927 and 1972, doctors in Virginia sterilized about 8,300 people under the law. Encyclopedia Virginia names the two main operations: a vasectomy for men, which cuts the tubes that carry sperm, and a salpingectomy for women. It does not say which operation was done on each person. Virginia's lawmakers repealed the law in 1974. On May 2, 2002, Governor Mark Warner apologized for the state's program. No later group of justices has overruled *Buck v. Bell*, or cancelled it with a new ruling.

**By 1927:** The justices had struck down the grandfather clause and allowed the sterilization law. Tennessee's teachers still could not teach evolution, and most of the money for schools was still local.

### Franklin D. Roosevelt

> **Who:** The president who lost key cases in the Supreme Court, tried to add justices to it, and was elected four times.
>
> **When and where:** Washington, D.C., 1933 to 1945. His plan for the courts went to Congress on February 5, 1937.

**After losing in the Supreme Court, Roosevelt tried to add up to six justices.**

Franklin D. Roosevelt tried to change the size of the Supreme Court after its justices struck down one of his laws. On May 27, 1935, in *Schechter Poultry Corp. v. United States*, the justices struck down part of the National Industrial Recovery Act. That part let the president approve "codes of fair competition," which were rules for whole industries.

The justices held that members of Congress had given the president powers that Congress had no right to give away. They also held that the poultry business in the case was not trade between the states, so Congress could not make rules for it.

On February 5, 1937, Roosevelt sent Congress a plan to reorganize the federal courts. Under the plan, the president could name one new justice to the Supreme Court for each justice over the age of 70, up to six more. The Court could have grown from nine justices to fifteen.

On March 29, 1937, in *West Coast Hotel Co. v. Parrish*, the justices ruled that Washington State's minimum wage for women and minors was allowed. A minimum wage is the lowest pay the law allows, and minors are young people who are not yet adults. Soon after, they ruled that other New Deal laws were allowed too.

**Did the plan change the justices' minds?** Many people at the time believed it had. As the historian William Leuchtenburg describes it, they believed the justices, and Justice Owen Roberts above all, had "crossed over." The legal historians G. Edward White and Barry Cushman argue against that. Court papers show that Roberts had already voted for the Washington law at the justices' private meeting on December 19, 1936, weeks before Roosevelt sent his plan to Congress.

On June 14, 1937, the members of the Senate Judiciary Committee told the Senate to reject the plan. They called it "needless, futile, and utterly dangerous." On July 22, 1937, the senators rejected it, 70 to 20. According to the Federal Judicial Center, Roosevelt lost a great deal of political support for proposing it.

**Four terms.** The senators turned down his court plan, but the voters elected him twice more. George Washington had served two terms, and presidents after him had kept that custom. Roosevelt was elected four times, in 1932, 1936, 1940 and 1944.

**An order on jobs.** In his third term, Roosevelt barred discrimination in defense work and government jobs with an order of his own. He signed Executive Order 8802 on June 25, 1941. An executive order is a written order from the president to the officials under him.

The order states: "There shall be no discrimination in the employment of workers in defense industries and in Government, because of race, creed, color, or national origin." Discrimination means treating people worse because of who they are. A creed is a religion. With the order, Roosevelt created the Committee on Fair Employment Practice. After the war, members of Congress refused to make that committee permanent.

**The camps.** Eight months after the jobs order, Roosevelt signed a second one, Executive Order 9066, on February 19, 1942. It let the Secretary of War and military commanders mark off military areas and shut "any or all persons" out of them. Lieutenant General John L. DeWitt, commander of the Army's Western Defense Command, used it to force people of Japanese descent from their homes. He issued Public Proclamation No. 4, an official public order, on March 29, 1942.

Over six months, under his orders, about 122,000 men, women and children were forced into assembly centers, which were short-term holding places. From there they were forced into ten camps in remote parts of six western states and Arkansas. Nearly 70,000 of them were American citizens, by the count of the National Archives. None was charged with a crime, and none had any way to appeal.

### The courts and the camps

A federal court in San Francisco found Fred Korematsu guilty of breaking the military's exclusion orders, the orders that shut people of Japanese descent out of the military areas. It gave him five years of probation, a time when a person found guilty lives under a court's watch instead of in prison. On December 18, 1944, in *Korematsu v. United States*, the justices of the Supreme Court let his conviction stand, 6 to 3. They held that forcing citizens out of their homes in wartime was justified.

On the same day, in *Ex parte Endo*, all the justices agreed that federal officials could not hold a citizen whom they admitted was loyal. According to the National Archives, that ruling "paved the way for the end of mass confinement."

In the 1980s federal judges threw out the convictions of Korematsu and others. Judge Marilyn Hall Patel vacated, or cancelled, Korematsu's conviction on November 10, 1983. In the Civil Liberties Act of 1988, members of Congress apologized for the imprisonment and voted to pay $20,000 to each person who had been held.

### Poll taxes and the white primary

**The poll tax.** Under Georgia law, a voter owed a poll tax of $1 a year, and officials let no one vote who had not paid it. People under 21 or over 60, blind people, and women who did not register to vote did not have to pay. A poll tax kept anyone who could not pay it from voting. In 1890 the delegates who wrote Mississippi's constitution had added one as part of their plan to stop Black men from voting.

Nolan Breedlove sued Georgia's tax collector, T. Earl Suttles. All the justices of the Supreme Court ruled that the tax was allowed, in *Breedlove v. Suttles* on December 6, 1937. Justice Pierce Butler wrote that "the equal protection clause does not require absolute equality." The equal protection clause is the part of the Fourteenth Amendment that requires states to treat people equally under the law.

**The white primary.** In Texas, the Democratic Party was the only party that won elections, so its primary was the election that counted. A primary is the election in which a party chooses its candidates. On May 24, 1932, the leaders of the Texas Democratic Party voted that only "white citizens" could be members. The election judges of precinct 48 in Harris County refused Lonnie Smith, a Black voter, a ballot in the primary. A precinct is one small voting area. Smith sued one of those judges, a man named Allwright, and the others.

In *Smith v. Allwright*, decided on April 3, 1944, the justices held that the party's leaders were acting for the state when they ran the primary. Keeping Black voters out of it therefore broke the Fifteenth Amendment. Justice Stanley Reed wrote the opinion. Justice Owen Roberts dissented.

### Ending California's law on segregated schools, 1947

Governor Earl Warren of California signed the Anderson Bill in June 1947. With it, California's lawmakers and governor became the first in the country to repeal their own state's law on segregated schools. Segregated schools kept children of different races apart.

### 1948: the armed forces, refugees and conventions on television

On July 26, 1948, President Harry Truman signed Executive Order 9981. It states: "There shall be equality of treatment and opportunity for all persons in the armed forces without regard to race, color, religion or national origin." By about 1953 Black and white troops served together in nearly all the armed services.

The Displaced Persons Act of 1948 was the first American law for refugees, people forced from their home countries. It first allowed 200,000 Europeans who had lost their homes in the war to come to the United States. Members of Congress raised the number later. Between 1948 and 1952 about 350,000 to 400,000 people came in under it.

Both major parties held their national conventions in Philadelphia in 1948, and television networks broadcast them. A national convention is a large meeting of a party. Delegates, the people each state's party sends, choose the party's candidate for president there. They also write its platform, the list of positions it stands for. The National Constitution Center puts the television audience at as many as 10 million viewers on the East Coast.

On July 12, 1948, after a speech by Hubert Humphrey, the Democratic delegates added a civil rights plank to their platform. A plank is one position in a platform. Civil rights are the rights every citizen has to equal treatment under the law. Two Southern delegations walked out on live television.

On July 17, Southern delegates met in Birmingham, Alabama, and formed the States' Rights Democratic Party, called the Dixiecrats. They chose Strom Thurmond, the governor of South Carolina, as their candidate. Their platform stated, "We stand for the segregation of the races." Thurmond won four states and 39 electoral votes.

**If you remember one thing:** In this era the justices allowed a state to sterilize people who had not agreed to it and allowed the Army to force 122,000 people into camps, and later officials apologized for both.

About 122,000 men, women and children of Japanese descent were forced into camps in 1942, nearly 70,000 of them American citizens, more than half. None was charged with a crime. In 1988 members of Congress apologized and voted to pay each person who had been held $20,000. Virginia's governor apologized for the sterilizations in 2002. No later justices have overruled *Buck v. Bell*.

**Next:** In 1954 the same Court ruled that segregated schools broke the Constitution, and the fight moved to how fast anything had to change.

## 1950 to 2000

**Era 9 of 10 · 1950 to 2000 · about 24 minutes**

A senator with a brain tumor, unable to speak, pointed to his eye to vote "aye" on June 10, 1964, and the Senate cut off debate on a civil rights bill for the first time. That law banned segregation in public places. Under a second law, in 1965, officials in some states and counties had to ask federal officials before changing any voting rule. Between 1954 and 1977 the justices of the Supreme Court decided cases on schools, on how votes and voting districts were counted, and on how police question people they arrest.

Five amendments were added to the Constitution between 1951 and 1971. In 1974 President Richard Nixon resigned before members of the House could vote to impeach him. To impeach a president is to charge him formally with wrongdoing, which leads to a trial in the Senate. In 1998 the members of the House impeached President Bill Clinton, and the senators found him not guilty.

### Five amendments, 1951 to 1971

Each of the five amendments added between 1951 and 1971 governs who holds office or who votes.

Since the Twenty-second Amendment was ratified on February 27, 1951, "No person shall be elected to the office of the President more than twice." Before it, Washington's two terms had been a custom, and Franklin Roosevelt had broken it. Members of Congress proposed the amendment in 1947, and Minnesota's lawmakers made it the thirty-sixth state to approve it.

The District of Columbia, the capital city, got electors in presidential elections through the Twenty-third Amendment, ratified on March 29, 1961. The District got no senators and no voting member of the House.

The Twenty-fourth Amendment, ratified on January 23, 1964, bans poll taxes only in elections for president, vice president, senator and representative. A state could still charge a poll tax in its own elections.

Then, on March 24, 1966, in *Harper v. Virginia State Board of Elections*, the justices of the Supreme Court struck down state poll taxes too. Virginia's constitution had set a poll tax of up to $1.50 a year. Justice William O. Douglas wrote that making "the affluence of the voter or payment of any fee an electoral standard" breaks the Equal Protection Clause. Affluence means wealth.

The Twenty-fifth Amendment was ratified on February 10, 1967. It states what happens when a president dies, resigns or is removed. It also sets out a way to fill an empty vice presidency: the president names someone, and the members of both houses of Congress vote to confirm, or approve, the choice.

Eighteen-year-olds got the vote under the Twenty-sixth Amendment. It was ratified on July 1, 1971, faster than any other amendment.

### Brown v. Board of Education and all deliberate speed

On May 17, 1954, in *Brown v. Board of Education*, the justices of the Supreme Court held that segregated public schools broke the Constitution. The ruling did not state how or when to end segregation.

A year later, on May 31, 1955, they decided a second case, often called *Brown* II. Chief Justice Earl Warren wrote for a unanimous Court, meaning every justice agreed. The justices sent the cases back to federal district judges, the judges of the lowest federal courts. They told school boards to make "a prompt and reasonable start toward full compliance." Compliance means obeying the ruling.

They ordered the judges to admit the children who had sued to public schools "on a racially nondiscriminatory basis with all deliberate speed." A racially nondiscriminatory basis meant that no child could be turned away because of race. Deliberate means careful and unhurried, so under those words school boards could move slowly. The order set no date. School board members who moved slowly were not clearly breaking it.

### Thurgood Marshall

> **Who:** The lawyer who won 29 of the 32 cases he argued in the Supreme Court and later became its first Black justice.
>
> **When and where:** Baltimore, New York and Washington, D.C. Born 1908. Died 1993.

**The law school that turned him away had to admit Black students three years later.**

Thurgood Marshall wanted to study law at the University of Maryland, and officials at the law school turned him away because he was Black. He went to Howard University's law school instead and graduated first in his class in 1933. One of his first cases, *Murray v. Pearson*, ended with Maryland's judges ordering that same law school to admit Black students. The Maryland Court of Appeals ruled in the case on January 15, 1936.

He went on to hold four jobs in the American legal system. From 1940 to 1961 he ran the Legal Defense and Educational Fund of the NAACP, a law office whose lawyers took civil rights cases to court. The NAACP is the National Association for the Advancement of Colored People. Colored was a word used then for Black people.

After that he was a federal appeals judge, then Solicitor General, the officer who argues the government's own cases in the Supreme Court, and then a justice of the Supreme Court. He was the first Black justice.

Before he became a justice, he argued 32 cases in the Supreme Court and won 29.

**Disputed:** When he argued them. The NAACP's own history puts all 32 in his years at the Fund. The *New York Times* put 18 of them in his years as Solicitor General, and the National Park Service counts 19 cases in that job, 14 of them won.

His NAACP cases included *Smith v. Allwright* in 1944, *Morgan v. Virginia* in 1946 on segregated buses between states, *Sweatt v. Painter* in 1950 on the University of Texas law school, and *Brown v. Board of Education* in 1954.

On October 5, 1961, President John F. Kennedy made Marshall a judge of the United States Court of Appeals for the Second Circuit, a court that hears appeals from trial courts. He did it by recess appointment, which means a president fills the seat while the Senate is away. A recess appointment ends unless the senators confirm it. Southern senators opposed Marshall, and the senators did not confirm him until September 11, 1962, eleven months later.

He left that court on August 23, 1965, to become Solicitor General of the United States. President Lyndon Johnson nominated him, or named him, to the Supreme Court on June 13, 1967. The senators confirmed him on August 30, 1967, and he took the oath as a justice on October 2. He stopped full-time work on the Court on October 1, 1991, and died on January 24, 1993.

After his death, Chief Justice William Rehnquist said most justices are remembered for their work on the Court. "Justice Marshall, however, is unique because his contributions to constitutional law before becoming a member of the Court were so significant."

### Prayer and the Bible in public schools, 1962 and 1963

The members of the New York State Board of Regents, the officials who oversaw the state's schools, wrote a prayer for public school children to say each morning. It read: "Almighty God, we acknowledge our dependence upon Thee, and we beg Thy blessings upon us, our parents, our teachers and our Country." No child had to say it.

On June 25, 1962, in *Engel v. Vitale*, the justices of the Supreme Court held the prayer unconstitutional anyway, 6 to 1. Unconstitutional means against the Constitution. The justices ruled against the prayer because government officials had written it.

The prayer was short and a child could stay silent, and the justices held that neither fact changed the ruling. Justice Hugo Black wrote that the First Amendment's ban on establishing a religion, meaning setting up an official religion, "must at least mean that in this country it is no part of the business of government to compose official prayers for any group."

The justices decided two more cases together in *Abington School District v. Schempp* on June 17, 1963. In Pennsylvania's public schools, the school day opened with Bible readings. In the Baltimore city schools, children said the Lord's Prayer together. The justices struck down both. Justice Tom Clark wrote the opinion, and Justice Potter Stewart was the only one to dissent.

### One person, one vote

Under Georgia's county unit system for statewide elections, the candidate who won a county got all of that county's unit votes. So a vote in a small rural county counted many times as much as a vote in a city. The justices struck the system down, 8 to 1, in *Gray v. Sanders* on March 18, 1963. Justice William O. Douglas wrote: "The conception of political equality from the Declaration of Independence, to Lincoln's Gettysburg Address, to the Fifteenth, Seventeenth, and Nineteenth Amendments can mean only one thing." He ended the sentence with the words "one person, one vote."

On June 15, 1964, in *Reynolds v. Sims*, the justices applied the same rule to the lawmaking bodies of the states. Alabama's lawmakers had not redrawn the lines of the state's legislative districts, the areas that elect the state's lawmakers, since 1901. They still used the 1900 census. By 1960, 25.1 percent of Alabamians could elect a majority of the state senate. In the worst case, one senate district had about 41 times as many people as another.

Chief Justice Earl Warren wrote the opinion. Under it, districts had to hold about equal numbers of people, and lawmakers in almost every state had to redraw their districts.

### Lyndon B. Johnson

> **Who:** A Senate leader who kept count of how each senator would vote, then a president who used the same skill on civil rights laws.
>
> **When and where:** Texas and Washington, D.C., 1948 to 1969.

**Johnson's 87-vote win in 1948 earned him the nickname "Landslide Lyndon."**

Lyndon Johnson reached the Senate in 1948 by 87 votes, out of nearly a million cast. That was his final margin over Coke Stevenson in the Texas Democratic runoff, a second election between the top two candidates in the party's primary. A landslide is a win by a huge margin. For the rest of his life people called him "Landslide Lyndon."

**Precinct 13.** On the night of the runoff, Johnson seemed to have lost. Six days after the polls closed, an election judge named Luis Salas reported 202 more votes from Precinct 13 in Jim Wells County. Of them, 200 were for Johnson and 2 for Stevenson. He had changed the total on the tally sheet from 765 to 965. The added names were in alphabetical order, in the same ink and the same handwriting. Some of the people listed said they had not voted that day.

The members of the state party's executive committee voted 29 to 28 to declare Johnson the winner. A federal judge, T. Whitfield Davidson, blocked that result. Then Supreme Court Justice Hugo Black, acting alone, ruled for Johnson. He ruled aloud on September 28, 1948, and in writing the next day. Johnson's name went on the ballot.

In 1977 Salas told a reporter, James Mangan of the Associated Press, that the local political boss, George B. Parr, had ordered about 200 votes added. No court ever ruled that the votes were forged, and Johnson was never charged.

**The vote counter.** Johnson became his party's whip in the Senate in 1951. The whip counts votes and keeps party members in line. In 1953 he became its minority leader, the leader of the smaller party, and from 1955 to 1961 he was majority leader, the leader of the larger party. At 45, still in his first term, he was the youngest party leader the Senate had ever had.

The Senate's historians describe how he worked on other senators. He stood close to a senator's face and pulled "clippings, memos, statistics" out of his pockets. They list the tones he used: begging, accusing, coaxing, high spirits, scorn, tears, complaint and "the hint of threat."

In 1957 he pushed through the first civil rights law since Reconstruction, the years after the Civil War. He wanted it passed, but he feared a long filibuster would split his party. A filibuster is a way of blocking a bill by talking on and on so that no vote can happen. To get the bill through, he took out its main enforcement sections. Members of Congress passed it without them. According to the Senate's own history, very little changed because of it.

As president, Johnson signed the Civil Rights Act on July 2, 1964. On April 11, 1965, he signed the Elementary and Secondary Education Act, and he said, "no law I have signed or will ever sign means more to the future of America." On August 6, 1965, he signed the Voting Rights Act. It included the kind of enforcement tools that the 1957 law had been passed without. Federal examiners could register voters themselves, and some states had to ask federal officials before changing any voting rule.

### How the civil rights laws passed

**The filibuster.** Southern senators led by Richard Russell of Georgia tried to block the Civil Rights Act of 1964 with a filibuster. They held the Senate floor, meaning they kept talking so that no vote could happen, for 60 working days, including seven Saturdays. On June 10, 1964, the senators voted 71 to 29 for cloture, the motion that ends debate. It was the first time senators had ever cut off debate on a civil rights bill.

Senator Clair Engle of California had a brain tumor and could not speak. He raised his weakened arm and pointed to his eye to vote aye, which means yes. The senators passed the bill 73 to 27 on June 19.

**What the 1964 act says.** The act has ten parts, called titles. Title II bans segregation in places that serve the public. Its words are: "All persons shall be entitled to the full and equal enjoyment of the goods, services, facilities, and privileges ... of any place of public accommodation ... without discrimination or segregation." Title VI bans discrimination in any program paid for with federal money.

Later, federal officials used Title VI to cut off money to school districts that stayed segregated. Title VII bans discrimination in jobs. In Title VII, members of Congress also created the Equal Employment Opportunity Commission.

**What the 1965 act says.** Section 4 of the Voting Rights Act of 1965 contains a formula for which places were covered. A state or county was covered if it had used a literacy test, a reading test for voters, or a similar device on November 1, 1964. It also had to have fewer than half of its voting-age people registered or voting in the 1964 presidential election. With the act, members of Congress outlawed literacy tests in the covered places.

Under Section 5, officials in every covered place had to get permission before changing any voting rule at all. The permission had to come from the Attorney General, the head of the Justice Department, or from a federal court in Washington. By the end of 1965, a quarter of a million new Black voters had been registered, one-third of them by federal examiners, according to the National Archives.

**By 1965:** The justices had ruled that segregated schools, official school prayers and unequal voting districts all broke the Constitution. Members of Congress had passed the two civil rights laws, and federal examiners were registering Black voters in the South.

### Federal money for schools, 1965

Johnson signed the Elementary and Secondary Education Act on April 11, 1965, outside the former Junction Elementary School near Stonewall, Texas. Elementary and secondary schools are the schools for children from first grade through high school. Junction Elementary was the one-room school where he had started at the age of four. His first teacher, Kate Deadrich Loney, sat beside him.

Under Title I of the act, federal officials send money to school districts according to how many children in them come from families with low incomes. The money comes with conditions the districts have to meet. In the 2015 budget year, about $14.3 billion went out under Title I, according to the National Center for Education Statistics in 2019.

### Immigration law after 1965

Members of Congress passed the Immigration and Nationality Act in 1965. Under it, the national quotas set in the 1920s ended, and officials admitted immigrants on the basis of family ties and skills. The act also set the first cap on immigration from the Americas.

The Refugee Act of 1980 set out a permanent system for admitting refugees. The Immigration Reform and Control Act became law on November 6, 1986. Under it, about 2.7 million people who had lived in the country for years without permission got legal status, meaning the right to stay. The act also set penalties for employers who hired workers without permission to work.

### Miranda v. Arizona, 1966

On March 13, 1963, police arrested Ernesto Miranda at his home in Phoenix, Arizona. They questioned him in a police interrogation room, a room for questioning suspects. After about two hours he signed a written confession. At his trial the officers admitted that no one had told him he could have a lawyer with him. An Arizona court found him guilty of kidnapping and rape.

The justices of the Supreme Court set a rule for police in *Miranda v. Arizona* on June 13, 1966. Chief Justice Earl Warren wrote the opinion. Before questioning a person in custody, meaning held by police and not free to leave, police must give four warnings. The person has the right to remain silent. Anything the person says can be used against them in court. The person has the right to a lawyer. If they cannot pay for one, a lawyer will be appointed, or provided free. If the person asks for those rights, the questioning must stop.

### School law in the 1970s

**The Amish fathers.** Wisconsin law required children to attend school until age 16. Three fathers did not send their children to high school after the eighth grade. Jonas Yoder and Wallace Miller belonged to the Old Order Amish church, and Adin Yutzy to the Conservative Amish Mennonite church. Their children were Frieda Yoder and Barbara Miller, both 15, and Vernon Yutzy, 14. Each father was fined $5.

The justices of the Supreme Court held 6 to 1 in *Wisconsin v. Yoder*, on May 15, 1972, that Wisconsin officials could not make the fathers send their children to high school. Chief Justice Warren Burger wrote the opinion. The justices found that the families' way of life was a religious practice, lived every day and centuries old. They held that Wisconsin's officials had not shown that two more years of school mattered enough to override that practice, which the First Amendment protects.

**Title IX.** The Education Amendments of 1972 became law on June 23, 1972. Title IX of that law states: "No person in the United States shall, on the basis of sex, be excluded from participation in, be denied the benefits of, or be subjected to discrimination under any education program or activity receiving Federal financial assistance." That means a school or college that gets federal money may not treat a student worse because the student is a girl or a boy.

**Is education a right?** Texas schools were paid for partly with local property taxes. A property tax is a tax on the value of land and buildings. In the school year 1967-68, two school districts in San Antonio spent different amounts on each pupil. Edgewood, whose students were mostly Mexican American, spent $356 on each pupil. Alamo Heights spent $594.

In *San Antonio Independent School District v. Rodriguez*, on March 21, 1973, the justices decided 5 to 4 that education is not a fundamental right. A fundamental right is a right the Constitution itself protects. They found no right to education written in the Constitution or clearly implied by it. Justice Lewis Powell wrote the opinion.

Texas officials only had to show that their way of paying for schools was rational, meaning it had a sensible reason. Keeping schools under local control counted as a sensible reason. After 1973, people who sued over unequal school money had to go to state courts, under state constitutions.

**Children with disabilities.** President Gerald Ford signed the Education for All Handicapped Children Act on November 29, 1975. Handicapped is an older word for disabled. Under the act, every child with a disability had a right to a free, appropriate public education.

The Department of Education's history of the law states that in 1970, schools in the United States educated only one in five children with disabilities. It also states that members of Congress were concerned about "the more than 1 million children with disabilities excluded entirely from the education system."

The history also records that under the laws of many states, certain children were not allowed in school. Those laws applied to children who were deaf or blind. They also applied to children with an intellectual disability, a condition that makes learning and thinking much harder, and to children who were emotionally disturbed, meaning they had serious trouble controlling their feelings and behavior.

**The paddle.** In October 1970, James Ingraham was a student at Drew Junior High School in Dade County, Florida. Because he was slow to follow a teacher's instructions, he was held over a table in the principal's office and hit more than 20 times with a wooden paddle. School policy allowed one to five blows, called licks, on the buttocks with a flat wooden paddle less than two feet long, three to four inches wide and about half an inch thick.

The beating raised a hematoma, a pocket of blood under the skin. He needed a doctor, and he missed school for several days.

His family sued three school officials: the principal, Willie J. Wright, an assistant principal, Lemmie Deliford, and an assistant to the principal, Solomon Barnes. The Supreme Court's opinion does not say who held him or who struck him. Another student, Roosevelt Andrews, was paddled several times for small offenses. Once he was hit on the arms and lost the full use of an arm for a week. The opinion does not say who struck him either.

The justices decided *Ingraham v. Wright* 5 to 4 on April 19, 1977. They held that the Eighth Amendment's ban on "cruel and unusual punishments" does not cover school discipline. They wrote that it "was designed to protect those convicted of crimes."

They also held that school staff do not have to give a child a hearing, a chance to tell his side, before hitting him, because the child can sue afterward if the beating was too severe. The Constitution, as the justices read it, did not forbid paddling in schools. So paddling ended only in states where lawmakers voted to end it, one state at a time.

**By 1977:** The justices had let Amish children leave school after eighth grade, had refused to call education a right, and had let school staff go on paddling. Members of Congress had opened schools to every child with a disability and barred schools that take federal money from treating girls worse than boys.

### Congress and the president: war powers and Watergate

**War powers.** Members of Congress passed the War Powers Resolution in 1973, a law that limits how long a president may keep troops fighting without the approval of Congress. President Nixon vetoed it, meaning he rejected it, on October 24, 1973. On November 7, 1973, the representatives voted 284 to 135 and the senators voted 75 to 18 to override the veto, which made it law without his signature.

Under it, when a president sends troops into fighting without a declaration of war, he must report to Congress in writing within 48 hours. Within 60 days he must end the fighting unless members of Congress declare war, vote to approve it or give more time.

**The break-in.** Early on June 17, 1972, five men broke into the offices of the Democratic National Committee at the Watergate building in Washington, D.C. Police arrested them with cash and equipment for spying on the offices. Investigators later tied them to Nixon's re-election campaign. Officials in Nixon's White House at first denied any link. The break-in and the scandal that followed are called Watergate. A scandal is wrongdoing that becomes publicly known.

**The tapes.** On February 7, 1973, the senators voted to create a committee to investigate, led by Sam Ervin of North Carolina. A White House aide, Alexander Butterfield, told the committee that the president kept a tape recorder in rooms of the White House that switched on at the sound of a voice. In October 1973 Nixon ordered Attorney General Elliott Richardson to fire the special prosecutor, Archibald Cox, a lawyer named to investigate the case, who had demanded the tapes. Richardson and his deputy resigned in protest over Nixon's order.

In *United States v. Nixon*, decided on July 24, 1974, the justices of the Supreme Court ruled 8 to 0 that Nixon had to hand the tapes over to the prosecutor. Justice William Rehnquist took no part. Chief Justice Warren Burger wrote that the president's right to keep his talks private "must yield to the demonstrated, specific need for evidence in a pending criminal trial."

**The charges and the resignation.** In late July the members of the House Judiciary Committee approved three articles of impeachment, or formal charges. They approved obstruction of justice on July 27, abuse of power on July 29 and contempt of Congress on July 30. Obstruction of justice means trying to block an investigation. Abuse of power means using the powers of an office for wrong purposes.

On the morning of August 9, 1974, Nixon signed a one-sentence letter of resignation. He addressed it to the Secretary of State, because a law passed in 1792 states that a president's resignation is filed there. It took effect at 11:35 a.m., when Secretary of State Henry Kissinger initialed it, or wrote his initials on it. The members of the full House never voted on the articles.

Gerald Ford took the oath of office at noon. He said: "My fellow Americans, our long national nightmare is over." He went on to say that the Constitution worked. He also said: "I am acutely aware that you have not elected me as your President by your ballots."

Vice President Spiro Agnew had resigned in October 1973. Nixon had named Ford to replace him under the Twenty-fifth Amendment, and the members of both houses had confirmed him. As president, Ford named Nelson Rockefeller as his vice president the same way. For about two and a half years, the country had a president and a vice president whom no voter had chosen for either office.

### New kinds of schools, 1991 to 1996

In 1991 Minnesota's lawmakers passed the first state law allowing charter schools. Under it, a local school district could grant a group a charter, a written agreement, to run a school. The law's text calls them "outcome-based schools," and it allowed only eight in the whole state. State Senator Ember Reichgott Junge was its chief author. The first one, City Academy in St. Paul, opened in 1992.

Homeschooling became legal across the country state by state during the 1980s and early 1990s, through new laws and court rulings. Michigan was the last state, and it took two steps there, in 1993 and 1995.

On May 25, 1993, in *People v. DeJonge*, the justices of the Michigan Supreme Court struck down the state's rule that parents who taught their children at home must use certified teachers, meaning teachers licensed by the state. The ruling covered only families whose religious beliefs forbade certified teachers.

On the same day, in *People v. Bennett*, the same justices ruled that the rule still applied to a family with no religious objection. Michigan's lawmakers wrote a home-education exemption into the state's school attendance law in 1995. An exemption is a rule that lets some people off a requirement. It took effect on July 1, 1996.

### An impeachment at the end of the century

The members of the House of Representatives impeached President Bill Clinton on December 19, 1998. They voted 228 to 206 to charge him with perjury, which means lying under oath, before a grand jury, a group of citizens who hear evidence in secret and decide whether someone should be charged with a crime. They voted 221 to 212 to charge him with obstruction of justice in the matter of Monica Lewinsky. They voted down two other charges.

The Constitution requires the votes of two-thirds of the senators, 67 votes, to find a president guilty and remove him. On February 12, 1999, the senators voted 45 guilty and 55 not guilty on the perjury charge. On the obstruction charge the vote was 50 to 50. Clinton stayed in office.

**If you remember one thing:** In this era members of Congress and the justices, between them, ended the poll taxes and literacy tests that officials in many Southern states used to keep Black Americans from voting, and a president resigned rather than face a vote on three charges.

Who counts the votes when the count itself is disputed? In 1948 a party committee and a single justice settled Lyndon Johnson's 87-vote win. The next era opens with that question in Florida in 2000, and the answer this time came from the Supreme Court.

**Next:** Since 2000, judges have ruled on recounts, on money in elections and on the shape of voting districts, and on January 6, 2021, a crowd attacked the Capitol while the electoral votes were being counted.

## 2000 to Today

**Era 10 of 10 · 2000 to Today · about 19 minutes**

Since 2000, judges have ruled on how votes are counted, how voting districts are drawn and whether corporations may spend money on elections. In 2000 the justices of the Supreme Court stopped a recount, a second count of the votes, in Florida during the presidential election. On January 6, 2021, while members of Congress counted the electoral votes, a crowd attacked the Capitol, the building where Congress meets. Judges also ruled on public money for religious schools and on how children are assigned to schools.

### Bush v. Gore, 2000

The presidential election of 2000, between George W. Bush and Al Gore, came down to Florida. In Florida's official count, Bush led by 537 votes out of nearly 6 million. The justices of the Florida Supreme Court ordered recounts by hand of the ballots that counting machines had read as blank. They also ordered votes found in two counties' earlier recounts added to the official count.

The justices of the United States Supreme Court decided *Bush v. Gore* on December 12, 2000, in an unsigned opinion, one that no single justice signed as its author. Seven justices saw a problem under the Constitution. Different counties used different rules to decide what a ballot meant, so two identical ballots could be counted differently depending on where they were cast. Five justices voted to stop the recount instead of sending it back to be fixed, because there was no time left.

Justices John Paul Stevens, David Souter, Ruth Bader Ginsburg and Stephen Breyer dissented. The opinion states that the ruling was "limited to the present circumstances." The recount ended. Bush won Florida's 25 electoral votes and became president, with 271 electoral votes to Gore's 266. Gore had received more votes across the country than Bush.

### Money and maps

**Money.** The justices decided *Citizens United v. Federal Election Commission* on January 21, 2010, 5 to 4. Citizens United, a nonprofit corporation, had made a film attacking Hillary Clinton. A nonprofit corporation is a group organized like a company that does not pay profits to owners. Its leaders wanted to advertise the film during a period before an election when federal law barred corporations from spending money on elections.

Justice Anthony Kennedy wrote for the majority that "the Government may not suppress political speech based on the speaker's corporate identity." Suppress means stop. That means government officials may not ban a group's political speech just because the group is a corporation. The justices overruled a 1990 decision, *Austin v. Michigan Chamber of Commerce*, and part of another, *McConnell v. Federal Election Commission*.

**Maps.** The justices decided *Rucho v. Common Cause*, also 5 to 4, on June 27, 2019. Gerrymandering is drawing the lines of voting districts so that one side wins more seats. Two maps were before the Court: North Carolina's map for Congress drawn by Republicans in 2016, and Maryland's drawn by Democrats in 2011.

Chief Justice John Roberts wrote that "partisan gerrymandering claims present political questions beyond the reach of the federal courts." Partisan means favoring one political party. Justice Elena Kagan wrote in dissent: "For the first time ever, this Court refuses to remedy a constitutional violation because it thinks the task beyond judicial capabilities." After 2019, a voter who believed a map was drawn to favor one party could not take that complaint to a federal court. Judges in state courts and members of Congress could still act on it.

### Asking permission to change voting rules, 2013

Under Section 5 of the Voting Rights Act, officials in the places the act covered had to get federal permission before changing any voting rule. On June 25, 2013, in *Shelby County v. Holder*, the justices struck down the formula in Section 4(b) that set which places were covered. The ruling states that the formula "can no longer be used" to make a place ask permission. So the places it had covered no longer had to ask.

The justices left Section 5 itself in place and wrote that "Congress may draft another formula based on current conditions." As of September 2026, members of Congress had passed no new formula.

### Schools and the courts

**Tests and money.** The No Child Left Behind Act is named for 2001, but it became law on January 8, 2002. Members of Congress wrote it as a new version of the Elementary and Secondary Education Act of 1965, and they kept that act's method: federal money for schools, with conditions attached. The Congressional Research Service, the office that does research for members of Congress, states that with No Child Left Behind, members of Congress began to focus on accountability for test results. Accountability here means judging schools by how their students scored on tests.

On December 10, 2015, members of Congress replaced it with the Every Student Succeeds Act. State officials still had to set standards, lists of what students should learn, and test students every year in reading, mathematics and science. Under the new law, state officials had more say over what to do about the results. In the 2023 budget year, federal spending on all the programs under the 1965 act came to $29.0 billion, according to a Congressional Research Service report of February 2024.

**Public money for religious schools.** Four times between 2002 and 2022, the justices of the Supreme Court ruled on public money for religious schools. On June 27, 2002, in *Zelman v. Simmons-Harris*, the justices ruled 5 to 4 that Ohio's scholarships for students in Cleveland were allowed. The scholarships paid up to $2,250 a year for families with low incomes, and up to $1,875 for other families.

According to the Court's 2002 opinion, 82 percent of the private schools taking part were religious, and 96 percent of the children using the scholarships went to a religious school. The justices held that such a program is allowed if it treats religion neutrally, favoring no religion and no lack of one. The money also had to reach a religious school only because a family chose that school.

In the next three rulings the justices went further. They held that when state officials pay for private schools or programs, they may not leave out religious ones. Missouri officials had refused a church preschool a grant, a gift of public money, for resurfacing its playground just because it was a church, though the grant was open to others. The justices ruled against them in *Trinity Lutheran Church of Columbia v. Comer* on June 26, 2017.

Three years later, five justices barred Montana officials from keeping scholarship money from religious schools, in *Espinoza v. Montana Department of Revenue*, decided 5 to 4 on June 30, 2020. Maine officials paid tuition, the cost of attending a school, for children from towns with no high school, but only at nonreligious schools. In *Carson v. Makin*, decided 6 to 3 on June 21, 2022, the justices held that Maine officials could not require that.

**Race and school assignment.** On June 28, 2007, in *Parents Involved in Community Schools v. Seattle School District No. 1*, the justices struck down two plans that used a child's race to decide which school the child attended. The vote was 5 to 4. Officials of Seattle's school district had used race to break ties, meaning to choose between students who ranked the same for a high school place. School officials in Jefferson County, Kentucky, had used it in placing children in elementary schools.

Chief Justice Roberts wrote: "The way to stop discrimination on the basis of race is to stop discriminating on the basis of race." Only four justices joined that sentence. Justice Kennedy cast the fifth vote and wrote separately. He wrote that school officials may still work toward a mix of students.

He listed ways to do it. Officials could choose where to build new schools, draw attendance zones and pay for special programs. They could also recruit students and teachers, and track enrollment and results by race. Attendance zones are the areas whose children go to each school. After 2007, school officials could still try to mix their schools, but they could not assign a single child to a school because of that child's race.

### Counting the votes, January 6, 2021

Every four years, the members of the House and Senate meet together in the House chamber to count the electoral votes for president. The vice president presides, or runs the meeting. Tellers, the members chosen to count, open each state's certificate and read out its votes. A certificate is an official paper that states a fact, here the state's electoral votes. Until 2022, one member of the House and one senator together could object in writing to a state's votes. The members of the two houses then met separately, debated and voted.

Joe Biden won the 2020 election, with 306 electoral votes to Donald Trump's 232, by the count of the National Archives.

In some states, groups of Republicans signed papers stating that they were their state's electors, and they sent the papers to the Senate and the National Archives. Federal law requires each state's governor or other top official to sign a certificate naming the state's electors. No such official had signed one for these groups, so the papers were left out of the count, as a Congressional Research Service report of December 2024 states.

**The attack.** A crowd attacked the Capitol while the count was under way on January 6, 2021. The Government Accountability Office is a federal agency that checks the government's work. Its 2023 report states that over about seven hours, members of the crowd assaulted, or attacked, at least 174 police officers. Of them, 114 were from the United States Capitol Police and 60 from the police department of Washington, D.C.

The same office's 2022 reports record about $1.5 million in damage. They state that the plans Capitol Police officials made for the day "did not reflect the potential for extreme violence aimed at the Capitol." Those officials had information that protesters might be armed and were planning to target Congress.

That day, members of Congress took up two objections. According to the Congressional Research Service report, senators rejected the objection to Arizona's votes 93 to 6, and representatives rejected it 303 to 121. The objection to Pennsylvania's votes failed 92 to 7 among senators and 282 to 138 among representatives. The members of Congress then finished the count and declared the result.

**The new rules.** Afterward, members of Congress changed the rules. The Electoral Count Reform and Presidential Transition Improvement Act became law on December 29, 2022. Under it, an objection must have the support of one-fifth of the members of each house, about 87 representatives and 20 senators. Only the state's executive, usually the governor, may certify the state's electors. Electors must be chosen under state laws passed before election day.

The President of the Senate is the vice president, and the act states: "The President of the Senate shall have no power to solely determine, accept, reject, or otherwise adjudicate or resolve disputes over the proper certificate of ascertainment of appointment of electors, the validity of electors, or the votes of electors." That means the vice president cannot decide alone which electors or which votes count.

**The pardons.** On January 20, 2025, the day he took office again, President Donald Trump signed Proclamation 10887, a formal order from the president. With it, he cut the prison sentences of fourteen named members of two groups, the Oath Keepers and the Proud Boys, to the time they had already served. Among them were Stewart Rhodes and Kelly Meggs.

A pardon is a president's order that forgives a federal crime, so the person is no longer punished for it. He gave "a full, complete and unconditional pardon" to everyone else found guilty of crimes connected with the events at the Capitol on January 6, 2021. He also ordered everyone still in prison for them released.

### Donald Trump's two impeachment trials

Senators can remove a president from office only if two-thirds of them, 67 votes, find him guilty. Senators have never found a president guilty.

The members of the House impeached President Donald Trump on December 18, 2019, on two charges: abuse of power and obstruction of Congress, meaning blocking Congress's investigation. On February 5, 2020, the senators voted 48 guilty and 52 not guilty on the abuse of power charge, and 47 to 53 on the obstruction charge.

The members of the House impeached him a second time on January 13, 2021. The charge was incitement of insurrection, meaning stirring people up to rise against the government. On February 13, 2021, the senators voted 57 guilty and 43 not guilty, ten votes short of conviction. Seven Republican senators voted guilty: Richard Burr, Bill Cassidy, Susan Collins, Lisa Murkowski, Mitt Romney, Ben Sasse and Pat Toomey.

### Wandrea ArShaye "Shaye" Moss

> **Who:** A Fulton County election worker who was publicly and falsely accused of cheating in the 2020 count by a lawyer for the Trump campaign and by Rudolph Giuliani, and who told a committee of Congress under oath what followed.
>
> **When and where:** Fulton County, Georgia, 2017 to 2022. Sworn testimony in Washington, D.C., June 21, 2022.

**The object on the video was a ginger mint.**

Shaye Moss worked in the Department of Registration and Elections in Fulton County, Georgia, from 2017 until 2022. She handled applications from voters and requests for absentee ballots, which are ballots mailed to voters who vote from home. She also helped count the votes. Her mother, Ruby Freeman, worked as a temporary election worker in the same county for the 2020 election.

On June 21, 2022, Moss testified under oath to the House committee that investigated January 6. She said: "I have always been told by my grandmother how important it is to vote and how people before me, a lot of people, older people in my family did not have that right."

Older voters were her favorite part of the job: "the older voters like to call, they like to talk to you, they like to get my card, they like to know that every election I am here." She once drove to a hospital to bring a woman her absentee ballot application.

**The count.** About five million Georgians voted in 2020. From November 11 to 19, 2020, election workers counted every ballot by hand, in 41,881 batches. In no county did the margin, the gap between the two candidates' totals, change by more than 0.73 percent. Secretary of State Brad Raffensperger certified the result on November 20, and Governor Brian Kemp certified it too. After a machine recount, requested on behalf of the Trump campaign, state officials certified the result again on December 7, 2020. Joe Biden won Georgia and its 16 electoral votes.

On December 3, 2020, a lawyer working for the Trump campaign played clips of a security video from the State Farm Arena at a hearing of the Georgia Senate. The lawyer said election workers there had pulled 18,000 hidden ballots from "suitcases of ballots under a table, under a tablecloth." The two women in the clips were Freeman and Moss.

The women's lawsuit, as the federal court described it in 2022, states what happened next. Georgia's state election officials and agents of the Georgia Bureau of Investigation watched the whole security tape, which ran for hours, and interviewed everyone who had been there. They found no evidence for any of the claims. Early on December 4, the state's Voting Implementation Manager posted that the video "Shows normal ballot processing." The containers held ballots that had been processed earlier that night, and no observer had been told to leave.

On December 10, 2020, Rudolph Giuliani, a lawyer for President Trump, told a hearing of the Georgia House that the two women were "quite obviously surreptitiously passing around USB ports as if they are vials of heroin or cocaine." Surreptitiously means secretly. USB ports are the sockets that computer memory sticks plug into. He said their homes and workplaces should have been searched. Moss later testified that the object her mother handed her in the video was "a ginger mint."

On January 2, 2021, Trump telephoned Raffensperger and named Ruby Freeman again and again. He called her "a vote scammer, a professional vote scammer and hustler." Raffensperger answered on the call that Giuliani "or his people, they sliced and diced that video and took it out of context."

**What followed.** Moss testified that Trump supporters sent her messages. She described them as "a lot of threats, wishing death upon me, telling me that, you know, I will be in jail with my mother, and saying things like, 'Be glad it's 2020 and not 1920.'" Many were racist, she said. The historian Tera W. Hunter wrote that the "1920" message, and messages telling the two women they should hang, pointed back to the history of lynching, murder by a mob without a trial.

Strangers went to her grandmother's house and pushed their way in. They said they had come to make a citizen's arrest, an arrest by someone who is not a police officer, and needed to find Moss and her mother. Agents of the FBI, the Federal Bureau of Investigation, a national police agency, advised Freeman to leave her home around the week of January 6, 2021, and she stayed away about two months. "I've lost my name," Freeman said, "and I've lost my reputation."

Moss said she stopped giving out her business cards and stopped going to the grocery store. Asked how many of the permanent election workers and supervisors in that video were still doing the job, Moss answered: "There is no permanent election worker or supervisor in that video that is still there." She had left too.

**The lawsuit.** In December 2021 Freeman and Moss sued Giuliani for defamation in federal court in Washington, D.C. Defamation is harming a person's good name with false statements. On August 30, 2023, Chief Judge Beryl Howell ruled against Giuliani on all their claims, as a penalty for refusing to hand over evidence. On December 15, 2023, a jury awarded the two women about $148 million, a figure reported by PBS. The judge later reduced the amount to about $146 million, according to NBC News.

On April 15, 2024, Judge Howell refused Giuliani's request to throw out or change the verdict, the jury's decision. In January 2025 a federal judge in New York, Lewis Liman, found Giuliani in contempt of court, the offense of disobeying a court's orders, for failing to give information about his property. A court filing showed that the judgment had been satisfied, meaning its terms had been met, on February 21, 2025.

In November 2025 President Trump pardoned Giuliani and others who had worked to overturn the 2020 result. A presidential pardon covers only federal crimes, and none of the people named had been charged with a federal crime over the 2020 election. A pardon does not cancel a civil judgment, a court's order in a lawsuit to pay money, such as the award to Freeman and Moss. That award had already been paid.

### Who does not get a vote

In the 2020 census, Census Bureau workers counted about 690,000 people living in the District of Columbia, more than in Wyoming or Vermont. The voters of each of those states elect two senators and a voting representative. The District has no voting member of the House and no senators. It has three electors for president because of the Twenty-third Amendment.

The same census found about 3.3 million people in Puerto Rico, more than lived in 21 of the 50 states. Its residents are United States citizens. While they live there, they cannot vote for president. Their Resident Commissioner, their one member in the House, cannot vote on the House floor.

Just under 339,000 people lived in four smaller island areas: Guam, the United States Virgin Islands, American Samoa and the Northern Mariana Islands. None of the four has a voting member of Congress or electors for president. People born in American Samoa are nationals, who belong to the United States without being full citizens.

In all, about 4.3 million people lived in 2020 in places with no voting member of Congress. The Census Bureau states the rule itself: "The populations of the District of Columbia and Puerto Rico are excluded from the apportionment population because they do not have voting seats in Congress." The apportionment population is the count used to divide the seats in the House among the states.

**Felony convictions.** In 2024, about 4 million Americans could not vote because of a felony conviction, 1.7 percent of adults of voting age. A felony is a serious crime. The count is an estimate by the Sentencing Project, not a government count. In 2016 the number had been 5.9 million. Among Black Americans of voting age, 1 in 22, or 4.5 percent, could not vote for this reason. That was more than three times the rate for everyone else, 1.3 percent.

About 72 percent of the people counted were not in prison. They were on probation, which is supervision in place of prison, or on parole, which is early release from prison under supervision, or they had finished their sentences. State lawmakers and state constitutions set these rules. Under the laws of Maine and Vermont, people in prison can vote.

### A senator convicted, 2024

On September 22, 2023, federal prosecutors in Manhattan charged Senator Bob Menendez of New Jersey, his wife, Nadine Menendez, and others with bribery. According to news reports of the case in 2023, agents had found $480,000 in cash and more than $100,000 in gold bars in the Menendez home. On July 16, 2024, a jury found him guilty on all counts, or charges, including acting as a foreign agent of Egypt, meaning acting on behalf of Egypt's government.

He resigned from the Senate in August 2024. On January 29, 2025, a judge sentenced him to 11 years in prison. He reported to prison in June 2025.

### Immigration law after 2001

In the Homeland Security Act of 2002, members of Congress created the Department of Homeland Security. Its officials began work in 2003. Under the act, the old Immigration and Naturalization Service was split into three agencies: U.S. Citizenship and Immigration Services (USCIS), Immigration and Customs Enforcement (ICE) and Customs and Border Protection (CBP).

On June 15, 2012, officials of the Department of Homeland Security began a policy called Deferred Action for Childhood Arrivals, or DACA. Under it, certain people brought to the country as children could get protection from being deported, or sent out of the country, and permission to work. Lawsuits over DACA went on for years.

**If you remember one thing:** Since 2000 the fights over the rules have been about counting: who counts the votes, whose money counts, and who gets no vote to count.

- 2000: Five justices stopped the Florida recount, and George W. Bush became president with fewer votes across the country than Al Gore.
- 2021: A crowd attacked the Capitol during the electoral count, and members of Congress then finished the count and declared the result.
- 2020: About 4.3 million people lived in places with no voting member of Congress, and in 2024 about 4 million adults could not vote because of a felony conviction.

**Next:** The chapter closing is below. Chapter 21, Crime, Police, and Justice, follows.

**The three questions, answered**

- Who decided who could vote, and how did the answer change? Each colony's and then each state's lawmakers decided, and the men who wrote the Constitution left it that way. Virginia's lawmakers took the vote from free Black men in 1723, New Jersey's lawmakers took it from women and free Black men in 1807, and Southern delegates took it from Black men again after 1890. Members of Congress took most of that power from the states with four amendments (1870, 1920, 1964, 1971), which state lawmakers approved, and with the Voting Rights Act of 1965.
- When did judges first cancel a law, and what have they done with that power since? In 1803, in *Marbury v. Madison*. The justices have used it to allow forced sterilization, separate railroad cars and the wartime camps, and to strike down school segregation, official prayers, poll taxes and unequal districts.
- What happens when people in power break the law? A jury, a court or the Senate decides. In 1614 royal judges found Juan de Oñate, a former governor of New Mexico, guilty of 12 charges and ordered him out of New Mexico for life. A jury found a cabinet secretary guilty of taking a bribe in 1929, and a judge sentenced him to a year in prison. A president resigned in 1974 rather than face a vote. Bill Clinton and Donald Trump were impeached, Trump twice, and the senators found neither guilty. A jury found a senator guilty of bribery in 2024, and he went to prison.

**What changed:** The rules began as whatever the lawmakers of each colony chose. Over ten eras they became a written plan that judges enforce, and the vote, which began with men who owned property, reached women in 1920 and eighteen-year-olds in 1971.

**Five dates to keep**

- 1619: Twenty-two elected burgesses met at Jamestown, the first elected assembly in English North America.
- 1803: The justices of the Supreme Court first cancelled a law passed by Congress.
- 1870: The Fifteenth Amendment barred every state from denying a man the vote because of race.
- 1920: The Nineteenth Amendment barred every state from denying a woman the vote.
- 1974: Richard Nixon resigned the presidency rather than face a House vote on three charges.

**Not known:** Whether the feet of the Acoma men were cut off in 1599: the sentence is in the written record, the Acoma account says it was done, and two historians doubt it.

**Where to go:** Independence Hall in Philadelphia, where the delegates signed the Constitution on September 17, 1787, is open to visitors as part of a national park.

**Next:** Chapter 21, Crime, Police, and Justice. It asks who enforced these laws, and what happened to the people they caught.
