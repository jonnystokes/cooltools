# How This Book Works

This is a history of the United States, told in 37 chapters. Each chapter follows one subject, such as food, war or music, through the same ten eras, from before 1500 to today. You can read the chapters in order or start with any one you like. A hard word is explained the first time it appears, and the glossary at the back explains them all.
