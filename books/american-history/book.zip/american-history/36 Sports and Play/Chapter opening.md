# Chapter 36: Sports and Play

**Chapter 36 of 37 · Sports and Play · 10 eras · about 125 minutes**

**From chunkey at Cahokia to Fortnite, American games moved out of open fields and into leagues, arenas and screens run by adults and companies, and at almost every step someone in charge decided who was allowed to play.**

On September 10, 1674, the judges of the York County court in Virginia punished a tailor named James Bullocke. He had bet 2,000 pounds of tobacco on a race between his mare and a gentleman's horse. Racing, the judges ruled, was "a sport only for Gentlemen," and they fined him. Then they found that the gentleman had fixed the race so that the tailor's mare would win. They sent the gentleman to sit in the stocks for an hour.

This chapter follows play through ten eras, from Native ball games on fields a mile long to games played on phones with strangers. Watch who runs the game. At first the players ran it themselves. Later club members wrote the rules, owners paid the players, adults ran leagues for children, and companies sold games played on a screen. And watch who gets kept out: a tailor in 1674, enslaved riders whose names the race cards left off, Black players after 1887, girls after 1951, Black children at city pools.

**Three questions this chapter answers**

- Who invented baseball?
- Who was kept out of American games, and how did they get in?
- How has children's free time changed?

**Five minutes?** Read "Who wrote the rules of baseball?" in 1800 to 1850, then "Who could play Little League" and "How did a child's afternoon change?" in 1950 to 2000.

**Can skip:** "Games of chance", "Children, toys and the circus", "The Miracle on Ice", "Television and the Super Bowl". The chapter still makes sense without them.

## Before 1500

**Era 1 of 10 · Before 1500 · about 6 minutes**

Native nations played games of skill and games of chance long before 1500, and their children made toys out of clay. Nobody wrote down the rules at the time. What survives are objects in the ground, found by archaeologists, the scientists who dig up and study the things people left behind. Stone disks for a game called chunkey, and little clay animals made by children, date from these centuries.

Archaeologists have also found split reeds used as dice and wooden pieces kicked along a race course, but no one has dated those. How the games were played is known from the nations' own traditions and from Europeans who watched them in later centuries.

**Two kinds of games.** Stewart Culin sorted Native games into two kinds in a long study printed in 1907 by the Bureau of American Ethnology, a government office in Washington that studied Native peoples.

In games of chance, players threw marked pieces and counted how they landed. In games of skill, players won by how well they used their hands and bodies. Culin found no game like chess, which a player wins by planning alone. Native children played many games with no objects at all, such as tag, he wrote, and he left those out.

### Chunkey at Cahokia

Chunkey was a game played with a stone disk and long poles. One player rolled the stone along the ground. The players ran after it and threw their poles. The aim was to land a pole closest to the spot where the stone came to rest. The stones had rounded edges and hollowed sides, and some had a hole through the middle.

The game began about the year 600, in the area around present-day St. Louis. People built the city of Cahokia in that same area around 1050. By hand, they filled in and leveled a plaza, a huge open square, of about 50 acres. They used the plaza for ceremonies and for chunkey.

**The stones got bigger.** A chunkey stone made before Cahokia existed measures about 2.5 inches across. A stone from the 1100s measures about 3.5 inches. It is made of quartzite, a hard rock, from a single place on the Mississippi River. A shell collar found 90 miles south of Cahokia shows a chunkey player holding a pole and a stone.

Timothy Pauketat, an archaeologist at the University of Illinois, thinks messengers from Cahokia carried a chunkey stone in one hand and a war club in the other. In his account, they went out to the lands around the city to make peace or to make agreements with other peoples. He also writes that chunkey played a large part in how Cahokia's people lived together and how they were governed.

Chunkey stones from about 1300 have turned up as far away as Georgia, and in Maryland at sites in Frederick and Montgomery counties. Most of Cahokia's people had left the city by about 1350, and it was empty by about 1400. Staff at the Jefferson Patterson Park and Museum in Maryland say that people across North America went on playing chunkey after that.

### Ball games with sticks

Nations in the East, among them the Choctaw, the Huron and the Haudenosaunee, played a ball game with sticks. The Choctaw call their game kapucha toli, which means "stick play." The Huron and the Haudenosaunee, also called the Iroquois, played the game known today as lacrosse. Writers for the Choctaw Nation, on the nation's website, say that stickball "has been the Choctaw national sport for unknown centuries."

No object or written record dates a stick-and-ball game before 1500. Jean de Brebeuf, a French missionary, a man who traveled to other peoples to spread the Christian religion, described Huron lacrosse in 1636. He belonged to the Jesuits, a group of Catholic priests. Another Jesuit missionary described a Choctaw match in 1729, the oldest written account of a Choctaw game.

**How big a game could be.** Fields ran from about 100 yards long to, perhaps, several miles, according to the same Choctaw writers. Some games had several hundred players on each side, and others had twenty or fewer. Among the Choctaw, women played alongside men. Betting was a large part of the game, especially for the women. The Choctaw writers also say that deaths were common in the old games.

People used the game to teach and to heal. The Choctaw have used it to show their young people how Choctaw families were arranged and what men and women each did, the Choctaw writers say. Among the Huron, Brebeuf wrote, a sick person or a healer could call for a lacrosse game to make the sick person well. Whole villages played against each other and bet beaver robes and what Brebeuf called "porcelain collars," his word for collars of wampum, beads made from shells.

Choctaw tradition says that towns sometimes played ball to settle an argument. The two games of this kind that someone wrote down took place long after 1500, around 1790 and 1800.

### Games of chance

Pieces for games of chance survive in the Southwest. The archaeologist J. Walter Fewkes dug up split reeds used for a dice game at the Chevlon ruin, about 15 miles east of present-day Winslow, Arizona. Culin took the reeds as a sign that the Hopi and Zuni cane game was old. No one has dated them.

Pieces from a racing game survive too. Runners kicked a small wooden piece ahead of them along a race course. Pieces like these were found in cliff dwellings in Mancos Canyon, Colorado. One is 4 3/4 inches long and marked with lines cut into the wood.

### What did children play with?

Most of the children's things that survive from before 1500 are made of clay. Toys made of wood, hide and grass rot away, so few of them last.

The archaeologist Kathryn Kamp studied clay objects about 800 years old from Sinagua village sites in northern Arizona. She measured the fingerprints left in the clay. The ridges of a child's fingerprint are narrower than an adult's. Kamp found that very young Sinagua children made little clay animals, and probably small dishes, to play with. While making them, the children learned how clay behaves.

People in the Southwest made animal figures out of split twigs about 2,000 years ago. Archaeologists had thought the figures were used in religious ceremonies for hunting. Then three of them, two deer and a duck, turned up in a child's grave. Archaeologists now think that some of the figures were toys.

Bacqueville de la Potherie, who wrote about the Huron in the early 1700s, said that Huron children played lacrosse. He wrote that they "never or rarely" played the dice games that Huron women played.

## The 1500s

**Era 2 of 10 · The 1500s · about 2 minutes**

Nearly everything written about games here in the 1500s describes Native games. The writers were Spanish and French soldiers, sailors and missionaries, and they set down what they saw Native people play. The Spanish soldiers at the forts of St. Augustine and Santa Elena on the Atlantic coast left guns, tools and pottery behind. No record from the 1500s describes what those soldiers played.

### Timucua games in Florida, 1564 and 1565

René de Laudonnière led a French colony at Fort Caroline, near present-day Jacksonville, Florida, in 1564 and 1565. The Timucua lived there. Laudonnière wrote that they trained their young men to run. In one of their races, the runner who could keep going longest won. The young men also practiced often with bows and arrows.

Laudonnière described a Timucua ball game too. The players set up a tree trunk about 50 feet high in an open space. At the top they fixed a square mat woven from reeds. Whoever hit the mat with the ball won the game.

Jacques Le Moyne, the colony's artist, painted Timucua life. Theodor de Bry, an engraver in Europe, a man who cut pictures into metal plates so they could be printed many times, made prints from the paintings. He never went to Florida. One print shows young men running, shooting arrows and throwing a ball at a target on a tall pole.

**Which record to trust.** Most sources date the print to 1591, and a National Park Service web page gives 1587. The same page states that de Bry mixed in details from other parts of the Americas to sell more copies. Laudonnière's written account is the firmer record of the game.

### Spanish games on horseback, 1598

Juan de Oñate led Spanish colonists north to the Rio Grande, in what is now New Mexico, in 1598. Gaspar Pérez de Villagrá wrote about that year in a book printed in 1610. Writers for the Museum of New Mexico's magazine, *El Palacio*, state that the colonists' celebrations in 1598 included "tilts with cane spears, running bulls and tilts at the ring."

In a tilt with cane spears, two lines of riders threw light spears made of cane at each other and blocked them with shields. In a tilt at the ring, a rider galloped at full speed and tried to push the point of a lance, a long spear, through a ring and carry it off.

Spanish friars, Catholic religious men who lived by strict rules, began building missions in Florida and Georgia in the 1590s. A mission was a church settlement where friars worked to make Native people Christians. About eighty years later, a friar in Florida set out to end a Native ball game.

## The 1600s

**Era 3 of 10 · The 1600s · about 10 minutes**

The men who governed the English and Dutch colonies in the 1600s wrote laws about when and where people could play. In Massachusetts and Plymouth, lawmakers and judges fined people for cards, dice and tavern games. In New Netherland, the Dutch director banned ball games, cards and bowling on Sunday before, between and during church services. Virginia planters, men who owned big farms, raced horses for thousands of pounds of tobacco, and one county court punished a tailor for racing, saying racing was "a sport only for Gentlemen."

Native nations kept playing their own games, and English and Spanish writers described some of them. In Spanish Florida, a friar and the governor worked to end the Apalachee ball game. Almost nothing written in these years describes what children did.

### Bowling at Jamestown, 1611

Sir Thomas Dale arrived at Jamestown in May 1611 with about 300 soldiers, to govern the colony. The colonist Ralph Hamor later wrote that on his first day Dale found the colonists at "their daily and usuall works, bowling in the streetes."

The historians William Kelso and Karen Ordahl Kupperman argue that the colonists were sick and badly fed. In their view, hunger and disease made the men act in ways that could look like laziness.

**Dale's code.** Dale then put the colony under a code of military rules called the Lawes Divine, Morall and Martiall. Chapter 21 describes the punishments under those rules.

### Massachusett football, 1634

William Wood, an Englishman, described the games of the Massachusett people on the coast in a book printed in 1634. He listed football, shooting, running and swimming. When one area played another, Wood wrote, "their goals be a mile long," set on sand as flat as a board. Players kicked a ball about the size of a handball with their bare feet. A game could last two days. The players marked the ground they had won and started again from that spot the next day.

The winners took the prizes hung on the goals: wampum, beaver skins and black otter skins. Players painted themselves before a game, as they did for war. Wood wrote that they did it so that no one could tell who had hurt him and take revenge later. While the men played, the boys played pipes and the women danced and sang. Wood also claimed that one Englishman could beat ten Native players at football.

**Hubbub.** Wood described a dice game called hubbub. A player put five small bones, black on one side and white on the other, in a small smooth tray. He thumped the tray on the ground so that the bones jumped, and scored by the colors that landed face up. The players shouted "Hub, Hub, Hub," and Wood wrote that they could be heard a quarter of a mile away.

### Fines for games in New England

Lawmakers and judges in Massachusetts Bay and Plymouth fined people for playing games, although betting on the games was rare. The historian T. H. Breen found only a little betting in Massachusetts in the 1600s, most of it among poor people and servants, and none among the colony's leaders.

**Tavern games.** The lawmakers of Massachusetts Bay banned shuffleboard, a game of sliding pieces down a long board, in taverns in 1647. Three years later they banned bowling and every other game in taverns as well. They wrote that the games wasted "much precious time" and much wine and beer.

A tavern keeper who allowed the games paid 20 shillings, which made one pound in English money, and each player paid 5 shillings. Anyone who bet money had to pay three times the amount of the bet. A law of 1659 fined anyone caught playing cards or dice anywhere in the colony 5 shillings.

**Fined by name.** The judges of Plymouth Colony's court wrote down the name of each person they fined, wives among them. In June 1679 they fined John Holbrooke one pound for playing cards once in the woods, and "His man, Patricke," a servant who had played with him, 10 shillings. Mathew Gannet paid two pounds for playing cards several times and letting others play cards in his house.

### New Netherland: Sunday bans, the goose and golf

New Netherland was the Dutch colony that is now New York. Peter Stuyvesant was its director, the man who governed it. He and the men of his council, who helped him govern, banned work on Sunday on October 26, 1656. They also banned "playing Ball, Cards, Tricktrack, Tennis, Cricket or Ninepins" (tricktrack was a board game like backgammon, and ninepins was bowling at nine wooden pins) before, between or during church services, along with boat and wagon trips. Anyone caught paid a double fine.

**Pulling the goose.** Dutch farmers brought a game from home called pulling the goose. They hung a goose by a rope between two poles and greased its neck and head with oil or soap. Riders galloped past and grabbed at the goose to pull it down. The winner was called king of the festival. The Dutch records printed in 1868 do not say whether the goose was alive.

Stuyvesant called the game "heathenish and Popish," which meant un-Christian and Catholic, and he banned it. Some farmers held it anyway. They were fined, and some were put in jail, even though the leaders of the town of New Amsterdam protested. Those printed Dutch records do not name the farmers or the officials who punished them.

The game first came to New Netherland in about 1654, and the records do not make clear in which year the farmers were fined. Farmers on Manhattan asked to hold the game in February 1658, and Stuyvesant refused. One later book dates his ban to that same month.

**Golf in the streets.** People in Fort Orange, now Albany, complained that men playing golf in the streets broke windows and put passers-by in danger of being hurt. The town's officers banned golf in the streets on December 10, 1659. The fine was 25 guilders, the Dutch unit of money.

### Horse racing for tobacco

The English took New Netherland in 1664 and renamed it New York. A year later Colonel Richard Nicolls, its first English governor, laid out a two-mile racecourse on the Hempstead Plains of Long Island. He named it Newmarket, after a racecourse in England. According to the Encyclopaedia Britannica, he offered a silver cup to the best horses. Another account gives the prize as a silver crown or a bushel of wheat.

Native people had lived on that land. English settlers from Stamford, Connecticut, bought the land of the present towns of Hempstead and North Hempstead in 1643. They bought it from Tackapausha, a Marsapeague leader, and six other Native leaders. The town's history does not say what the leaders were paid or how they understood the sale.

**Quarter races.** Virginia planters ran quarter races, in which two horses sprinted a quarter mile along a dirt track. Men from leading families such as the Randolphs, Jeffersons and Washingtons appear in county court records of races. The largest bet in those records was made in Northumberland County in 1693. John Baker and John Haynie bet 4,000 pounds of tobacco and 40 shillings on their horses, Prince and Smoaker.

In early races a rider could shove, whip or knee the other rider and try to knock him off his horse. Later, riders agreed to "fair Rideing." They also chose a starter, judges and a stakeholder, the man who held the bets, before the race.

### James Bullocke

> **Who:** A tailor in York County, Virginia, punished for racing his horse against a gentleman's.
>
> **When and where:** September 10, 1674, the York County court, Virginia.

**The bet was 2,000 pounds of tobacco on one horse race.**

James Bullocke bet a gentleman, Mathew Slader, that his mare would beat Slader's horse. On September 10, 1674, the justices of the York County court, the county's judges, punished Bullocke for it.

The justices ruled that it was "contrary to Law for a Labourer," a man who worked with his hands, "to make a race, being a sport only for Gentlemen." The court order, as it was printed in 1894, fined Bullocke 100 pounds of tobacco. The historian T. H. Breen read the same court book and gives the fine as 200 pounds.

**The fixed race.** The justices also found that the race had been fixed. Slader had signed a promise that his horse "should runn out of the way," which meant it would leave the track, so that Bullocke's mare would win. The justices called it "an apparent cheate." They ordered Slader, the gentleman, to sit for one hour in the stocks, a wooden frame that locked a person's ankles while he sat in a public place.

W. G. Stanard, a historian writing in 1894, called the court order the earliest notice of racing in Virginia's records.

**Not known:** which law the justices meant. The order names none, and no such law has been found in the colony's printed laws.

### The Apalachee ball game banned, 1676

The Apalachee and Yustaga nations of northern Florida played a ball game between towns. A town sent a messenger to challenge another town, naming the day and the number of players, about forty or fifty. Players kicked a small ball, a little bigger than a musket ball, at a single tall pole. Eleven hits won.

Fray Juan de Paiva was the Spanish friar at the mission of San Luis, where Tallahassee is now. He wrote a long paper against the game, dated September 23, 1676, with the royal interpreter Diego Salvador and Juan Mendoza, an Apalachee leader who interpreted for the church.

**What the players did.** Paiva described what players did to each other. They stepped on faces, heads and bellies. They pulled at arms and legs without caring whether the joints came apart. When a player swallowed the ball, others made him throw it up by squeezing his windpipe or kicking him in the stomach.

Paiva listed broken legs and ribs, people who had lost the use of one or both hands, and people blinded in one eye. He wrote of two players he knew who had been killed at San Luis. Five games in a row in 1676 ended in open fighting, he wrote, and soldiers were present at the games.

Paiva wanted the game banned. He also charged that people left their fields unplanted and their houses open to thieves while they watched. Governor Pablo de Hita Salazar backed him. So did Fray Francisco Perete, the head in Florida of the Franciscans, one group of Catholic friars.

**The poles came down.** Paiva wrote that the Apalachee chiefs pulled down the ball poles and put "the holy cross" in their place, and that Captain Juan Fernández de Florencia thanked the chiefs for it on the governor's behalf. Some people, he wrote, asked the governor in writing not to end the game. The historian Amy Bushnell dates the Spanish campaign against the game from 1675 to 1684. The Talimali Band of the Apalachee lives in Louisiana today.

### Enslaved people and children

**A law against gathering.** Members of the Virginia General Assembly, the colony's lawmakers, passed a law against gatherings of enslaved people on June 8, 1680. They named it "An act for preventing Negroes Insurrections." "Negroes" was a word of the time for Black people. An insurrection is an uprising, so the lawmakers wrote the law to stop enslaved people from rising up against the men who held them.

The law's opening words stated that meetings of enslaved people "under pretence of feasts and burialls" were dangerous. The lawmakers meant that the feasts and funerals were only an excuse to meet.

An enslaved person who left the owner's land without a written pass was to get "twenty lashes on his bare back well layd on." That meant twenty hard blows with a whip on the bare skin. An enslaved person who raised a hand against "any Christian" was to get thirty lashes.

If an enslaved person hid out and fought back against the men sent by law to catch him, the same law said those men could kill him. Two years later the lawmakers barred enslaved people from gathering at another owner's plantation for more than four hours at a time.

**Children.** No one in the 1600s wrote down how a child spent the hours of a day. The only dated records of enslaved people's free time in these years are the laws of 1680 and 1682 that punished them for gathering.

The oldest marble that can be dated at Jamestown is made of brown stoneware, a hard kind of pottery, and dates from the middle of the 1600s. It may have been made in Germany, the Netherlands or England. Historic Jamestowne's description of the marble does not say whether a child or a grown person played with it.

## 1700 to 1750

**Era 4 of 10 · 1700 to 1750 · about 6 minutes**

Horse races and cockfights, and the bets men made on them, fill most of the written record of play from 1700 to 1750. Virginia planters raced horses on straight quarter-mile paths. By the late 1730s they also held race meetings that lasted several days, with prizes for fiddlers, wrestlers and runners. Men in South Carolina and Massachusetts held cockfights, in which two roosters fought until one was dead.

No record shows adults organizing children's play into teams or clubs, and almost no one wrote down what children played. The few dated records are a boys' footrace at a Virginia race meeting in 1737 and an English children's book of 1744 with a rhyme called "Base-Ball."

### Horses in Virginia

Robert Beverley wrote in 1705 that young Virginians loved to hunt wild horses. The horses were born in the woods of the upland country and had never been handled. An unmarked horse belonged to whoever caught it first.

The minister Hugh Jones wrote in 1724 that "almost every ordinary Person keeps a Horse." He had seen men spend a morning catching a horse in the woods, only to ride two or three miles to church, to court, "or to a Horse-Race."

**Who could race?** Historians disagree. In a quarter race, two horses sprinted along a straight, narrow path about a quarter mile long. Historians at Mount Vernon, George Washington's home in Virginia, write that owners rode their own farm horses, so ordinary farmers could race. The historian T. H. Breen found that gentlemen tried to keep racing to themselves, as the York County justices did in 1674.

A court record of 1678 shows a "boy" riding another man's horse, so not every rider owned his horse. The records of these races name the owners of the horses and seldom say who rode.

**Horses from England.** Planters began to bring racehorses from England. In 1730 a man named James Patton brought over a stallion, a male horse kept for breeding, named Bulle Rock. The horse was then 21 years old. Bulle Rock is thought to be the first English Thoroughbred, a breed raised in England for racing, brought to the colonies. Between 1740 and 1775 planters brought at least fifty stallions and thirty mares from England to Virginia.

### Race meetings with prizes, 1736 to 1739

**Prizes for fiddlers.** A group of gentlemen in Hanover County, Virginia, offered prizes at Page's Warehouse on St. Andrew's Day, a church holiday, November 30, 1736. Their notice in the newspaper offered a hunting saddle to the fastest horse over a quarter mile. It offered a violin made in Cremona, Italy, to the best country fiddler. There were other prizes for dancing, singing, football, jumping and wrestling. A pair of silk stockings was to go to the young woman whom the crowd judged prettiest.

A later notice asked everyone who came to behave "with Decency and Sobriety," which meant politely and without getting drunk. Breen writes that poorer people apparently were welcome to come and watch.

A notice in the *Virginia Gazette* of July 1, 1737, stated that there would be horse races every Saturday until October near Williamsburg. That November, John Pinkerton held three days of races at the Old Field track in Virginia, with a three-mile race each day. Mount Vernon's historians call it the first documented long-distance race in Virginia.

Pinkerton's meeting also had a fiddling contest, a running race for boys, a contest for the prettiest unmarried woman, and a dinner with singing and dancing. Different sources spell the host's name Pinkerton or Brickerton, and the right spelling is not known.

**A one-mile course.** A Williamsburg fair in December 1739 had three days of races. On the first day, eight horses raced around a one-mile course for a saddle worth 40 shillings. Colonel Chiswell's horse Edgcomb won. The second horse won a bridle and the third won a whip.

### Cricket

Colonists also played cricket, the English bat-and-ball game. William Byrd II owned the Westover plantation in Virginia. His diary for April 25, 1709, records that he played cricket and then "went to cricket again till dark." In Georgia in 1737, William Stephens wrote that townsmen, landowners and servants gathered in the main square to play cricket.

### Cockfighting and gander pulling

In a cockfight, two roosters fought in a ring. Their owners strapped sharp spurs made of silver, steel or bone to the birds' legs, and the birds cut each other with the spurs. The fight went on until one bird was dead. Men bet on which bird would win. William Byrd II, Robert Carter and George Washington were among the men who followed cockfighting.

An advertisement in the *South Carolina Gazette* listed a cockfight at the house of a Mrs. Eldridge in 1732. Men in Salem, Massachusetts, held a cockfight in the Town House in 1744. Both Black and white people came to cockfights and bet on them. Some critics complained that "genteel people," meaning the well-off, mixed at the fights with people they called "the vulgar and debased," meaning common and low.

**Gander pulling.** Gander pulling was another game played on live birds. Men tied a live gander, a male goose, upside down by its feet to a tree branch and greased its neck. Riders galloped past and grabbed at the neck until one of them pulled the bird's head off.

Riders fell from their horses, and some lost fingers. In Virginia the game was often held on the Monday after Easter, and the crowd bet on the riders. Accounts describe gander pulling through the colonial years, but none gives a dated event before 1750.

### Children

The London bookseller John Newbery printed *A Little Pretty Pocket-Book*, a book of rhymes and pictures for children, in 1744. He sold it with a ball for a boy or a pincushion for a girl. Its rhyme "Base-Ball" is the first known use of that word in print. It reads: "The Ball once struck off, / Away flies the Boy / To the next destin'd Post, / And then Home with Joy."

John Thorn, the historian of Major League Baseball, suggests that the game in the book may have been played without a bat. No copy of the 1744 printing survives. The rhyme is known only from later printings, such as one made in Worcester, Massachusetts, in 1787, and the words of the 1744 rhyme are taken from those later copies.

The records of these years do not show how much free time children had. Nor do they show how that time differed for free children, enslaved children and indentured children, who were bound to work for a master for a set number of years.

## 1750 to 1800

**Era 5 of 10 · 1750 to 1800 · about 10 minutes**

The records of these fifty years start to say who owned the horses and who rode them. In Virginia the owners of racehorses came more and more from the top ranks of society, and enslaved men and boys often rode. The enslaved people at one Virginia plantation had a holiday on Easter Monday 1774 and went to cockfights. That June the planter's son Bob Carter pestered his tutor, his private teacher, for leave to go to a cockfight too.

The delegates to the First Continental Congress, men chosen in each colony to meet together, agreed in 1774 to stop buying British goods. They also promised to discourage horse racing, cockfighting and games.

People still played ball games. Soldiers at Valley Forge played a running game called base, and the voters of Pittsfield, Massachusetts, banned "baseball" near their new meeting house in 1791. No record from these years shows leagues, paid teams, or towns sharing written rules.

Native nations kept playing their own ball games. In Hawaii, British sailors wrote descriptions of surfing in 1779. Chapter 23 tells how those islands later became part of the United States.

### Native games written down

James Adair described chunkey as the Choctaw played it, in a book printed in 1775. Only one or two players played on each side. The field was a square of ground, cleared and spread with fine sand, near the town house, the building where the town's leaders met.

Players ran after the rolling stone with 8-foot poles "most part of the day." They bet their silver ornaments, their nose, finger and ear rings, and even their clothes. Each town kept its chunkey stones from one generation to the next. Nobody buried a stone with the dead.

**The beaver pond.** The Creek and the Choctaw both claimed a large beaver pond on the Noxubee River, in present-day Mississippi, around 1790. Beaver furs sold well at the trading towns of Mobile and Pensacola. The two nations agreed to decide the claim with a game of stickball.

The account of that game comes from Stonie Hadjo, a Creek-born man whom the Choctaw adopted. He lived in Noxubee County, Mississippi, and often told the story to the white settlers there before he died in 1836. H. S. Halbert later wrote the story down, and H. B. Cushman printed it in 1899. Stonie Hadjo said that ten thousand people camped around the field. The Creek team won.

A fight broke out after the game, and the tellings differ on who started it. In Stonie Hadjo's telling, a Choctaw player insulted a Creek player, and the two began to fight. Choctaw accounts say the Creek player threw a petticoat, a woman's underskirt, on the Choctaw player first.

The fight spread to the warriors on both sides, who used sticks, knives, guns, tomahawks and bows and arrows. It lasted through the night until the chiefs arrived the next morning and stopped it. Stonie Hadjo said that the ball players "almost to a man perished," which means that nearly every ball player was killed. His account gives no count of the dead. The Choctaw kept the pond, even though the Creek team had won the game, and the account does not say why.

Writers for the Choctaw Nation describe two games around the 1790s played to settle land claims with the Creek, and both ended in battles. H. B. Cushman dates the second game, near the Black Warrior River, to about 1800.

Far to the north, the Mohawk and the Seneca played lacrosse at Grand River, in present-day Ontario, in 1797, with about 600 players on each side.

### Surfing in Hawaii, 1779

No outside nation ruled Hawaii in 1779. Chiefs governed the islands, and Kalaniʻōpuʻu ruled the island of Hawaii. The islands were joined into one Hawaiian Kingdom starting in 1795.

British sailors with Captain James Cook watched Hawaiians surfing at Kealakekua Bay, on the island of Hawaii, in January 1779. The ship's surgeon's mate, David Samwell, the assistant to the ship's doctor, described surf riding there on January 22, 1779.

Lieutenant James King also wrote an account, which was printed in 1784. When storms made the waves highest, twenty or thirty people each took "a long narrow board, rounded at the ends," and swam out together. They dove under the breaking waves until they were past them. Then they lay on their boards and rode the largest wave back to shore.

### Who owned the horses and who rode them

Almost every town in Virginia held yearly races by 1772, according to the English traveler J. F. D. Smyth. At Williamsburg the races ran for a week each spring and fall. The winner on the first day took a purse, a prize in money, of 100 pounds.

**Jockey clubs.** Horse owners in Fredericksburg, Petersburg, Richmond and other Virginia towns formed jockey clubs by the late 1700s. A jockey is a rider in horse races, but these clubs were groups of horse owners, and the members held races for one another. George Washington helped manage a race at Alexandria in May 1761.

The historian Gabrielle McCoy writes that the owners of racehorses came more and more from the top ranks of society. She writes that the riders "often came from the bottom of the social hierarchy," the ranking of people from the most powerful to the least. They were "enslaved men and boys."

### Austin Curtis

> **Who:** An enslaved jockey and horse trainer who became a free man.
>
> **When and where:** Halifax, North Carolina, and the racecourses of Virginia and North Carolina, from the 1770s to 1807.

**He kept his enslaver's racehorses safe from British raiders.**

Willie Jones of Halifax, North Carolina, held Austin Curtis in slavery. In the 1770s Curtis rode Jones's horses in races in Virginia and North Carolina. During the Revolutionary War, British troops raided the Carolinas for horses to breed, and Curtis kept Jones's horses safe from them.

**The petition.** On December 5, 1791, Jones asked the lawmakers of North Carolina to free Curtis. He wrote that Curtis had shown "attachment to his Country during the War" and "fidelity," or loyalty, "to his Master," and so "has demonstrated that he deserves to be free." The lawmakers granted the request, and Curtis became free. His name was legally changed to Austin Curtis Jones.

Curtis kept working with horses as a trainer. He came to own more than 300 acres of land, and he bought the freedom of his son William. He and his wife, Nancy, had eleven children.

Curtis died at Halifax on December 10, 1807, at about 50 years old. A Raleigh newspaper, the *Minerva*, printed a notice of his death under the name Austin Jones on January 5, 1808. It called him "well known for many years past, as keeper of race horses," and said that he "particularly excelled" at managing them.

### A plantation tutor's journal, 1773 and 1774

Philip Fithian taught the children of the planter Robert Carter at Nomini Hall, Virginia, from 1773 to 1774. He kept a journal. It records how the Carter children and the people Carter enslaved spent their free hours.

Easter Monday fell on April 4, 1774. Fithian wrote that the enslaved people had a holiday until Wednesday morning and were "at Cock Fights through the County." The next day his pupils complained that they had to study while the enslaved workers had the day off.

**Sunday.** Fithian saw a ring of enslaved people at the stable fighting cocks before breakfast on Sunday, April 10. Other enslaved people were digging the small garden plots that Carter allowed them to grow food on. Fithian explained that they did all their own work on Sundays because they worked for the Carters every other day.

On two winter evenings in 1774, enslaved people gathered in the schoolroom to play the fiddle and the banjo and to dance. Two of the Carter boys, Ben and Harry, joined them. The first time, Fithian sent them all away.

Another son, Bob, "teaz'd" Fithian, meaning he pestered him, on June 18 to let him go to a cockfight and a horse race two miles away. Fithian let him go after Bob promised to be home by sunset. Pupils at another school had "barred out" their teacher, Mr. Goodlet, in December 1773. They locked him out of the schoolhouse until he agreed to give them a Christmas holiday until January 6.

### Fist fights with no rules

Fithian wrote on August 29, 1774, that four young men had arranged two fist fights near Mr. Lane's place. He listed what such fighters did, including kicking, scratching, biting, choking, "Gouging" and "Dismembring," which meant tearing or biting off parts of the other man's body. A crowd came to watch.

**Gouging.** Gouging was a kind of fighting in which only weapons were banned. A fighter tried to push his thumbs into the other man's eye socket and force the eye out. Jim L. Sumner, writing for NCpedia, says most historians think fighters seldom lost an eye. He writes that the fights still risked broken bones, scars, crippling injuries and death.

Gabriel Johnston, the governor of North Carolina, complained about this kind of fighting in 1746. North Carolina's lawmakers made it a crime to cut out tongues, pull out eyes, or bite off noses or fingers. Sumner's article does not give the year of that law.

### The Revolution: a pause in racing and a game of base

**A pause in racing.** The delegates to the First Continental Congress agreed to the Continental Association, a pact among the colonies, on October 20, 1774. In it they agreed to stop buying goods from Britain, starting on December 1, 1774. They also promised to discourage "all horse-racing, and all kinds of games, cock fighting," plays and "other expensive diversions," meaning ways to have fun.

Members of the jockey clubs of Annapolis and New York called off their races that year. Four years later, on October 12, 1778, the members of Congress asked the lawmakers of each state to pass laws to stop "horse racing, gaming" and plays.

**Base at Valley Forge.** Soldiers in the Continental Army still played games. George Ewing was an ensign, a young officer, in the 3rd New Jersey Regiment, a unit of soldiers. At Valley Forge in April 1778 he wrote that the men drilled in the afternoon and "playd at base this evening."

General Washington dined with General Henry Knox on May 4, 1778. Afterward he played wicket, a bat-and-ball game like cricket, with Ewing and other officers. After the war, in 1793, Virginia's lawmakers banned bets of more than 7 dollars on horse races or "any other sport or pastime."

### Toys and ball games

George Washington married Martha Custis in January 1759. Her children, Jacky and Patsy, were about six and four. In his first order of goods from London he asked for 10 shillings' worth of toys. He also ordered six little books for children learning to read, and a doll dressed in the latest fashion. When that doll was lost or broken, he ordered another that cost a guinea, which was 21 shillings. He also ordered a box of gingerbread toys and sugar figures.

Archaeologists at Mount Vernon found a small limestone marble at the House for Families. Most of the people George Washington enslaved at his Mansion House Farm lived in that building. Mount Vernon's historians think the marble may have belonged to one of the enslaved children who lived and worked there.

A reference book on leisure in America states that at fairs and on court days, the days when the county court met, poorer people ran footraces, wrestled, jumped, bowled and played football. They played for prizes such as a purse of money or a bottle of liquor, while wealthy people watched.

The printer Isaiah Thomas published *A Little Pretty Pocket-Book* in Worcester, Massachusetts, in 1787, with the English rhyme and a picture of "Base-Ball."

**Baseball in Pittsfield.** Voters at a town meeting in Pittsfield, Massachusetts, passed a rule on September 5, 1791, to protect the windows of their new meeting house, the town's main public building. They banned "any game of wicket, cricket, baseball, batball, football, cats, fives, or any other game played with ball" within 80 yards of the building. The rule is the oldest known record of people in an American town playing a game called baseball.

## 1800 to 1850

**Era 6 of 10 · 1800 to 1850 · about 15 minutes**

Crowds of many thousands began to gather to watch sport in the first half of the 1800s, and the biggest crowds came to see horses race. By 1850 trotting races, in which a horse pulled a driver in a light cart, had begun to replace races with riders as the sport Americans most liked to watch. Prize fights, boxing matches with bare fists fought for money, had become about as popular to watch as trotting.

Members of clubs in Philadelphia and New York wrote down rules for their ball games, and in 1845 members of the Knickerbocker club of New York wrote the rules that grew into baseball.

Enslaved people played ball, wrestled and ran races on their few days off, and enslaved jockeys rode horses that other men owned. Children like Lucy Larcom in Massachusetts made their own toys from burrs and played outdoors. A Philadelphia firm began to make toys to sell in 1838.

### Native ball games and the loss of Choctaw land

The Choctaw and the Creek both claimed the land between the Tombigbee and Black Warrior rivers, in present-day Alabama, about 1800. They agreed to settle the claim with a ball game about a mile below present-day Tuscaloosa. The Creek chief was Tuskeegee and the Choctaw chief was Luee. Both sides said they had won. A battle followed "in which many were killed and wounded on both sides," and more battles followed that fall. The account, which H. B. Cushman printed in 1899, gives no count of the dead.

**The treaty.** Choctaw leaders signed the Treaty of Dancing Rabbit Creek, a written agreement with the United States, on September 27, 1830. The men who bargained for the United States, Secretary of War John Eaton and John Coffee, gave the Choctaw two choices: move west of the Mississippi River, or stay and live under US and state law.

The chief Choctaw men at the talks were Greenwood LeFlore, Mosholatubbee and Nittucachee. Under the treaty, the Choctaw had to hand over about 11 million acres of their land to the United States, most of it in Mississippi. So staying meant living on land the Choctaw had handed over, under the laws of the state.

About 5,000 to 6,000 Choctaw stayed in Mississippi. US officials forced the rest, about 15,000 people, to leave their homeland and go west to Indian Territory, in present-day Oklahoma, in three groups between 1831 and 1833. A winter blizzard and an outbreak of cholera, a disease that kills by draining the body of water, struck them on the way. Writers for the Choctaw Nation say that more than a quarter of the Choctaw people forced out in those years died. Another count gives about 2,500 dead.

**The graves.** The ball players killed after the beaver-pond game of about 1790 had been buried at the ball ground with money and silver ornaments. A settler named Charles Dobbs took that ground in 1832, part of the land the Choctaw had to hand over under the 1830 treaty. Dobbs dug up their graves. He took about $500 in silver and about $250 in silver ornaments.

**The game in Indian Territory.** The Choctaw kept playing in their new land. The painter George Catlin watched a Choctaw ball game there in 1834. Several thousand people camped beside the field. Two leaders had chosen the players three or four months before and sent runners to each one with a decorated ball stick. The women placed the bets. They bet knives, dresses, blankets, pots and kettles, dogs, horses and guns.

Through the night before the game, the players danced by torchlight every half hour while the women sang. At 9 the next morning, at the firing of a gun, four old men who served as judges threw up the ball. Six or seven hundred players ran for it. Each player held a stick in each hand and could not touch the ball with his hands.

Catlin painted a Choctaw player named Tul-lock-chísh-ko, which means "Drinks the Juice of the Stone." Catlin called him "the most distinguished ball-player of the Choctaw nation." By the rules of the game he played barefoot, in a breechcloth, a strip of cloth worn around the hips, with a tail of white horsehair.

### Surfing in Hawaii, 1847

Hawaii was still an independent kingdom. Hiram Bingham led the first American missionaries there from the Protestant churches, the Christian churches that broke away from the Catholic Church, and they arrived in 1820. He wrote in 1847 that surfing was "the favorite amusement of all classes." Surfers used boards from 3 feet to 14 feet long and paddled out as far as half a mile. People used to bet on it, he wrote.

Fewer Hawaiians surfed than before, Bingham wrote, because Hawaiians now wore cloth clothing in the missionaries' style and the people who made that clothing had less free time. He also gave the cause as more "modesty, industry or religion." In his time, modesty meant keeping the body covered, and industry meant hard work.

**Was surfing banned?** No law against surfing is on record. In the same passage, Bingham denied that the missionaries had caused any law against it. Peter T. Young, a historian of Hawaii, writes that only the king and the chiefs could make such a law, and that Hawaiians kept surfing through these years.

### Games on the days off from slavery

Frederick Douglass was enslaved in Maryland. In his book of 1845 he wrote that the enslaved people he knew had the days from Christmas to New Year's Day off. Some of them made brooms, mats and baskets or hunted opossums, hares and raccoons. Most played ball, wrestled, ran footraces, fiddled, danced and drank whiskey. Douglass wrote that the drinking was what "our masters" liked best.

For a time Douglass taught other enslaved men to read on Sundays in St. Michael's, Maryland. Two class leaders, men who led small religious groups in the church, Wright Fairbanks and Garrison West, came in with other men carrying sticks and stones and broke up the school. Douglass wrote that the enslavers "had much rather see us engaged in those degrading sports," by which he meant wrestling, boxing and drinking whiskey.

In the South, planters set up boxing matches between enslaved men and bet on them. The reference book *American Eras*, which records this, gives the name of no fighter and no match.

### Tom Molineaux

> **Who:** A boxer from Virginia who fought twice for the championship of England.
>
> **When and where:** Virginia, New York, England and Ireland, 1784 to 1818.

**About 15,000 people watched the English champion break Molineaux's jaw.**

Tom Molineaux fought the English champion, Tom Cribb, in Oxfordshire on December 18, 1810. In the 19th round the crowd pushed into the ring, and Molineaux hurt his left hand. Under the rules, a fighter had 30 seconds to come back to the line marked in the ring. Later in the fight, people argued over whether Cribb had taken longer than that. Cribb won. Accounts give the length of the fight as 35 rounds or about 39.

The English boxing writer Pierce Egan wrote that Molineaux surprised everyone with his power and his skill. About 15,000 people watched the second fight, on September 28, 1811. Cribb broke Molineaux's jaw and knocked him out in the 11th round.

**Where he came from.** Molineaux was born in Virginia on March 23, 1784. Writers at the Virginia Museum of History and Culture say he was born enslaved and fought other enslaved men while plantation owners bet on the fights. They say he won his freedom and $500 in one of those fights. Other accounts say the story comes from boxing writers of the 1800s and cannot be proved.

He had gone to New York and then to England by 1809. His trainer there was Bill Richmond, who had been born into slavery on Staten Island, New York, in 1763. The Virginia museum's writers say Richmond was born in Virginia.

Molineaux died in Ireland on August 4, 1818, at 34, with no money. He died in the band room of the 77th Regiment, a unit of soldiers, of tuberculosis, a lung disease, and of heavy drinking. The Galway City Museum in Ireland gives the place as an army barracks in Galway, and the Virginia museum's writers give Dublin.

### Enslaved jockeys and trainers

Every state east of the Mississippi River had at least one racetrack by 1830, and Virginia had more than twelve. Enslaved men rode, trained and cared for horses at these tracks, and the records name a few of them.

An enslaved jockey named Simon raced against horses owned by Andrew Jackson, who later became president, from 1810 to 1815. The National Museum of Racing records nine races between them. Jackson's side lost eight times and gave up once without running.

An enslaver named John Henry Hammond bought an enslaved trainer and groom, a worker who cares for horses, named George in 1834. Hammond and other enslavers talked about splitting the ownership of George three ways.

**Cato's win.** An enslaved jockey named Cato rode the horse Wagner to victory at Louisville, Kentucky, on September 30, 1839, for a prize of $14,000. About 10,000 people watched. Some of them made bets in dollars and some bet enslaved people. Wagner's owner, John Campbell, also held Cato in slavery.

The Notable Kentucky African Americans Database states that Campbell freed Cato for the win and that Cato kept riding for him. Jessica Dallow, who has written about the painter Edward Troye's pictures of racehorses, writes that his freedom was only rumored at the time.

She points to the writer Edward Hotaling. He noted that each win made an enslaved jockey worth more to his owner, so freedom would have been an unusual reward. Enslaved jockeys could earn some money by riding, and Dallow writes that Cato may have been freed or may have bought his own freedom.

A race card, a printed list of the horses in a race, for the Washington Race Course at Charleston, South Carolina, in 1846 listed the owner of each horse, including Wade Hampton. It listed no rider. Each jockey appears only by the colors he wore.

### Crowds for horses, runners and fighters

**North against South.** The northern horse American Eclipse beat the southern horse Sir Henry at the Union Course on Long Island, New York, on May 27, 1823. One history of the period puts the crowd at as many as 100,000 people. Horses from the North and the South raced each other in more matches of this kind until 1845.

People also came to watch men run. John Cox Stevens offered $1,000 in 1835 to any man who could run ten miles in under an hour. Henry Stannard did it in 59 minutes and 49 seconds. Trotting races began to take the place of races with riders on horseback about 1845.

**Fights against the law.** Prize fighting was against the law in most states, so organizers set up fights at the last minute. By 1850 prize fighting was about as popular to watch as trotting races. In the North, many fights set Irish Catholic immigrants against Protestants born in America.

Thomas McCoy, who was 21, died after a prize fight with Christopher Lilly at Hastings, New York, on September 13, 1842. A coroner's jury, a group of citizens who look into a sudden death, found that he died "by blows and injuries received in a fight with Christopher Lilly." The jury named eight men as the main people in the fight. None of them had been arrested when a Michigan newspaper printed the jury's finding on September 26.

A judge sentenced James "Yankee" Sullivan, who arranged the fight, to two years in prison. Sullivan served two months. He then paid a $200 bond, money a court keeps if a person breaks a promise, and promised not to fight for two years, and he was let out. The records do not say what happened to Lilly. Tom Hyer beat Sullivan in 17 minutes and 18 seconds in Maryland in 1849 and won a purse of $10,000.

### Who wrote the rules of baseball?

No one person wrote them. Players in many towns played bat-and-ball games that went by local names, such as town ball, and clubs wrote down their own rules. Two groups of town ball players from Philadelphia met in Camden, New Jersey, on July 4, 1833, and joined to form one club, the Olympic. The club printed its rules and its list of members in 1838.

**Twenty rules.** The members of the Knickerbocker Base Ball Club of New York adopted twenty written rules on September 23, 1845. Two members, William Wheaton and William Tucker, wrote them down. A game ended when one side scored 21 runs. Three outs ended a side's turn at bat. A fielder put a runner out by throwing the ball to a baseman, not by hitting the runner with it. The members were merchants, lawyers and doctors. They played at the Elysian Fields in Hoboken, New Jersey.

The Knickerbockers played the New York club under the new rules on June 19, 1846, in one of the first recorded games between two clubs. One account says the New York club won 23 to 1. Another says the Knickerbockers won.

**The Doubleday story.** Albert Spalding and the members of a committee he asked for later spread a story about how baseball began that was not true. Spalding, a maker of sporting goods, asked for a study of how baseball began in 1905. Abner Graves, a 71-year-old mining engineer, wrote to an Ohio newspaper that Abner Doubleday had invented baseball in Cooperstown, New York, in 1839. Graves had been 5 years old in 1839. Doubleday was then a cadet, a student training to be an army officer, at West Point.

The historian Victor Salvatore found that baseball does not appear in any of Doubleday's 67 surviving diaries. Other writers say he mentioned it once in his letters or diaries. No member of Spalding's committee met Graves or wrote to him. Even so, the committee's chairman, Abraham Mills, wrote in a report of December 30, 1907, that Doubleday had invented the game.

Spalding wanted to show that baseball owed nothing to any English game. Salvatore titled his article about Doubleday "The Man Who Didn't Invent Baseball."

### Children, toys and the circus

The toy firm Francis, Field and Francis opened on North Second Street in Philadelphia in 1838. It was Philadelphia's first toy maker and one of the first in the country. The owners sold toys brought from France and Germany and made toys of their own. According to the Encyclopedia of Greater Philadelphia, their toy fire engine pulled by horses is believed to be the first toy made in a factory in the United States.

The city leaders of Wilmington, Delaware, banned public shows in 1825. Joshua Purdy Brown put up a canvas tent for his circus just outside the city line. With his own tent, Brown could set up his circus in any town, and the circus became a traveling show.

### Lucy Larcom

> **Who:** A girl who went to work in a mill at 11 and later wrote about it.
>
> **When and where:** Beverly and Lowell, Massachusetts, 1824 to the 1840s.

**"The children will have to leave school and go into the mill."**

Lucy Larcom grew up in Beverly, Massachusetts, in the 1820s and 1830s. She and her friends shaped burrs from burdock plants into chairs, cradles and sofas for their dolls. They played school on the doorsteps and climbed over the wall onto the hill. She wrote that the neighborhood children, from large families, enjoyed "a little wholesome neglect." She meant that the grown-ups mostly left them alone, and that this was good for them.

**The move to Lowell.** Her father, a retired sea captain, died in 1832. Three years later her mother, Lois Larcom, moved the family to Lowell, a mill town. There she ran a boarding house for women who worked in the mills, cooking and keeping house for up to forty of them. Each boarder paid her $1.25 a week. In her book about her childhood, Lucy wrote down the sentence that sent her to work: "The children will have to leave school and go into the mill." She was 11.

She went to work at the Lawrence Manufacturing Company as a doffer. A doffer took full bobbins, the spools that held thread, off the spinning machines and put on empty ones, about every 45 minutes. At first she told her family, "It is just like play." Between changes, she and the other little girls played games in a corner.

In winter the working day ran from first daylight to 7:30 at night. She earned one dollar a week plus her board, and her family needed the money, so she could not go on to high school. She wrote that mill work "was not, and could not be, the right sort of life for a child."

The mill rules banned books, so she pasted poems cut from newspapers all over the side of her window seat in the mill. She and her sister Emeline published poems in two magazines, the *Operatives' Magazine* and the *Offering*. Lucy Larcom grew up to teach school and to write poems. Her book about her childhood, *A New England Girlhood*, came out in 1889.

**If you remember one thing:** Sport turned into something huge crowds came to watch, while US officials forced the Choctaw west and enslaved jockeys rode horses that other men owned.

- 1823: as many as 100,000 people watch American Eclipse beat Sir Henry on Long Island.
- 1830: Choctaw leaders sign the Treaty of Dancing Rabbit Creek and must hand over about 11 million acres.
- 1845: the Knickerbocker club of New York writes down twenty rules for baseball.

**Next:** After 1850 a team paid its players openly, a teacher invented basketball, and the men who ran baseball shut Black players out.

## 1850 to 1900

**Era 7 of 10 · 1850 to 1900 · about 14 minutes**

Sport turned into a business between 1850 and 1900, and the men who ran it decided who could play. Harry Wright put together the Cincinnati Red Stockings in 1869, the first known baseball team whose players were all openly paid. Students from Rutgers and Princeton played the first college football game that same year, and a teacher named James Naismith invented basketball in 1891. Black jockeys won most of the early Kentucky Derbies, and Isaac Murphy, who was born enslaved, won it three times.

The men who ran baseball's leagues shut Black players out, first in 1867 and again in 1887.

Adults also began to organize children's play. Members of a Boston health group put piles of sand in chapel yards for small children in 1885 or 1886, and people in other cities opened playgrounds in the 1890s. Many children had no time to play. Census takers in 1900, who counted everyone in the country, found more than 1.75 million children under 15 at work.

### The first paid team and new games

Harry Wright hired ten players for the Cincinnati Red Stockings in 1869 and paid them openly. He and his brother George were two of the ten. They won all 57 of their games against clubs in the national association of that time. That September they traveled to San Francisco, and they became the first club to play on both coasts. The Brooklyn Atlantics beat them in 1870, in 11 innings, while 20,000 people watched.

**Football.** Rutgers beat Princeton 6 to 4 at New Brunswick, New Jersey, on November 6, 1869, in the first college football game. Each side had 25 players. They could kick the ball or hit it with their fists or hands, but they could not hold it or trip anyone. About 100 people watched. The game looked more like soccer than like football today.

**Basketball.** James Naismith was a young teacher from Canada at a YMCA training school in Springfield, Massachusetts, in the winter of 1891. Luther Gulick told him to take a class that needed a game to play indoors in winter: "Naismith, I want you to take that class and see what you can do with it."

Naismith wrote 13 rules. He asked the janitor for two boxes to use as goals, and the janitor brought two peach baskets instead. Nine players played on each side. Accounts date the first game to December 21 or 29, 1891.

James Connolly, a 27-year-old Harvard student from Boston, won the hop, skip and jump at Athens, Greece, on April 6, 1896. That event is now called the triple jump. It was the first final of the first modern Olympic Games, so Connolly was the first modern Olympic champion. A dean at Harvard had warned him that he might not be let back into the college if he left to compete, and he went anyway.

**Games at home.** Milton Bradley sold a board game called *The Checkered Game of Life* in 1860. Buyers took more than 45,000 copies by 1861. Six years later Bradley printed rules for croquet, a lawn game played by hitting wooden balls with mallets.

### The color line in baseball

A color line was a rule, written or unwritten, that kept Black people out. The members of the National Association of Base Ball Players, the group that ran club baseball, put in place a formal ban on Black players and Black clubs in 1867.

Some Black men still played baseball for pay after that. Bud Fowler did in 1878. The Society for American Baseball Research calls him the first acknowledged Black professional baseball player. William Edward White, who had been born enslaved, played one game for Providence in 1879. He lived as a white man and gave his race as white in the census.

Moses Fleetwood Walker and his brother Weldy played for Toledo in the American Association, then a major league, in 1884. They were the first Black major-league players known to the public as Black men.

**The vote in Buffalo.** Cap Anson, the captain of the Chicago club, said in 1887 that his team would not play Newark if Newark's two Black players took the field. They were Walker and the pitcher George Stovey. On July 14, 1887, Newark played Chicago without them.

Newark played in the International League, a minor league, one of the lower leagues below the major leagues. That same day, at a meeting in Buffalo, New York, the league's owners, whom the surviving accounts do not name, voted 6 to 4 to tell the league's secretary, C. D. White, to approve no more contracts with Black players. The owners of teams with only white players voted for the ban, and those with a Black player voted against it.

Two Black players stayed in the league because their contracts had been signed before the vote: Frank Grant of Buffalo and Walker, who moved to Syracuse. Walker played in the league until 1889. After him, no Black player played in the International League until Jackie Robinson joined the Montreal Royals in 1946. The owners of the major-league teams, a step above, never wrote down a rule against Black players. They kept Black players out by an unwritten agreement among themselves.

### Moses Fleetwood Walker

> **Who:** A catcher, the first major-league player known to the public as a Black man.
>
> **When and where:** Ohio, Toledo, Newark and Syracuse, 1856 to 1924.

**A letter warned that a mob would attack if Walker played.**

Moses Fleetwood Walker, born in Mount Pleasant, Ohio, in 1856, studied at Oberlin College and then studied law at the University of Michigan. He caught for Toledo in 1883. In a game that year that did not count in the standings, Cap Anson of Chicago used a racist slur about Walker and said his team would never again play a team with Walker on it.

Walker played his first major-league game for Toledo, at Louisville, on May 1, 1884. He played 42 games and batted .263, which means he got a hit in about 26 of every 100 times at bat. He often caught the ball barehanded, with little padding. Toledo's pitcher Tony Mullane later said Walker "was the best catcher I ever worked with, but I disliked a Negro." "Negro" was a word of the time for a Black person. Mullane said he threw his pitches without looking at the signals Walker gave him.

**The letter.** Toledo's manager got a letter in September 1884 warning that a mob would attack if Walker played in Richmond, Virginia. David Zang's account of Walker's life does not name the men who wrote it. The men who ran the Toledo team released Walker before the trip.

**Syracuse, 1891.** A group of white men attacked Walker outside a saloon in Syracuse on April 9, 1891. One of them, Patrick Murray, threw a stone that hit Walker in the head. Walker stabbed Murray with a pocketknife and killed him. On June 3, 1891, an all-white jury found Walker not guilty of second-degree murder, which means killing someone on purpose but without planning it ahead.

Walker was found guilty of robbing the mail in September 1898, and he spent a year in jail. He later ran an opera house, a theater, in Cadiz, Ohio. In 1908 he and his brother Weldy published *Our Home Colony*, a book arguing that Black Americans should move to Africa. He died of pneumonia, an infection of the lungs, in Cleveland on May 11, 1924, at 67.

### Black jockeys

Oliver Lewis rode the horse Aristides to win the first Kentucky Derby on May 17, 1875. The horse's trainer, Ansel Williamson, had been born enslaved in 1806. Black jockeys won 15 of the first 28 Kentucky Derbies.

### Isaac Murphy

> **Who:** A jockey born into slavery who won the Kentucky Derby three times.
>
> **When and where:** Kentucky and the Eastern racetracks, 1861 to 1896.

**By his own count he won 628 of his 1,412 races.**

Isaac Burns Murphy was born into slavery in Clark County, Kentucky, on January 6, 1861. His father, Jerry Burns, joined the Union Army in 1864 and died that fall in the hospital at Camp Nelson.

Murphy won the Kentucky Derby in 1884, 1890 and 1891. He was the first jockey to win it three times and the first to win it two years in a row. By his own count, he won 628 of the 1,412 races he rode, about 44 of every 100.

The racing writer Terry Conway writes that Murphy was said to earn $15,000 to $20,000 a year, at a time when the average family of four earned about $1,200. He and his wife, Lucy, bought a 10-room house in Lexington for $10,000 in 1887.

**The fall at Monmouth.** Murphy rode the favorite, Firenze, in a race called the Monmouth Handicap in 1890. He swayed in the saddle and fell off after the finish. The race officials, called stewards, said he was drunk and barred him from riding for a time.

Murphy said he had been drugged. One account says he blamed a sudden loss of weight. Someone had bet heavily against his horse, and that betting made some people suspect a crime. The accounts of the race do not say who placed those bets.

Murphy died in Lexington in February 1896, at 35. Accounts give the cause as pneumonia or heart failure. How much money he left is not known. After he died, Lucy Murphy could not pay back a $5,500 loan from Gus Luigart, and she lost the house in a lawsuit. It was sold at auction in 1900.

He was buried in African Cemetery No. 2 in Lexington. In later years the grave had no marker. He became the first jockey named to the Racing Hall of Fame in 1955. His body was moved in 1967 to a site near the grave of the racehorse Man o' War, and later to the Kentucky Horse Park.

### Football deaths

Football players in the 1890s wore no helmets, no mouthpieces and no padding. Reporters at a New York newspaper, the *World*, counted at least eight deaths and more than 200 serious injuries in the 1897 season. Their list included broken bones, fractured skulls, twisted necks and crushed chests.

Richard Von Gammon, a 17-year-old University of Georgia player, dove into a pile of players to make a tackle against the University of Virginia in Atlanta on October 30, 1897. He lay still on the field and died early the next morning of a concussion, which is an injury to the brain from a hard blow to the head.

**A mother's letter.** Georgia's lawmakers voted to ban football at the state's colleges. Von Gammon's mother, Rosalind Burns Gammon, wrote to her representative. She asked that her son's death not be used as an argument against the sport. Governor William Atkinson vetoed the ban on December 7, 1897, which means he refused to sign it and it did not become law.

A Tennessee newspaper, the *Knoxville Tribune*, printed a full-page editorial, an article giving the paper's own opinion, calling for a ban on October 30, 1898. The editorial listed three deaths and gave no names. Two players' heads struck together and one of them died. A player at the bottom of a pile had his neck broken. A player kicked in the head by a heavy shoe died three days later.

### Women on bicycles

Frances Willard learned to ride a bicycle at 53. In 1895 she published a book about it. As a girl in the country she had almost no toys except the ones she made herself, such as a wooden plow. She practiced on the bicycle for three months. She wrote that women who rode "must, when riding, dress more rationally," which meant in clothes that made sense for the job.

Susan B. Anthony told the reporter Nellie Bly, in an article printed on February 2, 1896, that the bicycle "has done more to emancipate women," or set them free, "than anything else in the world." Anthony said that bloomers, which were loose pants gathered at the ankle, or very short skirts were the right clothes for riding.

### The first playgrounds

Dr. Marie Zakrzewska wrote to a Boston health group, the Massachusetts Emergency and Hygiene Association. She told its leaders that in Berlin's public parks, children rich and poor dug and played in heaps of sand.

**Which year?** Accounts give two different years for the first sand in Boston. Joseph Lee, who wrote a book about helping the poor in 1902, gives 1886. That year, he wrote, members of the association put three piles of yellow sand in the yards of a children's mission, a church charity for children, and of two chapels, which are small churches.

A 1925 history by the Playground and Recreation Association of America says that a large sand pile was put in the yard of the Children's Mission on Parmenter Street in 1885.

The association had ten sand piles by 1887, and about 400 children came each day. The children's favorite games in the sand were "house" and "funeral." By 1900 members of the association ran 21 playgrounds, 20 of them in school yards.

**Other cities.** People in other cities opened playgrounds in the 1890s. Donors in Philadelphia started two summer playgrounds in 1893. A playground opened at Hull-House in Chicago in 1894, with swings, a may-pole, a tall pole that children danced around holding ribbons, a sand pile and benches. A kindergarten teacher and a policeman ran it, and the policeman usually captained one of the baseball teams.

The members of a New York City committee wrote in an 1897 report that New York "has as yet not a single municipal playground," meaning none run by the city. Jacob Riis was the committee's secretary.

People began to build amusement rides in these years too. LaMarcus Thompson opened a roller coaster, the Switchback Railway, at Coney Island in Brooklyn in 1884. A ride cost 5 cents, and the car went just over 6 miles an hour.

### The children who had no time to play

Census takers counted working children for the first time in 1870. They found more than 750,000 workers under 15. That count left out children who worked on their own family's farm or in its shop. The number more than doubled by 1900, to more than 1.75 million children under 15 with jobs. After 1880 most working children aged 10 to 14 worked somewhere other than a farm.

One child in eight had a job in 1870, and more than one in five did by 1900. The census counts do not name the employers. About 25,000 of the nearly 100,000 workers in the cloth mills of the South in 1900 were children under 16. Children in the mills worked 12-hour days, six days a week.

### Cherokee ball play, 1890

The researcher James Mooney described the Eastern Cherokee ball game in North Carolina in 1890. In the fall a game took place somewhere on the reservation, the land where the Eastern Cherokee lived, at least every other week. Each player carried two sticks just under 3 feet long, each with a net of twisted squirrel skin or hemp. For 7 to 28 days before a game, a player did not eat rabbit or frog or hot or salted food, and did not touch a woman.

**The scratching.** Before a game an old man named Standing Water scratched each player with a comb made of seven sharp splinters of turkey leg bone. He pressed the teeth into the skin from shoulder to elbow and from elbow to wrist, and down each leg. He also cut an X on each player's chest and back. The scratches added up to nearly three hundred cuts.

Mooney wrote that the cuts were shallow but painful, and that the players took them willingly as part of the ritual they believed would help them win. No order banning the Cherokee or the Choctaw ball game in these years is on record. The games drew large crowds, including local white people.

**If you remember one thing:** Paid teams, leagues and new games turned play into a business in these fifty years, and the men who ran baseball used that power to shut Black players out.

In 1850: no baseball team paid all its players, and nobody had played basketball or a college football game.

In 1900: paid baseball teams played in leagues closed to Black players, Isaac Murphy had won the Kentucky Derby three times, and more than 1.75 million children under 15 were at work.

**Next:** After 1900 adults filled children's free time with clubs, troops and leagues, and football deaths brought college coaches to the White House.

## 1900 to 1950

**Era 8 of 10 · 1900 to 1950 · about 22 minutes**

Clubs, troops and leagues run by adults filled more and more of children's free time in the first half of the 1900s. Adults set up 4-H clubs in 1902, the Boy Scouts in 1910, the Girl Scouts in 1912 and Little League baseball in 1939. Children also spent many free hours watching and listening, at Saturday movies, beside the radio and over comic books. In Muncie, Indiana, in the 1930s, at least half of the children at Saturday movies stayed five or six hours.

At least 11 people died of football injuries in 1905, and President Theodore Roosevelt called coaches to the White House. The white owners of the major leagues, the top professional baseball teams, kept Black players out until Jackie Robinson played for Brooklyn in 1947. Black players had their own leagues from 1920. In the 1920s and 1930s, white officials and white swimmers in many Northern cities separated the public pools by race and kept Black children out of the pools where other children learned to swim.

### Clubs and troops for children

A. B. Graham started a youth program in Clark County, Ohio, in 1902. Its first clubs were a Tomato Club and a Corn Growing Club, and they are counted among the beginnings of 4-H. William D. Boyce, a Chicago publisher, filed the legal papers that made the Boy Scouts of America an official organization on February 8, 1910.

Juliette Gordon Low signed up 18 girls in Savannah, Georgia, on March 12, 1912, as the first troop of what she called Girl Guides. The name changed to Girl Scouts in 1913. The Savannah girls started a basketball league and went camping.

### Choctaw and Chickasaw ball play, 1903

Choctaw and Chickasaw people met near Allen, in Indian Territory, each spring and fall to race horses and play the stick-and-ball game. Allen is now in Oklahoma. In the spring of 1903 about 300 people came and bet on a game. A player hit a Choctaw player with a ball stick, and a fight spread through the crowd. The Choctaw Nation's mounted police, called Lighthorsemen, and US marshals, who were federal police officers, stopped it. After that fight the twice-yearly games between the two nations ended.

### How many died playing football in 1905?

At least 11 people died of football injuries in the 1905 season, and counts of all the deaths tied to football that year run from 18 to 25. The firmest count comes from the writer Aaron Gordon, who later checked the newspaper reports. He found about 20 deaths tied to football, 11 of them directly from football injuries, and the cause of the others was not clear.

The NCAA's published history of its own beginnings states 18 deaths and 149 serious injuries. Reporters at the *Chicago Tribune* counted 19 deaths, and reporters at another newspaper, the *Cincinnati Commercial Tribune*, counted 25.

The dead included college players and high-school boys. Harold Moore, 19, a Union College player, was knocked out in a game against New York University. He died six hours later of bleeding inside his brain. In Rockville, Indiana, a broken rib pierced the heart of Carl Osborne, a high-school player, and killed him at once. Robert Brown, 16, of Sedalia, Missouri, was paralyzed by a neck injury and died without waking.

**The White House meeting.** President Theodore Roosevelt met coaches and graduates from Harvard, Yale and Princeton at the White House on October 9, 1905. They signed a statement against rough play. That December, Henry MacCracken, the head of New York University, called a meeting of college leaders for December 9.

At a second meeting, on December 28, the men from 62 colleges formed a group. Its members renamed it the National Collegiate Athletic Association, the NCAA, in 1910. The rules of the game changed for 1906. A team now had to gain 10 yards, not 5, to keep the ball. Jumping over the line was banned, and the forward pass was allowed.

### Jack Johnson

> **Who:** A Black heavyweight boxing champion. After he beat a white former champion in 1910, white crowds attacked Black people across the country.
>
> **When and where:** Galveston, Texas, Sydney, Reno, Chicago and Leavenworth, 1878 to 1946.

**His opponent said he fought to prove "a white man is better."**

Jack Johnson, born in Galveston, Texas, in 1878, beat Tommy Burns in Sydney, Australia, on December 26, 1908. That made him the heavyweight boxing champion of the world, the champion of the boxers in the heaviest weight class.

He fought James Jeffries, a white former champion, in Reno, Nevada, on July 4, 1910. Before the fight Jeffries said he was fighting "for the sole purpose of proving that a white man is better than a Negro." "Negro" was a word of the time for a Black person. Jeffries's own helpers stopped the fight in the 15th round, and Johnson won.

**That night.** White crowds attacked Black people in more than 25 states. Between 11 and 26 people were killed, and hundreds were hurt. In Uvalda, Georgia, white gunmen fired into a work camp and killed three Black workers. In New York City a crowd clubbed a Black man to death. In Norfolk, Virginia, more than 300 white Navy sailors hunted Black people in the streets. The records do not name the people who were killed or the people who killed them.

Officials in many states and cities banned showing the film of the fight. The members of Congress banned carrying boxing films from one state to another in 1912. The ban lasted until 1940.

**The arrest.** Johnson opened a nightclub in Chicago, the Café de Champion, in July 1912, and Black and white customers mixed there. He was arrested on October 18, 1912, under the Mann Act, a federal law of 1910. It made it a crime to take "any woman or girl" across state lines "for the purpose of prostitution or debauchery, or for any other immoral purpose." Prostitution means selling sex, and debauchery meant wild, immoral living.

Federal prosecutors, the lawyers who bring charges for the government, used the law against Johnson because he traveled with white women. An all-white jury, a group of citizens who decide whether a person is guilty, found him guilty in June 1913. Judge Kenesaw Mountain Landis ordered him to spend a year and a day in prison. Johnson fled to Canada and Europe and stayed away for seven years. He gave himself up on July 20, 1920, and served his sentence at Leavenworth prison in Kansas.

He died in a car crash near Franklinton, North Carolina, on June 10, 1946, after the staff of a diner that served only white people refused to serve him. President Donald Trump pardoned him on May 24, 2018. A pardon is an official act by a president or governor that forgives a crime and ends its punishment.

### Black jockeys forced out

Jimmy Winkfield of Kentucky won the Kentucky Derby, a horse race held each spring in Louisville, in 1901 and 1902. No Black jockey has won it since. He left to ride in Russia in 1904, and later he rode in France. A Louisville newspaper, the *Courier-Journal*, printed the headline "Negro Jockeys Now Extinct" on January 21, 1912.

**How it happened.** Two economists, scholars who study money and business, Michael Leeds and Hugh Rockoff, studied why Black jockeys were driven out of American racing. They found that white jockeys attacked Black jockeys during races. The white riders boxed them in, ran them into the rail and hit them with their whips. Owners then stopped hiring Black jockeys, so that their horses would not be hurt. Henry King rode in the 1921 Kentucky Derby. No Black jockey rode in it again until 2000.

### Jim Thorpe and his medals

Jim Thorpe was a Sac and Fox athlete, born in 1887 near Prague, in what is now Oklahoma. He played football at the Carlisle Indian Industrial School for the coach Glenn "Pop" Warner. At the 1912 Olympic Games in Stockholm, Sweden, he won the pentathlon, a contest of five track and field events, and the decathlon, a contest of ten. In the decathlon he beat the second-place man by 688 points.

**The newspaper report.** Roy Johnson, a reporter for the *Worcester Telegram* in Massachusetts, reported in January 1913 that Thorpe had been paid to play minor-league baseball, in the lower leagues below the major leagues, in North Carolina in 1909 and 1910. Accounts of his pay run from $2 a game to $35 a week. Olympic athletes then had to be amateurs, people who were never paid to play a sport.

Thorpe wrote to James E. Sullivan of the Amateur Athletic Union that he "was simply an Indian schoolboy and did not know all about such things." James Ring Adams wrote in the magazine of the National Museum of the American Indian that Warner and Moses Friedman, the head of the Carlisle school, may have written the letter for him.

Sullivan and the other officials of the Amateur Athletic Union took away Thorpe's amateur standing. The members of the International Olympic Committee struck out his wins. Their own rules allowed a complaint only within 30 days of the Games, and the newspaper report came about six months later. Warner took the medals from Thorpe's house and sent them back to Stockholm. Hugo Wieslander, who had come second in the decathlon, refused the gold medal.

Thorpe played major-league baseball for the New York Giants and other teams from 1913 to 1915 and from 1917 to 1919. He played pro football for the Canton Bulldogs for $250 a game. In 1920 he became the first president of the league that later took the name National Football League. In his last years he worked as a film extra, a laborer and a doorman. He died of heart failure in 1953, at 65.

**The medals restored.** A researcher, Florence Ridlon, found the 30-day rule in the 1912 rule book in 1982. On October 13 of that year, the leaders of the International Olympic Committee named Thorpe a co-champion, sharing each title with the second-place man: Hugo Wieslander in the decathlon and Ferdinand Bie in the pentathlon. On July 15, 2022, they named him the only champion of both events.

### Baseball and the Negro Leagues

The Boston Americans beat the Pittsburgh Pirates 5 games to 3 in the first modern World Series, in October 1903. The owners of the two teams, Henry Killilea of Boston and Barney Dreyfuss of Pittsburgh, arranged it. About 100,000 people watched the eight games. There was no series in 1904, because the owners of the New York Giants refused to play.

**By 1920:** Football had new rules after the deaths of 1905, Black jockeys were nearly gone from American racing, and the owners of Black baseball teams were about to start a league of their own.

**A league of their own.** Rube Foster, the owner and manager of the Chicago American Giants, met other owners of Black teams at a YMCA in Kansas City on February 13, 1920. Together they started the Negro National League. It had eight teams in its first year. The league closed in 1931, during the Great Depression, when millions of people lost their jobs. Teams in other Negro Leagues kept playing until 1948.

Major League Baseball's leaders began counting seven Negro Leagues of 1920 to 1948 as major leagues in December 2020. That added about 3,400 players to the major-league record. On May 28, 2024, they added the Negro League players' numbers to the official record books.

### Babe Ruth

> **Who:** A pitcher and home-run hitter for Boston and New York.
>
> **When and where:** Baltimore, Boston and New York, 1895 to 1948.

**His school's records called him "incorrigible," a child no one can control.**

George Herman Ruth, born in Baltimore in 1895, was seven when he entered St. Mary's Industrial School for Boys on June 13, 1902. It was a reform school, a school meant to correct boys' behavior, and an orphanage, a home for children without parents. He spent most of the next 12 years there. A teacher there, Brother Matthias, taught him baseball.

Jacques Kelly, a writer for the *Baltimore Sun*, wrote in 1995 that Ruth's parents decided to place him at the school. The school's records listed the boy as "incorrigible," Kelly wrote. Writers have argued about the parents' reasons for many years.

**The sale.** Ruth pitched for the Boston Red Sox from 1914 to 1919. The owner of the Boston team, Harry Frazee, sold him to the New York Yankees for $100,000. The sale was made in December 1919 and announced in January 1920.

Ruth hit 54 home runs in 1920 and 60 in 1927, and he finished his career with 714. In 1936 he was one of the first five players chosen for the Baseball Hall of Fame. Cancer in the back of his nose and throat killed him on August 16, 1948, at 53.

### Movies, radio and comic books

Children in the 1920s and 1930s spent many of their free hours at the movies. Walt Disney started Mickey Mouse Clubs that met at Saturday matinees, the afternoon showings, in 1929. Richard Butsch gathered studies of movie audiences from the 1930s in a study printed in 2001. In Muncie, Indiana, at least half of the children at Saturday matinees stayed five or six hours. In a working-class part of New Haven, Connecticut, more than half the children went twice a week or more.

Researchers of the time found that children were choosing movies over outdoor games. A child in the Bronx, in New York City, said that when the film broke, the children booed, stamped their feet and often got into fist fights.

**Worried adults.** The mayor of Chelsea, Massachusetts, closed a theater in 1930 because of how children in the audience behaved. Researchers paid by the Payne Fund, a private group that gave money to good causes, carried out 13 studies of how watching movies changed children's behavior from 1929 to 1933.

*Little Orphan Annie*, a radio show, began in Chicago in 1930 and was broadcast across the country from April 6, 1931. It had about 6 million listeners of all ages before it went off the air in 1942.

**Comic books.** Superman first appeared in a comic book, *Action Comics* number 1, on April 18, 1938. A comic book cost 10 cents. A survey for the publishers in 1944 found that 95 of every 100 boys and 91 of every 100 girls aged 6 to 11 read comic books, about 12 a month.

Sterling North, a newspaper book editor in Chicago, called comic books "badly drawn, badly written and badly printed" in 1940. He wrote that they strained children's eyes and nerves. Comic books were burned in the 1940s. The Comic Book Legal Defense Fund's history of these burnings does not name who burned them.

Lizzie Magie patented a board game called *The Landlord's Game* in 1904. Monopoly grew out of it, and Parker Brothers began selling Monopoly on November 5, 1935.

**By 1940:** Children spent hours each week at the movies and with comic books, Babe Didrikson and Jesse Owens had won Olympic gold, and the owners of the major leagues still kept every Black player out.

### Babe Didrikson Zaharias

> **Who:** A track star, basketball player and golfer who won Olympic gold and helped start women's professional golf.
>
> **When and where:** Texas, Los Angeles and golf courses in the United States and Britain, 1911 to 1956.

**In three hours she won five events and tied for a sixth.**

Mildred Didrikson was born in Port Arthur, Texas, in 1911, the sixth of seven children of Norwegian immigrants. She became known as Babe. Managers at the Employers Casualty Insurance Company in Dallas hired her in 1930 to do office work and to play on the company's women's basketball team, the Golden Cyclones.

At the national track championships of 1932 she was the company's whole team. In three hours she won five events and tied for first in a sixth. She scored more points than any other team.

**The Olympics.** At the 1932 Olympic Games in Los Angeles she won the javelin and the 80-meter hurdles. In the high jump she won second place, because the officials ruled that going over the bar head first was a foul.

Later that year the Amateur Athletic Union's officials banned her from amateur sport, the contests for unpaid athletes, because her name appeared in an advertisement for a car. Her family needed money, so she played for pay. She toured with a men's traveling baseball team, the House of David.

**Golf.** She took up golf. Officials of the US Golf Association barred her from amateur golf in 1935, after complaints from members of the Texas Women's Golf Association. She married the wrestler George Zaharias in 1938. She helped found the Ladies Professional Golf Association, in 1948 or 1950 by different accounts. She won the US Women's Open in 1948, 1950 and 1954. From 1950 she lived with the golfer Betty Dodd, and the two hid that they were a couple.

She had cancer of the bowel in April 1953. Surgeons removed the cancer and gave her a colostomy. In that operation, surgeons bring the end of the large bowel out through an opening cut in the belly, so that body waste collects in a bag outside the body. Fourteen weeks later she was playing golf again, and in 1954 she won the US Women's Open. The cancer came back in 1955, and she died of it on September 27, 1956, at 45.

### Jesse Owens

> **Who:** A runner and jumper who won four gold medals at the Olympic Games in Nazi Germany.
>
> **When and where:** Alabama, Cleveland and Berlin, 1913 to 1980.
>
> **Movie:** *Race* (2016), a drama film about Owens.

**"I had four gold medals, but you can't eat four gold medals."**

James Cleveland Owens was born in Oakville, Alabama, in 1913, the son of a sharecropper, a farmer who paid his rent with part of his crop. His family moved to Cleveland, Ohio, when he was nine. A teacher heard his initials, "J.C.," as "Jesse."

At a college track meet in Ann Arbor, Michigan, on May 25, 1935, he set five world records and tied a sixth in about 45 minutes.

**Berlin.** Owens won the 100 meters, the long jump, the 200 meters and the relay at the Olympic Games in Berlin in August 1936. Adolf Hitler's Nazi government ruled Germany then. The Nazis taught that white people they called "Aryans" were a superior race.

Back home, Owens had to ride the freight elevator, the one used for goods, to reach a party in his honor at the Waldorf Astoria hotel in New York. Accounts do not name who sent him there. President Franklin Roosevelt never invited him to the White House. Owens said later, "Hitler didn't snub me. It was our president who snubbed me. The president didn't even send me a telegram."

When Owens refused to finish a tour of Europe, Avery Brundage and other officials of the Amateur Athletic Union barred him from amateur sport. He earned money by racing against horses. Later he went bankrupt, which means he could not pay his debts. He said, "I had four gold medals, but you can't eat four gold medals." He received the Presidential Medal of Freedom in 1976. Lung cancer killed him in Tucson, Arizona, on March 31, 1980.

### Who was kept out of the pools

Jobless workers paid by a federal program, the Works Progress Administration, built about 6,000 athletic fields and playgrounds and 770 new swimming pools from 1935 to 1943. Each year tens of millions of Americans swam in city pools.

Jeff Wiltse, who wrote a book about public pools called *Contested Waters*, studied who was allowed in. Many cities in the North began letting men and women swim in the same public pools in the 1920s and 1930s. Wiltse found that white officials and white swimmers in those cities then separated the pools by race.

He wrote that "most northern whites did not want black men to have the opportunity to interact with white women" at the pools. Black children in those cities could not use the pools where other children learned to swim.

**Fairground Park, 1949.** John O'Toole, the head of public welfare in St. Louis, opened the Fairground Park pool to Black swimmers on June 21, 1949. He said, "They are taxpayers and citizens, too." About 30 to 40 Black people came.

Crowds of white young men gathered with baseball bats and bricks and beat Black people as they left the pool. The crowd grew to thousands. Twelve people were hurt, and police arrested seven, three white and four Black. The published accounts of the attack do not name the attackers. Afterward, so few people came to the pool that it lost money, and it was closed.

### Carl Stotz and the first Little League boys

> **Who:** A Williamsport man who organized baseball for his nephews and the neighborhood boys, and two of the boys who played.
>
> **When and where:** Williamsport, Pennsylvania, 1938 to 1955.

**Three local businesses paid $30 each for the first uniforms.**

Carl Stotz, 28, tried out rules and field sizes in the summer of 1938 with his nephews, Jimmy and Major Gehron, and other boys from his neighborhood in Williamsport, Pennsylvania. He had no children of his own.

**The first season.** Stotz, George Bebble and Bert Bebble each managed a team in 1939. Three local businesses paid $30 each for uniforms, and the teams took their names: Lycoming Dairy, Lundy Lumber and Jumbo Pretzel. Thirty boys played. The bases were 60 feet apart, and the pitcher threw from 40 feet. On June 6, 1939, Lundy Lumber beat Lycoming Dairy 23 to 8 on a vacant lot. It was the first Little League game.

Two boys on the Lycoming Dairy team were Bill Bair and Al "Sonny" Yearick. Yearick later became the first Little Leaguer to play baseball for pay, in the minor leagues. Both men died in January 2020. A volunteer remembered that they talked about Stotz and about how Little League had helped them stay out of trouble.

Only boys could play. Stotz said in 1973, "When we started the Little League, the idea of a girl playing baseball, even with other girls, was simply unthinkable." He left Little League's national company in November 1955 over "commercialization and central control," which meant that he objected to the league being run as a business from one head office.

### Women's professional baseball, 1943 to 1954

More than 600 women played in the All-American Girls Professional Baseball League from 1943 to 1954. Philip Wrigley, the owner of the Chicago Cubs, started it. The league's rules required players to wear skirts and lipstick and banned pants. During spring training they went to evening classes at a charm school, a school that taught manners and how to look and dress. No Black women were recruited or hired. The accounts of the league do not name who made that choice.

### Josh Gibson

> **Who:** A catcher and home-run hitter whom the white major-league owners never signed.
>
> **When and where:** Georgia and Pittsburgh, 1911 to 1947.
>
> **Movie:** *Soul of the Game* (1996), a television drama about several Negro Leagues players, with Mykelti Williamson as Gibson.

**His Hall of Fame plaque says he hit "almost 800" home runs.**

The catcher for the Homestead Grays, a Black team near Pittsburgh, was hurt in a game on July 25, 1930. The Grays' owner, Cum Posey, called Josh Gibson, 18, out of the stands to catch. Gibson had been born in Buena Vista, Georgia, in 1911, and his family had moved to Pittsburgh in 1926. There he worked in an air-brake factory and at a steel company.

Gibson played for the Grays and for the Pittsburgh Crawfords. The Crawfords' owner, Gus Greenlee, sold him back to the Grays in 1937 for $2,500 and two players. People called him "the Black Babe Ruth."

**Never in the majors.** The white owners of the major-league teams kept Black players out, so Gibson never played in their leagues. Doctors told him in 1943 that he had a brain tumor. He died in Pittsburgh on January 20, 1947, at 35, less than three months before Jackie Robinson played his first game for Brooklyn.

Since 2024 the major-league record books have included the Negro Leagues. A batting average shows how often a player got a hit: .466 means about 47 hits in every 100 times at bat. Gibson's .466 for 1943 is the highest for a single season in those records, and his career average of .372 is also the highest.

**The plaque.** Gibson was named to the Baseball Hall of Fame in 1972. His plaque there says he hit "almost 800" home runs.

### Jackie Robinson

> **Who:** The first Black player in the white major leagues since the 1880s.
>
> **When and where:** Georgia, California, Kansas City and Brooklyn, 1919 to 1972.
>
> **Movie:** *42* (2013), a drama film with Chadwick Boseman as Robinson. An earlier film, *The Jackie Robinson Story* (1950), starred Robinson as himself.

**"I need a Negro player with guts enough not to fight back."**

Jackie Robinson was born in Cairo, Georgia, in 1919, the youngest of five children of sharecroppers. His father left, and in 1920 the family moved to Pasadena, California. At the University of California, Los Angeles, he was the first athlete to earn varsity letters, awards for playing on the college's top teams, in four sports.

As a soldier at Fort Hood, Texas, on July 6, 1944, he refused to move to the back of an Army bus. Officers charged him with disobeying orders. A panel of nine white officers found him not guilty.

**The meeting with Rickey.** Robinson played for the Kansas City Monarchs of the Negro Leagues in 1945. Branch Rickey, the head of the Brooklyn Dodgers, met him on August 28, 1945. Robinson asked, "Are you looking for a Negro who is afraid to fight back?" Rickey answered, "I need a Negro player with guts enough not to fight back." Rickey signed him for $600 a month. Robinson played the 1946 season for the Montreal Royals, a minor-league team.

He played his first game for Brooklyn on April 15, 1947, before 26,623 people. More than 14,000 of them were Black. During that first season, Ben Chapman, the manager of the Philadelphia team, told his players to "call Robinson everything and anything they wanted to." Chapman and his players shouted racial slurs, insulting names for Black people, at him. Chapman told him to "go back to the cotton fields." They kept it up until officials in the office of Happy Chandler, the commissioner who ran baseball, ordered them to stop.

**Threats.** Robinson got letters, signed by no one, telling him to leave baseball. Arthur Mann, who worked for Rickey, gave two of them to the police. A sportswriter, Stanley Woodward, reported that St. Louis players had threatened to strike rather than play against him. The St. Louis owners and managers denied it. The National League's president, Ford Frick, said he would suspend any player who went on strike. A St. Louis player, Enos Slaughter, cut Robinson's leg with the metal spikes on his shoe and left a seven-inch gash.

Robinson was named the first Rookie of the Year, the best first-year player, in 1947 and Most Valuable Player in 1949. He died on October 24, 1972, at 53. Officials of Major League Baseball retired his number, 42, for every team in 1997, so that new players could no longer be given it.

**If you remember one thing:** Adults filled children's free time with clubs, troops and leagues, and the white owners of the major leagues kept Black players out until 1947.

**One number:** 26,623 people watched Jackie Robinson's first game for Brooklyn, on April 15, 1947, and more than 14,000 of them were Black.

**Next:** After 1950 girls fought to get into Little League, television carried the Super Bowl into homes, and children began playing video games.

## 1950 to 2000

**Era 9 of 10 · 1950 to 2000 · about 17 minutes**

Girls and Black children pushed their way into games that had kept them out in the second half of the 1900s, while more of children's afternoons went to lessons and organized sports. Fewer children walked or biked to school. Diaries of how children spent their days in 1981 and 1997 showed more time in organized sports and lessons, and less time in free play and watching television. Children could play video games for a quarter in arcades from 1972, and on game machines at home from 1975.

Little League officials kept girls out from 1951 until 1974. After Title IX became law in 1972, the number of girls playing high-school sports rose from about 294,000 to about 2.7 million by 1999.

Boxing officials took Muhammad Ali's title after he refused to be drafted in 1967. US Olympic officials suspended Tommie Smith and John Carlos and sent them out of the Olympic Village, where the athletes lived, after they protested on the medal stand in 1968. Two television networks, CBS and NBC, showed the first Super Bowl in 1967 to about 51 million viewers.

### Kathryn "Tubby" Johnston

> **Who:** A girl who played Little League baseball under a boy's name. Little League officials then banned girls.
>
> **When and where:** Corning, New York, 1950.

**"I ran into my brother's room, got a pair of his slacks."**

Kathryn Johnston played baseball with boys on a sandlot near her home in Corning, New York, in the spring of 1950. She wanted to play on a Little League team, and only boys could play on Little League teams.

She described what she did next: "I ran into my brother's room, got a pair of his slacks, put on a baseball cap and signed up as Tubby Johnston." She took the name Tubby from a comic strip, *Little Lulu*. She tucked her hair under her cap and went to the tryouts with her brother.

She made the King's Dairy team and played first base. Then she told the coach she was a girl. He said she was good enough to make the team, so she could stay. More people came to the games once word got out.

**The Tubby Rule.** Little League officials made a rule in 1951 that no girls could play. Johnston said later, "It's known as the Tubby Rule because I was the reason why they put that rule in." She wrote to Little League's headquarters in 1974, after the ban ended. The officials there checked her story and wrote back that she was the first girl to play in Little League.

### Who could play Little League

Little League officials also stopped a team of Black boys from playing on for a title. The Cannon Street YMCA in Charleston, South Carolina, entered its all-star team of 14 Black boys in the city Little League tournament in 1955. The adults who ran the 61 other teams, all of them white, pulled every team out rather than play them. Accounts do not name those adults. Cannon Street won the city and state titles because no one would play them.

At the regional tournament in Rome, Georgia, officials ruled that Cannon Street could not go on. The team had won without playing, and the officials said a team that had not won its games on the field could not advance. Little League's president agreed with the ruling. The managers of the white leagues left Little League and started their own league for white teams only.

Little League officials invited the Cannon Street boys to watch the Little League World Series in Williamsport. The crowd there chanted "Let them play." In 2023 one of the players, John Rivers, looked back on what had happened to the team: "So we didn't talk about it. So it tells me how painful it was."

**Maria Pepe.** Maria Pepe, 12, pitched three games for a Little League team in Hoboken, New Jersey, in 1972. Little League officials told the Hoboken league to drop her or lose its right to be part of Little League, and the Hoboken league's officials dropped her. Robert Stirrat, a Little League vice president, said, "as far as we're concerned, the incident is closed."

Members of the National Organization for Women, a women's rights group, took Pepe's case to New Jersey's civil rights office. Sylvia Pressler, the officer hearing the case, ruled in 1973 that keeping girls out broke the state's law. She called Little League "as American as the hot dog and apple pie," and wrote, "There is no reason why that part of Americana should be withheld from girls."

Little League's officials asked a higher court to overturn the ruling, and they lost in 1974. Little League held a charter from Congress, a paper that gave it official standing. President Gerald Ford signed a law in December 1974 that changed the charter to let girls play. That year nearly 30,000 girls signed up for Little League's new softball program.

### Who could swim

Some city officials closed their public pools rather than let Black residents swim in them. Officials in Jackson, Mississippi, closed four public pools in 1963. They gave up a fifth pool, and the YMCA then ran it for white people only. Five Supreme Court justices, the judges of the nation's highest court, ruled on June 14, 1971, in *Palmer v. Thompson*, that closing the pools to everyone was lawful. Four justices disagreed.

**The Monson Motor Lodge.** Black and white protesters jumped into the pool of the Monson Motor Lodge in St. Augustine, Florida, on June 18, 1964, in a protest against keeping Black and white swimmers apart. The motel's manager, James Brock, poured muriatic acid, a strong acid used to clean pools, into the water. A photograph of him doing it ran in newspapers across the country.

Jeff Wiltse, the historian of public pools, found that when Black swimmers won equal use of city pools, white swimmers "generally abandoned them for private pools," which means most of them left. He wrote that city officials then treated public pools as less important.

### Television and the Super Bowl

The Green Bay Packers beat the Kansas City Chiefs 35 to 10 in Los Angeles on January 15, 1967. It was the first championship game between the two professional football leagues of the time. Tickets cost $6 to $12. Two television networks, CBS and NBC, both showed the game, to about 51 million viewers. A 30-second advertisement cost $42,000.

From the third game, in 1969, the official name was the Super Bowl. Lamar Hunt, who founded one of the two leagues, took the name from his children's toy, a Super Ball.

**The 1993 game.** NFL officials took the 1993 Super Bowl away from Arizona because its voters had said no to a holiday for Martin Luther King Jr. in November 1990. The league's officials moved the game to Pasadena, California. *PHOENIX* magazine says the game was to be played in Tempe, next to Phoenix, and the Pima County Public Library says Phoenix. People there had expected about $200 million from the game. Arizona hosted the Super Bowl in 1996. Chapter 37 tells the fight over the King holiday.

### Muhammad Ali

> **Who:** The heavyweight boxing champion whose title was taken from him when he refused to be drafted into the Army.
>
> **When and where:** Louisville, Rome, Houston, Atlanta and Zaire, 1942 to 2016.

**"I ain't got no quarrel with them Viet Cong."**

Cassius Clay was born in Louisville, Kentucky, in 1942. When he was 12, someone stole his bicycle. A police officer, Joe Martin, taught boxing, and he got Clay started in the sport. Clay won an Olympic gold medal in Rome in 1960. On February 25, 1964, at 22, he beat Sonny Liston for the heavyweight title. He then joined the Nation of Islam, a Black Muslim religious group, and took the name Muhammad Ali.

**Houston, 1967.** Ali went to Houston to be drafted, which means ordered by law to join the Army, on April 28, 1967, during the Vietnam War. He had already said, "I ain't got no quarrel with them Viet Cong," the fighters the US Army was fighting in Vietnam. He refused three times to step forward when his name was called.

That same day the members of the New York State Athletic Commission suspended his boxing license, and officials of the World Boxing Association took away his title. Officials of other boxing commissions did the same. In a federal court in Houston on June 20, 1967, a jury of six white men and six white women found him guilty of draft evasion, which means refusing to serve when drafted. The judge sentenced him to five years in prison and a $10,000 fine.

**Back in the ring.** He could not box for more than three years. He fought again on October 26, 1970, in Atlanta. On June 28, 1971, all eight Supreme Court justices who heard his appeal overturned his conviction. On October 30, 1974, he beat George Foreman in Zaire, in Africa, and won the title back.

Ali retired in 1981. In 1984 he said he had Parkinson's syndrome, a disease of the brain that makes the body shake and move slowly. He died on June 3, 2016.

### The 1968 Olympic protest

Tommie Smith won the 200 meters at the Olympic Games in Mexico City on October 16, 1968, in a world-record 19.83 seconds. John Carlos came third. Peter Norman of Australia came second. During the US national anthem, Smith and Carlos each raised a fist in a black glove. They stood in black socks without shoes to stand for poor people. All three men wore the badge of a protest group, the Olympic Project for Human Rights.

Smith said they were protesting "the lack of black assistant coaches," the taking of Muhammad Ali's title, and the "lack of access to good housing."

**Sent home.** Avery Brundage, the head of the International Olympic Committee, called the protest "a domestic political statement unfit for the apolitical, international forum." He meant that the protest was about politics inside the United States, and that the Olympic Games were a world meeting place that should be kept free of politics.

The US Olympic Committee's officials refused at first to suspend the two men. Brundage then threatened to ban the whole US track team. The US officials suspended Smith and Carlos and sent them out of the Olympic Village. The sports commentator Brent Musburger called them "black-skinned storm troopers." Storm troopers were the street fighters of Hitler's Nazi party. Smith, Carlos and their families got death threats.

Both men later played pro football. Smith coached track at Oberlin College and taught at Santa Monica College. Norman was left off Australia's 1972 Olympic team, although his times qualified him, and accounts differ on why. Lawmakers in Australia's parliament apologized to him in 2012, six years after he died. Smith and Carlos carried his coffin at his funeral.

### Players and owners

A team's owner could renew a player's contract year after year without his permission until 1975. The owner could also trade him to another team, and the player could not leave to sign with a team of his choice.

Curt Flood, a St. Louis Cardinals outfielder, refused to be traded to another team in December 1969. A television reporter, Howard Cosell, said to him, "You're a man who makes $90,000 a year, which isn't exactly slave wages." Flood answered, "A well-paid slave is nonetheless a slave." He sued baseball's commissioner. On June 19, 1972, five Supreme Court justices ruled against him and three sided with him.

About three years later, in 1975, an arbitrator named Peter Seitz ruled in a case brought by two pitchers, Andy Messersmith and Dave McNally. An arbitrator is a person both sides agree will settle a dispute. Seitz ruled that a team could renew a player's contract without his permission for only one season. After that the player was a free agent, free to sign with any team.

### Girls' sports after Title IX

President Richard Nixon signed Title IX into law on June 23, 1972. Under it, no school or college program that gets money from the federal government may shut a person out because of sex.

**The count.** About nine times as many girls played high-school sports in 1999-2000 as in 1971-72, according to counts by the National Federation of State High School Associations. In the 1971-72 school year about 294,000 girls played, and girls were about 7 of every 100 players. By 1999-2000 about 2.7 million girls played, and girls were about 41 of every 100.

Yale University had 13 women's varsity teams, the college's top teams, in 1979. Writers for Yale's library later stated in an online exhibit that those teams got "only a grudging fraction of the resources" given to the men's teams.

### Chris Ernst

> **Who:** The captain of Yale's women's rowing team, who led a protest that won the team a locker room.
>
> **When and where:** Yale University, New Haven, Connecticut, 1972 to 1977.
>
> **Movie:** *A Hero for Daisy* (1999), a documentary about Ernst by Mary Mazzio.

**Nineteen women wrote "Title IX" on their bodies and walked in.**

Chris Ernst grew up in Scituate, Massachusetts. In high school she beat boys at arm wrestling to win time on the gymnastics equipment.

She began rowing at Yale in her second year and was captain of the women's team by her last year. The showers at the boathouse were for the men's team only. After practice, the women waited on a bus in wet clothes while the men showered. Then they rode back to campus to wash.

**The protest.** The 19 women on the team wrote "Title IX" on their bodies in early 1976 and went into the office of Joni Barnett, Yale's director of women's sports. They took off their clothes, and Ernst read a statement that began, "These are the bodies Yale is exploiting." To exploit someone means to use them for your own gain.

A *New York Times* reporter called the university that day. Yale officials set up a trailer with running water and planned a $250,000 addition to the boathouse. By 1977 the women had a locker room.

Ernst was a backup rower for the 1976 Olympic team, the first Olympic Games with women's rowing. She became the first woman in the plumbers' union in New Haven in 1980, and she won a world rowing title in 1986.

### Billie Jean King

> **Who:** A tennis champion who started the Women's Tennis Association and beat Bobby Riggs in a match called the "Battle of the Sexes."
>
> **When and where:** Long Beach, California, and Houston, Texas, 1943 to 1973 and after.

**She saved $8 to buy her first racket.**

Billie Jean King was born in Long Beach, California, in 1943. At 11 she switched from softball to tennis after her parents suggested a more "ladylike" sport. She saved the $8 and took free lessons on the city's public courts. As a young player she was kept out of a group photograph because she wore shorts her mother had sewn instead of a tennis dress. The account does not name who left her out.

**The Battle of the Sexes.** King founded the Women's Tennis Association, a group that represents women players, in June 1973. Three months later she played Bobby Riggs in a match called the "Battle of the Sexes," because it set a man against a woman. Riggs was 55, and King was 29. She beat him 6-4, 6-3, 6-3 at the Houston Astrodome on September 20, 1973.

About 30,000 people watched in the stadium, about 50 million on television in the United States, and about 90 million more in 37 other countries. She won $100,000.

King won 39 Grand Slam titles, the four biggest tennis championships. She received the Presidential Medal of Freedom in 2009.

### Arcades and game machines at home

Some computer games were made for school. Three student teachers from Carleton College, Don Rawitsch, Bill Heinemann and Paul Dillenberger, made *The Oregon Trail* for a junior high class in Minneapolis in 1971. It was first played on December 3, 1971. A Minnesota computer group for schools put out new versions in 1975 and 1985, and Oregon Trail games have sold more than 65 million copies.

**Pong.** Nolan Bushnell and Allan Alcorn of the company Atari put a test machine of their game *Pong* in a bar called Andy Capp's Tavern in Sunnyvale, California, in August 1972. *Pong* was a simple tennis game played on a screen. The bar's owner soon called them because the machine had stopped working. Its coin box was jammed full of quarters.

Atari sold *Pong* from November 29, 1972, at 25 cents a game, and sold more than 8,000 machines by the end of 1974. Bushnell said players sat "shoulder to shoulder" and could talk, laugh and challenge each other.

Sears sold a home version of *Pong* for $98.95 at Christmas 1975. Atari's own home game machine came out in 1977 for $199. By 1992 Atari had sold about 30 million of that one model.

The company Midway began selling the arcade game *Pac-Man* in North America in October 1980. Its designer, Toru Iwatani, wanted "a nonviolent, cheerful game" that women would play. By 1981 *Pac-Man* machines had taken in more than $1 billion in quarters.

**The crash.** About 30 million game machines of all makes sat in American homes by 1982, and about 35 million households had children aged 6 to 16. Then sales fell, from about $3.2 billion in 1983 to about $100 million in 1985. Workers for Atari buried about 728,000 unsold game cartridges in a landfill at Alamogordo, New Mexico, in September 1983.

Sales rose again after Nintendo began selling its home machine in the United States in 1985. Nintendo's Game Boy, a game machine small enough to hold in the hands, came out in 1989 for $89.95.

Senators Joe Lieberman and Herb Kohl led public hearings, meetings where senators question witnesses, on violent video games such as *Mortal Kombat* in December 1993 and March 1994. Leaders of the game companies then set up the Entertainment Software Rating Board. From September 13, 1994, its staff put age ratings on games.

### The Miracle on Ice

The US Olympic hockey team beat the Soviet Union 4 to 3 at Lake Placid, New York, on February 22, 1980. The American players were college players with an average age of 21, coached by Herb Brooks. Two days later they beat Finland and won the gold medal.

### The Iroquois Nationals

Haudenosaunee (Iroquois) people formed their own national lacrosse team in 1983, and the Grand Council of the Haudenosaunee approved it. Officials of the International Lacrosse Federation turned the team down for 1986 and accepted it as a member nation in 1988. In 1990 the team played in the world championship in Perth, Australia, and finished fifth of five.

### How did a child's afternoon change?

Children spent less of it in free play and more of it in school, lessons and organized sports.

**Walking or riding.** Nearly half of children in kindergarten through eighth grade usually walked or biked to school in 1969, and about 12 of every 100 were driven, according to national travel surveys studied by Noreen McDonald and other researchers. A 1995 survey asked a slightly different question: how children got to school on the survey day. That day nearly half went by car, and about 14 of every 100 walked or biked.

**Time diaries.** The researchers Sandra Hofferth and John Sandberg compared diaries of how children spent their time in 1981 and in 1997. Children spent more time in school, day care, sports and art lessons. They spent less time in free play, housework and watching television. The drop in free play showed up among children whose mothers stayed home as well as those whose mothers had jobs.

More mothers did work for pay. In 1975, 47 of every 100 mothers with children under 18 were working or looking for work. By 2000 it was 73 of every 100, according to the US Bureau of Labor Statistics.

**On their own.** About 18 of every 100 children aged 5 to 14, some 6.9 million, regularly looked after themselves for part of the week in the fall of 1995. On average they did so for about six hours a week. More than twice as many children that age, about 15 million, took part in sports, lessons or clubs, according to the US Census Bureau.

**Private teams.** Organized sport also became more private. In a survey of adults published in 2025, about 4 of every 100 who were born in the 1950s said they had played on a private club or travel team as children. For those born in the 1990s it was 13 of every 100. The researchers, Chris Knoester and Chris Bjork, found that children whose parents had more schooling were more likely to play on these teams.

**If you remember one thing:** Girls won their way into Little League and school sports through a court case and a new law, while children spent less time in free play and more in lessons and organized sports.

**One question this era leaves open:** Senators held hearings on violent video games in 1993 and 1994. Do games and screens harm children? The next era gives what researchers later found about attention and mood, and where they disagree.

**Next:** After 2000 children's free time moved onto phones and into games played online with strangers.

## 2000 to Today

**Era 10 of 10 · 2000 to Today · about 22 minutes**

Much of children's free time moved onto phones and into games played online, often with strangers, after 2000. Researchers at the Pew Research Center, which surveys American teenagers, found that 73 of every 100 teenagers aged 13 to 17 had or could use a smartphone in 2014-15, and 95 of every 100 by 2022. Fewer children walked to school or played outdoors. The average sports family spent $883 on one child's main sport in 2022. Researchers disagree about whether screens harm children's attention and mood.

Doctors found a brain disease in football players who had died. A team doctor who had sexually abused more than 500 girls and women pleaded guilty, and judges gave him prison sentences so long that he will die in prison. College athletes won the right to be paid, betting on games became legal in most states, and the men's soccer World Cup was played in the United States, Canada and Mexico in 2026.

### Phones and social media

Pew researchers ask American teenagers aged 13 to 17 how they use phones and the internet. In 2014-15, 24 of every 100 said they were online "almost constantly." In 2022 it was 46 of every 100, and in 2025 it was 40. In Pew's 2025 survey, about 90 of every 100 teenagers used YouTube, and about 60 used TikTok. That year 64 of every 100 teenagers had used an AI chatbot, a computer program that writes answers in plain language.

**Hours a day.** Common Sense Media, a group that studies children and media, surveyed children in 2021. Children aged 8 to 12 spent an average of 5 hours 33 minutes a day on screens for fun, not counting schoolwork. Teenagers aged 13 to 18 spent 8 hours 39 minutes. In 2019 the figures had been 4 hours 44 minutes and 7 hours 22 minutes.

When a child used two screens at once, the researchers counted the time on both, so two hours of screen time can fit into one hour of the day. The survey's authors wrote that they could not tell how much of the rise came from the COVID-19 pandemic.

**The warning.** The US Surgeon General, Vivek Murthy, the country's top public health doctor, issued an advisory, a public warning, about social media on May 23, 2023. The advisory states that "we do not yet have enough evidence to determine if social media is sufficiently safe for children and adolescents."

It cites a study of 6,595 American children aged 12 to 15. Those who spent more than 3 hours a day on social media had double the risk of symptoms of depression and anxiety. In the advisory, Murthy asked lawmakers to set safety rules and limits for children's use.

State lawmakers began to keep phones out of classrooms. Florida's lawmakers passed a law banning students' phone use during class time in 2023.

By January 2026, lawmakers in 26 states had banned phones for the whole school day, from the first bell to the last, according to a count by the group Ballotpedia. By July 2026, lawmakers in at least 39 states and Washington, DC, had passed rules requiring schools to ban or limit phones, according to a tally by *Education Week*. The two counts differ because they count different kinds of laws.

### Games played online, and with strangers

*Minecraft* is a game of building and digging in a world of blocks, played alone or with others. It came out in 2011. By 2023 it had sold more than 300 million copies, more than any other video game.

*Roblox* opened in 2006. Its players build games and play each other's games. According to the company, half of all American children under 16 play it each month. *Fortnite* came out in 2017. In its best-known version, up to 100 players land on an island and fight until one player or team is left.

*Fortnite* is free to play. The companies behind *Fortnite* and *Roblox* sell game money, called V-Bucks in *Fortnite* and Robux in *Roblox*, which players buy with real money and spend on costumes and other items inside the game.

**The Fortnite case.** Officials of the Federal Trade Commission, the government agency that enforces laws protecting buyers, accused Epic Games, the maker of *Fortnite*, of breaking the law on December 19, 2022. They said the company had collected information on children under 13 without their parents' permission. They said the game's settings turned on live voice and text chat for children, and that the company matched "children and teens with strangers to play Fortnite together."

Children had been "bullied, threatened, harassed," some of them sexually, and "exposed to dangerous and psychologically traumatizing issues such as suicide," the officials said. Epic employees had urged the company to change those settings as early as 2017. In a settlement, an agreement that ended the case, Epic Games agreed to pay $520 million.

**Roblox.** People who brought four lawsuits in June 2025 accused the company that runs *Roblox* of letting adults use the game for the sexual exploitation of children, which means using children for sex acts or sexual pictures. Every *Roblox* player had to prove their age, with an ID or a video scan of the face, before chatting from January 2026. Chat was also limited to players of similar ages.

Esports are video game contests played for prize money. The first *Fortnite* World Cup, held from July 26 to 28, 2019, in New York City, paid $30 million in prizes. About 40 million players tried to qualify.

### Kyle "Bugha" Giersdorf

> **Who:** A 16-year-old who won the first Fortnite World Cup and $3 million.
>
> **When and where:** Arthur Ashe Stadium, New York City, July 28, 2019.

**He scored 59 points. The second-place player scored 33.**

Kyle Giersdorf was born in 2002. His father, who also played video games, got him started on *Fortnite*. Kyle played under the name "Bugha." He joined an esports team called Sentinels on March 25, 2019. That summer he qualified for the first *Fortnite* World Cup, out of about 40 million players who tried.

**The final.** At 16, he played six games against 99 other finalists in Arthur Ashe Stadium in New York City on July 28, 2019. He scored 59 points, and the second-place player scored 33. He won $3 million, more than any other *Fortnite* player has won in total.

Hours after he won, someone broke into his Twitter account and his account on Twitch, a website where players show their games live to viewers. Later he became a streamer on Twitch, playing his games live for viewers there.

### What is measured

Researchers who surveyed children after 2000 found that they walked less and had less free time than children in earlier years. Team sports cost families hundreds of dollars a year, children from richer homes played more, and more children had obesity.

Fewer children walk or bike to school. Nearly half did in 1969. By 2009 it was about 13 of every 100, according to the national travel surveys studied by Noreen McDonald and other researchers. In 2017 about 11 of every 100 students aged 5 to 17 usually walked or biked, according to a later government travel survey.

**Less free time.** Sandra Hofferth's later time diaries of children aged 6 to 12 showed their free time falling from about 57 hours a week in 1981 to about 48 hours in 2003, the year her diaries end.

The share who played a sport on the diary days fell from 76 to 60 of every 100 between 1997 and 2003. The share who spent time in outdoor activities fell from 16 to 10 of every 100.

The National Survey of Children's Health is a government survey of parents. It found in 2023 that 55 of every 100 children aged 6 to 17 played on a sports team or took sports lessons. Children from richer homes played more.

The gap was already plain in 2012. About 35 of every 100 children in homes earning under $25,000 a year played a sport regularly, against about 49 of every 100 in homes earning $100,000 or more. By 2024 the difference between those two groups had grown to about 20 of every 100 children, according to the Sports and Fitness Industry Association.

**What it costs.** The average parent spent $883 in a year on one child's main sport, in a 2022 survey by the Aspen Institute and Utah State University. Travel to games and tournaments cost more than any other part. The richest families spent about four times as much as the poorest.

Fifteen of the 50 states had rules in 2012 that recommended or required a daily recess, according to a 2013 report by the research group Bridging the Gap.

Doctors measure obesity by comparing a child's weight with the child's height. From 1971 to 1974, about 5 of every 100 children aged 2 to 19 had obesity. From 2017 to March 2020 it was about 20 of every 100, nearly four times as many, or about 14.7 million children, according to the Centers for Disease Control and Prevention. In the poorest homes it was about 26 of every 100, and in the richest about 12.

### What researchers disagree about

ADHD stands for attention-deficit/hyperactivity disorder. Doctors diagnose it when a child has trouble paying attention, or is overactive and acts without thinking, badly enough to cause problems in more than one place, such as at home and at school.

**The count.** In national surveys of parents, 9.5 of every 100 children aged 4 to 17 had been diagnosed with ADHD in 2007, and 11 of every 100 in 2011. The researchers who reported those counts wrote that the rise "could also reflect better detection" and more awareness, not only more children with ADHD.

The American Psychiatric Association changed its rules for diagnosing ADHD in 2013. Its manual of mental disorders now allowed a diagnosis when symptoms began by age 12 instead of age 7. That change came after the 2011 count, so it could explain only a rise that came later.

In 2022, 11.4 of every 100 children aged 3 to 17 had been diagnosed, about 7.1 million children, according to a 2024 study by M. L. Danielson and other researchers. They wrote that the survey changed its methods in 2022, which makes it harder to compare 2022 with earlier years.

**A study of screens and attention.** Researchers have studied whether screens are linked to attention problems. A team at the University of Southern California, led by Chaelin Ra and Adam Leventhal, followed 2,587 high-school students in Los Angeles County for two years, in a study printed in 2018. None had serious ADHD symptoms at the start. Students who used more kinds of digital media many times a day later reported more ADHD symptoms.

Among students who used no kind of media that often, 4.6 of every 100 reported the symptoms. Among students who used seven kinds, 9.5 of every 100 did. The researchers called the link "modest." They wrote that more research was needed "to determine whether this association is causal," which means whether the media use caused the symptoms. The students rated their own symptoms, and doctors did not diagnose them.

Other researchers studied something different: how well teenagers felt. The Oxford researchers Orben and Przybylski studied surveys of 355,358 teenagers in the United States and Britain in 2019. They found that technology use explained "at most 0.4%" of the differences in how well teenagers felt. That is less than half of one percent. They called the link "too small to warrant policy change," meaning too small to be a reason for new laws or rules.

**By 2022:** Ninety-five of every 100 teenagers had or could use a smartphone, 46 of every 100 said they were online "almost constantly," and researchers still disagreed about what screens did to children.

**The argument over a book.** The psychologist Jonathan Haidt of New York University published a book called *The Anxious Generation* in 2024. He wrote that phone and social media companies had "rewired childhood" by taking the place of play and time with friends.

The psychologist Candice Odgers of the University of California, Irvine, answered in the science journal *Nature* on March 29, 2024. She wrote that the book's "repeated suggestion that digital technologies are rewiring our children's brains and causing an epidemic of mental illness is not supported by science." She wrote that studies had found "a mix of no, small and mixed associations." She agreed that the social media companies needed to make large changes.

### Football and the brain

Mike Webster was a center for the Pittsburgh Steelers who played 17 seasons in the NFL, from 1974 to 1990, and won four Super Bowls. After he retired he lost his memory, suffered from depression and pain, and at times lived in his pickup truck or in train stations. He died of a heart attack on September 24, 2002, at 50.

**What Omalu found.** Bennet Omalu, a doctor in Pittsburgh who examines bodies to find out why people died, studied Webster's brain. He found clumps of protein unlike those of Alzheimer's disease. Omalu and other doctors described the disease in a medical journal in July 2005. It is called chronic traumatic encephalopathy, or CTE.

Doctors link CTE to repeated blows to the head. Its signs can include problems with behavior, mood and thinking. It often gets worse over time, and it can lead to dementia, the loss of the ability to think and remember. Doctors can find it only by examining the brain after death.

**What the league said.** Paul Tagliabue, the league's commissioner, had set up the NFL's own brain injury committee in 1994. He named Elliot Pellman to lead it, a doctor who treated joints and muscles, not the brain.

The committee's papers stated from 2003 on that concussions, brain injuries from a hard blow to the head, caused no lasting harm in NFL players. In May 2006 committee members wrote to the journal asking it to take back Omalu's paper. Years later Jeff Miller, a league official, told members of Congress that "there is a link between football-related head trauma and chronic traumatic encephalopathy."

More than 4,500 former players sued the NFL, saying the league had hidden the dangers. Judge Anita Brody approved a settlement in April 2015 to pay retired players with brain illness for 65 years, expected to cost more than $1 billion. Families of players who died before 2006 were not covered, so Webster's family got nothing from it. The NFL's own Retirement Board had already paid his family $1.8 million in 2005, after finding that football caused his brain injuries.

**The scoring rule.** Until 2021 the dementia tests used to judge claims were scored as if Black players started with lower thinking skills than other players. That made it harder for Black players to prove dementia and be paid. The news accounts of the lawsuit do not name who set that scoring rule. After a lawsuit, NFL officials said in June 2021 that they would stop.

Children were hurt in football too. About 23,000 football brain injuries a year that did not kill the player sent people to emergency rooms, and 90 of every 100 of those hurt were aged 5 to 18. Pop Warner, a youth football program, had 9.5 percent fewer players in 2012 than in 2010, according to Robert Boland of New York University.

Researchers at Boston University had found CTE in the brains of 345 of the 376 former NFL players they studied by 2023. They warned that families who suspected the disease were the ones who gave the brains. So the figure does not mean that 92 of every 100 NFL players have CTE.

### The team doctor who abused gymnasts

Larry Nassar worked with the USA Gymnastics national team from 1986. From 1996 to 2014 he was its national medical coordinator, the doctor in charge of the gymnasts' care. From 1997 to 2016 he was also a doctor for athletes at Michigan State University.

**What he did.** During appointments he said were treatment for pain, he put his ungloved finger into girls' vaginas. Sometimes a parent was in the room and could not see what he was doing. More than 500 girls and women were abused. Some were as young as 6.

**Who was told.** Many adults were told and did not stop him. Athletes said they told Michigan State employees about him as early as 1997. Court papers say the Michigan State gymnastics coach, Kathie Klages, was told in 1997, and they accuse her of pressuring gymnasts to stay quiet. Michigan State officials looked into a complaint in 2014 and let him keep treating patients.

A coach, Sarah Jantzi, reported him to USA Gymnastics on June 17, 2015. Its president, Steve Penny, told agents of the FBI, the federal police, in Indianapolis. The agents did not open a formal investigation or tell officials in Michigan. Reporters at *USA Today* wrote that for more than a year Nassar went on "treating, and raping, gymnasts" in Michigan. Rape means forcing a person into a sex act.

Michael Horowitz, the Justice Department's inspector general, the official who checks for wrongdoing inside the department, reported in July 2021 that the FBI agent W. Jay Abbott had failed to act and later lied about it. At least 70 more girls and women were abused after the FBI was told. The victims put the number at 120.

**The sentences.** Reporters at the *Indianapolis Star* published the story in September 2016. Nassar pleaded guilty to federal crimes of having sexual pictures of children, and to ten counts of first-degree criminal sexual conduct with girls in two Michigan counties. Under Michigan law, first-degree criminal sexual conduct means sexual penetration of a person in certain cases, such as when the victim is under 13, and it can be punished with life in prison.

Judges sentenced him to 60 years in federal prison, and to 40 to 175 years and 40 to 125 years in Michigan, so he will die in prison. Before he was sentenced, more than 200 women and girls spoke about what he did to them, over nine days in court.

**What happened to the others.** The heads of USA Gymnastics, Michigan State and the US Olympic Committee resigned. Nassar's dean at Michigan State, William Strampel, was convicted of neglect of duty and spent a year in jail. Klages was convicted in 2020 of lying to police, and that conviction was overturned in 2021.

John Geddert, an Olympic coach who had employed Nassar at his gym, was charged in 2021 with human trafficking, forced labor, sexual assault and other crimes. Human trafficking means using force, tricks or threats to make people work or perform sex acts. He killed himself shortly after the charges were announced.

Michigan State paid $500 million to 332 victims in 2018. USA Gymnastics and the US Olympic and Paralympic Committee together agreed to pay $380 million in 2021. Three years later the Justice Department paid $138.7 million to victims who sued over the FBI's failure.

The Olympic gymnasts Simone Biles, McKayla Maroney, Maggie Nichols and Aly Raisman told senators on September 15, 2021, how FBI agents had handled their reports. Raisman said it "was like serving innocent children up to a pedophile on a silver platter." A pedophile is an adult who is sexually drawn to children. The FBI's director, Christopher Wray, said he was "deeply and profoundly sorry."

### Rachael Denhollander

> **Who:** A former gymnast who was the first woman to accuse Larry Nassar in public.
>
> **When and where:** Kalamazoo and Lansing, Michigan, 2000 to 2018.
>
> **Movie:** *Athlete A* (2020), a Netflix documentary by Bonni Cohen and Jon Shenk about the *Indianapolis Star* reporters and the scandal.

**"How much is a little girl worth?" she asked the judge.**

Rachael Denhollander was a club gymnast from Kalamazoo, Michigan. She was 15 in 2000 when she saw Larry Nassar for pain in her lower back. He sexually abused her on five visits.

At least seven other girls and women had told someone about Nassar over twenty years before she spoke. By 2016 she was a lawyer. She reported Nassar to the Michigan State University police and filed a complaint with the university in August 2016. The *Indianapolis Star* printed her accusation on September 20, 2016. Michigan State officials fired Nassar that day. By January 2018 more than 265 women and girls had been identified as his victims, and the count later passed 500.

**In court.** She spoke last at both of his sentencing hearings, in January and February 2018. She asked the judge, "How much is a little girl worth?" She answered that "everything is what these survivors are worth." Judge Rosemarie Aquilina called her "the bravest person I have ever had in my courtroom."

*Time* magazine named her one of its 100 most influential people of 2018. In 2019 she published a book about the case, *What Is a Girl Worth?*

### College athletes paid

NCAA rules let college athletes receive only scholarships and school costs until 2021. California's governor, Gavin Newsom, signed the first state law letting college athletes be paid for their name, image and likeness, meaning for ads and appearances that use who they are, in September 2019.

All nine Supreme Court justices ruled against NCAA limits on education benefits on June 21, 2021, in *NCAA v. Alston*. Justice Brett Kavanaugh wrote that antitrust law, which forbids businesses from agreeing to hold down pay, "should not be a cover for exploitation of the student athletes." From July 1, 2021, NCAA officials let athletes be paid for their name, image and likeness.

**The settlement.** Grant House, a swimmer at Arizona State, and Sedona Prince, a basketball player, sued the NCAA in 2020. Judge Claudia Wilken approved a settlement on June 6, 2025. Athletes who played from 2016 to 2024 will share about $2.8 billion over ten years.

Each college may pay its athletes directly from the 2025-26 school year, up to about $20.5 million that year, a limit that rises 4 percent a year. Eight women athletes asked a higher court to change the settlement. They argued that most of the money would go to men who played football and basketball.

**By 2025:** Doctors had tied CTE to football, Larry Nassar was serving prison sentences so long that he will die in prison, and a judge had approved a settlement under which colleges may pay their athletes directly.

### Betting on games

A federal law of 1992 barred states from allowing betting on sports, except in Nevada and three other states. On May 14, 2018, in *Murphy v. NCAA*, a case New Jersey brought, the Supreme Court justices struck the law down. By September 2023, 38 states and Washington, DC, allowed betting on sports. Americans bet $121 billion with licensed sports betting companies in 2023, according to the American Gaming Association, the casino industry's trade group.

**Jontay Porter.** Adam Silver, the NBA's commissioner, banned Jontay Porter, a Toronto Raptors player, for life on April 17, 2024. League investigators found that Porter told a bettor about his own health before a game in March 2024. He then left that game after three minutes, saying he felt ill. A person he knew had bet $80,000 that Porter would play poorly. Porter had also placed at least 13 bets on NBA games.

### Transgender athletes

A transgender girl is a girl who was counted as a boy at birth. Idaho's governor, Brad Little, signed the first state law keeping transgender girls and women off girls' and women's teams in March 2020. By June 2026, 27 states had passed such laws, according to the Supreme Court.

Lia Thomas, a transgender swimmer at the University of Pennsylvania, won a women's college title in 2022. On February 5, 2025, President Donald Trump signed an order titled "Keeping Men Out of Women's Sports." The next day NCAA officials limited women's college events to athletes counted as female at birth. In July 2025 officials of the University of Pennsylvania agreed with the federal government to change Thomas's records.

**The Supreme Court.** Six Supreme Court justices ruled on June 30, 2026, in *West Virginia v. B.P.J.* and *Little v. Hecox*, that Title IX allows schools to keep separate teams "defined by biological sex." Three justices disagreed in part. B.P.J., who is named in court only by her initials, had wanted to run on the girls' cross-country and track teams at her school in West Virginia. She was 11 when she first asked to play, according to Justice Sotomayor's opinion.

### Protest and equal pay

Colin Kaepernick, the quarterback for the San Francisco 49ers, knelt during the national anthem before games in 2016. He was protesting police brutality, which means violence by police officers, and unfair treatment of Black Americans. He chose to end his contract with the 49ers in March 2017, and after that no team signed him.

Kaepernick accused the NFL's owners in October 2017 of secretly agreeing among themselves to keep him out. He settled with the league in February 2019, and the terms were kept secret. The NFL's commissioner, Roger Goodell, apologized in June 2020 for not listening to Black players' concerns.

**Equal pay.** Five players on the US women's soccer team, among them Hope Solo, Carli Lloyd and Megan Rapinoe, filed a complaint in April 2016 that they were paid less than the men's team. The women won the World Cup in 2019. US Soccer officials settled for $24 million in February 2022. In May 2022 they signed contracts that pay the women and the men equally.

### The Haudenosaunee Nationals

The Haudenosaunee national lacrosse team, formed in 1983, is the same team as the Iroquois Nationals. The Haudenosaunee have issued their own passports since 1927. British officials refused to accept those passports for the world lacrosse championship in England in 2010. They told the 23 players to travel on US or Canadian passports. The players refused, and they did not play.

The team won third place at the world championships of 2014, 2018 and 2023. Olympic officials added lacrosse to the 2028 Los Angeles Games in October 2023, and they said that only countries with a national Olympic committee could enter. President Joe Biden and Canada's prime minister, Justin Trudeau, asked them on January 17, 2025, to let the Haudenosaunee play under their own flag. No decision on that request is on record as of September 2026.

### The 2026 World Cup

FIFA, the group that runs world soccer, held the men's World Cup in the United States, Canada and Mexico from June 11 to July 19, 2026. It was the first with 48 teams. Of the 104 games, 78 were played in 11 American cities. About 6.8 million people went to the games, more than at any World Cup before.

Spain beat Argentina 1 to 0 after extra time in the final at MetLife Stadium in New Jersey. The US team lost to Belgium 4 to 1 in the round of 16.

Tickets for the final started at $6,730. For the first time, FIFA officials raised ticket prices as more people wanted them.

**The three questions, answered**

- Who invented baseball? No one person did. Clubs wrote the rules, and the Knickerbocker club of New York adopted twenty of them in 1845. The story that Abner Doubleday invented it in 1839 rests on one letter from a man who was 5 years old that year.
- Who was kept out of American games, and how did they get in? The people who ran the games kept out laborers, Black players, girls and Black swimmers, and left enslaved riders' names off the race cards. Some got in through courts and a new law, like Maria Pepe and the girls of Title IX. Jackie Robinson got in when Branch Rickey signed him, and Kathryn Johnston played anyway, under a boy's name.
- How has children's free time changed? In the 1830s Lucy Larcom made doll furniture from burrs while the grown-ups left the children alone. Since then more of children's time has gone to lessons and organized sports, and by 2022, 95 of every 100 teenagers had or could use a smartphone.

**What changed:** Play moved from fields the players ran themselves to leagues, arenas and screens run by adults and companies, and the fight over who could play moved from a county court in Virginia to the Supreme Court.

**Five dates to keep**

- September 10, 1674: a Virginia court calls racing "a sport only for Gentlemen."
- September 23, 1845: the Knickerbocker club adopts twenty rules for baseball.
- April 15, 1947: Jackie Robinson plays his first game for Brooklyn.
- June 23, 1972: President Nixon signs Title IX.
- July 28, 2019: Kyle Giersdorf, 16, wins the first *Fortnite* World Cup.

**Not known:** how old the Native ball games played with sticks are, because no object or written record dates one before 1500.

**Where to go:** The National Baseball Hall of Fame in Cooperstown, New York, holds Josh Gibson's plaque, which says he hit "almost 800" home runs.

**Next:** Chapter 37, Holidays. It asks how each day on the American calendar got there, and who had the power to name a day.
