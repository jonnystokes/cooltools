**Part 7: Health and Safety**

# Chapter 26: Health, Disease, and Medicine

**Chapter 26 of 37 · Health, Disease, and Medicine · 10 eras · about 115 minutes**

**For most of American history nobody knew what caused disease, and after doctors learned how to stop it, the people with the least power were often the last to be protected and the first to be tested on.**

Cotton Mather, a Boston minister, wrote to scientists in London in 1716 about a scar on the arm of Onesimus, an African man Mather enslaved. Onesimus said it came from an operation that gave him a small case of smallpox, a disease of fever and blisters that often killed. The small case, he said, would keep him from ever catching it again. When Boston doctors tried the method in 1721, about 2 in 100 of the people they treated died, against 14 or 15 in 100 of those who caught smallpox the ordinary way.

This chapter follows sickness and healing through ten eras, from what ancient bones show to COVID-19. In the first eras, look for the new diseases that came after 1492 and emptied whole Native towns. Then for a long stretch doctors guessed at what caused disease and bled and purged their patients, until scientists showed in the late 1800s and in 1900 that germs and mosquitoes spread it. Through all of it, notice who paid for the new knowledge: enslaved women operated on with nothing to stop the pain, Black men in Alabama kept from treatment for 40 years, and children fed a virus on purpose.

**Three questions this chapter answers**

- Why did new diseases kill so many Native people after 1492?
- How did Americans learn to stop smallpox, yellow fever and polio?
- Who was used in medical experiments without agreeing, and what changed because of it?

**Five minutes?** Read "The Tuskegee study, 1932 to 1972" in 1900 to 1950, then "The Tuskegee study ends, 1972 to 1997" in 1950 to 2000.

**Can skip:** "Midwives and surgeons in New Amsterdam", "Medical care for sailors, 1798", "New operations and new pictures of the body, 1954 to 1963". The chapter still makes sense without them.

## Before 1500

**Era 1 of 10 · Before 1500 · about 4 minutes**

Almost everything known about sickness in this land before 1500 comes from bones and teeth, because nobody here wrote about illness then. They show that people had diseases, but not the ones that arrived after 1492 and killed great numbers of them. Smallpox, measles, influenza, yellow fever and cholera had never reached the Americas. Neither had mumps, chickenpox, malaria, diphtheria, typhus, leprosy or bubonic plague. Every one of these twelve diseases is an infection caused by a germ, a living thing too small to see.

### What do the bones show?

Some diseases leave marks on bone, so archaeologists, scientists who learn about the past from what people left behind, can find them in skeletons hundreds of years old. Two researchers, Debra Martin and Alan Goodman, wrote in 2002 that Native people before 1492 "were most definitely not living in a pristine, disease-free environment," pristine meaning untouched and pure.

Tuberculosis was here. It is caused by bacteria, one kind of germ, and it most often infects the lungs, though it can spread to the bones, including the spine. Skeletons with its damage appear after about the year 900. Most of them come from inland places in the middle of the continent and in the Southwest.

Bones also show diseases in the same family as syphilis, a disease that is passed during sex. Two of them, yaws and bejel, spread mainly by touching skin and mouths, not by sex. Bejel is also called non-venereal syphilis, which means syphilis that is not passed by sex.

A team of scientists studied the DNA of these bacteria, taken from five people buried in the Americas long ago. DNA is the set of chemical instructions inside every living cell. In 2025 the team reported that the bacteria behind syphilis and its whole family most likely began in the Americas. Their results fit that idea for every sample of these bacteria that scientists have studied, ancient or modern.

Martin and Goodman list other illnesses that were present: rabies, whooping cough, polio, hepatitis (an infection of the liver), herpes (a virus that causes sores), tularemia (a fever people catch from animals), and stomach infections from tiny living things called giardia and amoebas. They add that almost all of these were probably rare in any one group of people.

**Farming and weak blood.** People who took up farming became sicker in some ways. At Dickson Mounds in Illinois, people moved over many years from hunting and gathering to farming. Researchers studied the skeletons of people buried there, among them farmers who lived in the 1100s. Those farmers came to depend more and more on maize, which is corn, and the body cannot get much iron from maize.

Among the Dickson Mounds people, signs of anemia, having too few red blood cells, rose sharply. Anemia leaves a person weak and tired. In a skull it shows as spongy patches full of tiny holes on the top of the head and in the eye sockets. Those patches form where the marrow, the soft center of the bone, swelled to make more blood. Bone infections among the same people became nearly four times as severe, a team of researchers found in 1977.

### Why the crowd diseases were missing

The diseases that later struck this land in epidemics can keep spreading only where great crowds of people live. An epidemic is a disease that spreads to many people in one place at the same time.

A person sick with measles can pass it on for less than two weeks. Then the sick person either dies or becomes immune, which means the body can fight off that disease and will not catch it again. So measles keeps spreading only where new children who have never had it are always being born.

One scientist worked out in 1957 how big a population must be for measles to stay in a place for good. His answer was 200,000 to 300,000 people, with about 7,000 of them still able to catch it. Another put the number at 500,000 in 1975.

In small towns spread far apart, a disease like that infects everyone who can catch it. Then it dies out, because nobody is left to infect. The diseases that last in small towns are slow ones, like yaws and pinta, another skin disease in the syphilis family, the scholar Linda Newson explained in 1993.

When the crowd diseases arrived after 1492, nobody here had been exposed to them and nobody was immune. The historian Alfred Crosby gave what followed a name in 1976: "virgin soil epidemics." In a virgin soil epidemic, everyone in a town can be infected at the same time.

Newson also reported research on genes, the instructions inside every cell that pass from parents to children. It suggested that among Native Americans, the body's defenses against germs varied less from person to person, which may have made whole towns easier to infect. Newson called that a partial explanation.

**Not known:** how many people lived north of Mexico in 1492. Scholars' estimates run from about 1 million, made in 1949, to about 18 million, made in 1983. Others fall between, such as about 1.85 million (made in 1976) and about 3.8 million (made in 1992). How many people died after 1492 depends on which starting number is right.

## The 1500s

**Era 2 of 10 · The 1500s · about 6 minutes**

Three Europeans saw Native people in this land begin dying of diseases they had never had before, and each wrote down what he saw. None of the three could name the disease. One was a Spanish man stranded on the Texas coast in 1528. Another was a Portuguese man in Hernando de Soto's army in 1540. The third was an English scientist on the Carolina coast in 1585 and 1586, and only his account points to who carried the disease.

### The Texas coast, 1528 and 1529

About 80 Spanish men came ashore in two boats on or near Galveston Island, on the Texas coast, in November 1528. They were survivors of a Spanish expedition, a group sent out to explore and conquer, led by a commander named Narváez. One of them, Cabeza de Vaca, later wrote an account of what happened. He wrote that the people of the island spoke two languages, and he called them the Capoque and the Han.

The islanders watched most of the Spaniards die. Only 15 of the 80 stayed alive. Five Spaniards camped on the coast grew so desperate that they ate the bodies of their own dead as each one died. Their names were Sierra, Diego López, Corral, Palacios and Gonçalo Ruiz. Nobody ate the body of the last one to die. Cabeza de Vaca wrote that the islanders were in an uproar when they learned of it.

Then a disease of the bowels, the long tube in the belly that food passes through after the stomach, killed half of the island's people, Cabeza de Vaca wrote. He did not name the disease. The islanders believed the Spaniards had caused the deaths, and they planned to kill the survivors. The Native man who had charge of Cabeza de Vaca talked them out of it. He told them that if the Spaniards had such power, they would have saved their own men, whom the islanders had watched die.

**Healing for food.** The islanders then told the Spaniards to heal the sick, and they gave them no food until they did. Cabeza de Vaca described how the island's own healers worked. A healer made small cuts in the skin over the place that hurt and sucked at the cuts. Healers also burned the skin at the painful spot on purpose, a treatment called cautery, and then blew on it.

Cabeza de Vaca tried the burning on himself and wrote that it helped him. The Spaniards blessed the sick, breathed on them, and said two Christian prayers, the Lord's Prayer and the Hail Mary.

Years later, on a long walk west, people brought Cabeza de Vaca a man with an arrowhead lodged in his chest above the heart. The year and the place are not certain, because accounts of the route differ. Cabeza de Vaca cut open the man's chest with his knife and pulled the arrowhead out. He closed the cut with two stitches, using a deer bone as a needle, and stopped the bleeding with hair from an animal skin. He wrote that the next day he cut the stitches and the man was well.

### Empty towns at Cofitachequi, 1540

The army of the Spanish commander Hernando de Soto reached Cofitachequi in the spring of 1540. It was a town on a river in what is now South Carolina or Georgia, and accounts place it in different spots.

A Portuguese member of the army, known only as the Gentleman of Elvas, wrote that there were large empty towns nearby, grown over with grass. People at Cofitachequi told the Spaniards that a disease had struck the land two years before. The people of those towns had moved away to other towns. The Gentleman of Elvas did not name the disease, and he did not say how many people died.

That disease arrived before de Soto's army did. No record shows where it came from. Accounts differ about whether de Soto's own army carried new diseases inland. The records do show that de Soto's men killed and enslaved Native people and took their food.

### Roanoke, 1585 and 1586

English colonists sent by Sir Walter Raleigh lived on Roanoke Island, in what is now North Carolina, in 1585 and 1586. The island lay in the land of the Carolina Algonquian peoples. The colonists visited Algonquian towns, and within a few days after they left a town, people there began to die quickly.

The scientist Thomas Harriot, who was with the colonists, wrote down the deaths. In some towns about 20 people died, in some 40, in some 60, and in one town 120. Harriot wrote that, as far as he could learn, the deaths happened only in towns the English had visited. The oldest people told him nothing like it had ever happened before. During the same months, he wrote, no English colonist died or became seriously sick.

Harriot did not name the disease. Peter Mires, writing in 1994 in the journal *Historical Archaeology*, compared Harriot's report with John Smith's later accounts. Smith had heard about an epidemic among the Accomac, a people the Roanoke colonists visited in the winter of 1585 to 1586. Mires concluded that the English colonists carried the disease, and that it was probably influenza. He called influenza probable, not certain.

### Thomas Harriot

> **Who:** An English mathematician and scientist who wrote down, town by town, an epidemic among the Carolina Algonquians. His name is also spelled Hariot.
>
> **When and where:** Roanoke Island and the Carolina Algonquian towns, 1585 and 1586. His report was printed in London in 1588.

**The Algonquians said invisible bullets were killing them.**

Thomas Harriot recorded what the Carolina Algonquians believed was killing them in 1585 and 1586. Some believed the English God was killing people for the English. Others believed that more English people were still to come, to kill them and take their places. These coming English were already in the air, invisible and without bodies, and they were shooting "invisible bullets" into people at the English colonists' request.

Algonquian healers sucked what they called "strings of blood" out of the sick. They said these were the strings tied to the invisible bullets.

Harriot had taught how to find the way across the open ocean at Sir Walter Raleigh's house in London. He sailed with the colony that reached Roanoke Island on June 26, 1585, and there he and the artist John White mapped the area.

Wingina was the wiroans, or chief, of the people the English lived among. Twice he was so sick that he nearly died, and he sent for the English to pray for him. Wingina and others also asked the English to pray that their enemies would die of the same disease. Harriot wrote that he told them such prayers were ungodly. When their enemies did die, they came to thank the English anyway.

Harriot explained the deaths as "the special work of God" for the English. He also described how the Algonquians used a plant they called uppowoc, which is tobacco, as a medicine. They breathed in its smoke through clay pipes, and Harriot believed it kept them healthy.

## The 1600s

**Era 3 of 10 · The 1600s · about 10 minutes**

Epidemics emptied Native towns along the Atlantic coast in the 1600s, sometimes years before colonists settled beside them. English colonists also died in large numbers in their own first years, from disease and hunger. The people who treated the sick in the colonies included a weaver with no known medical training and a minister.

In New Amsterdam, officials of a Dutch trading company paid the town's midwives. At the end of the century yellow fever reached Boston, after the virus that causes it and the mosquito that carries it had crossed the Atlantic on the ships of the slave trade.

### Jamestown, 1607

A group of 104 English men and boys built a fort at Jamestown, in Virginia, in 1607. The fort stood in the land of the Paspahegh, one of the nations led by the Powhatan paramount chief, a leader over the chiefs of many nations. By the end of September 1607, half of the 104 colonists were dead, most of them from sickness.

George Percy, one of the colonists, wrote down each death with its date and cause. John Asbie died on August 6 of the "bloudie Flixe," Percy's spelling of bloody flux. Flux was the old word for diarrhea, so a bloody flux was diarrhea with blood in it. Percy also listed "Swellings" and "Burning Fevers," and deaths from wounds in fighting.

Percy blamed hunger most of all. Each day, five men shared one small can of barley boiled in water. They drank from the river. At high tide its water was salty, and at low tide it was "full of slime and filth." Many nights three or four men died.

Then Native people of the area, whom Percy called "our mortall enemies," brought bread, corn, fish and meat to the fort in great plenty. Percy wrote that "divers Kings," meaning several Native leaders, brought more. He did not name them.

**The river and the drought.** The geographer Carville Earle pointed to the river in 1979. At Jamestown the river water was part salt and part fresh, so the colonists' waste stayed in it instead of washing away. Tree rings show a drought that lasted seven years, from 1606 to 1612. The historian Dennis Blanton wrote that colonists who were hungry and thirsty from the drought were the most likely to fall sick.

Eight ships from England reached Jamestown in August 1609 with hundreds of new colonists. When the winter of 1609 to 1610 began, about 500 colonists were in Virginia, and about 240 of them were in the fort. By spring only about 60 of those 240 were alive. That winter is called the Starving Time.

### An epidemic on the New England coast, 1616 to 1619

A disease killed Native people along about 200 miles of the coast of southern New England, as far as Cape Cod, from 1616 to 1619. As far as the records show, the European fishermen and traders nearby did not catch it.

No count of the dead exists. Estimates of the share who died rest on weak records, and they run from one third to nine tenths of the people in the area. Before the epidemic, the Wampanoag Nation had about 21,000 to 24,000 people, and the Patuxet town had about 2,000. The colonist Daniel Gookin later wrote down what Native people told him about the sick. "The bodies all over were exceedingly yellow," they said, both before the people died and after. Gookin's account dates from 1674.

No one has settled what the disease was. The ideas put forward include yellow fever, smallpox, plague, typhus and several other diseases. Two researchers, John Marr and John Cathey, proposed leptospirosis in 2010. Leptospirosis is an infection by bacteria that rats carry in their urine. Marr and Cathey suggested that rats from European ships spread it into the water and soil, and they called their idea a proposal for others to test, not an answer.

When the Plymouth colonists arrived in 1620, the Patuxet town was empty. The colonists built Plymouth on its site. Governor William Bradford wrote that so many had died that the living could not bury the dead. He wrote that in many places in the area, skulls and bones still lay above the ground where houses had stood.

Squanto, also called Tisquantum, was one of the few Patuxet survivors. Bradford wrote that Squanto told other Native people the English kept the plague buried in the ground. Squanto said the English could send it among them whenever they wished.

### Plymouth's first winter, 1620 and 1621

In two or three months of their first winter, about half of the roughly 100 Mayflower passengers at Plymouth died. Sometimes two or three died in one day. Bradford blamed the cold, the lack of houses, and scurvy and other diseases from the long voyage. Scurvy is a disease caused by too little vitamin C, which comes from fresh fruit and vegetables. The gums swell and bleed, the teeth loosen, and the person grows too weak to work.

At the worst, only six or seven people were well enough to care for everyone else. They cut wood, made fires, cooked, made beds and washed the sick people's clothes. William Brewster and Myles Standish were two of them.

### Samuel Fuller

> **Who:** A wool weaver with no known medical training who came on the Mayflower and became the doctor for Plymouth and its neighbors.
>
> **When and where:** Plymouth, Salem and Charlestown, in Massachusetts, 1620 to 1633.

**A weaver of woolen cloth became the doctor for three towns.**

Samuel Fuller treated the sick of Plymouth and the towns near it for about thirteen years, although no record shows he ever trained as a doctor. Before the voyage he lived in Leiden, in the Netherlands, where he wove woolen cloth. He came to Plymouth on the Mayflower in 1620. His brother Edward and Edward's wife died in Plymouth's first winter.

Settlers at Salem fell sick in 1629 with scurvy and with a fever that had spread on their ships. Their leader, John Endicott, asked Governor Bradford to send Fuller. Endicott had heard that Fuller had cured people "by letting blood and other means."

Letting blood, or bloodletting, meant cutting open a vein, most often in the arm, and letting blood run out into a bowl. Doctors of the time believed it balanced the fluids of the body. It does not cure scurvy or fever, and it left sick people weaker. In 1630 Fuller let blood from about 20 newly arrived colonists at Charlestown.

A fever killed more than 20 men, women and children at Plymouth in 1633, and many Native people nearby. Fuller treated the sick. Then he died of the same fever, sometime between August and late September 1633. The colonist Nathaniel Morton later wrote that Fuller "was their surgeon and physician, and did much good in his place."

### Smallpox on the Connecticut River, 1634

About 1,000 Native people closed themselves inside a fort on the Connecticut River in the winter of 1633 to 1634, upriver from Plymouth's trading house. A disease struck them, and more than 950 of them died, Bradford wrote. Many of the bodies lay rotting above the ground, unburied. Bradford did not name the nation or the disease.

That spring, smallpox struck the Native people living near the trading house itself. Smallpox is caused by a virus, a germ even smaller than bacteria, and it spread from person to person through close contact, face to face. It caused a fever and a rash, and the rash turned into blisters and then scabs. In general, about 3 of every 10 people who caught smallpox died, though the share in a single epidemic could be higher or lower. Many survivors had scars for life, most of all on their faces.

Bradford described the sick lying on hard mats. The blisters broke open and ran, and the skin stuck to the mats. When a sick person turned over, the skin of a whole side came off at once. So many were sick that no one could make a fire, fetch water or bury the dead. Some crawled on their hands and knees to get water and died on the way.

The English at the trading house brought the sick wood, water and food, and buried the dead. None of the English there caught the disease. Very few of the Native people survived. Their chief sachem, or leader, died, and so did almost all of his friends and relatives. Bradford did not write down his name. No record shows who brought the disease to the river.

### Midwives and surgeons in New Amsterdam

The officials who ran New Amsterdam paid some of the people who cared for its sick, and in 1658 they set up a place for sick patients. They were officials of the Dutch West India Company, a trading company, and they governed the whole colony of New Netherland. New Amsterdam stood on Manhattan, in the homeland of the Munsee Lenape.

Company officials appointed and paid the town's midwives, women who help other women give birth. The midwife Lysbert Dircksen lived in a house built for her with public money in 1638. The officials also made rules for the town's surgeons, such as Hans Kierstede, who arrived in 1638 and worked there for nearly 30 years. Under rules of 1652 and 1657, barbers from the ships needed permission to treat wounds on shore, and surgeons had to report how each wounded person had been hurt.

The Company surgeon Jacob Hendrichsen Varvanger asked in 1658 for a place to care for sick patients. Members of the colony's council agreed. They made Hilletje Wilbruch the matron, the woman in charge, and paid her 100 florins, which were Dutch coins, a year. Richard Amerman, who wrote about medicine in New Netherland, called it the first hospital.

### Tryntje Jonas

> **Who:** A midwife from Amsterdam who served as an official midwife of New Amsterdam.
>
> **When and where:** New Amsterdam, now New York City, by 1644.

**The mother named one man as the father, then another.**

Tryntje Jonas was the official midwife of New Amsterdam by 1644. Officials of the Dutch West India Company appointed her and paid her, and she had her own house on Pearl Street. She came from Amsterdam. Her daughter Anneke Jans arrived in New Netherland in 1630.

Tryntje Jonas swore to the colony's secretary on July 7, 1644, what a mother had said about her baby's father. She had been called to help a woman named Hillegont Joris give birth. Hillegont Joris first named "Jan, the pilot" as the father of the child. Afterward she named Laurens Cornelisz. The secretary copied the statement into the colony's record book, where it survives. The record does not say why the midwife was asked to report this.

After Tryntje Jonas died, her daughter Anneke Jans collected the pay that the Company still owed her mother for her work. The date of her death is not known.

### Smallpox advice and yellow fever, 1677 to 1693

After smallpox spread through Boston in 1676 and 1677, the minister Thomas Thacher of the Old South Church wrote a guide for families. It was printed in 1677 or 1678 on a single large sheet called a broadside. Librarians at Harvard University's medical library call it the first medical paper published in the American colonies.

Thacher told families not to put a smallpox patient under heavy bedclothes, in a hot room, or give strong hot drinks. He told them to give weak beer, a thin porridge of cornmeal and water, and boiled apples. He warned that bloody or black urine, and diarrhea, were danger signs.

**Yellow fever.** Yellow fever came from Africa. It is a disease caused by a virus, and a mosquito called Aedes aegypti carries the virus from one person to another when it bites. The virus and the mosquito both crossed the Atlantic aboard the ships of the slave trade, a team of scientists reported in 2007. Nobody knew about the mosquito's part until the early 1900s.

Yellow fever struck Boston in 1693. The makers of the PBS history series *American Experience* call Boston the first British colony in North America to have a yellow fever epidemic. That June a fleet of English warships arrived in Boston, and the first Boston death from the fever came on June 25. No surviving count gives the number of dead. Charleston and Philadelphia had yellow fever soon after.

### Smallpox along the slave-raiding paths, 1696 to 1700

Smallpox broke out in Virginia in 1696 and spread south and west along the trading paths. It traveled with Native slave raiders and the captives they took for the colonial slave trade. By 1699 it had reached the Tunica people, in what is now Louisiana. It came back in waves until 1715.

By one estimate, some Native nations lost more than 60 of every 100 people. A South Carolina colonist wrote that smallpox had killed so many Native people that there was "little reason to believe they will be capable of doing any harm to us for several years to come."

## 1700 to 1750

**Era 4 of 10 · 1700 to 1750 · about 6 minutes**

Doctors in Boston and Charleston began protecting people against smallpox in these fifty years by inoculation: giving a healthy person a small case of smallpox on purpose, so that the person would not catch it again. Epidemics still killed thousands of people. Diphtheria killed about 5,000 people in New England, most of them children, and smallpox killed about half of the Cherokee Nation.

### Smallpox and inoculation in Boston, 1721

The ship *Seahorse* sailed into Boston from the island of Barbados on April 22, 1721, with sailors sick with smallpox. Boston had about 10,600 people. Close to 5,800 of them caught smallpox that year, and 844 died.

The minister Cotton Mather led the Boston ministers who backed inoculation. He had first heard of it from Onesimus, a man he enslaved. To inoculate someone, a doctor took pus from a smallpox sore and dried it. Then the doctor rubbed or scratched the pus into a cut in a healthy person's skin.

Almost all of Boston's doctors feared that inoculation would spread the disease. Zabdiel Boylston was the one Boston doctor who tried it, starting in June 1721. By the end of the epidemic, about 287 people had been inoculated, most of them by Boylston, and 6 of them died. That is about 2 in every 100. Among people who caught smallpox the ordinary way, about 14 or 15 in every 100 died.

**The fight.** The doctor William Douglass led the people who opposed inoculation. He called it a "poisonous humor," humor being an old word for a fluid of the body. James Franklin printed attacks on inoculation in his newspaper, the *New-England Courant*. The town's selectmen, its elected officials, ordered Boylston to stop. He started again two days later.

Someone threw a bomb through a window of Mather's house on November 14, 1721. The note that came with it ended with the words "I will inoculate you with this, with a pox on you!" The records do not name who threw it.

### Onesimus

> **Who:** An enslaved African man who described inoculation to Cotton Mather years before Boston first tried it.
>
> **When and where:** Boston, enslaved by Cotton Mather from 1706 to 1716.

**He showed his enslaver the scar on his arm.**

Onesimus told Cotton Mather how people in Africa protected themselves against smallpox. Mather later used that knowledge to back inoculation during Boston's smallpox epidemic of 1721.

Members of Mather's North Church gave Onesimus to Mather as a gift in December 1706. Another account gives the year as 1707. Mather named him Onesimus, after an enslaved man in the Bible. The name he was born with is not recorded. He was probably Coromantee, one of the Akan peoples of the Gold Coast, which is now Ghana.

Mather wrote to the Royal Society in London, a group of leading scientists, in 1716. He wrote that he had asked Onesimus whether he had ever had smallpox. Onesimus answered "both, Yes, and No." He had "undergone an Operation, which had given him something of the Small-Pox, and would forever preserve him from it." He showed Mather the scar on his arm.

Mather wrote down the method in Onesimus's words: people "take Juice of Small-Pox" and "Cut the Skin, and put in a drop." Mather wrote that he heard this from Onesimus months before he read of the same method in reports from Europe.

Onesimus married and had two children. Both died before they were ten. His son Onesimulus died in 1714. His daughter Katy died of tuberculosis.

Onesimus paid money in 1716 toward buying another enslaved man, Obadiah, to take his place. Mather then freed him, but with conditions. Onesimus still had to work for Mather's household, shoveling snow and chopping wood, whenever Mather called for him. He also had to repay five pounds that Mather said he had stolen. Few records of his life after 1716 survive.

### Zabdiel Boylston

> **Who:** The one Boston doctor who tried inoculation in 1721, when almost all the others feared it.
>
> **When and where:** Boston, 1721 and 1722. Born 1679, died 1766.

**His first three patients were his son and two enslaved people.**

Zabdiel Boylston inoculated three people on June 26, 1721. One was his son Thomas, who was about six. The other two were people Boylston enslaved: Jack, a man of 36, and Jack's son Jackey, who was two and a half. By law Jack and Jackey were Boylston's property, so they could not refuse. The accounts of that day do not say whether Jack agreed.

Boylston wrote down how each one's illness went. Thomas and Jack each had about "an hundred" blisters full of pus. On the ninth day Boylston gave them a medicine to make them vomit. All three recovered.

He went on to inoculate between 242 and 248 of the about 287 people inoculated in the epidemic, by different counts. Six of them died. When the selectmen ordered him to stop, he started again two days later. For a time he stayed on his farm, because he could not leave it without risk of being attacked.

Later he sailed to London, where the scientists of the Royal Society made him a member. In 1726 he published a book about his inoculations, *An Historical Account of the Small-Pox Inoculated in New England*.

### Elizabeth Phillips

> **Who:** A licensed midwife from London who delivered babies in Boston for more than forty years.
>
> **When and where:** Boston and Charlestown, Massachusetts, 1719 to 1761.

**Her gravestone says she delivered more than 3,000 babies.**

The gravestone stands in the Phipps Street Burying Ground in Charlestown, Massachusetts. It says that Elizabeth Phillips "brought into this world above 3000 Children." She delivered them in and around Boston.

She was born in Westminster, in London, in about 1685. The Bishop of London gave her a license to work as a midwife in 1718. She came to Boston the next year and worked there until she died in 1761.

### The throat distemper, 1735 to 1740

A disease began in Kingston, New Hampshire, in May 1735, and spread along the coast into Maine and Massachusetts. People called it the throat distemper, distemper being an old word for a sickness. Doctors today identify it as diphtheria, an infection by bacteria.

The bacteria killed the living tissue of the throat and nose. The dead tissue formed a thick coating across the throat, until the child could no longer breathe.

About 5,000 people in New England died of it by 1740, and more than three quarters of them were children. That count comes from Ernest Caulfield's 1939 book on the epidemic. In the town of Hampton Falls, New Hampshire, 210 people had died by July 1736, and 160 of them were under ten. The *Boston Gazette* newspaper printed treatments: bloodletting, borax (a white powder made from a mineral) or honey on the throat, and drinks made from herbs.

In Ipswich, Massachusetts, Mark and Hephzibah Howe lost eight children in November 1736. They were Abijah (1), Mark (2), Aaron (5), Mary (7), Lucy (9), Moses (11), Love (12) and Hannah (13).

### Smallpox among the Cherokee and Catawba, 1738 and 1739

Smallpox struck the Cherokee towns in the southern Appalachian Mountains in 1738 and 1739. Between 7,000 and 10,000 Cherokee people died, about half of the nation. About half of the Catawba Nation died too.

How the disease reached them is disputed. The trader James Adair wrote in 1775 that it came into Charleston on slave ships from West Africa. Historians writing for NCpedia, a North Carolina encyclopedia, give two other routes. In one, traders brought it. In the other, Cherokee warriors carried it home after fighting beside the British against the Spanish in Florida.

Cherokee healers treated the sick in sweat houses and then plunged them into icy streams. The NCpedia historians write that this only added to the number who died. Adair wrote that some survivors whom the disease had scarred killed themselves.

In Charleston, during the same epidemic, the doctor James Kilpatrick inoculated 800 to 1,000 people. Eight of them died.

## 1750 to 1800

**Era 5 of 10 · 1750 to 1800 · about 10 minutes**

Philadelphia doctors opened a hospital for the sick poor in 1752 and a medical school in 1765, while epidemics went on killing people in the colonies and the Native nations. Smallpox spread through the colonies and the Native nations during two wars, and in 1763 the British commander at Fort Pitt and a trader tried to spread it on purpose.

Yellow fever killed about 4,000 to 5,000 people in Philadelphia in 1793, about one person in ten. Under a 1798 law that members of Congress passed and President John Adams signed, federal officials took money from sailors' pay for their medical care.

### Caesar

> **Who:** An enslaved healer whose cure for poison led South Carolina's lawmakers to pay his enslaver for his freedom.
>
> **When and where:** St. Paul's Parish, South Carolina, near the Edisto River. Freed in 1750. Died in 1754.

**Lawmakers paid 500 pounds for one man's cure for poison.**

South Carolina's lawmakers bought Caesar's freedom in 1750 in exchange for his cure for poison. Caesar was enslaved by John Norman of Beach Hill, near the Edisto River. He was known for curing people of poisoning and of rattlesnake bite.

White South Carolinians feared that the enslaved people who cooked their food would poison them. In 1740 the colony's lawmakers had made poisoning a crime punished by death. In November 1749 the members of the Commons House, the colony's lawmaking body, voted to pay Norman 500 pounds for Caesar's freedom. They made the payment final on May 31, 1750. The lawmakers also promised Caesar 100 pounds a year for life, and he received his first payment in 1751.

The *South Carolina Gazette* newspaper printed Caesar's cure in May 1750. It was made by boiling plantain roots, horehound and goldenrod with rum, sugar, tobacco and lye made from wood ash.

The same lawmakers passed a law in 1751 aimed at enslaved healers, "commonly called doctors." Under it, enslaved healers could not give anyone medicine without permission from white people.

Caesar died in early 1754, at about 77 years old. He left an estate worth 62 pounds, and it included an enslaved woman. The record of his estate does not give her name or say how he came to own her. His wife Lilly and his daughter Hannah were never freed by the lawmakers. They were still enslaved by John Norman.

### Pennsylvania Hospital and the first medical school

Dr. Thomas Bond and Benjamin Franklin founded Pennsylvania Hospital in Philadelphia on May 11, 1751. They founded it to care for "the poor, sick and insane." Franklin's petition, a written request, described people "deprived of their rational Faculties," meaning they had lost their reason. It stated that they could be "contained and confined" there.

The first patients came on February 6, 1752, to a house on Market Street that the hospital used until its own building was ready. Writers for the Mütter Museum, a museum of medical history in Philadelphia, give the year as 1753. The permanent building opened in 1756. Its basement held rooms for patients with mental illness. The first floor was for men, and the second floor was for women.

Older places in the colonies also housed people in need. Philadelphia's almshouse, a home for the poor, opened in 1732. A New York workhouse of 1736, a place where poor people lived and were put to work, later became Bellevue Hospital. The place for the sick that Dutch officials set up in New Amsterdam in 1658 was older than both.

Dr. John Morgan founded a medical school at the College of Philadelphia, now the University of Pennsylvania, in 1765. The museum's writers call it the first medical college in the colonies. Students learned at the bedsides of the hospital's patients.

### Smallpox as a weapon at Fort Pitt, 1763

Two British men at Fort Pitt gave two Delaware men blankets from a smallpox hospital in 1763, hoping to spread the disease. Fort Pitt was a British fort where Pittsburgh stands now. That year Delaware, or Lenape, and Shawnee and Mingo warriors surrounded the fort, during the war led by the Ottawa leader Pontiac. Smallpox had broken out among the soldiers inside.

**The blankets.** Captain Simeon Ecuyer, the fort's commander, and the trader William Trent met two Delaware men, Turtle's Heart and Mamaltee, on June 24, 1763. Most accounts give that date, though one copy of Trent's journal dates the entry May 24. Ecuyer and Trent gave them two blankets and a handkerchief taken from the fort's smallpox hospital. Trent wrote in his journal, "I hope it will have the desired effect." Ecuyer signed the bill that charged the army for the blankets.

**The letters.** In July, General Jeffery Amherst, the British commander in North America, wrote to Colonel Henry Bouquet. He asked: "Could it not be contrived to send the Small Pox among those disaffected tribes of Indians?" By contrived he meant arranged, and by disaffected, unfriendly. Bouquet answered that he would "try to inocculate the Indians by means of Blankets."

Amherst also wrote of trying "to extirpate this Execrable Race," which means to wipe out completely a people he called hateful. Ecuyer and Trent had given away the blankets in June, before these letters, and on their own.

**Known:** Smallpox spread among the Native nations, and a man named Gershom Hicks reported in 1764 that about 100 people died of it between the spring of 1763 and April 1764.

**Not known:** whether the blankets caused any of it. The historian Elizabeth Fenn writes that no one can know whether the attempt worked, and a month after the meeting Turtle's Heart and Mamaltee showed no sign of smallpox.

### Smallpox in the Revolution, 1775 to 1782

Lord Dunmore, Virginia's royal governor, promised freedom in 1775 to people enslaved by the rebels if they joined his army. In the spring and summer of 1776, smallpox and other fevers spread through his camps. An estimated 500 Black soldiers of his Ethiopian Regiment died on Gwynn's Island, in Virginia, along with about 150 white soldiers.

General George Washington ordered the Continental Army to be inoculated on February 6, 1777. He wrote that if smallpox spread through the army, "we should have more to dread from it, than from the Sword of the Enemy." Dr. William Shippen ran the inoculations in secret, in winter, at Morristown, New Jersey, and in Philadelphia, so the British would not learn of them.

### What started the Doctors' Riot of 1788?

Medical students in New York were digging up the dead. To learn how the body is built, students cut open dead bodies and studied the parts, which is called dissection. They dug up bodies from the Negroes Burial Ground, where Black New Yorkers buried their dead ("Negro" was a word for Black people used at the time). They also dug up bodies from the paupers' graveyard, where the poor were buried.

Free and enslaved Black New Yorkers asked the city's Common Council, the group that ran the city, to stop it in February 1788. Their petition described "young gentlemen in this city who call themselves students of the physic," meaning students of medicine, who were digging up "bodies of our deceased friends and relatives." The council members took no action to stop the digging.

**The riot.** Boys outside New York Hospital saw a human arm from the dissecting room in April 1788. Crowds attacked the hospital. The mayor had a doctor and medical students taken to the city jail to protect them, and about 5,000 people then gathered at the jail.

Militiamen, ordinary citizens called up to serve as soldiers, had orders not to fire. A rock hit the politician John Jay in the head, a brick hit General Baron von Steuben, and the militiamen opened fire. The accounts of the riot do not name an officer who gave the order. As many as 20 people were killed, among them at least 3 rioters and 3 militiamen.

New York lawmakers banned grave robbing in 1789. The same law let judges order that the bodies of executed murderers, arsonists and burglars be dissected.

### Yellow fever in Philadelphia, 1793

Yellow fever killed 4,041 people in Philadelphia from August to November 1793, by the count of Mathew Carey, who wrote a book about the epidemic. Other counts run to about 5,000, which was about one person in every ten in the city. About 20,000 people left the city. Nobody in 1793 knew that mosquitoes carried the disease.

Dr. Benjamin Rush treated patients by bleeding them heavily and giving them purges, medicines that emptied the bowels. Rush's purges were made with mercury, a metal. Losing that much blood could send a weak patient into shock, which happens when too little blood is left in the body. A person in shock becomes confused, the heart beats fast, and the blood pressure drops. A French doctor, Jean Devèze, used milder treatment at the Bush Hill hospital.

Mayor Matthew Clarkson issued a public order about the epidemic on September 10, 1793. From September 14, a committee of 26 citizens worked with him to run the city's response.

Absalom Jones and Richard Allen, two Black Philadelphians who led volunteers in nursing the sick, printed an account of the epidemic in 1794. They wrote that some prisoners were let out of jail after the elders of the African church asked, on the condition that they nurse the sick at Bush Hill. Two thirds of those prisoners were Black. Jones and Allen's account does not name the officials who let them out.

### Benjamin Rush

> **Who:** A Philadelphia doctor who treated patients in the 1793 yellow fever epidemic, and a signer of the Declaration of Independence.
>
> **When and where:** Philadelphia, 1793. He worked at Pennsylvania Hospital from 1783 to 1813.

**He told Philadelphians that Black people could not catch yellow fever.**

Benjamin Rush printed that belief in the newspapers. In fact Black Philadelphians caught the fever and died of it while they nursed the sick.

Rush bled his patients heavily during the 1793 epidemic and gave them purges made with mercury. Several doctors died, and most of the rest were worn out by sickness or work. Then Rush asked Absalom Jones and Richard Allen, who both knew how to bleed a patient, to care for the sick. He told them where to get medicine, how to give it, and at what stage of the fever to bleed. When they could not tell what to do, he came himself or sent his student Edward Fisher.

At Pennsylvania Hospital, Rush moved patients with mental illness out of the basement and onto hospital floors with windows.

### Absalom Jones and Richard Allen

> **Who:** Two Black Philadelphians who led Black volunteers to nurse the sick and bury the dead.
>
> **When and where:** Philadelphia, September to November 1793. Their account was printed in 1794.

**They buried several hundred people and never asked for pay.**

Absalom Jones and Richard Allen led members of the Free African Society, a group of Black Philadelphians, in nursing the sick and burying the dead in 1793. In early September a notice in the newspapers asked "the people of colour" to help the sick. It stated that they could not catch the fever. Jones, Allen and a few others met to talk over how to act. The next day they asked the mayor how they could help.

They carried away and buried the dead, several hundred poor people and strangers in all. Five men they hired helped them, and two of those men were Allen's brothers. Rush taught them when to bleed a patient, and they bled more than 800 people.

The fever killed Black Philadelphians too. In 1792, 67 Black people were buried in the city. In 1793 the number was 305. When some Black nurses fell sick, the families they worked for put them out of their houses. Jones and Allen knew of one who died in a stable.

Mathew Carey wrote that Black nurses had overcharged the sick and stolen from them. In 1794 Jones and Allen printed their own account to answer him. For burying the dead, they wrote, they had "never received, nor never asked any compensation," meaning any pay. They also named Mary Scott, a Black nurse who refused to take more than her wage from a Mrs. Mason. Mrs. Mason then gave her six pounds a year for life.

### Medical care for sailors, 1798

President John Adams signed the Act for the Relief of Sick and Disabled Seamen on July 16, 1798, after members of Congress passed it. Under it, federal officials took 20 cents a month out of every merchant sailor's pay to pay for sailors' medical care. For a time, the first marine hospital, a hospital for sailors, stood on Castle Island in Boston Harbor. Today's United States Public Health Service began as this program.

## 1800 to 1850

**Era 6 of 10 · 1800 to 1850 · about 12 minutes**

A safer protection against smallpox reached the United States in 1800, and in 1846 surgeons learned to operate on patients who felt no pain, but neither one reached everybody. The new protection, vaccination, scratched matter from cowpox, a mild disease of cows, into the skin. A federal official left the Mandan people out of a vaccination program, and in 1837 smallpox killed at least nine in ten of them on the upper Missouri River.

A Boston dentist showed surgeons in 1846 that a drug called ether, breathed as a vapor, could keep a patient from feeling an operation. From 1845 to 1849 an Alabama doctor, J. Marion Sims, operated again and again on enslaved women to work out a new surgery, and he gave them nothing to stop the pain during the operations.

Cholera, a disease spread in dirty water, killed thousands of people in the growing cities in 1832 and 1849. In 1849 Elizabeth Blackwell became the first woman in the United States to earn a medical degree.

### Vaccination arrives, 1800 and 1802

To vaccinate a person, a doctor scratched fluid from a cowpox sore into the skin, and it protected the person against smallpox. In the older method, inoculation, doctors put pus from a real smallpox sore into a cut in the skin, and some inoculated people died of smallpox.

Dr. Benjamin Waterhouse of Cambridge, Massachusetts, vaccinated his young son Daniel Oliver and a servant, Samuel Carter, on July 8, 1800. He used cowpox matter on threads sent from England. It is the first recorded vaccination in the United States. Doctors in other places claimed earlier ones, but Waterhouse kept official records. He then vaccinated three more of his children and a second servant, Kesiah Flag.

Waterhouse sent vaccine to other doctors and to President Thomas Jefferson. Jefferson vaccinated his family, the enslaved people at his plantation, Monticello, and his neighbors. The enslaved people were Jefferson's property by law, so they could not refuse. The accounts of these vaccinations do not say whether they agreed.

**The test.** Waterhouse and six other doctors vaccinated nineteen boys on August 16, 1802. That fall the boys, whom the record calls volunteers, were exposed to smallpox to test the vaccine. The Harvard medical library's account of the test does not say who exposed them, whose sons they were, or whether their parents agreed. The members of Boston's Board of Health then reported that cowpox was "a complete preventive against all the effects of the Small-pox." That meant it kept a person from getting smallpox at all.

### Smallpox on the upper Missouri, 1832 and 1837

President Andrew Jackson signed a law on May 5, 1832, that set aside $12,000 to vaccinate Native people. Members of Congress had passed it. Secretary of War Lewis Cass designed the program and ran it through federal Indian agents, the government officials sent to deal with each Native nation. By February 1833, more than 17,000 Native people had been vaccinated. Some Army doctors refused to take part because the pay was too low.

Cass left the Mandan, Hidatsa and Arikara nations on the upper Missouri River out of the program. He believed the fur trade on the upper Missouri was no longer worth much to the United States. He also said that the treaties the three nations had signed in 1825 described them as hostile to the country and its citizens.

**The steamboat.** The American Fur Company's steamboat *St. Peters* stopped at Fort Clark, beside the Mandan villages in what is now North Dakota, on June 18, 1837. A deckhand had shown signs of smallpox weeks earlier, and three Arikara women who had caught it had boarded to go home to their village. The fort's trader, Francis Chardon, learned from the captain that people on the boat had smallpox. The crew unloaded goods and loaded furs in less than a day, and the boat went on upriver.

The historian R. G. Robertson blames the captain, Bernard Pratte Jr., who would not keep the sick apart from other people. Robertson calls that "criminal negligence," a failure to take care so serious that it should count as a crime.

Chardon wrote on July 14 that a young Mandan had died that day of smallpox. Later he wrote that the Mandan "die so fast that it is impossible" to keep count. About 2,000 Mandan lived in the villages in the spring. By October only 23 to 138 were alive, and the counts differ.

The Arikara lost between half and two thirds of their people, by different counts, and the Hidatsa lost many people too. Along the Missouri River more than 17,000 people died. About two thirds of the Blackfoot died, about half of the Assiniboine, about one third of the Crow and about one quarter of the Pawnee.

The Mandan leader Four Bears caught smallpox. Before he died he accused white people of ingratitude, of giving no thanks in return for kindness. As Chardon recorded his words: "I have loved the Whites ... and how have they repaid it! With ingratitude!"

### Cholera in the river cities, 1832 and 1849

Cholera is an infection of the gut. People catch it from food or water that carries its germ. It causes diarrhea that can start two hours after a person swallows the germ, and the body loses so much water and salt that the person can die. Cholera first reached the United States in 1832. It killed about 3,500 of New York City's roughly 250,000 people that year, about 1 New Yorker in 70.

Two steamboats from New Orleans reached St. Louis, on the Mississippi River, on January 2, 1849, with 66 passengers sick with cholera. In the spring more boats and gold seekers headed for California came through, and deaths rose. St. Louis had grown from about 5,000 people in 1830 to 77,000 by 1850, and it had no sewers. About three of every four people drank from shallow wells, often dug near outhouses. Pigs rooted through the garbage in the streets.

Doctors did not know what caused cholera. They blamed night air, bad food and alcohol, and told people to stop eating vegetables and then meat. At night they lit fires to clean the air. Some bled their patients, which left the sick person weaker.

Cholera killed 65 people in St. Louis on June 13, 1849, and 85 on June 21. In early July more than 100 a day died.

**The cleanup.** The city's lawmakers gave a Committee of Public Health $50,000 on June 27. The committee members stopped steamboats at a quarantine station, a place where people who may carry a disease are kept apart from others, on an island in the river. The city engineer drained standing water, and city officials banned hogs from the city. By late July, deaths had dropped to about 10 a day.

Reports from 1849 give 4,557 cholera deaths in St. Louis that year. Many deaths were never reported, so the real number was higher. About 7 of every 10 of the dead were Irish and German immigrants. Two researchers identified the germ that causes cholera in 1854 and showed that it spreads in dirty water.

### Ether, 1842 and 1846

Before anesthesia, the use of a drug so that a patient does not feel pain during an operation, surgeons worked as fast as they could. A long operation could send a patient into shock.

Dr. Crawford Long of Jefferson, Georgia, cut a tumor, a lump of tissue that grows where it should not, from the neck of James Venable on March 30, 1842, while Venable breathed ether. Long had noticed that people who breathed ether for fun at parties felt little pain when they got hurt. He did not publish what he had done until 1849.

The dentist William T. G. Morton gave ether to Edward Gilbert Abbott, a young house painter, at Massachusetts General Hospital in Boston on October 16, 1846. Abbott breathed the vapor through an inhaler, a breathing device, that Morton had made. Dr. John Collins Warren cut a tumor from Abbott's neck. Abbott said afterward that he had not been fully asleep but "had felt no sensation of pain."

### J. Marion Sims's operations on enslaved women, 1845 to 1849

Dr. J. Marion Sims of Montgomery, Alabama, operated again and again on enslaved Black women and girls from 1845 to 1849 to work out a new surgery. He gave them nothing to stop the pain.

The women had an injury called a vesicovaginal fistula. It is a hole torn through the wall between the bladder, where urine is held, and the vagina, the passage a baby is born through. A long, blocked childbirth crushes the tissue and makes the hole. Afterward urine runs out of the woman's body all the time. Her skin becomes sore and infected, and she smells of urine. Some women also had a hole into the bowel, so stool leaked too.

The women's enslavers sent them to Sims. The enslavers paid for their clothes and taxes, and Sims fed and housed them in a small hospital behind his office.

Seven of the women and girls are known by name. Sims named three of them, Anarcha, Betsey and Lucy. Another doctor, Nathan Bozeman, later named four more: Ann McRee, 16, Lavinia Boudurant, 13, Delia, 23, and Julia McDuffie, 20. How many there were in all is not settled. One count gives twelve. A museum of the history of anesthesia says that Sims left six or seven women unnamed.

Sims wrote that he promised to operate only with "the full consent of the patients." An enslaved woman had no power to refuse.

**No drug for the pain.** Ether was shown in Boston in 1846, partway through these years. Sims still used nothing to stop the pain during any of the operations. He wrote that the operations were "not painful enough to justify the trouble, and risk attending their administration." He meant the trouble and risk of giving a drug against the pain. Many white doctors of the time wrongly believed that Black people felt less pain. After the operations Sims often gave the women opium, a drug that dulls pain and brings sleep.

For each operation Sims had the woman placed naked on her knees and elbows so that he could see inside her. Sims operated on Lucy, who was about 18, for about an hour while about twelve doctors watched. Sims left a sponge inside her bladder to draw off urine. She nearly died of an infection that spread through her blood. Sims wrote: "Lucy's agony was extreme."

Sims closed the hole in Anarcha in 1849, on about the thirtieth operation. He sewed it shut with silver wire, which caused fewer infections than silk thread. A sponge or a tube drained urine from her bladder while it healed. He published the method in 1852.

**The babies.** Sims also operated on enslaved babies sick with neonatal tetanus, an infection in newborn babies that locks the jaw and other muscles in spasms. He believed the bones of the baby's skull had been pushed in on the brain. The historian Stephen Kenny later studied Sims's own reports of these cases.

Sims kept the baby son of an enslaved woman named Ann at his home in 1847. He cut through the baby's scalp with the point of a knife and pried a skull bone outward. Over the next two months he went on puncturing the same baby's scalp from time to time. Now he used the point of a crooked awl, a pointed tool for punching holes, to pry the skull bones outward. Kenny does not say whether Ann's baby lived.

Sims blamed the baby's illness on Ann. He said she had carried her son with his head pressed against her arm. He also blamed an enslaved nurse for not following his orders.

Sims used the awl in the same way on the baby of another enslaved woman, Frances, prying up the skull bone on one side and then the other. Her baby died twelve hours later, and Sims then cut open the body.

In his reports, every baby he operated on or cut open after death was enslaved. When a white baby, the daughter of Wyatt Peters, had the same disease, Sims gave no medicine and had her laid on her side on a pillow. Sims's two articles on the disease report 27 cases, 17 of them from his own notes. Kenny's study of those articles does not give a total of how many enslaved babies Sims operated on or how many died.

New York City officials voted in April 2018 to take down Sims's statue in Central Park.

### Anarcha

> **Who:** An enslaved young woman on whom J. Marion Sims operated about thirty times, with nothing to stop the pain, to work out his fistula surgery.
>
> **When and where:** Montgomery, Alabama, 1845 to 1849.

**Sims operated on her about thirty times before his surgery worked.**

Anarcha's childbirth had been long and blocked. It tore two holes, one from her vagina into her bladder and one into her rectum, the end of the bowel. Urine and stool leaked from her body all the time. The accounts of her age differ. Some give 17 when she gave birth. One estimate says she was 13 when Sims first treated her.

Her operations went on for about four years, until the one in 1849 closed the hole into her bladder. The records do not show what happened to Anarcha, Betsey and Lucy after Sims finished with them.

### Elizabeth Blackwell

> **Who:** The first woman to earn a medical degree in the United States.
>
> **When and where:** Geneva, New York, 1847 to 1849, then New York City. Born in Bristol, England, in 1821. Died in Hastings, England, in 1910.

**About 29 medical schools turned her down before one said yes.**

Elizabeth Blackwell graduated at the head of her class from Geneva Medical College in New York on January 23, 1849. She was the first woman in the United States to earn a medical degree.

The yes came in 1847, when the men studying at Geneva Medical College voted to let her in. Two accounts explain the vote. In one, the students thought the question was a joke by their teachers. In the other, they thought it would be funny to have a woman in the class.

Later in 1849 she worked at La Maternité, a hospital in Paris. She caught an eye infection from a baby she was treating and lost the sight of that eye, so she had to give up her plan to become a surgeon.

With her sister, Dr. Emily Blackwell, and Dr. Marie Zakrzewska, she opened the New York Infirmary for Indigent (poor) Women and Children in 1857. In 1868 she added a medical college for women beside it.

## 1850 to 1900

**Era 7 of 10 · 1850 to 1900 · about 8 minutes**

Disease killed more Civil War soldiers than fighting did, and in peacetime too Americans died of sicknesses spread by dirty water, filthy streets and unwashed hands. Smallpox killed more than 60,000 people who had just been freed from slavery between 1862 and 1868. Officers of New York's new health board ordered filth cleared from the streets in 1866, and cholera killed a smaller share of the city than in earlier years. Yellow fever killed about 20,000 people along the Mississippi River in 1878.

Most American doctors did not yet kill germs on their hands and tools. When President James Garfield was shot in 1881, his doctors probed his bullet wound with unwashed fingers. He died weeks later, and the doctors who examined his body found it full of infection. By 1900 women were training as nurses and doctors. Among them were the first Black woman to earn a nursing license and the first Native American woman to earn a medical degree.

### Disease in the Civil War armies, 1861 to 1865

Between about 620,000 and 850,000 soldiers died in the Civil War, and the count is disputed. For every three soldiers killed in battle, about five died of disease.

The diseases that killed them included diarrhea and dysentery, which are infections of the gut. Others were typhoid fever, an infection spread by food and water that has touched human waste, and pneumonia, an infection of the lungs. Measles, malaria (a fever spread by mosquitoes) and scurvy killed soldiers too.

Soldiers dug latrine trenches, the ditches they used as toilets, too shallow, and they did not cover the waste with dirt. Waste could then wash into the water the soldiers drank. One army surgeon found a camp's latrine uphill of "the stream, from which all water in the camp is obtained."

### Clara Barton

> **Who:** A clerk at the US Patent Office who took supplies to Civil War battlefields and later founded the American Red Cross.
>
> **When and where:** Antietam, Maryland, September 17, 1862. Born in North Oxford, Massachusetts, on December 25, 1821.

**A bullet passed through her sleeve and killed the soldier she helped.**

Clara Barton brought a wagon of bandages and supplies to the battlefield at Antietam, Maryland, on September 17, 1862. She had spent a year collecting them. At a farmhouse she held wounded men's heads, gave them water and cooked for them. The lanterns she brought let surgeons keep operating after dark.

She was giving a soldier a drink when the bullet went through her sleeve. She wrote that it cut "through his chest from shoulder to shoulder." A surgeon there, Dr. James Dunn, called her "the angel of the battlefield."

Before the war Barton had been a teacher and then a clerk. She and others formed the American Association of the Red Cross, the group now called the American Red Cross, in Washington, D.C., on May 21, 1881. She was its president until 1904, when she resigned after growing criticism.

### Hannah Ropes

> **Who:** The head nurse of a Civil War hospital in Washington, who reported a thief on the staff to the Secretary of War and died of typhoid caught at work.
>
> **When and where:** Union Hotel Hospital, Georgetown, Washington, D.C., 1862 and 1863. Born in 1809 in New Gloucester, in what is now Maine.

**She took her complaint about a thief to the Secretary of War.**

Hannah Ropes ran the nurses at a Civil War hospital in Washington until typhoid killed her in January 1863. Her son Edward was a Union soldier. In 1862 she volunteered as a nurse. She became matron, the woman in charge of the nurses, at the Union Hotel Hospital. It was an old hotel turned into a hospital for 300 to 400 patients.

The writer Louisa May Alcott nursed under her from December 1862. "A more perfect pestilence-box than this house I never saw," Alcott wrote in her diary, a pestilence being a deadly disease that spreads.

Ropes found that the hospital steward, the man in charge of supplies, was stealing supplies meant for the wounded. The chief surgeon ignored her complaints. She took them to the Secretary of War, Edwin Stanton, and the steward and the surgeon were both arrested. The accounts of her life do not say who arrested them.

She caught typhoid in late December 1862 and died on January 20, 1863. Alcott fell sick in the same outbreak and went home on January 21, 1863. Ropes's diary and letters were printed as a book in 1980.

### Smallpox among freed people, 1862 to 1868

Smallpox killed more than 60,000 people who had just been freed from slavery from 1862 to 1868, the historian Jim Downs counts. Women and children died at higher rates than men.

During the war, people who escaped slavery came to camps the Union army set up for them. The army called them contraband camps, contraband meaning goods taken from an enemy in war. The camps were crowded and dirty, and many people in them lacked the basic things they needed to stay alive. Smallpox broke out in Washington, D.C., in 1862 and spread to nearby Alexandria, Virginia.

Doctors already knew how to stop smallpox. They could vaccinate people and keep the sick apart from the healthy. Union army officers and officials of the Freedmen's Bureau, a federal office set up to help people freed from slavery, ran the camps. They put sick freed people in tents made of old, ripped army tarps, with blankets full of insects. Sick white soldiers went to army hospitals. The accounts of the epidemic do not name the men in charge.

Harriet Jacobs, who had escaped slavery herself, came to Alexandria to open a school and worked against the epidemic.

### Health boards and yellow fever, 1866 to 1879

New York State lawmakers passed a law in February 1866, and Governor Reuben Fenton signed it, giving New York City a Metropolitan Board of Health. The doctor Stephen Smith had worked to get it passed. By April its officers had given 7,000 orders to clear away piled horse manure, dead animals and heaps of garbage. Crews spread chloride and lime, chemicals that kill germs, where cholera struck. Cholera killed 1,137 New Yorkers in 1866. That was a smaller share of the city than in 1832 or 1849.

Yellow fever spread up the Mississippi River from New Orleans in 1878. It began after the ship *Emily B. Souder* arrived in New Orleans in late May, and crew members fell ill and died. The first official yellow fever death in the city that year was a four-year-old girl, in July. Along the river about 120,000 people caught the fever and about 20,000 died.

In Memphis, Tennessee, about 25,000 to 27,000 of the city's 47,000 people fled. More than 5,000 people died in the city. Annie Cook ran a brothel, a house where men paid women for sex. She turned it into a hospital, nursed the sick, and died of the fever.

Members of Congress set up a National Board of Health in 1879. Nobody proved that a mosquito spreads yellow fever until 1900.

### Germs and the death of President Garfield, 1881

The English surgeon Joseph Lister urged doctors to kill germs on their hands and tools, to stop wounds from getting infected. Most American doctors thought this was too much trouble.

Charles Guiteau shot President James Garfield at a railroad station in Washington, D.C., on July 2, 1881. Doctors pushed their unwashed fingers and unwashed tools into the wound to search for the bullet. Dr. Willard Bliss, who took charge, probed the wound several times a day and never cleaned his hands first. One doctor punctured Garfield's liver while probing. The accounts of Garfield's care do not name him.

Garfield died on September 19, 1881. Doctors who examined his body found pneumonia in both lungs and his body full of pus. A medical paper of 2013 argues instead that a burst artery near his spleen killed him. An artery is a large tube that carries blood from the heart, and the spleen is an organ beside the stomach. Candice Millard, who wrote a 2011 book about Garfield's death, said in an interview that Garfield "would have been better off if they had just left him alone."

### Women become nurses and doctors

Mary Eliza Mahoney had worked at the New England Hospital for Women and Children in Boston for 15 years before she began its nursing course. The hospital had only women doctors, and the course took 16 months. Of 42 students who began in 1878, four finished in 1879, and Mahoney was one of them.

She became the first Black woman in the United States to earn a professional nursing license. In 1908 she helped found a group for Black nurses, the National Association of Colored Graduate Nurses ("Colored" was a word then used for Black people).

### Susan La Flesche Picotte

> **Who:** An Omaha woman who became the first Native American woman to earn a medical degree, and went home to be the doctor for her own nation.
>
> **When and where:** The Omaha Reservation, Nebraska. Born 1865, graduated 1889, died 1915.

**As a child she watched a white doctor refuse to treat a dying woman.**

The woman was a sick Native woman, and she died because the local white doctor would not treat her. Susan La Flesche had been born in 1865 on the Omaha Reservation in northeastern Nebraska. Her father was Chief Joseph La Flesche, and her mother was Mary, also called One Woman.

She studied at the Woman's Medical College of Pennsylvania. She finished its three-year course in two years and graduated first in her class. In 1889 she became the first Native American woman in the United States to earn a medical degree.

Back on the reservation she cared for more than 1,300 people spread over 450 square miles. In 1913 she opened a hospital at Walthill, Nebraska, on the reservation. She died in 1915.

### Typhoid in the army camps, 1898

During the war with Spain in 1898, soldiers in army camps in the United States caught typhoid. There were 20,738 cases and 1,590 deaths in the camps. Typhoid caused 87 of every 100 deaths from disease in those camps. Major Walter Reed and two other army doctors, Victor Vaughan and Edward Shakespeare, studied the camps. They found that the disease spread mostly from man to man, and some of it by flies.

## 1900 to 1950

**Era 8 of 10 · 1900 to 1950 · about 20 minutes**

The first American patient saved by penicillin, a drug made from a mold that kills bacteria, was Anne Miller. She got her first dose in 1942. In the same years, government doctors kept that same drug from Black men in Alabama who had syphilis. Army doctors proved in 1900 that a mosquito spreads yellow fever.

An influenza epidemic, a flu that spread to huge numbers of people at once, killed about 675,000 people in the United States in 1918. A medicine mixed with a poison killed more than 100 people in 1937, and in 1938 a new law required drug makers to prove a drug safe before selling it.

Doctors of the United States Public Health Service began their study of 399 Black men in Alabama who had syphilis in 1932. For 40 years the doctors kept the men from being treated, while telling them they were being treated. Public Health Service doctors also exposed 1,308 people in Guatemala to diseases passed during sex, on purpose, from 1946 to 1948.

### Proving the mosquito, 1900 and 1901

Four army doctors near Havana, Cuba, proved in 1900 that mosquitoes pass yellow fever, a disease caused by a virus, from sick people to healthy ones. Major Walter Reed led the four, and the others were James Carroll, Jesse Lazear and Aristides Agramonte.

Lazear raised mosquitoes and let them feed on yellow fever patients. A mosquito that had fed on a patient at least 12 days before passed the disease on when it bit someone else. Carroll and a soldier who volunteered caught yellow fever from these bites in late August. Lazear was probably bitten by an infected mosquito himself, and he died of yellow fever on September 25, 1900.

**Two buildings.** The doctors tested two buildings in November 1900. In one, volunteers slept in bedding soiled by yellow fever patients, and they stayed well. In the other, a clean building, infected mosquitoes bit volunteers, and several caught yellow fever. All of them recovered. The volunteers signed written contracts that named the danger, and they were paid. After workers killed the mosquitoes in Havana, yellow fever there nearly stopped.

### Clara Maass

> **Who:** A New Jersey nurse who died after letting infected mosquitoes bite her in a yellow fever experiment.
>
> **When and where:** Havana, Cuba, 1901. Born in East Orange, New Jersey, in 1876.

**She let infected mosquitoes bite her twice.**

Clara Maass died of yellow fever at 25, after she let infected mosquitoes bite her in Havana in 1901. She came from a poor German immigrant family in East Orange, New Jersey. She started training as a nurse at 17, at the Newark German Hospital, and she was its head nurse by 21. She nursed soldiers in the 1898 war with Spain and then in the Philippines.

In Havana volunteers were paid $100, and $200 if they caught the fever. Maass let infected mosquitoes bite her in March 1901. She had a mild case and got well. In August 1901 she volunteered again, caught yellow fever, and died on August 24.

Soon after her death, the yellow fever commission was ordered to break up. The museum account of her life does not name who gave the order.

### Mary Mallon, held on an island

Mary Mallon was a cook in New York who carried the germs of typhoid, a fever spread through food and water, in her body without being sick herself. Health officials counted 47 people infected through her cooking, and 3 of them died.

Officials of the New York City Board of Health held her on North Brother Island, in the East River, from 1907. In a letter in June 1909, she wrote that they kept her "a prisoner without being sick nor needing medical treatment." She also wrote, "I have been in fact a peep show for everybody."

The officials let her go in February 1910, after she signed a promise not to work as a cook again. In October 1914 she took a job as a cook at the Sloane Maternity Hospital, under the name Mary Brown. Early in 1915 typhoid broke out there, and 25 people caught it and 2 died. Health officials found her in March 1915 and sent her back to the island. She stayed there until she died on November 11, 1938, and she became known as "Typhoid Mary."

### Fewer medical schools, 1910

Abraham Flexner published a survey of the country's 148 medical schools in 1910. Leaders of the Carnegie Foundation had hired him to do it. He called several schools "beyond repair." In the years after, the number of medical schools fell to 66.

Writers at JSTOR Daily, a history magazine, say that members of the American Medical Association, most of them white men, used the report to close schools and protect their own jobs and earnings. Seven medical schools had trained Black doctors. Only two were left: Howard University in Washington, D.C., and Meharry Medical College in Nashville, Tennessee.

### Polio in New York, 1916

Polio is a disease caused by a virus that can attack the nerves in the spine. It can leave a person unable to move the arms, the legs or the muscles used for breathing, a loss of movement called paralysis.

In the summer of 1916 polio spread through New York City. More than 9 of every 10 of the city's cases were in children five or younger. One count gives more than 27,000 cases and more than 6,000 deaths across the whole country. Accounts of New York City alone differ, from about 2,000 deaths to about 6,000.

Dr. Haven Emerson was the city's health commissioner. Every day the names and addresses of the sick appeared in the newspapers. Signs went up on their houses, and the accounts of the epidemic do not say who put them up.

**Shut in.** A team of Health Department workers led by Dr. Simon Blatteis kept the families shut inside. Under Health Department rules, a family that could not give the sick child a separate room, a separate toilet and a nurse had to let the department take the child to a hospital, free of charge. Police stood at the railroads, roads and rivers to turn back anyone trying to leave the city.

Writers in the *New York Times* blamed Italian immigrants for the disease. Italian immigrants were shunned, cursed and beaten up, and the accounts of the epidemic do not name who beat them.

### The 1918 influenza

Influenza, or flu, is a disease caused by a virus that infects the nose, throat and lungs. In 1918 a new kind of influenza spread around the world. About 500 million people caught it, and at least 50 million died. About 675,000 of the dead were in the United States. Many of them were healthy adults between 20 and 40.

There was no vaccine against it, no medicine that trains the body to fight off a germ before the germ can make a person sick. There was no antibiotic either, a medicine that kills bacteria. Many people died of pneumonia, with their lungs full of fluid.

**The parade.** In Philadelphia, Dr. Wilmer Krusen, the city's director of public health, let a parade to sell war bonds go ahead on September 28, 1918. People bought the bonds to lend money to the government for the war. About 200,000 people crowded onto Broad Street. Krusen said in public that the flu was not a threat, although army camps nearby were full of it.

Within three days every bed in the city's 31 hospitals was full. City officials closed schools, churches and theaters on October 3. More than 12,000 people in Philadelphia died within weeks.

The flu reached Brevig Mission, an Alaska Native village, in 1918. Within five days, 72 of the 80 villagers were dead. Miners from the town of Nome thawed the frozen ground with steam and dug one grave for all of them.

### Josie Mabel Brown

> **Who:** A Navy nurse from Missouri who worked the influenza wards at Great Lakes, Illinois, and described them in an interview when she was about 100.
>
> **When and where:** Great Lakes Naval Training Station, Illinois, fall 1918 to 1919. Born on a Missouri farm in 1886.

**The ambulance brought four sick men and took away four dead.**

Josie Mabel Brown nursed sailors dying of influenza at the Great Lakes Naval Training Station in Illinois in 1918. At the worst of the epidemic, 6,000 of the 173,000 men there were in the hospitals. She had finished nurse training in 1917 and been called into the Navy, and in the fall of 1918 she was ordered to Great Lakes.

On her first ward, one man lay dying on the bed and another lay on the floor. A third waited on a stretcher for the bed. The nurses wrapped each dead man in a sheet and tied a shipping tag to one big toe. The ambulance, she said, "would bring us four live ones and take out four dead ones."

The nurses had no time to take temperatures. Patients had nosebleeds so strong that "the blood would just shoot across the room," she said. In some men, air leaked from torn lungs into the body, and she could see bubbles under the skin of their arms.

She worked 16 hours a day until just before Christmas 1918. In March 1919 she caught a fever of 104 or 105 herself, and she recovered. She told her story to her niece in 1986 and died at 104.

**By 1920:** Army doctors had proved that mosquitoes carry yellow fever, and influenza had just killed about 675,000 Americans. Doctors still had no vaccine against the flu and no drug that killed bacteria.

### Radium in the body, 1917 to 1932

Radium is a metal that gives off radiation, a stream of energy that damages living cells. Radium belongs to the same family of elements as calcium, so growing bones take it up as if it were calcium. There it keeps giving off radiation from the inside.

Women painted watch dials with glowing radium paint at the U.S. Radium factory in Orange, New Jersey, from 1917. They shaped their brushes into a point with their lips. The radium destroyed their bone marrow, the soft tissue inside bones that makes blood, so their bodies could not make enough blood. Their jaw bones died and broke apart. Some grew cancers of the bone. In 1924 a dentist, Theodor Blum, examined the dial painter Grace Fryer. Her jaw bone was wasting away, and he called the damage "radium jaw."

Chapter 13, The Elements, tells the dial painters' story and their lawsuit in full. Five of them, Grace Fryer among them, signed an agreement with the company on June 8, 1928. Each woman received $10,000, though some accounts give $15,000, plus $600 a year for as long as she lived, and her medical costs. The company's officers never admitted that the company was to blame.

**A radium medicine.** William Bailey sold radium dissolved in water as a medicine called Radithor. He falsely claimed to have medical training and paid doctors to tell their patients to take it. Eben Byers, a Pittsburgh businessman, drank about 1,400 bottles from 1927 to 1930. A government investigator found in 1931 that the bone in Byers's body was falling apart and holes were forming in his skull. He died on March 31, 1932, of a cancer of the jaw bone caused by the radium.

### Native health, 1928

A team of investigators led by Lewis Meriam reported in 1928 on the lives of Native people on reservations and in government boarding schools. They wrote that "the health of the Indians as compared with that of the general population is bad." They wrote that the share of Native people who died each year was high, and so was the share of babies who died.

The investigators found tuberculosis, the lung disease that spreads by coughing, "extremely prevalent," which means very common. They found trachoma, an eye disease that "produces blindness," to be "a major problem." In the government boarding schools the children's food was "deficient in quantity, quality, and variety": there was not enough of it, and it was poor and the same every day. "The medical service rendered the boarding school children is not up to a reasonable standard," they wrote, meaning the care doctors gave the children was not good enough.

### The Tuskegee study, 1932 to 1972

Doctors of the United States Public Health Service watched hundreds of Black men in Alabama live with syphilis for 40 years, from 1932 to 1972, and they kept the men from being treated. They wanted to see what the disease did to a body when no one treated it.

**What syphilis does.** Syphilis is a disease caused by bacteria. It is passed during sex, or from a mother to her unborn baby. Left untreated, it goes through stages. At first the person gets a painless sore where the germ entered. Weeks later the person gets a rash, a fever and a sore throat.

Then the germ can hide in the body for years with no signs. After 10 to 30 years it can damage the heart and the large blood vessels, the brain and the nerves. It can cause blindness, and it can cause dementia, which is the loss of memory and reason. It can kill, and a baby born with syphilis can die.

**Who ran it.** Dr. Taliaferro Clark began the study in 1932. He was head of the Public Health Service's office for diseases passed by sex. The study took place in Macon County, Alabama, near the town of Tuskegee. Dr. Raymond Vonderlehr ran it there and later took Clark's place. Most of the men were poor farmers. Many were sharecroppers, who farmed someone else's land for a share of the crop.

The doctors chose 399 men who had syphilis and 201 men who did not, to compare them. They planned no treatment at all for the infected men. The study was planned to last six months, and it ran for 40 years.

**The lie.** The doctors told the men they had "bad blood" and that they were being treated for it. They did not tell the men that the disease was syphilis, and they never asked whether the men agreed to be studied. The men got free exams, hot meals on exam days and rides. From 1935 they were also promised about $50 toward their burials, if they let doctors cut open their bodies after death to study them.

Eunice Rivers, a Black nurse, kept in touch with the men for all 40 years. She gave them aspirin and a "spring tonic" that did nothing against syphilis. Dr. Oliver Wenger, who ran the clinic in the region, wrote, "we have no further interest in these patients until they die."

The exams also included spinal taps. In a spinal tap a doctor pushes a needle between the bones of the lower back and draws out fluid from around the spinal cord. The doctors wanted to see whether syphilis had reached the brain and nerves. A spinal tap often causes a lot of pain and other harm. The doctors' letter to the men called it their "Last Chance For Special Free Treatment."

**Keeping the cure away.** Keeping treatment away from the men was part of the study. Its doctors gave local doctors lists of the men's names and asked them not to treat them. In 1941 army officials drafted some of the men and told them to start treatment. Public Health Service officers gave the draft board, the group that chose men for the army, a list of 256 names to leave untreated, and the board members did as they asked.

Accounts differ on when penicillin, the drug made from a mold, became the usual cure for syphilis: 1943, by 1947, or the early 1950s. The study doctors never offered it to the men. Vonderlehr later wrote, "I hope that the availability of antibiotics has not interfered too much with this project."

**What their own reports show.** Reports that the study doctors printed show what the disease did to the men. In 1936 the doctors reported that the infected men had much more disease of the heart and blood vessels than the men without syphilis. Only 16 of every 100 infected men showed no sign of illness, against 61 of every 100 of the uninfected men.

About ten years later, nearly twice as many infected men as uninfected men had died. The doctors worked out that the disease had cut the men's lives by about a fifth.

Their 1955 report covered the infected men whose bodies they had cut open after death. More than 30 of every 100 had died because syphilis destroyed their heart and blood vessels or their brain and spinal cord.

A reporter made the study public in 1972. By then, by one count, at least 28 of the men had died of syphilis itself and 100 more of problems it caused. Forty of their wives had caught it. Nineteen of their children were born with it.

### Charles Pollard

> **Who:** An Alabama farmer who was kept in the Tuskegee study for 40 years without being told he had syphilis, and who then brought the lawsuit for the men.
>
> **When and where:** Near Tuskegee, Macon County, Alabama, 1932 to 1972.

**At 66, he learned from the news that he had syphilis.**

That was in July 1972, and Charles Pollard had had syphilis for 40 years. He farmed 66 acres of land he had inherited, about three miles from Tuskegee. His father was the son of two enslaved people.

Men from the study told Pollard in 1932 that he could get a free physical exam at a one-room school the next afternoon. "So I went on over and they told me I had bad blood," he said. "And that's what they've been telling me ever since." For 40 years doctors came around "from time to time and check me over."

Pollard went to Fred Gray, a lawyer in Tuskegee. Their lawsuit, *Pollard v. United States*, ended in a settlement of $10 million. In 1997 Pollard was one of the survivors at the White House when President Bill Clinton apologized to them.

### A poison sold as medicine, and a new law, 1937 and 1938

A poison in a new medicine killed more than 100 people in 1937, and the next year a new law required drug makers to prove a drug safe before selling it. The S. E. Massengill Company of Bristol, Tennessee, sold a liquid medicine called Elixir Sulfanilamide for strep throat. Its chemist, Harold Watkins, dissolved the drug in diethylene glycol, a chemical used in antifreeze and a poison. No law required the company to test the medicine for safety before selling it.

The medicine killed more than 100 people in 15 states in September and October 1937, many of them children. It shut down their kidneys. They stopped passing urine and had strong stomach pain, vomiting and seizures before they died.

A mother wrote to President Franklin Roosevelt about her daughter Joan: "we can see her little body tossing to and fro and hear that little voice screaming with pain." The owner, Dr. Samuel Massengill, said, "I do not feel that there was any responsibility on our part." Watkins killed himself.

President Roosevelt signed the Federal Food, Drug, and Cosmetic Act on June 25, 1938, after members of Congress passed it. Under it, a company had to prove to officials of the Food and Drug Administration, the FDA, that a new drug was safe before it could sell the drug.

### Penicillin, 1942

Penicillin is a drug made from a mold. It kills many kinds of bacteria, the germs behind infections such as blood infections and syphilis. It was the first antibiotic made in large amounts.

Anne Miller of New Haven, Connecticut, had an infection of the blood in March 1942, after a miscarriage, the loss of a baby before it can live outside the womb. For weeks her fever stayed at 103 degrees or higher. Her doctors got 5.5 grams of penicillin, half of all the penicillin in the United States at the time. She got her first dose on March 14. By the next morning her temperature was back to normal. She was the first patient in the United States whose life was saved by penicillin.

### Exposed on purpose in Guatemala, 1946 to 1948

Doctors of the United States Public Health Service, led by Dr. John Cutler, gave people in Guatemala syphilis, gonorrhea and chancroid on purpose, or tried to, from 1946 to 1948. All three are diseases passed during sex. The doctors infected people without asking whether they agreed.

The doctors exposed 1,308 people to these diseases: prisoners, soldiers and patients in the national mental hospital. They ranged from 10 to 72 years old. The records show some kind of treatment for 678 of them.

**How they did it.** The doctors used women who were paid for sex to pass on the diseases. They infected most of these women first, then sent them to the prisoners. They also rubbed pus from sick men painfully onto people's genitals and into the opening where urine leaves the body. They injected germs into people's spinal fluid.

For tests, the doctors also took blood or spinal fluid from 5,128 people, among them children in orphanages and schools and people with leprosy, a disease caused by bacteria that damages the skin and nerves.

The money came from the Public Health Service, the National Institutes of Health and the Pan American Sanitary Bureau. Guatemalan officials supplied staff and buildings. Cutler's records note 83 deaths while the experiments went on. A presidential commission studied the experiments in 2011 and found it unclear how many of those deaths the experiments caused. The doctors never published their results. The public learned of the experiments in 2010.

### Federal money for hospitals, 1946

The Hospital Survey and Construction Act became law on August 13, 1946. People call it the Hill-Burton Act, after the two senators who put it forward, Lister Hill of Alabama and Harold Burton of Ohio. Over the years, federal lawmakers set aside $3.7 billion under it to build hospitals, and states and towns added $9.1 billion.

Under the law, the people who ran hospitals built with the money could keep Black and white patients apart, as long as the separate care was called equal. Accounts differ on who asked for that rule. Judges struck it down in 1963.

### Pellagra, silica dust and forced sterilization

**A disease of diet.** Pellagra killed about 100,000 Americans between 1900 and 1940, out of about 3 million who had it, about 1 in 30. Pellagra is a disease caused by too little niacin, a vitamin, in the diet. Most of the sick were poor farmers, sharecroppers and cotton-mill workers in the South who lived on little but cornmeal, molasses and dried pork. Scientists identified niacin in 1937.

**Silica dust.** Almost 5,000 workers dug the Hawks Nest tunnel in West Virginia from 1930 to 1932, and Chapter 14, Work and Workers, tells its story in full. It was the Union Carbide company's tunnel, and the contractor was Rinehart and Dennis. Most of the workers were Black men who had come from other parts of the South. The rock was full of silica, the mineral in sand.

The men drilled through it with no masks and no way to control the dust. The West Virginia Encyclopedia's account of the tunnel does not name the company men who made that choice. Breathing silica's fine dust scars the lungs until a person cannot breathe, a disease called silicosis. Death counts run from 476 to close to 1,000.

**Forced sterilization in Puerto Rico.** Eugenics was the false idea that a country could improve its people by stopping some people from having children. In Puerto Rico, under a law that took effect in 1937, members of a government Eugenics Board ordered 97 women sterilized by force. Sterilized means that a person can never become pregnant. Doctors did it by cutting or tying the tubes that carry eggs to the womb, or by removing the womb.

Many thousands of other women were pressured into the same operation. Clarence Gamble, an heir to the Procter and Gamble soap fortune, set up birth control clinics in Puerto Rico with money from the Puerto Rico Reconstruction Administration, a federal office. Gamble made sterilization a rule in his clinics. A woman with three living children could be seen there only if she agreed to be sterilized, historians on the history podcast DIG report.

Some women were told the operation could be undone. Factory owners hired sterilized women first, and some women were told they would not get a job unless they were sterilized. Some employers opened clinics inside their factories where workers could be sterilized. Pregnant women were sometimes turned away from hospitals unless they agreed to be sterilized right after giving birth. The historians' accounts do not name the factories or the hospitals.

**If you remember one thing:** Doctors learned how to stop yellow fever and got penicillin to cure infections, and in the same years government doctors kept that cure from the Tuskegee men and infected people in Guatemala on purpose.

- 1900: Army doctors near Havana prove that mosquitoes spread yellow fever.
- 1932: Public Health Service doctors begin the Tuskegee study of 399 Black men with syphilis.
- 1942: Penicillin saves Anne Miller's life in New Haven.

**Next:** After 1950 a vaccine ended polio in the United States, and the Tuskegee study went on until a reporter made it public.

## 1950 to 2000

**Era 9 of 10 · 1950 to 2000 · about 24 minutes**

A vaccine ended polio in the United States in these fifty years, and new federal insurance paid for the care of older and poorer Americans, while reporters, judges and investigators exposed what doctors had done to people who never agreed. Doctors reported more than 21,000 Americans paralyzed by polio in 1952. A vaccine tested on about 1.8 million children was announced in 1955, and the last polio case caught inside the United States came in 1979.

President Lyndon Johnson signed Medicare, health insurance for people 65 and older, and Medicaid, for people with little money, in 1965. A reporter exposed the Tuskegee study in 1972, and a federal health official announced its end that November.

In the 1970s doctors in federally paid clinics sterilized poor Black women and girls, and doctors in the Indian Health Service sterilized Native women. Many of these women and girls never gave permission. Doctors reported the first cases of the disease later named AIDS in 1981. By the end of 2000, 448,060 Americans had died of it.

### Henrietta Lacks

> **Who:** A Black woman whose cancer cells doctors took without asking her. Her cells were the first human cells to keep growing in a laboratory.
>
> **When and where:** Johns Hopkins Hospital, Baltimore, 1951. Born Loretta Pleasant in Roanoke, Virginia, on August 1, 1920.
>
> **Movie:** *The Immortal Life of Henrietta Lacks* (2017), a drama made for HBO about her and her daughter Deborah.

**Doctors cut two samples from her cervix without asking her.**

Doctors at Johns Hopkins Hospital in Baltimore cut cells from Henrietta Lacks's body in 1951 without her permission or knowledge. Her cells were the first human cells to keep growing and dividing in a laboratory. At that time no rule required doctors to ask.

She grew up in Clover, Virginia, in a log cabin that had been slave quarters on a plantation. Her white great-grandfather and great-uncle had owned it. In January 1951 she went to Johns Hopkins with a lump in her womb. Doctors found cancer of the cervix, the opening of the womb. They treated her with radium placed inside her body, and then with X-rays. During her treatments, doctors cut the two samples.

Dr. George Gey grew the cells. They kept dividing, and they were named HeLa, from the first two letters of her first and last names. By 1954 Jonas Salk's team used HeLa cells in its polio vaccine work.

Another doctor, Chester Southam, injected HeLa cells into cancer patients, prisoners and healthy people to see whether cancer could be passed on. He did not tell the people he injected that the cells were cancer cells, and prisoners were hardly free to refuse.

The members of New York's Board of Regents, the state board that licenses doctors, later found Southam guilty of fraud, deceit and unprofessional conduct. Those are legal words for cheating, lying and breaking the rules of his profession. They put him on probation, a trial period under watch, for a year.

She died on October 4, 1951, at 31, after the cancer spread through her body. Her family did not learn about the cells until 1975. In 2021 her family sued a company, Thermo Fisher Scientific, for making money from HeLa cells without her permission, and the two sides settled in 2023.

### The polio vaccine, 1952 to 1979

Doctors in the United States reported more than 21,000 people paralyzed by polio in 1952. Fewer than 1 in 100 children who catch polio are paralyzed. When polio paralyzes the muscles used for breathing, the person needs a machine to breathe. The iron lung was a metal tube about seven feet long, and the patient lay inside it. Bellows, a pump with folding sides, changed the air pressure inside the tube to pull air into the lungs.

Jonas Salk of the University of Pittsburgh made a vaccine from polio virus that had been killed. The money for his work came from the National Foundation for Infantile Paralysis, a charity that later became the March of Dimes.

**The test.** Dr. Thomas Francis Jr. of the University of Michigan ran the test in 1954. About 1.8 million children in the United States, Canada and Finland took part, counting children who got no shot and were only watched. From April 26 to July 10, 1954, more than 443,000 children got at least one shot of vaccine. More than 210,000 got a placebo, a shot with no medicine in it. Neither the child nor the nurse knew which one it was.

The children were called Polio Pioneers, and their parents signed permission forms. The results were announced at the University of Michigan on April 12, 1955: the vaccine was 80 to 90 percent effective. It was approved for use the same year.

**The bad batch.** That April, Cutter Laboratories in Berkeley, California, made 120,000 doses that still held live virus. About 40,000 children who got it had a mild form of polio. Fifty-six were paralyzed, and five died.

The children passed the virus to others, and 113 more people were paralyzed and 5 more died. Cutter's managers took the vaccine off the market on April 27, 1955. At a hearing that June, members of Congress said the staff of the federal laboratory that was supposed to check the vaccine were mostly to blame, because they had not checked it closely.

Albert Sabin's vaccine, which people swallowed instead of getting a shot, was approved for use from 1961 to 1963. The last case of polio caught inside the United States was in 1979. Between 15 and 40 years after they got sick, 25 to 40 of every 100 people paralyzed by polio as children get new muscle pain and new weakness, which is called post-polio syndrome.

### Jonas Salk

> **Who:** The doctor who made the first polio vaccine and did not patent it.
>
> **When and where:** University of Pittsburgh, 1947 to 1955. Born in New York City in 1914.

**"Could you patent the sun?" he asked.**

Jonas Salk made the polio vaccine that was approved for use in 1955. He never took out a patent on it, the legal right to be the only one allowed to make and sell an invention.

He started work at the University of Pittsburgh School of Medicine in 1947. In 1952 he made a vaccine from polio virus that had been killed, so that it could not cause the disease.

Thomas Francis Jr. ran the 1954 test. Salk had first learned about viruses in Francis's laboratory in 1941. At first Salk did not want some children to get a dummy shot, because the dummy shot could not protect them against polio. He gave way, because only that kind of test could prove the vaccine worked.

The television reporter Edward R. Murrow asked Salk who owned the patent, and the question about the sun was Salk's answer. People at the charity that paid for the work and at the university had looked into a patent. They judged that the method was probably not new enough to patent. Salk died in La Jolla, California, in 1995.

### Paul Alexander

> **Who:** A Dallas boy paralyzed by polio at six who lived in an iron lung for more than 70 years and became a lawyer.
>
> **When and where:** Dallas, Texas, 1952 to 2024. Born in Dallas on January 30, 1946.

**He lived inside an iron lung for more than 70 years.**

Polio paralyzed Paul Alexander in 1952, during an outbreak in Dallas, when he was six. Within days he could not move below his neck or breathe on his own. Doctors saved him with a tracheotomy, an operation that cuts an opening in the front of the neck into the windpipe so that air can get in. Then they put him in an iron lung.

He learned to breathe outside the machine for hours at a time, starting in 1954, by swallowing air into his lungs. Every night he went back into it.

He held a stick in his mouth to turn pages, to paint, and later to type. He studied at Southern Methodist University and the University of Texas, earned a law degree in 1984, and worked as a lawyer in Dallas. In 2020 he published a book about his life, *Three Minutes for a Dog*.

"I've never thought of myself as a cripple," he said in 2017, using an old, unkind word for a person who cannot use part of the body. "I'm Paul Alexander, human being." Guinness World Records named him the longest-surviving iron lung patient. He died in Dallas on March 11, 2024, at 78.

### The Indian Health Service, 1954 to 1976

President Dwight Eisenhower signed the Indian Health Transfer Act in 1954. Under it, Public Health Service officials took over health care for Native people from the Bureau of Indian Affairs, the federal office that ran the government's dealings with Native nations. The new office was called the Indian Health Service.

That same year Dr. Thomas Parran reported to the Interior Department on the health of Alaska Natives. He wrote that they suffered "sickness, crippling conditions and premature deaths to a degree exceeded in very few parts of the world," meaning that people in very few places anywhere were sicker or died younger. Health care for Alaska Natives moved to the Indian Health Service in 1955, and its staff led the work against tuberculosis.

Under a 1959 law, Public Health Service workers could bring clean water and ways to get rid of sewage to reservations, and tribes took part in the decisions. In 1976 President Gerald Ford signed the Indian Health Care Improvement Act. Under it, Medicare and Medicaid could pay the Indian Health Service for the care its staff gave.

**By 1955:** Doctors had a polio vaccine that worked, and Public Health Service officials ran health care for Native people through the new Indian Health Service.

### New operations and new pictures of the body, 1954 to 1963

Dr. Joseph Murray moved a healthy kidney from Ronald Herrick into his identical twin brother, Richard, at a Boston hospital on December 23, 1954. Richard was dying of kidney disease. The body's defenses attack an organ from almost anyone else, which is called rejection. Because the twins were identical, Richard's body accepted the kidney. He lived eight more years, married and had two children.

Scientists at Brookhaven National Laboratory in New York built the first machine to make technetium-99m, a radioactive chemical, in 1958. A doctor injects a tiny amount into a patient. It gives off rays that a camera outside the body picks up, to make pictures of the bones, the heart and other organs. Doctors in the United States first reported scans with it in 1963. Doctors around the world now use it in tens of millions of scans a year.

### Fallout on Rongelap, 1954

United States scientists set off a hydrogen bomb called Castle Bravo at Bikini Atoll in the Marshall Islands on March 1, 1954. It was nearly three times as strong as they expected. Fallout, the radioactive dust and ash that falls after a nuclear blast, came down on Rongelap, an island of the Marshallese people about 110 miles away. It looked like snow, and children played in it.

Twenty-three Japanese fishermen on the boat *Lucky Dragon* got sick, and one died. More than 230 people were moved off Rongelap, Rongerik and Utirik. The Rongelap and Utirik people were moved about 72 hours after the blast. The accounts of the evacuation do not name who moved them or who decided when.

Radioactive iodine from the fallout collected in their thyroid glands, which sit in the neck. In the years after, doctors found more thyroid lumps and thyroid cancers among them. Staff of the Atomic Energy Commission, the federal office in charge of nuclear weapons and nuclear power, studied the exposed people. Doctors working for the United States government later gave them follow-up medical care.

### Radiation tested on people, 1944 to 1974

President Bill Clinton appointed a committee in 1994 to investigate radiation experiments paid for by the federal government. He acted after reports that doctors had injected plutonium, a radioactive metal, into hospital patients who did not know it. In its 1995 report the committee counted nearly 4,000 such experiments from 1944 to 1974. Researchers paid by the federal government had also run experiments on children and on prisoners.

The committee wrote that in the 1940s and 1950s it was common for doctors to use patients in research "without their awareness or consent." In some studies on children, the radioactive doses raised the children's lifetime risk of thyroid cancer. The committee also found studies in which patients died soon after receiving radiation doses as large as those given to treat disease.

Miners who dug uranium underground breathed radon, a radioactive gas that comes off uranium ore. At least several hundred of them died of lung cancer. The committee found that federal officials neither required the mines to be ventilated, which means fresh air pumped in, nor properly warned the miners. Under a 1990 law, the Radiation Exposure Compensation Act, some of the miners get payments from the government.

### Thalidomide, 1960 to 1962

Dr. Frances Kelsey, a new FDA reviewer, refused to approve thalidomide because the company's evidence was weak. The drug company Richardson-Merrell had asked the FDA for permission to sell it in 1960. It was a sleeping pill that doctors also gave pregnant women for morning sickness, and it was already sold in more than 20 other countries. For more than a year, under steady pressure from the company, Kelsey kept asking for more.

Doctors in Europe linked thalidomide in November 1961 to babies born with arms and legs that were very short or missing. Around the world more than 10,000 babies were born harmed by it, and about 40 of every 100 died at birth or soon after.

Richardson-Merrell staff had already given more than 2.5 million tablets to more than 1,000 American doctors to "test." Nearly 20,000 patients took them, and several hundred of those patients were pregnant. At least 17 American babies were born with thalidomide damage.

Company officials withdrew the application in March 1962. Members of Congress passed the Kefauver-Harris Amendments with no votes against in October 1962. Drug makers then had to prove that a drug worked, report its harms to the FDA, and get people's permission before testing drugs on them.

### Smoking and asbestos, 1954 to 1998

Surgeon General Luther Terry, the country's top public health doctor, released a report on smoking on January 11, 1964. Ten experts had written it after reading more than 7,000 articles. They found that smokers died at a rate 70 percent higher than non-smokers. The average smoker was 9 to 10 times as likely to get lung cancer, and a heavy smoker at least 20 times.

Smoking was the main cause of chronic bronchitis, a long-lasting swelling of the air passages, the experts found, and it was linked to emphysema and to heart disease.

Ten years earlier, in January 1954, the big tobacco companies had paid for an advertisement in more than 400 newspapers that disputed the studies linking cigarettes to lung cancer. In 1957 Surgeon General Leroy Burney said the evidence showed that smoking caused lung cancer.

Lung cancer grows in the cells that line the air passages of the lungs. It causes a cough that does not go away, trouble breathing, and coughing up blood. Smoking causes about 9 of every 10 lung cancers in men and 8 of every 10 in women. In emphysema, a lung disease, the thin walls between the lungs' tiny air sacs break down, so the person cannot get enough air.

Under a 1965 law, every pack of cigarettes had to carry a health warning. From 1970 cigarette ads were banned from television and radio. On April 14, 1994, the heads of seven tobacco companies told Congress that nicotine is not addictive. In a 1998 settlement, a deal to end lawsuits, the tobacco companies agreed to pay 46 states at least $206 billion over 25 years.

**Fibers in the lungs.** Asbestos is a group of minerals that split into thin fibers. Workers used it to insulate buildings and ships. Its fibers, breathed in, stay in the lungs and scar them. They cause lung cancer and mesothelioma, a cancer of the thin lining of the chest and belly. The sickness can start 10 to 40 years or more after the person breathed the dust.

Shipyard workers, insulation workers, miners and firefighters were among those who breathed it. Johns-Manville, the biggest maker of asbestos, went bankrupt in 1982 while facing thousands of lawsuits.

**By 1965:** Surgeon General Luther Terry's report had found smokers 9 to 10 times as likely to get lung cancer, and members of Congress had made drug makers prove that their drugs worked. The Tuskegee study was still running.

### Medicare and Medicaid, 1965 and 1966

Two thirds of Americans over 65 had incomes below $1,000 a year in 1950, and only 1 of every 8 had health insurance, a plan that pays doctor and hospital bills.

President Lyndon Johnson signed Medicare and Medicaid into law at the Truman Library in Independence, Missouri, on July 30, 1965. Former President Harry Truman was with him. Truman had asked Congress for national health insurance 20 years earlier. Medicare is health insurance for people 65 and older. Medicaid is health insurance for people with little money. Nearly 20 million people signed up for Medicare in its first three years.

**Separate wards.** Many hospitals still kept Black and white patients apart. In the South, the people who ran hospitals mostly put Black patients in separate basement wards or separate buildings, or turned them away. In many northern cities, hospital care was just as segregated through unwritten rules.

Judges of a federal appeals court ruled in 1963, in the case *Simkins v. Moses H. Cone Memorial Hospital*, that hospitals built with Hill-Burton money could not keep patients apart by race. The justices of the Supreme Court refused to take up the case in 1964.

**The inspectors.** The Civil Rights Act of 1964 barred federal money for any place that treated people differently by race, and Medicare payments to hospitals were set to begin on July 1, 1966. Before then, almost 1,000 federal workers volunteered to inspect about 6,000 hospitals. They checked beds, waiting rooms, lunch rooms and hiring.

Inspectors drove at high speed to get away from local groups of the Ku Klux Klan, a secret white group that used terror against Black people and their supporters. Some inspectors were jailed on false charges. Bullets were fired at their rental cars, and crosses were burned on the lawns of at least two of them. Several hospital workers who helped the inspectors had their homes bombed, and one may have been murdered, the historian David Barton Smith wrote. Smith's account does not name who jailed the inspectors, who fired, who burned the crosses or who set the bombs.

By July 1, hospitals holding 97 of every 100 beds for short-term care in the country had met the rule.

### Hepatitis experiments at Willowbrook, 1956 to 1971

Willowbrook State School on Staten Island, New York, was a state home for children with intellectual disabilities. It was built for 4,000 children and held 6,000 by 1965.

Dr. Saul Krugman of New York University and Dr. Robert McCollum of Yale ran experiments with hepatitis, a disease that inflames the liver, on children at Willowbrook from 1956 to 1971. In one study they fed 60 healthy children live hepatitis virus taken from other people's stool, their solid waste. The children's skin and eyes turned yellow, their livers swelled, and they vomited and would not eat. Every one of them became ill, some badly.

Parents signed permission letters, often because signing got their child a place in the crowded school. Critics said the letters played down that the children would be infected on purpose. At times the only beds open were in the study ward.

The television reporter Geraldo Rivera filmed the school's crowded wards and filthy bathrooms in 1972, and staff who beat and sexually abused the residents. That March, parents of 5,000 residents sued the State of New York. The last children left Willowbrook in 1987.

### The Tuskegee study ends, 1972 to 1997

The Tuskegee study ended in November 1972, four months after a reporter made it public. Peter Buxtun, a Public Health Service worker in San Francisco, had written in 1966 to the head of the service's office for diseases passed by sex, saying the study was wrong.

Officials of the CDC, the federal disease agency, ran the study by then. They decided to keep it going until every man had died. They also decided that doctors should then cut open each man's body and examine it. Members of local chapters of two doctors' groups, the National Medical Association and the American Medical Association, backed that decision. At a review in 1969 CDC officials decided again to keep it going.

**The story breaks.** In the early 1970s Buxtun went to the press. Jean Heller, a reporter for the Associated Press, wrote the story. It ran in the *Washington Star* on July 25, 1972, and on the front page of the *New York Times* the next day.

At the start of that year, 74 of the untreated men were still alive. In October a government panel advised stopping the study. In November 1972 Dr. Merlin DuVal, the top health official in the federal health department, announced the end of the study.

Senator Edward Kennedy held hearings in 1973, and federal officials began paying for the survivors' medical care. Their wives, widows and children were added in 1975. The men's lawsuit ended in a $10 million settlement out of court in 1974. Some accounts date it 1973.

**The new rule.** Members of Congress passed the National Research Act in 1974. Since then, a study on people that uses federal money must be approved by a review board. Every person in it must first be told what will be done and what the risks are, and must agree, which is called informed consent.

President Bill Clinton apologized at the White House on May 16, 1997, to five of the survivors, Charles "Charlie" Pollard, Herman Shaw, Carter Howard, Fred Simmons and Frederick Moss. "What the United States government did was shameful, and I am sorry," he said.

### Sterilized without consent, the 1970s

To sterilize a person is to operate so that the person can never have a baby. In an operation called a tubal ligation, a surgeon cuts or ties the two tubes that carry eggs from the ovaries to the womb. In a hysterectomy, a surgeon cuts out the womb.

A federal judge ruled in 1974 in the case of Minnie Lee and Mary Alice Relf, two Black sisters in Alabama who had been sterilized as children. The judge found that doctors in programs paid for by the federal government were sterilizing an estimated 100,000 to 150,000 poor people a year. Some doctors told women on welfare, government money for poor families, that they would lose it unless they agreed. The judge barred federal money for sterilizing people against their will, and barred the threats to cut off welfare.

### Minnie Lee and Mary Alice Relf

> **Who:** Two Black sisters in Alabama who were surgically sterilized as children through a federally paid clinic, after their mother was told they would get birth control shots.
>
> **When and where:** Montgomery, Alabama, June 1973.

**Their mother was told the girls would get birth control shots.**

Surgeons in Montgomery, Alabama, sterilized Minnie Lee and Mary Alice Relf in June 1973. The girls were 12 and 14, and accounts differ on which sister was older. The surgeons tied or cut the tubes that carry eggs to the womb, so the girls could never have children. No record names the surgeons.

Nurses from a family planning clinic had told their mother, Minnie Relf, about the shots. Montgomery Community Action ran the clinic with federal money. She could not read or write, and she signed the form with an X. Both girls had intellectual disabilities. The family lived in public housing that the same agency had found for them in 1971. In all, 11 children from the same clinic's program were sterilized, and 10 of them were Black.

Their father, Lonnie Relf, saw the scars when the girls came home from the hospital. The same day a nurse asked their sister Katie, who was 17, to agree to be sterilized. Katie locked herself in her room.

Lawyers from the Southern Poverty Law Center sued for the family in a case called *Relf v. Weinberger*. The federal officials they sued included Caspar Weinberger, the Secretary of Health, Education and Welfare, and Alvin Arnett of the Office of Economic Opportunity.

### Native and Puerto Rican women

**The Indian Health Service.** Investigators of the General Accounting Office, which checks how federal money is spent, reported on the Indian Health Service in 1976. In four of its 12 regions, its doctors had sterilized 3,406 Native women from 1973 to 1976. Writers for the National Library of Medicine and the National Archives describe the operations as done without the women's permission. Thirty-six of the women were under 21, although a federal judge had ordered that women that young not be sterilized.

The investigators' report does not name the doctors. Two years before it, in 1974, Dr. Connie Pinkerton-Uri, who is Choctaw and Cherokee, had found in her own study that 1 in 4 Native women had been sterilized without consent.

**One woman's case.** Norma Jean Serena, who was Shawnee and Creek, gave birth in Armstrong County, Pennsylvania, on August 16, 1970. Two days later Drs. Donald Carter and James Houston cut out her fallopian tubes, the tubes that carry eggs to the womb. She said no doctor ever told her. A welfare caseworker, Jean Burgess, had advised the operation. Burgess later said, "This was a burden on society. I felt that Mrs. Serena should have no further children."

Burgess and two other county child welfare workers, Patricia Walker and Natalie Leezer, had also taken three of Serena's children from her in 1970. Serena sued in 1974. The jurors found that the welfare workers had given a false picture of the children's health and of how long the children would stay in foster homes. They awarded her $17,000 for the taking of her children.

On the operation, the same jurors found against her. They decided that she had agreed to it, though she said no doctor ever told her about it.

In Puerto Rico, about 1 in 3 women of child-bearing age had been sterilized by 1968, and 37.4 of every 100 by 1976, historians on the history podcast DIG report. Some chose it because it was the only birth control offered to them. Others were told it could be undone, or were pushed into it by their employers.

### AIDS, 1981 to 2000

CDC doctors reported a rare kind of pneumonia in five young gay men in Los Angeles on June 5, 1981. Two of them had died. The disease was later named AIDS. It is caused by HIV, a virus that destroys the white blood cells that fight infection. As those cells die, other infections and cancers kill the person. HIV passes through blood, semen and other body fluids, not through touch.

More Americans were diagnosed with AIDS in 1985 than in all earlier years together. By early 1986 about half of the adults ever diagnosed had died, and patients died about 15 months after they were diagnosed. People with hemophilia, whose blood does not clot, took a clotting medicine made from blood given by many donors. Of those treated with it between 1979 and 1984, nearly 9 in 10 caught HIV, hepatitis C or both.

**ACT UP.** The writer Larry Kramer started ACT UP, the AIDS Coalition to Unleash Power, in New York in March 1987. That month FDA officials approved AZT, the first drug for AIDS. On October 11, 1988, more than 1,000 ACT UP members shut down FDA offices in Maryland, and police made 176 arrests. Eight days later FDA officials announced rules to approve drugs faster.

AIDS was the leading cause of death for Americans aged 25 to 44 in 1994. From 1996, doctors gave several drugs together, and the next year AIDS deaths fell by 47 percent. By the end of 2000, 774,467 Americans had been reported with AIDS, and 448,060 of them had died.

### Ryan White

> **Who:** An Indiana teenager who caught HIV from his hemophilia medicine, was kept out of school, and then spoke across the country about AIDS.
>
> **When and where:** Kokomo and Cicero, Indiana, 1984 to 1990. Born in Kokomo on December 6, 1971.
>
> **Movie:** *The Ryan White Story* (1989), a film made for ABC television. Ryan White had a small part in it.

**When he came back to school, 151 of 360 students stayed home.**

Ryan White was 13 when doctors told him, on December 17, 1984, that he had AIDS. They gave him six months to live. He had hemophilia and took a clotting medicine made from blood given by many people. Some of it carried HIV.

James O. Smith, the head of his school district, refused in 1985 to let him back into Western Middle School. In all, 117 parents and 50 teachers signed a petition, a written request, to keep him out. Health officials of the state and the CDC said he was no danger to anyone. When he went back for one day in February 1986, 151 of the school's 360 students stayed home.

After he returned, school staff made him use throwaway forks and spoons and a separate bathroom. Someone fired a bullet through his family's living room window while no one was home.

The family moved to Cicero, Indiana. On his first day at Hamilton Heights High School, the principal, Tony Cook, and students who had learned about AIDS shook his hand. In 1988 he spoke to a presidential commission on AIDS. He died on April 8, 1990, at 18. That August, members of Congress passed the Ryan White CARE Act. Under it, federal money pays for care for people with HIV.

**If you remember one thing:** A vaccine ended polio in the United States and Medicare paid for older Americans' care, while reporters and judges exposed experiments and operations done to people who never agreed.

In 1952: Polio paralyzed more than 21,000 Americans, and the Tuskegee men were being kept from penicillin.

In 2000: No one had caught polio inside the United States since 1979, Medicare paid for the care of people 65 and older, and a federally paid study on people needed each person's informed consent.

**Next:** After 2000 doctors learned to edit genes, and COVID-19 killed more than a million Americans.

## 2000 to Today

**Era 10 of 10 · 2000 to Today · about 8 minutes**

COVID-19 and drug overdoses cut American lives short in these years, even as doctors learned to edit the genes in a patient's own cells to treat sickle cell disease. COVID-19 killed 1,245,791 people in the United States from 2020 to September 19, 2026, by the early count of the CDC, the federal disease agency. Drug overdoses killed more than 100,000 Americans a year in 2022 and 2023.

Life expectancy, the average age a newborn would reach if that year's death rates held, fell from 78.8 years in 2019 to 76.4 in 2021. It was back to 79.0 in 2024, federal health officials who count births and deaths reported in January 2026. President Barack Obama signed the Affordable Care Act in 2010. In 2025, 26.7 million people had no health insurance all year, the Census Bureau reported in September 2026.

### Reading and editing genes, 2003 to 2023

A genome is the full set of DNA instructions in a person's cells. Scientists of the Human Genome Project, begun in 1990, finished the first reading of the human genome in April 2003.

Sickle cell disease bends red blood cells into a curved shape like a sickle, a farm tool with a curved blade. The bent cells slow the flow of blood in small blood vessels and carry less oxygen. That causes attacks of severe pain, and it can disable or kill a person. About 100,000 people in the United States have it, the Food and Drug Administration reported in 2023. It is most common in African Americans.

FDA officials approved Casgevy on December 8, 2023. It was the first treatment made with the gene-editing tool called CRISPR that the FDA has approved. Doctors take some of the patient's blood-making cells and edit their DNA. Then the patient gets high doses of chemotherapy, strong drugs that kill the cells left in the bone marrow. Doctors put the edited cells back in a single drip into a vein.

### The Affordable Care Act and the uninsured, 2010 to 2026

The Census Bureau counted 49.9 million people in the United States with no health insurance in 2010. That was 16.3 percent of everyone, about 1 person in 6.

President Obama signed the Patient Protection and Affordable Care Act on March 23, 2010. Members of the House had passed it 219 to 212. Most of its parts started in January 2014. Lawmakers in many states opened Medicaid to more adults with low incomes, and people could buy insurance on new insurance marketplaces, websites where people compare plans and sign up. By 2016, about 20 to 24 million more people had insurance, and the share without it had fallen by about half.

The Census Bureau reported on September 15, 2026, that 26.7 million people, or 7.9 percent, had no insurance for the whole of 2025. That is about 1 person in 13. Census Bureau staff changed their survey questions in 2013, so the 2010 and 2025 counts were not measured in exactly the same way.

**New Medicaid rules.** President Donald Trump signed a budget law with new rules for keeping Medicaid on July 4, 2025. From 2027, adults who got Medicaid when their state widened it under the Affordable Care Act must show 80 hours a month of work or similar activity to keep it. They can instead show a reason they are excused. In July 2025 staff of the Congressional Budget Office, which estimates the cost of laws for Congress, estimated that 10 million more people would have no insurance in 2034 because of the law.

Extra federal help with the price of marketplace insurance ended after 2025. In 2026, sign-ups fell by more than a million, to 23.1 million, the health research group KFF reported. The average monthly payment rose from $113 to $178.

Rural hospitals have closed too. Since 2005, 197 rural hospitals have closed or stopped keeping patients overnight, by the December 2025 count of the Sheps Center at the University of North Carolina.

### COVID-19, 2020 to 2026

COVID-19 is an illness caused by a coronavirus. It spreads when an infected person breathes out droplets and tiny particles that carry the virus. It causes fever, cough, shortness of breath and loss of taste or smell. In severe cases the person has trouble breathing and pain or pressure in the chest, becomes confused, and the lips or skin turn pale, gray or blue.

The first case in the United States was confirmed in a laboratory on January 20, 2020. On March 11, 2020, officials of the World Health Organization declared a pandemic, a disease spreading around the world. FDA officials allowed the first vaccine on December 11, 2020. Recorded deaths in the United States passed 500,000 on February 21, 2021, and 1 million on May 12, 2022. The federal health emergency ended in May 2023.

The CDC's early count, as of September 24, 2026, is 1,245,791 COVID-19 deaths from 2020 to September 19, 2026. The year with the most deaths was 2021, with 463,267. In 2025 there were 20,682. These early counts rise as late death records come in.

For American Indian and Alaska Native people, life expectancy fell from 71.8 years in 2019 to 65.2 in 2021. That was a drop of 6.6 years, federal health officials who count births and deaths reported in 2022, and it brought them to the same life expectancy that all Americans had in 1944. COVID-19, accidents and liver disease caused most of that drop.

### Sandra Lindsay

> **Who:** A nurse who led the intensive care nurses at a hospital in Queens through the pandemic, and was the first American outside a vaccine trial to get a COVID-19 vaccine.
>
> **When and where:** Long Island Jewish Medical Center, Queens, New York, 2020 and 2021. She came from Jamaica.

**She got the first COVID-19 vaccine given outside a trial.**

Sandra Lindsay got that shot on Monday, December 14, 2020, the first given in the United States outside a trial. She directed the nurses who cared for the sickest COVID-19 patients at Long Island Jewish Medical Center in Queens, New York.

She had questions about the vaccine at first. She did her own research and listened to experts before she decided. "We needed a more powerful tool," she said.

During the pandemic her aunt died, and she could not be with her mother. Her grandson Avery was born too soon, in March 2020, and spent about four and a half months in a hospital unit for newborns. Lindsay could not sleep or focus, and she began to meditate.

President Joe Biden gave her the Outstanding Citizen By Choice award, which honors immigrants who became citizens, on July 2, 2021. Her hospital scrubs and her ID badge went to the Smithsonian's National Museum of American History.

### Opioids and overdose deaths, 1999 to 2026

Opioids include strong painkillers such as oxycodone and fentanyl, and the illegal drug heroin. Too much of one slows a person's breathing, and the person can die. Fentanyl is 50 to 100 times stronger than morphine. A drug called naloxone reverses an overdose if someone gives it quickly.

The CDC describes three waves of deaths. The first came from pain pills, after doctors in the 1990s began writing more prescriptions, or written orders, for opioids. The second came from heroin, from 2010. The third came from fentanyl made illegally, from 2013. From 1999 to 2023, about 806,000 Americans died of opioid overdoses, the CDC counted in 2026.

**Guilty pleas.** Purdue Pharma, the maker of the pain pill OxyContin, pleaded guilty in 2007 to misleading the public about how easily people became addicted to it. It paid $600 million. Three of its leaders, Michael Friedman, Howard Udell and Paul Goldenheim, pleaded guilty too. Purdue pleaded guilty to federal crimes again in 2020.

Fifty-five attorneys general, the top lawyers of state and territory governments, joined a $7.4 billion settlement with Purdue and the Sackler family, who owned it, on June 16, 2025. In the settlement, Purdue and the Sacklers agreed to pay money to end lawsuits against them.

FDA officials approved a naloxone nasal spray for sale in stores without a doctor's order on March 29, 2023. Overdose deaths from all drugs peaked at about 112,000 in the 12 months ending August 2023. The CDC's early count for the 12 months ending April 2026 is about 67,000. About 42,000 of those deaths involved opioids.

### Smoking, measles and vaccines, 2006 to 2026

US District Judge Gladys Kessler ruled on August 17, 2006, that the big tobacco companies had cheated the public. In her words, they had "defrauded the American people by lying for decades about the health risks of smoking and their marketing to children." Smoking and breathing other people's smoke still kill more than 480,000 Americans a year, by the CDC's count last updated in 2024. That is nearly 1 of every 5 deaths in the country.

Measles is a disease caused by a virus. It spreads through the air when an infected person coughs or sneezes, and a person can catch it in a room up to 2 hours after the sick person has left, CDC doctors write. It starts with a high fever, a cough and red, watery eyes, and then a rash spreads down from the face.

As many as 1 of every 20 children with measles gets pneumonia, the most common way measles kills young children. About 1 child in 1,000 gets a swelling of the brain.

Measles had stopped spreading nonstop inside the United States for at least a year by 2000, which health officials call elimination. In 2025 there were 2,289 confirmed cases and 3 deaths, by the CDC's count. In an early count of 2,144 of those cases, 93 of every 100 were in people who had not been vaccinated. In 2026, by September 24, the CDC had counted 3,659 cases and 1 death.

**The vaccine panel.** Robert F. Kennedy Jr., the Secretary of Health and Human Services, removed all 17 members of the panel of experts that advises the CDC on vaccines on June 9, 2025. He wrote that the panel had become "little more than a rubber stamp for any vaccine," meaning a panel that approved every vaccine it was shown. Leaders of the American Medical Association said the move "upends a transparent process that has saved countless lives," meaning it threw out an open way of deciding about vaccines.

### The last of the Tuskegee men

The last man from the Tuskegee study died in January 2004. The last widow in the benefit program died in January 2009. CDC officials report that 10 of the men's children receive medical care through the program.

**The three questions, answered**

- Why did new diseases kill so many Native people after 1492? The crowd diseases, such as smallpox and measles, had never reached the Americas, so nobody here was immune and a whole town could fall sick at once. Smallpox killed about half of the Cherokee in 1738 and 1739.
- How did Americans learn to stop smallpox, yellow fever and polio? Boston doctors tried inoculation in 1721, using a method Onesimus described, and safer vaccination followed in 1800. Army doctors proved in 1900 that mosquitoes spread yellow fever, and after the Salk and Sabin vaccines the last polio case caught inside the country came in 1979.
- Who was used in medical experiments without agreeing, and what changed because of it? Enslaved women operated on by J. Marion Sims, the Black men of the Tuskegee study, prisoners and patients in Guatemala, and children at Willowbrook. After the Tuskegee study became public, members of Congress passed the National Research Act in 1974, and researchers in a federally paid study on people must now get each person's informed consent.

**What changed:** At the start of this chapter nobody knew what caused disease, and by its end doctors could prevent polio and measles with vaccines and edit the genes in a patient's own cells.

**Five dates to keep**

- 1721: Boston doctors inoculate against smallpox.
- 1900: Army doctors near Havana prove that mosquitoes spread yellow fever.
- 1932: Public Health Service doctors begin the Tuskegee study.
- 1955: The polio vaccine is shown to work and approved for use.
- 2020: COVID-19 reaches the United States.

**Not known:** Nobody knows how many people lived north of Mexico in 1492, so nobody knows how many died of the new diseases.

**Where to go:** Elizabeth Phillips's gravestone, in the Phipps Street Burying Ground in Charlestown, Massachusetts, says she "brought into this world above 3000 Children."

**Next:** Chapter 27, Disasters and Rescue. It follows fires, floods, storms and other sudden disasters, and what people changed after them.
