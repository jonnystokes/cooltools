# Chapter 6: City Building

**Chapter 6 of 37 · City Building · 10 eras · about 90 minutes**

**American cities were built by people who decided where the streets, pipes and buildings would go, and who could live where.**

About 600 men lifted a row of brick and stone buildings on Lake Street in Chicago in 1860. The row was 320 feet long, and with its sidewalks it weighed about 35,000 tons. The men turned about 6,000 lifting screws, and in five days the whole row rose 4 feet 8 inches, up to a new street that crews had built on top of the city's sewers. The shops inside stayed open the whole time, and people kept shopping while the buildings rose.

This chapter follows American cities in order, from the earth mounds of Cahokia to the empty office towers of today. As you read, watch the problems people were trying to fix: fire in wooden towns, sickness from dirty water, streets of mud, families packed into dark rooms. And watch who got to live where. Every colonial town and boomtown here went up on a Native nation's land. In the 1900s, white owners and judges kept Black families out of most neighborhoods, and federal officials refused to back home loans where Black families lived. Later, officials cleared whole neighborhoods for developers and ran freeways through others.

**Three questions this chapter answers**

- Why do so many American cities have straight streets that cross in a grid?
- How did people get clean water into crowded cities?
- Who decided which families could live in which neighborhoods?

**Five minutes?** Read "Central Park and Seneca Village" in 1850 to 1900.

**Can skip:** "Which tower would be tallest?", "Growth in the Sun Belt", "The tallest buildings now stand in other countries". The chapter still makes sense without them.

## Before 1500

**Era 1 of 10 · Before 1500 · about 4 minutes**

Hundreds of years before any European came, people on this land built planned cities, deciding ahead of time where each open square, wall and mound would go. They built them between about 900 and about 1350. The largest stood beside the Mississippi River. In the Southwest, people cut and stacked stone to build towns, and their descendants still live in towns along the Rio Grande.

The people who built these places kept no written records, and no builder's, planner's or ruler's name survives. Archaeologists, the scientists who dig up and study what people left behind long ago, know them only from the mounds, walls, rooms and roads they left.

### Cahokia, a city laid out on purpose

People built up the city of Cahokia quickly from about 1050, in what is now Illinois, across the Mississippi River from St. Louis, Missouri. It was the largest town north of Mexico before Europeans came. At its peak, around 1100, roughly 10,000 to 20,000 people lived in the center, about as many as lived in London at the same date. Some estimates put as many as 50,000 people in the wider settlement around the center, but those larger estimates do not agree with one another.

The people of Cahokia planned where the big pieces of their city would go. At its center they raised Monks Mound. It is the largest prehistoric structure made of earth in the Americas, built before anyone here kept written records. The mound holds about 814,000 cubic yards of earth. Workers carried every basketload of it by hand, and they raised the mound in stages.

**The mound.** It has four terraces, or wide steps, and its top stands about 100 feet high. Its base covers roughly 14 acres. The World Heritage listing for Cahokia, kept by UNESCO, the United Nations body for historic sites, records fourteen separate building stages in the mound.

The Grand Plaza, about 50 acres of open ground, lay at the foot of the mound. Its builders leveled it by hand and filled in the low spots, to make a flat field for ceremonies and for the game of chunkey. In chunkey, one player rolled a stone disk across the ground, and the players threw spears to see whose spear landed closest to the spot where the stone stopped.

West of Monks Mound the builders set up a circle of red cedar posts. They built five of these circles, one after another, and each new circle took the place of the last.

**A calendar of posts.** The posts line up with the points on the horizon where the sun rises on four days of the year. Two are the solstices, the longest day and the shortest day. The other two are the equinoxes, the days between them when day and night are the same length. So the posts worked as a calendar, and the builders set them into the plan of the city.

A palisade, a wall of upright logs about two miles long, ran around the central part of the city. People began it around 1100 and rebuilt it three times over about two hundred years. Each rebuilding took between 15,000 and 20,000 logs of oak and hickory, each roughly a foot thick and twenty feet tall.

The people of Cahokia had scattered and left the city by about 1350.

### Stone towns of the Southwest

Chaco Canyon, in what is now northwestern New Mexico, was the center of the Ancestral Puebloan world. The Ancestral Puebloans were the ancestors of the people who live in the pueblos of the Southwest today. Spanish colonists later used pueblo, their word for a town, for the towns of stone and adobe, or sun-dried mud brick, that they found there.

At Chaco the people built great houses, large buildings of shaped stone. They went on building and using the great houses for roughly 280 years, from about 900 to about 1180. One of them, Pueblo Bonito, had more than 650 rooms.

The people of Chaco planned their roads too. The roads run straight for miles across the Four Corners country, where Colorado, Utah, Arizona and New Mexico meet. They average about 30 feet wide, and they connected farther-off villages to the canyon.

At Mesa Verde, in southwestern Colorado, people built rooms of sandstone blocks and mud into the hollows under overhanging cliffs. They built Cliff Palace, the largest of these cliff dwellings, between 1190 and 1280. It has 150 rooms and 23 kivas, round rooms used for ceremonies and meetings and usually sunk into the ground. More than 100 people lived there.

People began leaving Chaco in the 1140s, and by about 1180 to 1200 they had stopped building and living in the canyon. People had left Mesa Verde by the 1280s. The people who left both places gathered again in the pueblo towns along the Rio Grande, and their descendants still live in those pueblos.

## The 1500s

**Era 2 of 10 · The 1500s · about 3 minutes**

The oldest lasting European town on the US mainland began inside a Timucua town. Eight years after Spanish colonists founded it, the king of Spain set written rules for how every new Spanish town must be laid out.

### St. Augustine and the Laws of the Indies

Pedro Menéndez de Avilés landed on the coast of Florida on September 8, 1565, with about 800 colonists, among them 26 women and an unknown number of enslaved Africans. He placed his town, St. Augustine, inside Seloy's town, a town of the Timucua people whose chief was named Seloy. Chief Seloy offered Menéndez his council house, and the colonists used it as their first fort. Timucua council houses were round and roofed with thatch, dried straw or reeds, and they were big enough to hold up to a thousand people.

Within months the Timucua had tired of the Spaniards living in their town, and they attacked them again and again to drive them away. In 1566, according to the Florida Museum of Natural History, the Timucua shot flaming arrows at the fort. The fort was the Timucua's own council house, and the museum's account states that this is why the attack did so much harm. On April 1, 1566, half of the fort burned, and the Spaniards lost all their supplies.

**Three places in seven years.** Menéndez moved the settlement across the bay to Anastasia Island in May 1566, about nine months after landing. There the Spaniards felt safer from attack, and they lived on the island for about six years. By about 1572 they had moved back to the mainland, to the site of today's St. Augustine.

Through both moves, people went on living in the town. Of all the cities Europeans founded on the mainland of the United States, St. Augustine is the oldest one that people have lived in the whole time.

King Philip II of Spain issued the Laws of the Indies in 1573. They were written orders for Spain's lands in the Americas, which the Spanish called the Indies, and they stated exactly how the men who founded Spanish towns had to lay them out.

Each town began with a central plaza, a public square of open ground with the town built around it. The plaza's sides had to face north, south, east and west, and it had to be one and a half times as long as it was wide. The streets ran out from it in a grid, straight streets crossing at right angles. The founders had to set aside certain lots, or pieces of land, for the church and for the government buildings.

St. Augustine's Plaza de la Constitucion was laid out under those orders, after the town already existed. It is the oldest public square in the country. Government buildings and the church faced onto it, and traders began holding a market there in 1598.

The 1573 orders were among the first written rules anywhere in the world that specified the same town plan for every new town, wherever Spanish officials founded one. Across what is now the Southwest, Spanish town-builders went on laying out towns in the same plaza-and-grid pattern.

## The 1600s

**Era 3 of 10 · The 1600s · about 7 minutes**

Each colonial town of the 1600s went up in the homeland of a Native nation, and some were planned while others simply grew. English colonists began Jamestown in 1607 as a fort. Spanish officials laid out Santa Fe around a plaza. Boston, founded in 1630, had no plan at all, and its streets formed around the houses and the hills.

William Penn planned the most. In 1682 he had his surveyor, the man who measured the land and marked out the streets, draw the whole of Philadelphia on paper before a single street existed on the ground. The founders of many early American towns later followed Penn's example.

### Fort towns, walls, and watchmen

Three English ships sailed into the Chesapeake Bay on April 26, 1607, with 144 English men and boys. They settled on Jamestown Island, on the James River in Virginia. The island lay inside the land of the Paspahegh people, who hunted there and had a town about four miles away. The Paspahegh were one of 28 to 32 nations, each with its own chief, that paid tribute, a payment of goods, to one ruler, Powhatan.

The Paspahegh attacked the newcomers on May 26. By June 15 the colonists had finished James Fort, a three-sided fort. Its wall was a stockade, a fence of upright oak and poplar logs about 14 feet high. In the 1620s the surveyor William Claiborne laid out a settlement east of the fort called New Towne, and archaeologists have dug up the foundations of rows of houses there.

Governor Pedro de Peralta founded Santa Fe about 1610 and planned it around a central plaza, in the Spanish pattern. He and his men laid it out at the foot of the Sangre de Cristo Mountains, on the ruins of an older Pueblo town. The Tewa people call that place O'Ga P'Ogeh, which means "white shell water place." The Palace of the Governors stands on Santa Fe's plaza. People have used it as a public building without a break for longer than any other building in the United States.

English colonists founded Boston in 1630 without any plan, on a peninsula that the Massachusett people called Shawmut, a piece of land with water on almost every side. The colonists put their houses up near the waterfront, and the streets formed around the hills, brooks and marshes that were already on the ground. The biggest hill was the Trimountain, a steep hill with three tops, which is now called Beacon Hill.

**The cow-path story.** According to a well-known story, Boston's crooked streets follow old cow paths. The story is a legend. A writer for Boston Magazine checked it in 2018 and traced it to a line that the American writer Ralph Waldo Emerson wrote in 1860.

Boston's first houses had chimneys made of wood and roofs made of thatch, and several of them burned in the colony's first months. Thomas Dudley, one of the colony's leaders, wrote a letter to the Countess of Lincoln in March 1631. In it he wrote that he and the other leaders had ordered "that noe man shall build his chimney with wood nor cover his house with thatch." The fires, he wrote, always began "in the wooden chimneys."

The people of Boston set up a night watch that same year. The watchmen walked the streets at night to guard the town against criminals, wild animals and fire. The Boston Police Department's own history lists that watch as the start of the city's police.

Wall Street in New York City runs along the line of a wall that is long gone. The wall ran across the northern edge of New Amsterdam, the Dutch town on the southern tip of Manhattan, in the homeland of the Lenape people. It stretched from the East River to the North River, which is now called the Hudson.

**Who dug it.** A gang of Black men dug a trench across the island for the wall in 1653. The Dutch West India Company, the trading company whose officials ran the colony, owned them. Some of the men had gained what the Dutch called half-freedom: a half-free man could hold land of his own, but he still owed the Company work and a yearly payment, and his children stayed the Company's property.

According to a Columbia University history project, the men dug as long as daylight allowed, all the way from the East River to the Hudson. The town's records show what went up along that line: a wall of planks 9 feet high, nailed to posts, from river to river. The officials had first planned a wall of sharpened logs 12 feet long, but nobody would build it for the price they offered, so they changed the plan to planks.

**Who ordered it.** Petrus Stuyvesant and the town's officials ordered the wall on March 13, 1653. Stuyvesant was the director general, the man who governed the Dutch colony of New Netherland for the Company. He and the officials had heard that the English in New England were preparing to attack.

In April, Stuyvesant's council gave out the rest of the work. The townsmen, "without exception," had to dig a ditch in front of the wall from river to river. The ditch was 4 to 5 feet deep and 11 to 12 feet wide, a much bigger hole than the trench, and it was there to slow down attackers. The soldiers, the other servants of the Company and the half-free Black men, "no one excepted," had to finish building up the town's fort.

So the order sent the half-free Black men to the fort, not to the ditch. The city's archivists write that enslaved and free workers built the wall itself together. The officials put the cost at 3,166 guilders, the Dutch money of the time. Townsmen paid that money in, and the minutes of the officials' meetings, their written record, name the men who paid. Officials reported the wall finished on July 28, 1653.

The Columbia project names three of the men who dug the trench: Paulo d'Angola, Simon Congo and Anthony Portuguese. All three were half-free. They were among eleven enslaved men who had worked for the Company for eighteen or nineteen years. The eleven asked the colony's council to free them, saying the Company had promised them their freedom.

The Company's director at the time, Willem Kieft, and his council granted half-freedom to the eleven men and their wives on February 25, 1644, nine years before the wall, on conditions. Kieft and his council gave the men plots of land north of the town. But their children, "at present born or yet to be born," stayed the property of the Dutch West India Company.

Each of the eleven owed the Company a yearly payment that Dutch colonists did not owe: 30 skepels (a Dutch measure for dry goods) of grain or beans, plus one hog. And whenever the Company's officials called, each had to come back and work for the Company.

A rattle watch began walking the streets of New Amsterdam on August 12, 1658. Its members were paid night patrolmen who carried wooden rattles, noisemakers that clack loudly when spun. The rattle watch was among the first paid public police forces in America.

### Philadelphia, drawn before it was built

William Penn made Thomas Holme the surveyor-general, or chief surveyor, of his colony of Pennsylvania in 1682. The land along the Delaware River was the homeland of the Lenape people. When Penn's colonists arrived, about 2,500 Lenape and about 3,000 Europeans lived on the two sides of the river. The Europeans were Dutch, Swedish and Finnish settlers, and English settlers in West New Jersey.

Penn bought land in southeastern Pennsylvania from the Lenape from 1682 to 1684, paying goods worth at least 1,200 English pounds. He landed on October 28, 1682, and Holme laid out the grid of Philadelphia that December. Holme's map, "A Portraiture of the City of Philadelphia," was printed in 1683. Penn used the map to guide the work, and to advertise the town and draw settlers to it.

### William Penn

> **Who:** The founder of Pennsylvania, a Quaker (a member of the Religious Society of Friends, a Christian group that began in England in the 1600s), who had Philadelphia planned on paper before it existed on the ground.
>
> **When and where:** The grid laid out by his surveyor-general Thomas Holme in December 1682, and Holme's map published in 1683.
>
> **Movie:** *Penn of Pennsylvania* (1941), released in the United States as *The Courageous Mr. Penn* (1942). The film is about Penn's life in general, not the making of the city plan.

**Holme drew the streets wide partly because London had burned in 1666.**

In his instructions for laying out the town, Penn asked for "a greene Country Towne which will never be burnt, and always be wholesome," meaning healthy to live in.

Holme drew a straight grid on the land between the Delaware and the Schuylkill rivers. Two wide main streets crossed it, Broad Street and High Street, which is now called Market Street. Holme drew the streets wide, partly because of the fire that burned London in 1666. Where the two main streets crossed, he placed a large central square, with one smaller public square in each of the four quarters of the town.

All five squares are still there. The four quarter squares are called Logan, Franklin, Washington and Rittenhouse squares, and Philadelphia's City Hall stands on the center square.

## 1700 to 1750

**Era 4 of 10 · 1700 to 1750 · about 2 minutes**

As the four biggest colonial ports grew to between 8,000 and 13,000 people each, the people in them organized to fight fire. Around 1750 about 13,000 people lived in Philadelphia, about 12,000 in Boston, about 11,000 in New York, and about 8,000 in Charleston, though some of the Charleston counts come from 1760 rather than 1750. London at the same date had over 700,000 people.

Boston was the busiest port until about 1750, when New York and Philadelphia passed it.

### Who fought fires in a wooden town?

Town officers and volunteers fought the fires. In Boston, a fire burned through the town on October 2 and 3, 1711. It destroyed some of the town's main buildings and left many families without homes.

A few months later, twelve men became Boston's first Board of Fire Wards, a group of town officers for fires. The Boston Public Library's guide to the city's great fires does not state who chose them or list their duties. Charleston had "firemasters," officers chosen by a vote. At a fire, everyone had to obey a firemaster's orders as if they were the law.

People in Boston also formed mutual fire societies, groups whose members helped one another. The members of each society agreed to protect one another's houses, and they had no duty to fight a fire at the house of anyone outside the society.

Men in Philadelphia went further in 1736. They formed a company of volunteers who agreed to fight a fire at any house in the town.

### Benjamin Franklin

> **Who:** A Philadelphia printer who helped start the first volunteer fire company in the colonies that protected a whole town, not only its own members.
>
> **When and where:** Philadelphia, December 7, 1736.

**Every member had to bring six leather buckets to every fire.**

Franklin printed a newspaper, the *Pennsylvania Gazette*. On February 4, 1735, he printed an unsigned letter in it, "On Protection of Towns from Fire," which he had written himself. In the letter he warned people about carrying live coals from room to room. His advice began with the line "an Ounce of Prevention is worth a Pound of Cure." The next year he and other men in the city set up a fire company themselves.

About twenty-five men, Franklin among them, signed the Articles of the Union Fire Company, the written rules of the group, on December 7, 1736. Each member had to bring six leather buckets and two strong linen bags to every fire. Members carried water in the buckets, and they used the bags to pack up people's belongings and carry them out of a burning house.

Every member had to come out at every fire alarm, to any house in the town, whether its owner was a member or not. Other Philadelphians soon set up more fire companies, among them the Heart-in-Hand, the Britannia and the Fellowship, and Franklin encouraged them.

Volunteer companies fought the fires in American towns for more than a hundred years. Then, on April 1, 1853, firefighters in Cincinnati, Ohio, began work as the first fire department in the United States whose firefighters were all paid. Miles Greenwood was their first chief.

## 1750 to 1800

**Era 5 of 10 · 1750 to 1800 · about 9 minutes**

The leaders of the new country had their capital city drawn on paper before anyone built it, on ground where three Native towns had once stood. The members of Congress put the capital on the Potomac River by a law of 1790, and in 1791 President George Washington chose the exact ground. By the spring of 1791 the chosen square held two towns that shipped tobacco, and enslaved people worked the farmland around them. Pierre L'Enfant drew the whole city on paper that year.

In Philadelphia, yellow fever killed about one person in every ten in 1793. After the fever came back in 1798, workers there built the first public waterworks in the country driven by steam.

### The ground the capital was built on

President George Washington signed the Residence Act, a law the members of Congress had passed, on July 16, 1790. In it they placed the capital somewhere on the Potomac River, inside a square no bigger than ten miles on each side. They left it to Washington to say exactly where, and to appoint a surveyor and three commissioners, officials put in charge of building the capital.

Washington rode out and looked at the country himself. He chose the ground at and beside Georgetown, and he told Congress his choice on January 24, 1791.

Three Native towns had stood inside that square of land. The largest was Nacotchtank, on the southeast side of the Anacostia River, and the river's name comes from the town's name. A second town, Nameroughquena, stood on the west bank of the Potomac, across from today's Theodore Roosevelt Island. The third stood on a bluff, a high, steep bank, in the northwest part of today's city, and the record does not give its name.

Captain John Smith reached that stretch of the Potomac in 1608. Within forty years of that first contact, only about a quarter as many Native people lived in the region as before 1608, according to a National Park Service history of the Native peoples of Washington. Many had died of diseases that Europeans brought, and others had been killed in wars, though the Park Service history does not say who fought them. Others joined nations to the north, south and west.

Two towns stood inside the square by the spring of 1791, and both are still there. Virginia's colonial lawmakers voted to create the town of Alexandria in 1749. The county surveyor, John West, laid out its first sixty acres around Hugh West's tobacco warehouse.

Maryland's colonial lawmakers approved the town of Georgetown in 1751. They bought sixty acres for it from George Gordon and George Beall for 280 English pounds. The site already had a tobacco inspection house, a building where tobacco was checked before it was shipped, and Georgetown grew into a tobacco port.

The members of Congress changed the law on March 3, 1791, so that the district, the land set aside for the capital, could reach south and take in Alexandria too. Jones Point, where the survey of the district's boundary began, is at Alexandria.

The rest of the land was farms, and the main crop was tobacco. Five men owned the ground where the National Mall is now. The Histories of the National Mall project at George Mason University reports that these men enslaved people, and the enslaved men and women raised tobacco, corn, wheat and cattle on the land.

The largest of the five farms was Notley Young's tobacco plantation, a big farm worked by enslaved people. It covered 800 acres, and the Smithsonian's National Museum of African American History and Culture stands on part of it. The museum gives the number of people enslaved there as 245, from the 1790 census, the government's count of the people. The Histories of the National Mall project gives 260. Federal officials bought Young's land in 1791.

In all, nineteen men owned the land for the new city, about 6,000 acres. Washington met them at a dinner in Georgetown, and they signed an agreement on March 30, 1791.

**The deal.** The owners got nothing for the land that became streets. For land taken for public buildings and squares, they were paid by the acre. The rest of the land was split into building lots, and half of the lots went back to the owners. These men were later called the Original Proprietors, which means the owners of the land when the city was laid out.

Before anyone could build the city, a crew had to survey the boundary of the district, measuring the ground and marking exactly where its corners and edges lay. Someone also had to draw the plan of the city that would go inside it.

Andrew Ellicott ran the boundary survey. Benjamin Banneker, a free Black farmer from Baltimore County, Maryland, worked under him and did the survey's astronomy, the science of the stars and planets. Pierre L'Enfant, an engineer born in France, drew the city plan in 1791, and Washington dismissed him the next year.

### Pierre L'Enfant

> **Who:** The French-born engineer who designed the plan of Washington, D.C., and was dismissed before it was built.
>
> **When and where:** The federal district, 1791 to February 1792.

**L'Enfant would not hand over his drawing, so Washington fired him.**

Pierre Charles L'Enfant drew the plan of the capital in 1791. He laid down a street grid and then drew diagonal avenues across it that meet at circles and squares.

The three commissioners Washington had appointed under the Residence Act asked for L'Enfant's original drawing, so that an engraver could cut it into a printing plate and print copies. L'Enfant refused to hand it over, and he clashed with the commissioners. In February 1792 George Washington dismissed him for insubordination, refusing to obey the people in charge of him.

Andrew Ellicott, with help from his brother Benjamin Ellicott, rebuilt the plan and changed parts of it. He straightened Massachusetts Avenue and took out some of the squares. The engravers Thackara and Vallance made an engraving of Ellicott's version in March 1792. Copies of their engraving were the first plan of the city that many people saw, and the city was built from it: L'Enfant's plan as Ellicott had changed it.

L'Enfant died poor in 1825. He was buried on a farm in Prince George's County, Maryland, that belonged to his friend William Dudley Digges.

**A second burial.** In 1908 the members of Congress set aside $1,000 for a new grave. On April 28, 1909, his coffin lay at the US Capitol for three hours, so that people could pay their respects. He was the first person from another country to be given that honor. That afternoon he was buried again at Arlington National Cemetery, on a hillside above the city he had planned.

### Benjamin Banneker

> **Who:** A free Black tobacco farmer and self-taught astronomer who made the observations that fixed the starting corner of the federal district.
>
> **When and where:** The survey's base camp at Jones Point, Virginia, February to April 1791.

**At nearly sixty, Banneker worked nights, timing the stars.**

George Ellicott, Andrew Ellicott's cousin and Banneker's neighbor and friend, recommended him, and Major Andrew Ellicott hired him as scientific assistant on the survey of the ten-mile square. Banneker was nearly sixty. He farmed tobacco, and he had taught himself astronomy.

Banneker worked at night. To find a position on the earth by astronomy, an observer watches particular stars cross a particular point in the sky and records the exact moment, then calculates the position from those times. Banneker made those observations and did those calculations, and he kept the survey's regulator clock, a very exact clock, running true.

He used his observations and calculations to fix the district's south corner at Jones Point. He was paid $2 a day, an ordinary day's pay for an assistant. Andrew Ellicott was paid $5.

Banneker left the survey in the spring of 1791, before the crew had run the full forty miles of the boundary. He was in poor health. His first almanac, a book printed once a year with a calendar and tables of the sun, moon and stars, was the one for the year 1792.

According to a popular story, Banneker redrew the whole plan of Washington from memory after L'Enfant was dismissed. The story is a legend. Banneker had left the project about ten months before L'Enfant was dismissed, and Andrew Ellicott rebuilt the plan. The historian Silvio Bedini and writers for the National Park Service and the Library of Congress have worked through the records. They credit Banneker with the astronomy for the boundary survey.

### Water after the fevers

Yellow fever killed about 5,000 people in Philadelphia between August 1 and November 9, 1793. About 50,000 people lived in the city, so the fever killed roughly one of every ten of them. About 20,000 other people fled the city, among them the officials of the new federal government.

Yellow fever comes from a virus that mosquitoes carry from person to person. Most people who catch it get better within a week. In about one case in seven, the illness comes back worse and the virus destroys the liver, so the skin and the whites of the eyes turn yellow. The person bleeds from the mouth, nose and eyes and vomits blood turned black by stomach acid, which people then called the black vomit. Between 30 and 60 percent of these people die.

**What people blamed.** Nobody then knew that mosquitoes spread the fever. Many Philadelphians thought it came from dirty water or from rotting matter in the streets, so they wanted clean water for the city. In 1797 a group of them asked the city's councils to take charge of the water supply, and the council members formed a Watering Committee. The fever came back in 1798. The city's leaders then hired Benjamin Henry Latrobe, an English-born architect and engineer, to design a waterworks.

**The waterworks.** The members of the Watering Committee accepted Latrobe's design in 1799, and workers began building the Centre Square Water Works that year. Nicholas J. Roosevelt built its engines and pumps under a contract worth $33,000. The steam engine went up from February 1800.

The steam pumps started supplying the city on January 21, 1801. The engines pumped water from the Schuylkill River through a tunnel along Chestnut Street to the pump house, a white marble building on Centre Square. From there the water ran through the streets in pipes made of hollowed-out logs. Philadelphia was the first American city with a public water supply driven by steam.

**What the water could not do.** Clean water could not stop a disease that mosquitoes spread. The fever came back seven times in the twelve years after 1793. Each time, only the winter frost, which killed the mosquitoes, brought it to an end.

The engines broke down often and cost a great deal to keep running. Centre Square ran for only fourteen years. In 1815 the Fairmount Water Works took its place.

## 1800 to 1850

**Era 6 of 10 · 1800 to 1850 · about 7 minutes**

Towns beside water that boats could reach grew into cities in a few years, on land that had belonged to Native nations. In New York, three commissioners laid a grid of straight streets over Manhattan's hills. After a deadly disease and a great fire, the city's leaders had clean water brought in from a river to the north.

### Boomtowns

Rochester, Chicago and San Francisco were all boomtowns between 1800 and 1850, towns whose number of people grew very fast, in a few years.

The City of Rochester's own history and the Monroe County Library's Rochester Voices project both describe Rochester as America's first boomtown. The land there was Seneca land. In 1788 Seneca leaders signed a treaty, a written agreement between nations or governments, that handed about 2,600,000 acres east of the Genesee River to two land dealers, Oliver Phelps and Nathaniel Gorham.

The Seneca leaders also granted land west of the river for a mill, on the condition that a mill be built for the Seneca to use. Ebenezer Allen built a sawmill and a mill for grinding grain on that tract in 1789.

The Erie Canal ran through Rochester from 1825, and workers finished the whole canal across New York that October. The falls of the Genesee River turned the mills' wheels. Grain from the Genesee Valley came to the mills, and canal boats carried the flour away. Before the canal, shipping a ton of flour from Rochester cost $100. By canal it cost $7. By 1838 the mills at Rochester ground more flour than the mills of any other American city, and Rochester got the nickname the Flour City.

About 1,500 people lived in Rochester in 1820. Census takers, who count the country's people every ten years, counted 9,269 there in 1830. By 1834, the year Rochester became a city, about 12,630 people lived there. That was more than eight times as many people as in 1820.

Chicago grew where the Chicago River runs into Lake Michigan, beside Fort Dearborn, an army fort built at the river's mouth in 1803. It became a town in 1833, when about 350 people lived there.

That September, in the Treaty of Chicago, Potawatomi leaders signed over about 5,000,000 acres: their last lands in Illinois and Wisconsin, and their last reservations, or lands kept for them, in Michigan. The Potawatomi leaders agreed to move west of the Mississippi River. Chicago became a city on March 4, 1837, when 4,170 people lived there.

For most of the year Chicago's streets were mud, until crews began in 1855 to raise them over sewers, underground pipes that carry waste water away.

San Francisco grew on the homeland of the Yelamu, an Ohlone people. About 200 people lived in the town in 1846, and by 1852 about 36,000 lived there. They had come in the California Gold Rush, a race to California to dig for gold.

People put the town together in a hurry. They lived in tents and in hulks, the hulls of old ships that no longer sailed. Six great fires burned the town between December 1849 and June 1851, and the fire of May 3 and 4, 1851, destroyed as much as three-quarters of it. People rebuilt after each one.

### A grid laid over Manhattan's hills

New York's state lawmakers appointed three commissioners on April 3, 1807, and gave them the job of laying out the streets of Manhattan. They were Gouverneur Morris, John Rutherfurd and Simeon De Witt, and they filed their plan in March 1811.

The commissioners laid the streets out as a grid. In the remarks they filed with the plan, they gave their reason: "straight-sided and right-angled houses are the most cheap to build and the most convenient to live in." Their plan covered Manhattan from Houston Street north to 155th Street. It had twelve avenues and 155 numbered cross streets, which cut the land into rectangles.

The commissioners drew the lines straight over the island's hills without bending them. Manhattan was Lenape land, and by 1811 much of this part of it was rocky hills, swamps and marshes, with farms, houses and barns scattered across it.

The chief surveyor, John Randel Jr., was hired for the job at twenty. In 1808 he mapped the island's hills, rocks, swamps, streams and ponds, and its houses, barns, fences and fields. Then his crews set 1,549 marble markers and 98 iron bolts into the ground to fix the grid in place.

Workers then had to make the island match the drawing. To build each street, they dug away hills or filled in hollows, leveled the strip of ground and paved it. The new streets ran through the spots where about 721 of the 1,825 buildings north of Houston Street stood in 1811, so those buildings had to be moved out of the way. The work took about sixty years to reach 155th Street.

The commissioners set aside very little land for parks, and Central Park came only later, on ground where the people of Seneca Village already lived.

### How New York got clean water

Cholera causes watery diarrhea so heavy that the body loses its water very fast. A person with a bad case who does not get water back into the body fast enough can die of it within hours. In 1832 cholera killed about 3,500 out of about 250,000 New Yorkers, about one person in every seventy.

New York had no clean piped water then. People drew water from wells, ponds and springs inside the city. Workers for a private firm, the Manhattan Company, sank wells and laid wooden pipes to send the water out. Carters drove barrels of country spring water around town and sold it for a penny a gallon, and that water was often dirty too. Others caught rain in tanks called cisterns.

The water from the downtown wells was dirty by the 1830s. More and more privies, outdoor toilets built over pits in the ground, stood near the wells, and liquid from old graves soaked into the ground as well. When people sick with cholera used the privies, the waste overflowed into nearby wells and cellars.

A fire started in a five-story warehouse on Merchant Street, near Wall Street in lower Manhattan, on the evening of December 16, 1835. A strong wind blew it toward the East River. It burned about seventeen blocks and destroyed between 600 and 700 buildings, and the damage came to about $20 million. Two people died in it.

**No water to fight it.** The firefighters could not get enough water onto the fire. There was little water to be had, and what there was froze in the wells, in the hoses and in the hydrants, the street pipes that firefighters draw water from.

The Croton Aqueduct, a channel built to carry water a long way, became the first large city water supply in the United States that ran without a break. New York's city leaders had decided by the late 1820s that they needed a cleaner and bigger supply of water. After the cholera and the fire, they had the aqueduct built. Workers began building it in 1837, with John B. Jervis as chief engineer.

The workers dammed the Croton River in Westchester County, north of the city. Then they built a covered tunnel of brick on a stone base, forty-one miles long, to carry the water down to Manhattan. Inside, the tunnel was eight and a half feet high and seven and a half feet wide. It dropped about 13 inches in every mile, so gravity carried the water along it.

Water entered the city on June 22, 1842. On July 4 the distributing reservoir, a large basin that held the water and fed it out to the city's pipes, began filling at 42nd Street and Fifth Avenue.

New Yorkers held a celebration across the whole city on October 14, 1842. A parade seven miles long marched through the streets, and the new fountain in City Hall Park threw water fifty feet into the air. People called a glass of the new water a "Croton cocktail," though it had no alcohol in it.

### George Templeton Strong

> **Who:** A young New York lawyer whose diary, kept for forty years, records the coming of Croton water.
>
> **When and where:** New York City, 1842.

**In 1842 Strong doubted that even Croton water could clean New York.**

George Templeton Strong was twenty-two when the Croton water arrived. He kept a diary from 1835 until his death in 1875, about 2,250 pages in all. It is a first-hand record of New York in the 1800s, and two editors, Nevins and Thomas, published it in 1952.

While the water was still on its way in 1842, Strong wrote that "Croton Water is slowly flowing towards the city, which at last will stand a chance of being cleaned." The sentence goes on: "if water can clean it." He thought the city was so dirty that even water might not get it clean.

## 1850 to 1900

**Era 7 of 10 · 1850 to 1900 · about 19 minutes**

Builders made American cities taller in these fifty years, dug sewers under them, and spread them outward along streetcar lines. In Chicago, crews raised the streets over new sewers and lifted the buildings to match. Census takers counted 1,099,850 people in Chicago in 1890, which made it the second-largest city in the country.

In New York in the same years, poor families crowded into tenements, apartment buildings put up cheaply to hold as many families as a plot of land would take.

### How crews lifted Chicago out of the mud

Rain and waste had nowhere to drain off Chicago's low, almost level clay ground, so pools of dirty water stood in the streets, and for most of the year the streets were mud. Diseases spread from that standing water, among them typhoid fever, a fever caught from food or water dirtied by human waste, and dysentery, a gut infection that causes bloody diarrhea. In 1854 cholera killed six of every hundred people in the city.

The members of the Board of Sewerage Commissioners, the officials in charge of Chicago's sewers, hired Ellis S. Chesbrough in December 1855. He had been the water engineer in Boston. His plan of 1856 was the first plan for a complete sewer system covering a whole American city.

**Streets on top of the sewers.** Workers laid the sewer pipes along the existing streets and then buried them under several feet of new fill, earth dumped on top. That raised the level of the street by an average of four to five feet, and by as much as eight feet in places. A building left at the old level now sat below its own street, and its ground floor became a basement.

Next the buildings had to come up to the new street level. The tool for lifting them was the jackscrew, a screw inside a case that a man turned by hand with a lever. Crews set many jackscrews under a building, and the men turned them together.

The first masonry building, one built of brick or stone, went up this way in January 1858. It was a four-story brick block at Randolph and Dearborn streets that weighed about 750 tons. It rose 6 feet 2 inches on 200 jackscrews. Reporters of the time wrote that it rose "without the slightest injury" to the building. More than fifty buildings like it were raised that same year. Every figure for these raisings comes from those newspaper reports.

A group of engineers that included George Pullman raised half a city block in 1860. It was the row of brick and stone buildings on Lake Street between Clark and LaSalle streets, 320 feet long. With its sidewalks, the row weighed about 35,000 tons. About 600 men worked about 6,000 jackscrews, and the block went up 4 feet 8 inches in five days. The shops in it stayed open the whole time, and people came and went, shopped and worked in them while the buildings rose.

### Up: the elevator and the steel frame

Builders could not make tall buildings without two inventions: an elevator people trusted, and a frame that could hold the building up.

The danger in an elevator was that the rope could break and drop the platform. Elisha Graves Otis made a brake from a steel wagon spring that locked into a ratchet, a bar with teeth, and held the platform if the rope broke.

**The test.** Otis showed his brake in 1854 at the Crystal Palace exposition in New York, a large public show of new machines and goods. He rode a platform up an open-sided shaft, and halfway up he had the rope cut with an axe. The brake caught, and the platform held.

The first passenger elevator sold for everyday use in a building went into the E. V. Haughwout Building, at 488 Broadway in New York, on March 23, 1857. A steam engine drove it. It cost $300 and rose about two-thirds of a foot per second.

**Rent on the top floor.** Before elevators, the higher a room was, the lower its rent, because people had to climb the stairs to reach it. Once elevators ran, floors above the fourth or fifth could rent for as much as the floors below, or more.

In a wall-bearing building, the outside walls hold up everything. The taller the building, the thicker the walls at the bottom have to be. The Monadnock Building in Chicago, finished in 1891, is 16 stories tall, the tallest building ever held up by brick walls. Its walls are six feet thick at the bottom. In a framed building, a skeleton of iron or steel columns and beams carries the weight. The walls hang on that frame as a covering.

The Home Insurance Building in Chicago is the building most often called the first skyscraper, a very tall building held up by a metal frame. William Le Baron Jenney designed it, and it was finished in 1885. It stood ten stories and 138 feet tall, and builders added two more floors in 1890. Its frame of iron and steel carried loads that walls had carried in older buildings. Workers tore it down in 1931 to make room for the Field Building.

That title is in dispute. The Home Insurance Building was not built all of steel, and it was not the first building with a metal frame. Jason Barr, who writes about the history of skyscrapers, traces the label "first skyscraper" partly to a later publicity campaign. People close to Jenney ran it, along with Chicago boosters, people who promoted their city to bring in money and business.

Other buildings have a claim to be first. One is New York's Equitable Life Building of 1870, the first office building with an elevator. A fire destroyed it in 1912 and killed six people, and the Equitable Building of 1915, about 40 stories tall, went up on the same ground. Whichever building came first, builders used the frame and the elevator to roughly triple the height of buildings within one generation.

**By 1893:** Chicago's downtown stood on streets raised over its sewers, and its office buildings rose ten stories and more on frames of iron and steel.

### Mohawk ironworkers

Mohawk ironworkers built steel frames like these. From 1886 on, men from two Mohawk communities, Kahnawake and Akwesasne, helped build bridges and tall buildings across the Northeast. That year, at a bridge job at Kahnawake, a Mohawk town near Montreal, Mohawk men started working high steel, joining the steel frames of bridges and buildings high above the ground.

From Kahnawake and Akwesasne, the men traveled to bridge and skyscraper jobs wherever the steel work was, and they called that "booming out." An exhibition at the Smithsonian's National Museum of the American Indian, *Booming Out: Mohawk Ironworkers Build New York*, documents their work. It includes their work in the next century on the Empire State Building, the Chrysler Building, the George Washington Bridge and the World Trade Center.

### The tenement

New York's state lawmakers passed a tenement law on May 14, 1867, the first broad housing law in the country. Under it, cellar apartments were banned unless the ceiling stood at least a foot above the street, and every building needed fire escapes and one toilet for every twenty people. The law also set the first rules for letting fresh air into rooms.

Officials did little to make builders obey it. To meet its rules about fresh air, builders cut windows in the walls between inside rooms, so the windows let in no outside air. The lawmakers tried again with the Tenement House Act of 1879, later known as the Old Law. Under it, every room a person lived in had to have a window that opened to outside air. Builders met that rule with the dumbbell tenement.

Builders pinched each building in at its middle, which left room for a narrow air shaft, and rooms in the middle of the building got their required window onto that shaft. Seen from above, the building was wide at both ends and thin in the middle, the shape of a dumbbell, an exercise weight with a ball at each end of a short bar.

The shaft was too narrow and too deep to bring daylight or moving air down below the top floors, so most of the rooms it was built for stayed dark and stale. The shafts filled up with garbage. The shaft also worked as a flue, a channel that draws hot air and smoke upward, as a chimney does. A fire in the shaft could climb it to the floors above.

New York's state lawmakers passed a new Tenement House Act in 1901, later known as the New Law. In it they banned the dumbbell design and required windows facing outward in every room, along with courtyards, indoor toilets and protection against fire. The rules covered old buildings as well, so owners had to change those too.

### Jacob Riis

> **Who:** A Danish immigrant and police reporter who took up flash photography early and used it to show how the poor of a city lived.
>
> **When and where:** New York's tenement districts. *How the Other Half Lives* came out in 1890.

**Riis took his photographs at night, by the flash of burning magnesium.**

Jacob Riis used flash photographs as evidence in an argument about how poor families in New York lived. He came to the United States from Denmark in 1870 and worked as a police reporter for the *New York Tribune* and then the *Evening Sun*. As a reporter he covered the city's poorest streets, among them Mulberry Street. The police there also ran shelters for homeless people, called police lodging houses, and Riis saw inside them and wrote about them.

Riis began using magnesium flash around 1887. Magnesium powder burns for an instant with a light bright enough to record a picture on a photographic plate, a glass sheet coated with chemicals that change where light hits them. With the flash he photographed tenements, saloons and slums at night.

Riis published an eighteen-page article in *Scribner's* magazine in 1889. The next year he published the book *How the Other Half Lives*, with seventeen photographs and a number of engravings, pictures printed from lines cut into metal or wood.

The *Dictionary of American History* states that Riis's work, along with the work of other reformers, pushed New York's lawmakers toward the tenement law of 1901, which banned the dumbbell design. Theodore Roosevelt, as New York City's police commissioner, became Riis's ally.

### Bridget and Joseph Moore

> **Who:** An Irish immigrant waiter and his wife, one tenement family the records document, whose apartment the Tenement Museum has recreated.
>
> **When and where:** 97 Orchard Street, on New York's Lower East Side, 1869.

**The Moores' water came from a backyard pump, beside the privies.**

Bridget Moore married at seventeen, in 1865. Joseph Moore worked as a waiter, and some of the Tenement Museum's accounts record him as a bartender. In 1869 the couple moved with their daughters into 97 Orchard Street, a tenement built in 1863. They were one of the few Irish families in a building where most people were German, and they lived there about a year.

Their daughter Agnes Mary died on April 21, 1869, at five months old. The cause given in the records was marasmus, severe malnutrition, a form of starvation. The body gets too little food of every kind, so it uses up its own fat and then its own muscle, and the child wastes away.

The Tenement Museum's account describes two things linked to the deaths of babies at that time. One was swill milk, which came from cows kept in stables beside distilleries, where liquor was made. The cows ate the leftover grain mush from making the liquor. Their milk was thin and dirty, and in the 1850s New Yorkers blamed it for the deaths of many babies. The museum says Agnes Mary's marasmus came from tainted milk.

The other was the building itself. The water at 97 Orchard Street came from a pump in the back yard, beside the privies.

Of the eight children Bridget and Joseph Moore had, four lived to be adults.

The building still stands, and museum staff have recreated the Moores' apartment as it was in 1869. Between 1863 and 1935, when the floors where people lived were sealed shut, an estimated 7,000 people from more than twenty countries lived at 97 Orchard Street. The Moores are one of the families among them whose names appear in the records.

### The White Wings

The reporter Jacob Riis wrote that one man's broom "saved more lives in the crowded tenements than a squad of doctors." The man was George E. Waring Jr. New York's reform mayor, William L. Strong, appointed him street-cleaning commissioner in 1895, and Waring held the job until 1898. He put about 2,000 street sweepers in white uniforms, and people called them the White Wings. Each day they cleaned about 450 miles of street.

Waring set up the first planned systems for getting rid of the city's waste and for recycling it. He organized Juvenile Street Cleaning Leagues too, clubs for children who helped keep their streets clean.

### Central Park and Seneca Village

The commissioners who drew the 1811 plan had left almost no land for public parks. In 1853 New York's state lawmakers set aside more than 700 acres in the middle of Manhattan for a park. Frederick Law Olmsted and Calvert Vaux won the design contest in 1858 with a plan they called Greensward, and building began that year.

People already lived on part of that land, in Seneca Village. John and Elizabeth Whitehead had divided their farmland there into about 200 lots, or pieces of land for sale, in 1825. On September 27 of that year, Andrew Williams, a twenty-five-year-old Black shoeshiner, bought the first three lots for $125. Epiphany Davis bought twelve lots for $578, and the African Methodist Episcopal Zion Church bought lots as well.

About 225 people lived in Seneca Village by 1855. Roughly two-thirds of them were African American, and Irish and German families lived there too. They had built three churches and a school.

**Land and the vote.** Under New York law at the time, a Black man could vote only if he owned at least $250 worth of property. In 1845 about 100 Black men in the whole city met that rule, and 10 of them lived in Seneca Village.

New York City officials took the whole park site by eminent domain, the power of a government to take private property for public use, paying the owner whether the owner wants to sell or not. Officials set a price for each piece of land, and the owners in Seneca Village were paid. The histories of the village by the Central Park Conservancy, the group that looks after the park, do not name the commissioners who set the prices.

Many of the owners said the price of their land was too low, and they objected in court. Researchers at the Conservancy have studied the records and found that, with few exceptions, the owners got about what their land would have sold for.

The New York State Supreme Court, the state's main trial court, approved the prices in February 1856, and the land became the city's property. The officials had taken the land from its owners, including Black men whose right to vote depended on owning it.

Many people left in 1856, and others stayed on as renters of the city. In the summer of 1856, Mayor Fernando Wood sent the people of Seneca Village a final notice to leave. In October 1857, once the money to build the park was in place, city officials evicted the last of them, forcing them out of their homes under the law. In all, city officials forced about 1,600 people off the whole park site by the end of 1857.

Accounts differ on how the last people were made to leave. The historians Roy Rosenzweig and Elizabeth Blackmar studied the records from the time for their 1992 history of the park, and they found that the people left "quietly and without violence." The Conservancy's researchers say their work since the early 1990s has found no sign of a fight over the taking.

A New York Public Library research guide describes it differently. It states that the people of Seneca Village fought the police sent to put them out, and that in August 1857 the last Black landowners were "forcibly and violently scattered throughout the city." Rosenzweig and Blackmar think the stories of police clubbing people out mix up the taking of the park land with police raids on pig farms near the park's western edge two years later.

Crews tore down the buildings, and workers began building the park in 1858.

### Frederick Law Olmsted

> **Who:** The designer, with Calvert Vaux, of Central Park, whom the Olmsted Network, a group that studies his work, calls the founder of landscape architecture as a job in the United States.
>
> **When and where:** New York from 1858, and parks in Brooklyn, Boston, Washington and Chicago afterward.
>
> **Movie:** *Frederick Law Olmsted: Designing America* (PBS, 2014), a documentary that premiered June 20, 2014.

**Editors once sent Olmsted through the slave states as a reporter.**

Olmsted had been a sailor on a trading voyage to China. From 1848 to 1855 he ran a farm on Staten Island, and in 1852 he published a book called *Walks and Talks of an American Farmer in England*. That year editors at the *New York Daily Times* sent him as a reporter through the Southern states, where slavery was legal.

His travels through the South and Texas lasted until 1857, and his reports were later collected in three books. In them he argued that slavery had held the South back. By his count, the same amount of work took four times as long in Virginia as in the North, and the profits of slavery went to no more than 8,000 owners of large plantations.

He and Calvert Vaux won the Central Park contest in 1858 with the Greensward plan. They designed the land itself, its paths, lawns, trees, water and roads, which is the work called landscape architecture. Olmsted meant the park for everyone in the city, rich and poor. He and Vaux gave it meadows and woods shaped to look like open country, so that city people could get some relief from the city.

Olmsted's best-known designs after Central Park include Prospect Park in Brooklyn, the Emerald Necklace in Boston, a chain of connected parks, and the grounds of the US Capitol in Washington. In 1893 he laid out the grounds of the World's Columbian Exposition in Chicago, in Jackson Park.

### The White City

A world's fair, the World's Columbian Exposition, opened in Chicago in 1893. Daniel Burnham directed the building work, and Olmsted drew the site plan, the layout of the grounds. Workers put up a matched set of white buildings in the style of ancient Greek and Roman buildings, with rows of columns. Electric lights lit them, and the fair got the name the White City.

The buildings were temporary, built to stand only while the fair ran. Under their fronts they were sheds on steel frames. The fronts were made of staff, a mix of plaster, cement and plant fiber that workers poured into molds, and then painted white. More than 27 million people visited the fair in its six months. Planners in the City Beautiful movement of the 1890s and 1900s took the White City as their model. They worked to bring grand public buildings, wide avenues and parks into American cities.

### Out: streetcar lines and streetcar suburbs

American cities of the 1800s were walking cities. Most people lived close enough to walk to their work and their shops. Horses pulled streetcars along rails in many cities, at 5 or 6 miles an hour.

**Electric cars.** Frank J. Sprague's Richmond Union Passenger Railway, an electric streetcar line in Richmond, Virginia, began running cars on a regular schedule on February 2, 1888. It started with ten cars on about twelve miles of track, and by May twenty-three cars ran on it. It was the first large electric street railway that worked well.

Electric streetcars ran at 10 to 15 miles an hour, so a ten-minute ride covered ground that took thirty minutes to walk. Within two years, about 110 electric railways using Sprague's equipment were built or under contract.

Builders put up houses along the new lines, out past the old edge of town, and many white city families moved out to them. These new neighborhoods of homes at the edge of a city, where people lived and from which they traveled in to work, were called streetcar suburbs.

### A city in one day

The land run into Oklahoma, a race in which settlers rushed in at a set signal to claim pieces of land, began at noon on April 22, 1889. That morning, Guthrie was a railroad station. By nightfall about 10,000 people were camped there.

The land was part of Indian Territory, where United States officials had forced many Native nations to move from their homelands. Dennis N. Cooley was the federal Commissioner of Indian Affairs in 1865, the official in charge of the government's dealings with Native nations. He told the leaders of five of those nations that they had lost their rights to their land. His reason was that they had sided with the Confederacy, the Southern states that fought the United States in the Civil War.

In treaties signed in 1866, the Creek signed over the western half of their land for $975,168, and the Seminole signed over all of theirs for fifteen cents an acre. The treaties stated that the land was for other Native nations and for people freed from slavery.

**The Unassigned Lands.** The land opened in 1889, about 1.9 million acres, lay in the middle of the land the Creek and Seminole had signed over. It was called the Unassigned Lands, because federal officials had not assigned it to any nation. In early 1889, members of Congress voted to pay the Creek about $2.28 million and the Seminole about $1.91 million to drop the rule about who the land was for. Then settlers could claim it.

Congressman William Springer wrote the change to a law that let President Benjamin Harrison open the land. Harrison announced the opening on March 23, 1889.

By the morning after the run, the settlers in Guthrie had set up a temporary government, a land office where settlers filed their claims, a newspaper and three banks, all of them working out of tents. Oklahoma City filled up on the same scale on the same day.

**If you remember one thing:** In these fifty years American cities grew taller and spread farther out, and in Chicago crews raised the streets over new sewers and lifted whole buildings to match.

In 1850: Chicago's streets were mud for most of the year, buildings were held up by their own walls, and most city people walked to work.

In 1900: Chicago's streets ran on top of its sewers, frames of iron and steel held up buildings ten stories and taller, and electric streetcars carried families out to new suburbs.

Who lived where: poor families in New York crowded into tenements, city officials forced the people of Seneca Village off their land to make Central Park, and in 1889 settlers raced onto Oklahoma land that the Creek and Seminole nations had signed over in 1866.

**Next:** In the 1900s, officials wrote rules about what could be built in each part of a city, and white owners and judges kept Black families out of most neighborhoods.

## 1900 to 1950

**Era 8 of 10 · 1900 to 1950 · about 18 minutes**

New York's officials wrote the first rules for a whole American city on what could be built where, and builders in New York went on to put up the tallest buildings in the world. Millions of people moved into American cities in these decades. In 1907 alone, more than a million immigrants came through Ellis Island in New York, and millions of Black Americans moved from the South to cities such as Chicago and Detroit.

White property owners and judges kept Black families out of most neighborhoods, and federal officials refused to back home loans in the neighborhoods where Black families lived. To build a secret city for the atomic bomb, Army officials took farmland in Tennessee from the families who lived on it.

### Drinking water for Chicago and San Francisco

People in Chicago drank water from Lake Michigan, drawn in through intake pipes about two miles offshore. The city's sewers emptied into the Chicago River, and the river flowed into the lake. In 1885 a great storm carried the river's filth far out into the lake, and people feared it would reach the intakes. The Sanitary District of Chicago, the public body in charge of the work, was set up to solve the problem.

The Sanitary District's engineers made the river flow the other way. Workers dug a canal 28 miles long, the Chicago Sanitary and Ship Canal. Through it, the river now flowed away from the lake, toward the Des Plaines River and on down to the Mississippi, carrying the city's sewage with it.

Missouri lay downstream on the Mississippi. Sanitary District officials feared that Missouri's officials would ask a court for an injunction, an order telling someone to stop. Partly to finish before a judge could issue that order, crews blasted out the last barrier at dawn on New Year's morning, and the reversal was complete on January 2, 1900.

Missouri's state officials sued the Sanitary District that year. A court later dismissed the case because Missouri could not prove that the river's pollution came from Chicago. The sewers of St. Louis also emptied that city's waste into the Mississippi.

Stephenson Strobel, a health researcher at McMaster University in Canada, estimated in a 2025 study that the reversal cut the number of deaths in Chicago by about 4 percent in 1900. That is about 985 people who would otherwise have died that year.

An earthquake broke the main pipes from San Francisco's reservoirs on April 18, 1906. It also broke the water mains, the large pipes that carry water under the streets, in more than 300 places. When firefighters hooked their hoses to the hydrants, no water came out. The fires burned for about three days and destroyed more than four square miles of the city.

**Hetch Hetchy.** After the fire, city officials planned to dam the Hetch Hetchy Valley in Yosemite National Park and pipe its water to the city. Damming the valley meant flooding it, and conservationists, people who work to protect wild land, fought to stop the dam.

President Woodrow Wilson signed the Raker Act on December 19, 1913. Under it, San Francisco's city officials could build the dam, and no other American city has been allowed to build in a national park for its own use. The members of Congress who passed the Act wrote into it that nobody could make a private profit from that water and power.

Workers finished the O'Shaughnessy Dam in 1923, and by 1934 the full system was carrying water to San Francisco. City officials later sold the dam's electricity to a private company, Pacific Gas and Electric, and people fought in court for decades over whether that broke the Act.

### Federal work crews of the 1930s

Federal crews laid new water and sewer pipes in cities across the country in the 1930s. They worked for the Works Progress Administration (WPA), a federal program that hired people to build public projects such as roads, pipes and schools, from 1935 to 1943. WPA crews laid about 24,000 miles of storm and sewer lines, which carry away rainwater and waste, and about 19,700 miles of water mains.

WPA crews built about 500 water-treatment plants, more than 4,000 new schools, hundreds of hospitals, and airports, and they built or improved about 651,000 miles of road. Counts of the WPA's work differ from one record to another, so each of these figures is close but not exact.

### Zoning: rules for what may be built where

Under zoning, officials divide a city into districts and set rules for what may be built in each one. The rules state how tall a building may be, how close it may stand to the street, and what it may be used for. No American city had zoning rules that covered the whole city before 1916. That year, on July 25, New York's officials voted to adopt the first citywide zoning resolution in the country.

Popular accounts state that the Equitable Building, finished in New York in 1915, caused the resolution. It rose about 40 stories straight up from the sidewalk, with no setback, no place where the upper floors step back from the street. It cast a shadow of about seven acres on the streets around it and cut off the sun from the buildings next to it.

Jason Barr, who writes about the history of skyscrapers, states that officials had been preparing the resolution for years. In his account they would have passed it without the Equitable Building, which became the best-known example of what the rules were meant to stop.

The resolution's height rule depended on the width of the street. A building's front wall could rise straight up to a height set by multiplying the street's width by a fixed number. Above that height, the building had to step back from the edge of its lot each time it went higher. A tower could go up with no height limit if it covered no more than a quarter of the lot.

**The wedding cake.** Architects who followed that formula designed New York's skyscrapers of the next decades as stacked boxes, each one smaller than the one below, and people called the shape a wedding cake. The officials who wrote the resolution meant the setbacks to keep air and sunlight reaching the sidewalks.

Officials also used city laws to decide who could live where. In Louisville, Kentucky, a city law barred Black buyers from buying homes on blocks where most people were white.

William Warley led the Louisville branch of the NAACP, a group that fought for Black Americans' rights. He agreed to buy a lot in a mostly white neighborhood so that the law could be tested in court. In 1917, in *Buchanan v. Warley*, the justices of the Supreme Court all agreed that the Louisville law could not stand. After that ruling, local officials turned to zoning rules that did not name race.

Officials in the village of Euclid, Ohio, had banned two-family houses and apartment buildings from parts of the village, so families who could not afford a whole house of their own could not live there. In 1926, in the case *Village of Euclid v. Ambler Realty Co.*, the justices of the Supreme Court ruled that a local government had the power to zone. After the ruling, officials in cities across the country wrote zoning rules.

### Daniel Burnham

> **Who:** The Chicago architect who directed the building of the 1893 world's fair and then wrote the first plan for the whole of a big American city.
>
> **When and where:** Chicago, from the 1893 world's fair to the *Plan of Chicago* in 1909.

**Burnham spent about thirty months on Chicago's plan and charged nothing.**

Daniel Burnham ran the building of the White City at the 1893 world's fair in Chicago, where the buildings were designed together as one planned city. After the fair, Burnham applied the same idea to a real city that already existed.

Burnham and Edward Bennett published the *Plan of Chicago* in 1909. The members of the Commercial Club of Chicago, a club of the city's business leaders, asked for the plan and raised about $80,000 to pay for it. Burnham worked on it for about thirty months and charged nothing. The club spent more than $40,000 more to print 1,650 copies of the finished book.

It was the first comprehensive plan for a large American city, setting out what the whole city should become, with its streets, parks and waterfront planned together. In it, Burnham and Bennett called for the lakefront to stay open to the public, for rings of parks around the city and for wider streets. Much of Chicago's lakefront is still open to the public because of that plan.

**Known:** Many people know Burnham for the line "make no little plans," but people began to credit it to him only after he died in 1912.

**Not known:** No record from his lifetime has him saying or writing it.

### Which tower would be tallest?

The builders of the Chrysler Building beat the builders of 40 Wall Street in 1929, in a race for the tallest building in the world. Then, in 1931, the builders of the Empire State Building went higher than both.

**The hidden spire.** The Chrysler Building's architect, William Van Alen, was racing the builders of 40 Wall Street. His workers put together a spire, a tall pointed top, 125 feet long. They built it in secret inside the building's fire tower, a shaft that ran up through the building, where nobody outside could see it. In October 1929 they raised the spire up through the roof and fixed it in place.

The spire brought the Chrysler Building to 1,046 feet, the official figure from the Council on Tall Buildings and Urban Habitat, though some popular accounts print 1,048. The tower at 40 Wall Street stood 927 feet tall. The Chrysler Building opened on May 27, 1930, and it was the tallest building in the world for eleven months.

The Empire State Building opened on May 1, 1931. It had 102 stories and stood 1,250 feet to the roof, taller than both. Its builders put it up in 410 days, for about $41 million. President Hoover turned on its lights by pressing a button in Washington.

The building opened during the Depression, the years of the 1930s when businesses failed and people lost their jobs. Through the Depression the building stood about half empty.

Mohawk ironworkers from Kahnawake and Akwesasne worked on the steel of both the Empire State and Chrysler buildings. From the 1920s to the 1960s, their families lived in a Brooklyn neighborhood that people called Little Caughnawaga, after an older spelling of Kahnawake.

### Where Great Migration families could live

The Great Migration was the move of about 6 million Black Americans out of the South between 1910 and 1970. In its first ten years, from 1910 to 1920, the Black population of Chicago rose 148 percent. Detroit's rose 611 percent, to about seven times its 1910 size. Philadelphia's rose about 59 percent, and New York's about 66 percent. In the 1920s New York's Black population more than doubled.

Black families who arrived could not live wherever they chose. White property owners kept them out of neighborhoods with restrictive covenants, sections written into the deed of a house, the legal paper that records who owns it. A covenant forbade the owner to sell or rent the house to a Black buyer, and sometimes to Jewish or Asian buyers as well. Each later owner of the house had to obey it too.

Through the 1920s, white owners in Chicago and across the country signed covenants into their deeds, and judges enforced the covenants by ordering owners to obey them. Because of the covenants and the judges, Black families could rent or buy homes in only a few districts. In Chicago that was a strip of the South Side called the Black Belt, which its own residents named Bronzeville. In New York it was Harlem.

**Kitchenettes.** The number of people who needed rooms in those districts kept rising. Landlords in the crowded districts split their flats, or apartments, into smaller units: one apartment became several one-room units, each rented separately. Each unit had a hotplate, a small electric burner for cooking, and the families shared one bathroom. Bronzeville had more than 80,000 of these kitchenettes. For each square foot of floor, families in them paid more rent than white families paid in white neighborhoods.

**The 1948 ruling.** In the case *Shelley v. Kraemer*, in 1948, the justices of the Supreme Court ruled that courts could no longer enforce the covenants. The ruling did not stop owners, builders and lenders from refusing Black buyers on their own, and many kept refusing for years.

### The maps with red lines

Federal officials set up an agency called the Home Owners' Loan Corporation in 1933, during the Depression, the hard times of the 1930s. Its staff worked with mortgages, loans to buy a house. They bought more than a million home loans from lenders and replaced each one with a new 15-year loan at 5 percent interest, easier terms than banks then gave. By 1936 they had swapped in new loans for about one in ten home loans outside farms.

The same staff made maps of 239 cities between 1935 and 1940, called "Residential Security" maps. They went through each city neighborhood by neighborhood and gave each one a grade for how safe they judged it was to lend money on the houses there.

**Four colors.** A was the best grade, shaded green on the map, followed by B in blue and C in yellow. D was the worst grade. The maps described D neighborhoods as "hazardous," and the staff shaded them red. From those red areas comes the word redlining: drawing a line around a neighborhood on a map and then refusing to lend money for houses inside it.

The appraisers, the staff members who judged each neighborhood, wrote notes that describe Black families moving in as "infiltration," a word for an enemy sneaking in. If Black families lived in a neighborhood, that all but guaranteed it a D.

**What the scholars dispute.** Scholars disagree about how much these particular maps changed who got loans. In a 2017 study, researchers at the Federal Reserve Bank of Chicago, a branch of the country's central bank, found lasting harm in the neighborhoods graded red.

Price Fishback, a historian of money and business, and three other scholars found in a 2021 study that the maps changed little about where the government lent. They also found that officials at the Federal Housing Administration, another federal agency, had already built their own way of redlining before these maps were drawn.

**What both sides agree on.** Federal Housing Administration officials insured home loans, promising to repay the lender if a buyer could not. They refused to insure loans in the neighborhoods where Black homeowners lived, and they backed loans mostly on new houses, which were sold almost only to white buyers.

Researchers at the National Community Reinvestment Coalition compared the old maps with present-day data in a study published in 2018. They found that about 74 percent of the neighborhoods graded red are low-to-moderate income today, meaning the families there earn well below the typical family in their area. About 64 percent are majority-minority, meaning most of the people living there are not white.

Researchers at the University of Richmond scanned the maps for their Mapping Inequality project and put them online, so anyone can look up what the appraisers wrote about a street.

**By 1940:** White owners and judges had kept Black families in a few crowded districts for twenty years, and federal staff had shaded nearly every neighborhood where Black families lived red on their lending maps.

### Oak Ridge: a secret city on taken farmland

Brigadier General Leslie Groves, an Army officer, had just taken charge of the Manhattan Project, the Army's secret program to build an atomic bomb. On September 19, 1942, he approved taking about 59,000 acres along the Clinch River in eastern Tennessee, a site Army officials called "Site X." Officers of the US Army Corps of Engineers took the land in October 1942.

**Who lived there.** About 1,000 families lived on that land. Some farmed it, and others lived in its small crossroads communities: Wheat, Elza, Scarboro (also spelled Scarborough) and Robertsville, with New Bethel and New Hope also named. Many of the families had farmed the same ground for generations. Accounts of how many people lived there differ: the Tennessee Encyclopedia states roughly 4,000 people, and other accounts state more than 3,000.

To take the land, the Corps officers filed a paper called a declaration of taking. Under it, the government could take the land right away, whether or not the owners wanted to sell, and settle the price later. Army officials paid an average of $46.86 an acre.

Army officials told the residents they had to leave, sometimes only by notices nailed to their front fence posts. The Tennessee Encyclopedia's account of the removals does not name the men who put up the notices. Families who had lived there for generations got a few weeks to go, and within a year all the families were gone.

Most families accepted the price the government set, and a few sued in court over what their land had been valued at. About an eighth of Roane County's land and about a seventh of Anderson County's land went into the site.

Workers built a city for the Army on that ground from 1942. The site's official name was the Clinton Engineer Works, and the city built there is Oak Ridge. The plans were for about 13,000 people, but by 1945 about 75,000 lived there, which for a short time made it the fifth-largest city in Tennessee.

**Alphabet houses.** Workers built about 3,000 houses from cemesto, ready-made panels of cement and asbestos, a mineral fiber. The houses came in a few standard types named by letters, such as the A house and the B house, so people called them alphabet houses. The flat-tops, flat-roofed houses, came in pieces made ahead of time by workers for the Tennessee Valley Authority, a federal agency, and crews put them together on the site.

The city had schools, buses, a 300-bed hospital and a symphony orchestra. Fences and gates surrounded it, and people had to show a badge to get in or out.

Oak Ridge did not appear on any published map. Los Alamos in New Mexico and Hanford and Richland in Washington were built for the same program. The plants at Oak Ridge separated the uranium, a heavy metal, for the atomic bomb that American forces dropped on Hiroshima. Most of the more than 70,000 people who lived and worked there did not know what they were making until the bombs fell. They had promised not to talk about their jobs.

### Colleen Black

> **Who:** A teenager from Nashville whose family moved to a city left off every published map, and who spent the rest of her life there.
>
> **When and where:** Oak Ridge, Tennessee, from 1944 until her death in March 2015.

**At nineteen, she hunted leaks in pipes without knowing what they carried.**

Colleen Black was born Colleen Rowan, one of more than ten children in a Nashville family. In 1944 the family moved to Oak Ridge for war work. They lived in a trailer camp. The ground was mud, with boardwalks laid across it, and people needed a pass to get through the gates.

At nineteen, Colleen worked as a leak detector at the K-25 plant. Her employer was Ford, Bacon & Davis, a company hired to do work at the plant. Her job was to find holes in the welded joints of pipes, the places where two pieces of metal had been melted together. She climbed over the pipes with a probe that sensed helium, looking for pinhole leaks.

Helium atoms are small enough to escape through a flaw too fine to see, so where the probe found helium, the weld was leaking. The plant had hundreds of miles of pipe. Even the gas's name was kept quiet: the workers were not supposed to say the word "helium." Years later she said, "I didn't know where those pipes were going, I didn't know what was going through them ... I just knew that I had to find the leak and mark it."

She learned what the plant had been separating only after American forces dropped an atomic bomb on Hiroshima, in Japan, on August 6, 1945. The bomb killed between 90,000 and 166,000 people in the city within two to four months. That count comes from the Radiation Effects Research Foundation, a research group that the United States and Japan run together and that studies the bomb's survivors. An American survey in 1946 recorded a lower count, 70,000 to 80,000. The exact number is not known.

She married a man called Blackie Black and stayed in Oak Ridge for the rest of her life. In 2005 she gave an oral history, a recorded interview about her life, to the Atomic Heritage Foundation's Voices of the Manhattan Project. The K-25 Virtual Museum includes her account, and she is featured in Denise Kiernan's 2013 book *The Girls of Atomic City*.

**If you remember one thing:** In these fifty years officials began zoning American cities, white owners and judges kept Black families out of most neighborhoods, and federal officials refused to back home loans where Black families lived.

- January 2, 1900: Chicago's river runs backward, carrying the city's sewage away from Lake Michigan, its drinking water.
- 1935 to 1940: federal staff grade the neighborhoods of 239 cities and shade the D neighborhoods red.
- October 1942: Army officials take the land of about 1,000 families in Tennessee to build Oak Ridge.

**Next:** After 1950, families moved out of the old city centers to new suburbs, and officials cleared whole neighborhoods for developers and ran highways through others.

## 1950 to 2000

**Era 9 of 10 · 1950 to 2000 · about 11 minutes**

St. Louis lost about 60 percent of its people between 1950 and 2000, and Detroit lost nearly half. Families moved out of the centers of older American cities to new suburbs at their edges. Cities in the hot South and West grew fast. Phoenix, Arizona, went from about 107,000 people in 1950 to more than 1.3 million in 2000.

At the edges of metropolitan areas, cities together with their suburbs, builders put up the same kind of neighborhood again and again: the subdivision, a tract of land divided into lots for single-family houses. White families bought those houses with mortgages that federal officials insured, promising to repay the lender if a buyer could not. Federal officials refused to insure the same kind of mortgage in the neighborhoods where Black families lived.

In the old centers, officials cleared whole neighborhoods and cut freeways through others. Under the Housing Act of 1949, city officials labeled neighborhoods blighted, run-down enough to tear down, and took the property by law. They had the buildings torn down, sold the cleared land to developers, and forced at least 300,000 families out of their homes.

Federal officials paid for new freeways with money from a highway law of 1956. Highway planners ran many of those freeways through poor neighborhoods, most of them home to Black families and other people of color.

### Urban renewal: clearing neighborhoods for developers

Members of Congress voted for the Housing Act of 1949. Under Title I, one section of that law, federal officials offered money to city governments for a program the law identifies as "urban redevelopment." People later called it urban renewal.

Once city officials had given an area the legal label blighted, they took the property in it by eminent domain, the government's power to take private property at a price that officials set. They had crews tear the buildings down. Then they sold the cleared land to private developers for much less than it had cost to take and clear, and federal money covered the gap. In 1954, in *Berman v. Parker*, the justices of the Supreme Court ruled that this was allowed.

Officials ran the program from 1949 to 1974, in more than 400 cities and on more than 1,200 projects, and crews tore down about 2,000 neighborhoods. Officials forced at least 300,000 families out of their homes, the lowest count the records support. Counting people instead of families, researchers estimate about 1.2 million.

**Who was forced out.** Black Americans were about 13 percent of the country's population in 1960, and they were at least 55 percent of the people forced out. These figures come from Brent Cebul's 2020 article in the Boston Review and from the Digital Scholarship Lab's "Renewing Inequality" project.

The writer James Baldwin said in a filmed interview in San Francisco in 1963 that urban renewal "means Negro removal," using what was then the usual word for Black Americans.

### Why freeways ran through Black neighborhoods

President Dwight D. Eisenhower signed the Federal-Aid Highway Act on June 29, 1956. It provided about $25 to $26 billion for a system of 41,000 miles of freeway.

Highway planners laid many of the routes where land was cheap and where the people who lived there were least able to organize against them. Those were mostly poor neighborhoods of Black families and other people of color. Builders defended taking land in Black neighborhoods by saying it was the cheapest. It was cheap partly because of redlining: for years, lenders and federal officials had refused to lend money for homes in those neighborhoods.

Rondo, a neighborhood in St. Paul, Minnesota, is one well-documented case. About 80 percent of St. Paul's Black residents lived there. Between 1956 and 1968, crews built Interstate 94 through the neighborhood.

Counts of what Rondo lost differ. Guides from the Minnesota Historical Society state about 600 families. ReConnect Rondo and reporting in Sahan Journal state about 700 homes and 300 businesses, and they record that Rondo lost 61 percent of its residents. One in eight of St. Paul's Black residents lost a home to the building of Interstate 94.

### Marvin Roger Anderson

> **Who:** A young man whose family lost its home and its apartment buildings to a freeway, and who has spent his later years working to build a land bridge over it.
>
> **When and where:** Rondo, St. Paul, Minnesota. His family learned of the freeway in 1958.

**Crews loaded his father's townhomes onto flatbed trucks and moved them away.**

Marvin Roger Anderson grew up in Rondo. His father built Rangh Court there, twelve two-story townhomes, in 1947 or 1948 (accounts give both years). To build them, his father got "the largest Federal Housing Authority mortgage backed loan ever given to nonwhite applicants in the state."

The family learned in 1958, the year Anderson finished Central High School, that the new Interstate 94 would run through their land. State officials condemned the buildings for the freeway, taking them by law, and called the homes "inferiorly constructed." Crews loaded the buildings onto flatbed trucks and moved them away. Four of them still stand, on other ground, on the University of Minnesota's St. Paul campus.

Anderson became the State Law Librarian of Minnesota, the librarian in charge of the state's law library. In 1983 he and Floyd Smaller founded Rondo Days to keep alive "the history, culture and memories of the Rondo that existed before the highway."

He now leads ReConnect Rondo. Its members propose to build a lid over the freeway, a land bridge of about 21 acres, with homes, businesses and community space on top. Early design studies for the land bridge list between 350 and 1,400 homes.

The *Voices of Rondo* oral-history collection records his account, and so do press interviews.

### Sprawl, and the people who left the old centers

Levittown, New York, opened in 1947, and by 1951 its builders had put up more than 17,000 houses there. The builders, Levitt and Sons, mass-produced the houses, building the same house over and over. They split the work into 27 steps and trained each crew to do one step. The houses stayed in place, and the crews moved from house to house. At the busiest time, about 30 houses went up in a day.

The first houses rented for $60 a month, and a renter could buy one for $7,500 after a year. From 1949, the builders sold ranch houses for $7,990. The lease for the first houses stated that they could not be "used or occupied by any person other than members of the Caucasian race," meaning white people. In 1960 every family in Levittown was still white.

Builders at the edges of other cities copied the pattern, and the spreading of cities outward in subdivisions like these came to be called sprawl.

The older cities lost people in the same fifty years. Detroit fell from about 1.85 million people in 1950 to about 950,000 in 2000, a loss of nearly half. St. Louis fell from about 857,000 to about 348,000, a loss of roughly 60 percent, and it kept shrinking after that, to about 300,000 by 2020.

Real estate agents and speculators, people who buy property to sell it again at a profit, pushed white families to sell and move out, a practice called blockbusting. They frightened white owners into selling cheaply by telling them Black families were moving in. Then they sold the same houses to Black families for much more, often "on contract."

**On contract.** Under a contract sale, if a buyer missed a single payment, the seller could put the family out, and the buyer lost everything already paid. In Chicago's North Lawndale neighborhood, about 3,000 buildings were sold on contract. North Lawndale went from 87 percent white in 1950 to 91 percent Black in 1960.

At the same time, federal officials insured mortgages on the new houses at the edge, under rules they set for which loans they would insure. Under those rules, they refused to insure mortgages in the neighborhoods where Black families lived.

### Jane Jacobs and Robert Moses

> **Who:** Robert Moses, who built roads, bridges and parks across New York for decades without ever winning an election, and Jane Jacobs, a writer who helped defeat three of the projects planned for the city.
>
> **When and where:** New York City, 1950s to 1968.
>
> **Movie:** *Citizen Jane: Battle for the City* (2016), a documentary directed by Matt Tyrnauer, 92 minutes.

**Police arrested Jane Jacobs at a public hearing in April 1968.**

Robert Moses held as many as twelve appointed posts at the same time, including parks commissioner and head of the Triborough Bridge and Tunnel Authority. Officials gave him every one of those posts, and he never won an election to any of them.

From those posts he directed the building of 13 bridges, 2 tunnels, 658 playgrounds, 17 state parks, and hundreds of miles of parkways and expressways, wide roads for fast traffic. To build the Cross-Bronx Expressway, Moses's crews cut a path through crowded blocks of the Bronx and forced thousands of families out of their homes.

Jane Jacobs lived in the West Village in New York and wrote about cities. She had never been trained in a school as a city planner. In 1961 she published *The Death and Life of Great American Cities*. In it she wrote that a busy street with both homes and shops stays safe because of "eyes on the street," the people who use it and watch it.

**Three fights.** Jacobs helped defeat three projects. In 1958 she and other opponents stopped a road planned through Washington Square Park. In 1961 and 1962 they beat city officials' attempt to label their own West Village a slum and clear it under urban renewal.

The third was the Lower Manhattan Expressway, a road ten lanes wide, raised above the street, planned across what is now SoHo and Little Italy. Jacobs led the Joint Committee to Stop the Lower Manhattan Expressway. Police arrested her at a public hearing in April 1968. The charges included inciting to riot, urging a crowd to violence, and they were later reduced.

Jacobs moved to Toronto in 1968. In 1969 Mayor John Lindsay declared the expressway "dead for all time," and city officials took it off the city's map that year.

Robert Caro's book about Moses, *The Power Broker*, came out in 1974 and won a Pulitzer Prize in 1975. It is the standard account of Moses's career, and in it Caro criticizes much of what Moses did. In 2007 the historians Hilary Ballon and Kenneth T. Jackson edited a book, *Robert Moses and the Modern City*. In it they give parts of his record, especially his parks and swimming pools, more credit than Caro gives them. The argument is not settled.

### Carl Stokes

> **Who:** The first Black mayor of a major American city, elected in the years when officials were clearing neighborhoods and building freeways through cities.
>
> **When and where:** Cleveland, Ohio. Elected on November 7, 1967, and mayor from January 1, 1968, to 1971.

**In 1969 oil and trash on Cleveland's river caught fire.**

Carl Stokes was the grandson of a man who had been enslaved. His mother was a widow, and she raised him in the Outhwaite public housing in Cleveland, apartments owned by a government and rented to families with low incomes.

Cleveland's voters elected Stokes mayor on November 7, 1967. He won about 50.5 percent of the vote and defeated Seth Taft. The 1960 census had counted 876,050 people in Cleveland, the eighth-largest city in the country.

Because Cleveland was one of the ten largest cities, Stokes counts as the first Black mayor of a major American city. On the same day, voters in Gary, Indiana, a much smaller city, elected Richard Hatcher their mayor. Stokes was re-elected in 1969 and served until 1971.

He had campaigned on housing, on bringing money into neighborhoods that had gone without it, and on the city's pollution. On June 22, 1969, an oil slick and piled-up trash on the Cuyahoga River caught fire under a railroad bridge, set off by sparks from a passing train. It burned for about twenty minutes and damaged two railroad bridges. It was at least the thirteenth fire on that river since 1868, and for a century people had used the working river as a sewer.

The next day Stokes held a press conference on the riverbank and demanded that state and federal officials act. In October 1972 the members of Congress passed the Clean Water Act over President Richard Nixon's veto, his refusal to sign it. Members of Congress can pass a law over a veto when two-thirds of each house vote for it. Stokes was one of the local leaders who had pushed for the Clean Water Act.

Black mayors followed Stokes in other big cities. By 1972 voters had elected Kenneth Gibson in Newark, James McGee in Dayton and Ted Berry in Cincinnati. In 1973 they elected Tom Bradley in Los Angeles, Maynard Jackson in Atlanta and Coleman Young in Detroit.

### Growth in the Sun Belt

While Detroit and St. Louis lost people, cities in the Sun Belt, the warm states of the South and the West, gained them. Phoenix, Arizona, had about 106,818 people in 1950 and 1,321,045 in 2000, and its metropolitan area went from about 323,000 people to about 3,014,000 in the same fifty years.

Phoenix grew in area too. It covered about 17 square miles in 1950, more than 475 square miles by the 2000s, and about 518 square miles now. City officials added that land by annexation, moving the city's legal boundary out to take in neighboring land.

Houston, Texas, went from 596,163 people in 1950 to 1,953,631 in 2000, and by 1990 it was the fourth-largest city in the country. Air conditioners cooled the air inside homes and offices, so people in Phoenix and Houston could live and work indoors through the hot summers. Land at the edge of these cities was cheap, and city officials kept annexing it. In the 1950s alone, Phoenix more than quadrupled in population.

## 2000 to Today

**Era 10 of 10 · 2000 to today · about 7 minutes**

Downtowns in most big American cities gained people in the 2000s, and in the 2020s many of their office towers began to empty. In the neighborhoods that buyers and lenders have returned to, rents and prices have risen, and some of the people who lived there can no longer afford to stay. Cities run hotter than the land around them, and in Miami Beach the sea now floods some streets at high tide.

### Downtown living and empty offices

Researchers at the Brookings Institution studied census counts for big American cities. Between 2000 and 2010, the downtowns grew faster than the areas around them. Of 53 downtowns they studied, 42 gained people. Young adults had already begun moving in. By 2000, people aged 25 to 34 made up nearly a quarter of downtown residents, up from 13 percent in 1970.

After the coronavirus pandemic of 2020, many office workers kept working from home for some or all of the week. Companies shrank the office space they rented, and as their leases, the contracts for renting the space, ran out, they gave up floors.

**A fifth of the space.** By 2024 about 20 percent of American office space stood empty, with figures for that year running from about 19.6 to 20.1 percent. That was the highest share since Moody's Analytics, a research company, began keeping track in 1979, and it came to more than 900 million square feet of empty floor. In downtown Manhattan the share was about 23 percent. Axios and ABC News reported these Moody's figures in January 2024.

Builders began turning empty office towers into apartments. In 2024 they had plans under way to make more than 55,300 apartments out of former office buildings, a record and more than four times the number in 2021. The Washington, D.C., area led, with 5,820 apartments planned. Researchers at the firm RentCafe counted those 2024 plans, as Time reported in January 2024.

Builders had finished, or were working on, 11.8 million square feet of former office space as apartments in 2025, the highest figure on record, according to industry reports from CBRE and Brevitas.

### Gentrification, and who can no longer afford to stay

In gentrification, buyers and lenders return to a neighborhood they had avoided for years. New owners fix up the houses, landlords and sellers raise rents and prices, and the people who lived there through the years without investment can no longer afford to stay.

Buyers and lenders have returned to close-in neighborhoods, the ones near downtown, that appraisers had marked red in the 1930s. The work of the National Community Reinvestment Coalition and the Mapping Inequality project documents that pattern.

Washington, D.C., is one documented case. Census figures record the city as 71 percent Black in 1970, when people called it Chocolate City. By 2011 the Black share of the population had fallen below half, to 49.2 percent, for the first time in about fifty years.

**U Street.** New money went mostly into Shaw, U Street and Columbia Heights, close-in neighborhoods that appraisers had redlined. Around U Street, builders put up more than 2,000 expensive condominiums (apartments that each owner buys) and apartments between 1997 and 2007. The neighborhood went from about 60 percent Black in 2000 to about 20 percent Black in 2010.

### Virginia Ali

> **Who:** A co-founder of Ben's Chili Bowl, a diner on U Street in Washington, D.C., who has helped run it since 1958 while the neighborhood around it changed.
>
> **When and where:** 1213 U Street NW, Washington, D.C., from August 22, 1958.

**Ben Ali wrote "Soul Brother" in soap on the diner's front window.**

Virginia Rollins came from Chance, Virginia. Her husband, Mahaboob Ali, who went by Ben, had come from Trinidad. On August 22, 1958, the two of them opened a diner at 1213 U Street NW with a bank loan of $5,000.

People then called U Street "Black Broadway." Hundreds of Black-owned businesses, churches and theaters lined it and the streets nearby. At the Lincoln Theatre and the Howard Theatre, Duke Ellington, Louis Armstrong and Billie Holiday performed.

Martin Luther King Jr. was shot and killed in Memphis, Tennessee, on April 4, 1968. James Earl Ray later pleaded guilty to his murder. For the next four days, riots broke out across Washington, and the corner of 14th and U was at the center of them. Thirteen people died, and about 1,200 homes and businesses were damaged.

**Open past curfew.** Stokely Carmichael led the Student Nonviolent Coordinating Committee, a civil rights group. He asked the Alis to keep the Bowl open past the curfew, an order to stay off the streets at night. According to the shop's own history, they did, and they fed police officers and activists. Ben wrote "Soul Brother" in soap on the front window. Like many other Black business owners, he wrote it to mark the diner as Black-owned and keep rioters from wrecking it, and the diner came through the riots untouched.

Drug dealing at 14th and U rose sharply in the mid-1970s. From 1986 to 1991, crews digging the Metro, Washington's subway, tore up U Street. From the 1990s, buyers and lenders returned, and the new condominiums went up around the Bowl.

Ben's is still open, and Virginia Ali, in her nineties, is still one of the people who run it. When the diner turned 65 in 2023, she told a reporter: "We really mean something to this community."

### Building for heat and water

Daytime air in a city is 1 to 6 degrees Fahrenheit warmer than in the areas around it, according to the Environmental Protection Agency (EPA). At night the air can be up to 22 degrees warmer, and a roof or road in the sun can be 50 to 90 degrees hotter than the air above it.

**Why cities run hot.** The EPA's guides state the reasons. Roads, sidewalks and buildings soak up much of the sun's heat and hold it. A city has fewer trees and plants than the country around it, so it gets less shade and less cooling from water drying off leaves. Tall buildings and narrow streets block cooling breezes. The EPA's list of ways to cool a city includes planting trees, growing plants on roofs, and building roofs and pavements that reflect sunlight.

In Miami Beach, Florida, streets flood on clear days with no storm, when the tide is at its highest. At those tides the ocean pushes the water of Biscayne Bay back up the storm drains, and bay water pours out of the drains into the lowest streets. Seawater also rises up through the soft, holey limestone under the city. In the fall of 2014, crews began raising streets, including West Avenue and Sunset Harbour, and putting in pumps to push the water back out.

Crews had put in twelve pump stations along the west side of South Beach by 2016 and 2017. The cost was first reported as about $400 million and later as about $600 million, as the project grew. During the King Tides, the name used in Miami Beach for the highest tides of the year, the raised and pumped blocks stayed mostly dry after the work.

### The tallest buildings now stand in other countries

The tallest building in the world has stood in Asia since 1998. Chicago's Sears Tower, finished in 1974, was the last building in the United States to be the tallest in the world. It lost that title because of a rule about how to measure height.

In April 1996, members of the Council on Tall Buildings and Urban Habitat ruled that a spire designed as part of a building counts toward its height. Under that rule, the Petronas Towers in Kuala Lumpur, Malaysia, measured 1,483 feet to the tops of their spires, and in 1998 they became the tallest buildings in the world. The Sears Tower's roof and its highest floor that people used were both higher than those of the Petronas Towers.

The Burj Khalifa in Dubai, finished in 2010, stands 2,717 feet (828 meters). That is more than 900 feet taller than the tallest building in the United States.

Workers set the last piece of the spire on One World Trade Center, in New York, on May 10, 2013. That November, members of the Council on Tall Buildings and Urban Habitat ruled that its spire counts toward its height. The building opened in 2014 at 1,776 feet, a height its builders chose for 1776, the year of the Declaration of Independence.

One World Trade Center is the tallest building in the Western Hemisphere, the half of the world that holds North and South America. Mohawk ironworkers worked on its steel, as Mohawk ironworkers had on the towers of the 1930s and on the bridges before them.

**The three questions, answered**

- Why do so many American cities have straight streets that cross in a grid? Town founders chose the grid on purpose, from Spain's town rules of 1573 to Penn's Philadelphia in 1682. The three men who laid a grid over Manhattan in 1811 wrote that square-cornered houses were "the most cheap to build and the most convenient to live in."
- How did people get clean water into crowded cities? City leaders paid for big waterworks after epidemics and fires: steam pumps in Philadelphia in 1801, the Croton Aqueduct in New York in 1842, and a canal that turned Chicago's river around in 1900.
- Who decided which families could live in which neighborhoods? White owners wrote rules called covenants into their deeds to bar Black buyers, and judges enforced them until 1948. Federal officials refused to back home loans where Black families lived, and after 1949 city officials cleared about 2,000 neighborhoods.

**What changed:** Builders went from carrying baskets of earth at Cahokia to raising steel towers, and owners, judges and officials wrote rules about who could live where.

**Whose land:** Every colonial town and boomtown in this chapter went up on a Native nation's land, from Seloy's Timucua town at St. Augustine to the Lenape homeland at Philadelphia and the Potawatomi lands at Chicago.

**Five dates to keep**

- About 1100: Cahokia reaches its peak.
- 1573: Spain's king orders a plaza and a grid for every new Spanish town.
- June 22, 1842: Croton water reaches New York City.
- July 25, 1916: New York adopts the first citywide zoning rules.
- 1948: The Supreme Court rules that courts can no longer enforce covenants.

**Not known:** No builder's, planner's or ruler's name survives from Cahokia.

**Where to go:** The Tenement Museum at 97 Orchard Street in New York, where staff have recreated the Moores' 1869 apartment.

**Next:** Chapter 7, Home and Family Life. It asks who lived in these houses and apartments, and how.
